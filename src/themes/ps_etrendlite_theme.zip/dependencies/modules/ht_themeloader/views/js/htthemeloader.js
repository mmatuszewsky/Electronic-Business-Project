$(window).on('load', function() {
    $('#loader-wrapper > #loader').fadeOut();
    $('#loader-wrapper').delay(350).fadeOut('slow');
});