-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: mariadb
-- Czas generowania: 11 Gru 2022, 21:58
-- Wersja serwera: 10.10.2-MariaDB-1:10.10.2+maria~ubu2204
-- Wersja PHP: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `prestashop`
--
CREATE DATABASE IF NOT EXISTS `prestashop` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `prestashop`;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_access`
--

CREATE TABLE `ps_access` (
  `id_profile` int(10) UNSIGNED NOT NULL,
  `id_authorization_role` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_access`
--

INSERT INTO `ps_access` (`id_profile`, `id_authorization_role`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20),
(1, 21),
(1, 22),
(1, 23),
(1, 24),
(1, 25),
(1, 26),
(1, 27),
(1, 28),
(1, 29),
(1, 30),
(1, 31),
(1, 32),
(1, 33),
(1, 34),
(1, 35),
(1, 36),
(1, 37),
(1, 38),
(1, 39),
(1, 40),
(1, 41),
(1, 42),
(1, 43),
(1, 44),
(1, 45),
(1, 46),
(1, 47),
(1, 48),
(1, 49),
(1, 50),
(1, 51),
(1, 52),
(1, 53),
(1, 54),
(1, 55),
(1, 56),
(1, 57),
(1, 58),
(1, 59),
(1, 60),
(1, 61),
(1, 62),
(1, 63),
(1, 64),
(1, 65),
(1, 66),
(1, 67),
(1, 68),
(1, 69),
(1, 70),
(1, 71),
(1, 72),
(1, 73),
(1, 74),
(1, 75),
(1, 76),
(1, 77),
(1, 78),
(1, 79),
(1, 80),
(1, 81),
(1, 82),
(1, 83),
(1, 84),
(1, 85),
(1, 86),
(1, 87),
(1, 88),
(1, 89),
(1, 90),
(1, 91),
(1, 92),
(1, 93),
(1, 94),
(1, 95),
(1, 96),
(1, 97),
(1, 98),
(1, 99),
(1, 100),
(1, 101),
(1, 102),
(1, 103),
(1, 104),
(1, 105),
(1, 106),
(1, 107),
(1, 108),
(1, 109),
(1, 110),
(1, 111),
(1, 112),
(1, 113),
(1, 114),
(1, 115),
(1, 116),
(1, 117),
(1, 118),
(1, 119),
(1, 120),
(1, 121),
(1, 122),
(1, 123),
(1, 124),
(1, 125),
(1, 126),
(1, 127),
(1, 128),
(1, 129),
(1, 130),
(1, 131),
(1, 132),
(1, 133),
(1, 134),
(1, 135),
(1, 136),
(1, 137),
(1, 138),
(1, 139),
(1, 140),
(1, 141),
(1, 142),
(1, 143),
(1, 144),
(1, 145),
(1, 146),
(1, 147),
(1, 148),
(1, 149),
(1, 150),
(1, 151),
(1, 152),
(1, 153),
(1, 154),
(1, 155),
(1, 156),
(1, 157),
(1, 158),
(1, 159),
(1, 160),
(1, 161),
(1, 162),
(1, 163),
(1, 164),
(1, 165),
(1, 166),
(1, 167),
(1, 168),
(1, 169),
(1, 170),
(1, 171),
(1, 172),
(1, 173),
(1, 174),
(1, 175),
(1, 176),
(1, 177),
(1, 178),
(1, 179),
(1, 180),
(1, 181),
(1, 182),
(1, 183),
(1, 184),
(1, 185),
(1, 186),
(1, 187),
(1, 188),
(1, 189),
(1, 190),
(1, 191),
(1, 192),
(1, 193),
(1, 194),
(1, 195),
(1, 196),
(1, 197),
(1, 198),
(1, 199),
(1, 200),
(1, 201),
(1, 202),
(1, 203),
(1, 204),
(1, 205),
(1, 206),
(1, 207),
(1, 208),
(1, 209),
(1, 210),
(1, 211),
(1, 212),
(1, 213),
(1, 214),
(1, 215),
(1, 216),
(1, 217),
(1, 218),
(1, 219),
(1, 220),
(1, 221),
(1, 222),
(1, 223),
(1, 224),
(1, 225),
(1, 226),
(1, 227),
(1, 228),
(1, 229),
(1, 230),
(1, 231),
(1, 232),
(1, 233),
(1, 234),
(1, 235),
(1, 236),
(1, 237),
(1, 238),
(1, 239),
(1, 240),
(1, 241),
(1, 242),
(1, 243),
(1, 244),
(1, 245),
(1, 246),
(1, 247),
(1, 248),
(1, 249),
(1, 250),
(1, 251),
(1, 252),
(1, 253),
(1, 254),
(1, 255),
(1, 256),
(1, 257),
(1, 258),
(1, 259),
(1, 260),
(1, 261),
(1, 262),
(1, 263),
(1, 264),
(1, 265),
(1, 266),
(1, 267),
(1, 268),
(1, 269),
(1, 270),
(1, 271),
(1, 272),
(1, 273),
(1, 274),
(1, 275),
(1, 276),
(1, 277),
(1, 278),
(1, 279),
(1, 280),
(1, 281),
(1, 282),
(1, 283),
(1, 284),
(1, 285),
(1, 286),
(1, 287),
(1, 288),
(1, 289),
(1, 290),
(1, 291),
(1, 292),
(1, 293),
(1, 294),
(1, 295),
(1, 296),
(1, 297),
(1, 298),
(1, 299),
(1, 300),
(1, 301),
(1, 302),
(1, 303),
(1, 304),
(1, 305),
(1, 306),
(1, 307),
(1, 308),
(1, 309),
(1, 310),
(1, 311),
(1, 312),
(1, 313),
(1, 314),
(1, 315),
(1, 316),
(1, 317),
(1, 318),
(1, 319),
(1, 320),
(1, 321),
(1, 322),
(1, 323),
(1, 324),
(1, 325),
(1, 326),
(1, 327),
(1, 328),
(1, 329),
(1, 330),
(1, 331),
(1, 332),
(1, 333),
(1, 334),
(1, 335),
(1, 336),
(1, 337),
(1, 338),
(1, 339),
(1, 340),
(1, 341),
(1, 342),
(1, 343),
(1, 344),
(1, 345),
(1, 346),
(1, 347),
(1, 348),
(1, 349),
(1, 350),
(1, 351),
(1, 352),
(1, 353),
(1, 354),
(1, 355),
(1, 356),
(1, 357),
(1, 358),
(1, 359),
(1, 360),
(1, 361),
(1, 362),
(1, 363),
(1, 364),
(1, 365),
(1, 366),
(1, 367),
(1, 368),
(1, 369),
(1, 370),
(1, 371),
(1, 372),
(1, 373),
(1, 374),
(1, 375),
(1, 376),
(1, 377),
(1, 378),
(1, 379),
(1, 380),
(1, 381),
(1, 382),
(1, 383),
(1, 384),
(1, 385),
(1, 386),
(1, 387),
(1, 388),
(1, 389),
(1, 390),
(1, 391),
(1, 392),
(1, 393),
(1, 394),
(1, 395),
(1, 396),
(1, 397),
(1, 398),
(1, 399),
(1, 400),
(1, 401),
(1, 402),
(1, 403),
(1, 404),
(1, 405),
(1, 406),
(1, 407),
(1, 408),
(1, 409),
(1, 410),
(1, 411),
(1, 412),
(1, 413),
(1, 414),
(1, 415),
(1, 416),
(1, 417),
(1, 418),
(1, 419),
(1, 420),
(1, 421),
(1, 422),
(1, 423),
(1, 424),
(1, 425),
(1, 426),
(1, 427),
(1, 428),
(1, 429),
(1, 430),
(1, 431),
(1, 432),
(1, 433),
(1, 434),
(1, 435),
(1, 436),
(1, 437),
(1, 438),
(1, 439),
(1, 440),
(1, 441),
(1, 442),
(1, 443),
(1, 444),
(1, 445),
(1, 446),
(1, 447),
(1, 448),
(1, 449),
(1, 450),
(1, 451),
(1, 452),
(1, 453),
(1, 454),
(1, 455),
(1, 456),
(1, 457),
(1, 458),
(1, 459),
(1, 460),
(1, 461),
(1, 462),
(1, 463),
(1, 464),
(1, 465),
(1, 466),
(1, 467),
(1, 468),
(1, 481),
(1, 482),
(1, 483),
(1, 484),
(1, 485),
(1, 486),
(1, 487),
(1, 488),
(1, 489),
(1, 490),
(1, 491),
(1, 492),
(1, 493),
(1, 494),
(1, 495),
(1, 496),
(1, 513),
(1, 514),
(1, 515),
(1, 516),
(1, 597),
(1, 598),
(1, 599),
(1, 600),
(1, 641),
(1, 642),
(1, 643),
(1, 644),
(1, 645),
(1, 646),
(1, 647),
(1, 648),
(1, 649),
(1, 650),
(1, 651),
(1, 652),
(1, 729),
(1, 730),
(1, 731),
(1, 732),
(1, 733),
(1, 734),
(1, 735),
(1, 736),
(1, 749),
(1, 750),
(1, 751),
(1, 752),
(1, 753),
(1, 754),
(1, 755),
(1, 756),
(1, 761),
(1, 762),
(1, 763),
(1, 764),
(1, 765),
(1, 766),
(1, 767),
(1, 768),
(1, 769),
(1, 770),
(1, 771),
(1, 772),
(1, 773),
(1, 774),
(1, 775),
(1, 776),
(1, 781),
(1, 782),
(1, 783),
(1, 784),
(1, 789),
(1, 790),
(1, 791),
(1, 792),
(1, 793),
(1, 794),
(1, 795),
(1, 796),
(1, 801),
(1, 802),
(1, 803),
(1, 804),
(1, 805),
(1, 806),
(1, 807),
(1, 808),
(1, 809),
(1, 810),
(1, 811),
(1, 812),
(1, 813),
(1, 814),
(1, 815),
(1, 816),
(1, 817),
(1, 818),
(1, 819),
(1, 820),
(1, 825),
(1, 826),
(1, 827),
(1, 828),
(1, 829),
(1, 830),
(1, 831),
(1, 832),
(1, 841),
(1, 842),
(1, 843),
(1, 844),
(2, 9),
(2, 10),
(2, 11),
(2, 12),
(2, 33),
(2, 34),
(2, 35),
(2, 36),
(2, 45),
(2, 46),
(2, 47),
(2, 48),
(2, 49),
(2, 50),
(2, 51),
(2, 52),
(2, 85),
(2, 86),
(2, 87),
(2, 88),
(2, 129),
(2, 130),
(2, 131),
(2, 132),
(2, 189),
(2, 190),
(2, 191),
(2, 192),
(2, 209),
(2, 210),
(2, 211),
(2, 212),
(2, 217),
(2, 218),
(2, 219),
(2, 220),
(2, 229),
(2, 230),
(2, 231),
(2, 232),
(2, 242),
(2, 243),
(2, 249),
(2, 250),
(2, 251),
(2, 252),
(2, 269),
(2, 270),
(2, 271),
(2, 272),
(2, 273),
(2, 274),
(2, 275),
(2, 276),
(2, 309),
(2, 310),
(2, 311),
(2, 312),
(2, 325),
(2, 326),
(2, 327),
(2, 328),
(2, 337),
(2, 338),
(2, 339),
(2, 340),
(2, 349),
(2, 350),
(2, 351),
(2, 352),
(2, 373),
(2, 374),
(2, 375),
(2, 376),
(2, 389),
(2, 390),
(2, 391),
(2, 392),
(2, 397),
(2, 398),
(2, 399),
(2, 400),
(2, 401),
(2, 402),
(2, 403),
(2, 404),
(2, 425),
(2, 426),
(2, 427),
(2, 428),
(2, 433),
(2, 434),
(2, 435),
(2, 436),
(2, 449),
(2, 450),
(2, 451),
(2, 452),
(2, 453),
(2, 454),
(2, 455),
(2, 456),
(3, 45),
(3, 46),
(3, 47),
(3, 48),
(3, 49),
(3, 50),
(3, 51),
(3, 52),
(3, 125),
(3, 126),
(3, 127),
(3, 128),
(3, 141),
(3, 142),
(3, 143),
(3, 144),
(3, 225),
(3, 226),
(3, 227),
(3, 228),
(3, 265),
(3, 266),
(3, 267),
(3, 268),
(3, 309),
(3, 310),
(3, 311),
(3, 312),
(3, 329),
(3, 330),
(3, 331),
(3, 332),
(3, 429),
(3, 430),
(3, 431),
(3, 432),
(3, 445),
(3, 446),
(3, 447),
(3, 448),
(3, 449),
(3, 450),
(3, 451),
(3, 452),
(3, 453),
(3, 454),
(3, 455),
(3, 456),
(3, 457),
(3, 458),
(3, 459),
(3, 460),
(4, 0),
(4, 9),
(4, 10),
(4, 11),
(4, 12),
(4, 17),
(4, 18),
(4, 19),
(4, 20),
(4, 41),
(4, 42),
(4, 43),
(4, 44),
(4, 45),
(4, 46),
(4, 47),
(4, 48),
(4, 49),
(4, 50),
(4, 51),
(4, 52),
(4, 129),
(4, 130),
(4, 131),
(4, 132),
(4, 154),
(4, 181),
(4, 182),
(4, 183),
(4, 184),
(4, 189),
(4, 190),
(4, 191),
(4, 192),
(4, 209),
(4, 210),
(4, 211),
(4, 212),
(4, 217),
(4, 218),
(4, 219),
(4, 220),
(4, 229),
(4, 230),
(4, 231),
(4, 232),
(4, 237),
(4, 238),
(4, 239),
(4, 240),
(4, 242),
(4, 243),
(4, 249),
(4, 250),
(4, 251),
(4, 252),
(4, 266),
(4, 309),
(4, 310),
(4, 311),
(4, 312),
(4, 317),
(4, 318),
(4, 319),
(4, 320),
(4, 330),
(4, 349),
(4, 350),
(4, 351),
(4, 352),
(4, 401),
(4, 402),
(4, 403),
(4, 404),
(4, 437),
(4, 438),
(4, 439),
(4, 440),
(4, 445),
(4, 446),
(4, 447),
(4, 448),
(4, 453),
(4, 454),
(4, 455),
(4, 456),
(4, 457),
(4, 458),
(4, 459),
(4, 460);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_accessory`
--

CREATE TABLE `ps_accessory` (
  `id_product_1` int(10) UNSIGNED NOT NULL,
  `id_product_2` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_address`
--

CREATE TABLE `ps_address` (
  `id_address` int(10) UNSIGNED NOT NULL,
  `id_country` int(10) UNSIGNED NOT NULL,
  `id_state` int(10) UNSIGNED DEFAULT NULL,
  `id_customer` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_manufacturer` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_supplier` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_warehouse` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `alias` varchar(32) NOT NULL,
  `company` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `address1` varchar(128) NOT NULL,
  `address2` varchar(128) DEFAULT NULL,
  `postcode` varchar(12) DEFAULT NULL,
  `city` varchar(64) NOT NULL,
  `other` text DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `phone_mobile` varchar(32) DEFAULT NULL,
  `vat_number` varchar(32) DEFAULT NULL,
  `dni` varchar(16) DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_address`
--

INSERT INTO `ps_address` (`id_address`, `id_country`, `id_state`, `id_customer`, `id_manufacturer`, `id_supplier`, `id_warehouse`, `alias`, `company`, `lastname`, `firstname`, `address1`, `address2`, `postcode`, `city`, `other`, `phone`, `phone_mobile`, `vat_number`, `dni`, `date_add`, `date_upd`, `active`, `deleted`) VALUES
(1, 14, 0, 1, 0, 0, 0, 'Anonymous', 'Anonymous', 'Anonymous', 'Anonymous', 'Anonymous', '', '00000', 'Anonymous', '', '0000000000', '0000000000', '0000', '0000', '2022-12-08 17:57:25', '2022-12-08 17:57:25', 1, 0),
(2, 8, 0, 2, 0, 0, 0, 'Mon adresse', 'My Company', 'DOE', 'John', '16, Main street', '2nd floor', '75002', 'Paris ', '', '0102030405', '', '', '', '2022-12-08 17:57:52', '2022-12-08 17:57:52', 1, 0),
(3, 21, 35, 0, 0, 1, 0, 'supplier', 'Fashion', 'supplier', 'supplier', '767 Fifth Ave.', '', '10153', 'New York', '', '(212) 336-1440', '', '', '', '2022-12-08 17:57:52', '2022-12-08 17:57:52', 1, 0),
(4, 21, 35, 0, 1, 0, 0, 'manufacturer', 'Fashion', 'manufacturer', 'manufacturer', '767 Fifth Ave.', '', '10154', 'New York', '', '(212) 336-1666', '', '', '', '2022-12-08 17:57:52', '2022-12-08 17:57:52', 1, 0),
(5, 21, 12, 2, 0, 0, 0, 'My address', 'My Company', 'DOE', 'John', '16, Main street', '2nd floor', '33133', 'Miami', '', '0102030405', '', '', '', '2022-12-08 17:57:52', '2022-12-08 17:57:52', 1, 0),
(6, 8, 0, 0, 0, 2, 0, 'accessories_supplier', 'Accessories and Co', 'accessories', 'accessories', '42 Avenue Maréchal Soult', '', '64990', 'Bayonne', '', '0102030405', '', '', '', '2022-12-08 17:57:52', '2022-12-08 17:57:52', 1, 0),
(7, 14, 0, 3, 0, 0, 0, 'Mój adres', '', 'Zieliński', 'Michał', 'sasa 123', '', '10-123', 'aaaaaa', '', '', '', '', '', '2022-12-11 22:12:53', '2022-12-11 22:12:53', 1, 0),
(8, 14, 0, 4, 0, 0, 0, 'Mój adres', '', 'a', 'Michał', 'sasa 123', '', '10-123', 'aaaaaa', '', '', '', '', '', '2022-12-11 22:16:04', '2022-12-11 22:16:04', 1, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_address_format`
--

CREATE TABLE `ps_address_format` (
  `id_country` int(10) UNSIGNED NOT NULL,
  `format` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_address_format`
--

INSERT INTO `ps_address_format` (`id_country`, `format`) VALUES
(1, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(2, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(3, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(4, 'firstname lastname\ncompany\naddress1\naddress2\ncity State:name postcode\nCountry:name\nphone'),
(5, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(6, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(7, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(8, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(9, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(10, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nState:name\nCountry:name\nphone'),
(11, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nState:name\nCountry:name\nphone'),
(12, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(13, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(14, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(15, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(16, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(17, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\ncity\npostcode\nCountry:name\nphone'),
(18, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(19, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(20, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(21, 'firstname lastname\ncompany\naddress1 address2\ncity, State:name postcode\nCountry:name\nphone'),
(22, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(23, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(24, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\ncity State:iso_code postcode\nCountry:name\nphone'),
(25, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(26, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(27, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(28, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(29, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(30, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(31, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(32, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(33, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(34, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(35, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(36, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(37, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(38, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(39, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(40, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(41, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(42, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(43, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(44, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nState:name\nCountry:name\nphone'),
(45, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(46, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(47, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(48, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(49, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(50, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(51, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(52, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(53, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(54, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(55, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(56, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(57, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(58, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(59, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(60, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(61, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(62, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(63, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(64, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(65, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(66, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(67, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(68, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(69, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(70, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(71, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(72, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(73, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(74, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(75, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(76, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(77, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(78, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(79, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(80, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(81, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(82, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(83, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(84, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(85, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(86, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(87, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(88, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(89, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(90, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(91, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(92, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(93, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(94, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(95, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(96, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(97, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(98, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(99, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(100, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(101, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(102, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(103, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(104, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(105, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(106, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(107, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(108, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(109, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\ncity\npostcode\nState:name\nCountry:name\nphone'),
(110, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nState:name\nCountry:name\nphone'),
(111, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(112, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(113, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(114, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(115, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(116, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(117, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(118, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(119, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(120, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(121, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(122, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(123, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(124, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(125, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(126, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(127, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(128, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(129, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(130, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(131, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(132, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(133, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(134, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(135, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(136, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(137, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(138, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(139, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(140, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(141, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(142, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(143, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(144, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nState:name\nCountry:name\nphone'),
(145, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(146, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(147, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(148, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(149, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(150, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(151, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(152, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(153, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(154, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(155, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(156, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(157, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(158, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(159, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(160, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(161, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(162, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(163, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(164, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(165, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(166, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(167, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(168, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(169, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(170, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(171, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(172, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(173, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(174, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(175, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(176, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(177, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(178, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(179, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(180, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(181, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(182, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(183, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(184, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(185, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(186, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(187, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(188, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(189, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(190, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(191, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(192, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(193, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(194, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(195, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(196, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(197, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(198, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(199, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(200, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(201, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(202, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(203, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(204, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(205, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(206, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(207, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(208, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(209, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(210, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(211, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(212, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(213, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(214, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(215, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(216, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(217, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(218, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(219, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(220, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(221, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(222, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(223, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(224, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(225, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(226, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(227, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(228, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(229, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(230, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(231, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(232, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(233, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(234, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(235, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(236, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(237, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(238, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(239, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(240, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone'),
(241, 'firstname lastname\ncompany\nvat_number\naddress1\naddress2\npostcode city\nCountry:name\nphone');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_admin_filter`
--

CREATE TABLE `ps_admin_filter` (
  `id` int(11) NOT NULL,
  `employee` int(11) NOT NULL,
  `shop` int(11) NOT NULL,
  `controller` varchar(60) NOT NULL,
  `action` varchar(100) NOT NULL,
  `filter` longtext NOT NULL,
  `filter_id` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_admin_filter`
--

INSERT INTO `ps_admin_filter` (`id`, `employee`, `shop`, `controller`, `action`, `filter`, `filter_id`) VALUES
(1, 1, 1, '', '', '{\"orderBy\":\"position\",\"sortOrder\":\"asc\",\"limit\":50,\"filters\":{\"id_cms_category_parent\":1}}', 'cms_page_category'),
(2, 1, 1, '', '', '{\"orderBy\":\"position\",\"sortOrder\":\"asc\",\"limit\":50,\"filters\":{\"id_cms_category_parent\":1}}', 'cms_page'),
(3, 1, 1, '', '', '{\"limit\":50,\"orderBy\":\"id_lang\",\"sortOrder\":\"ASC\",\"filters\":[]}', 'language'),
(4, 1, 1, '', '', '{\"limit\":50,\"orderBy\":\"id_currency\",\"sortOrder\":\"asc\",\"filters\":[]}', 'currency'),
(5, 1, 1, 'email', 'index', '{\"limit\":50,\"orderBy\":\"id_mail\",\"sortOrder\":\"desc\",\"filters\":[]}', ''),
(6, 1, 1, 'ProductController', 'catalogAction', '{\"filter_category\":\"\",\"filter_column_id_product\":\"\",\"filter_column_name\":\"\",\"filter_column_reference\":\"\",\"filter_column_name_category\":\"\",\"filter_column_price\":\"\",\"filter_column_sav_quantity\":\"\",\"filter_column_active\":\"\",\"last_offset\":\"0\",\"last_limit\":\"20\",\"last_orderBy\":\"id_product\",\"last_sortOrder\":\"desc\"}', ''),
(7, 1, 1, 'contacts', 'index', '{\"limit\":10,\"orderBy\":\"id_contact\",\"sortOrder\":\"asc\",\"filters\":[]}', ''),
(8, 1, 1, '', '', '{\"limit\":50,\"orderBy\":\"id_webservice_account\",\"sortOrder\":\"asc\",\"filters\":[]}', 'webservice_key'),
(9, 1, 1, '', '', '{\"limit\":10,\"orderBy\":\"id_request_sql\",\"sortOrder\":\"desc\",\"filters\":[]}', 'sql_request'),
(10, 1, 1, '', '', '{\"orderBy\":\"position\",\"sortOrder\":\"asc\",\"limit\":50,\"filters\":{\"id_category_parent\":2}}', 'category');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_advice`
--

CREATE TABLE `ps_advice` (
  `id_advice` int(11) NOT NULL,
  `id_ps_advice` int(11) NOT NULL,
  `id_tab` int(11) NOT NULL,
  `ids_tab` text DEFAULT NULL,
  `validated` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `hide` tinyint(1) NOT NULL DEFAULT 0,
  `location` enum('after','before') NOT NULL,
  `selector` varchar(255) DEFAULT NULL,
  `start_day` int(11) NOT NULL DEFAULT 0,
  `stop_day` int(11) NOT NULL DEFAULT 0,
  `weight` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_advice_lang`
--

CREATE TABLE `ps_advice_lang` (
  `id_advice` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `html` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_alias`
--

CREATE TABLE `ps_alias` (
  `id_alias` int(10) UNSIGNED NOT NULL,
  `alias` varchar(191) NOT NULL,
  `search` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_alias`
--

INSERT INTO `ps_alias` (`id_alias`, `alias`, `search`, `active`) VALUES
(1, 'bloose', 'blouse', 1),
(2, 'blues', 'blouse', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_attachment`
--

CREATE TABLE `ps_attachment` (
  `id_attachment` int(10) UNSIGNED NOT NULL,
  `file` varchar(40) NOT NULL,
  `file_name` varchar(128) NOT NULL,
  `file_size` bigint(10) UNSIGNED NOT NULL DEFAULT 0,
  `mime` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_attachment_lang`
--

CREATE TABLE `ps_attachment_lang` (
  `id_attachment` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_attribute`
--

CREATE TABLE `ps_attribute` (
  `id_attribute` int(11) NOT NULL,
  `id_attribute_group` int(11) NOT NULL,
  `color` varchar(32) NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_attribute`
--

INSERT INTO `ps_attribute` (`id_attribute`, `id_attribute_group`, `color`, `position`) VALUES
(46, 15, '', 0),
(47, 15, '', 1),
(48, 16, '', 0),
(49, 16, '', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_attribute_group`
--

CREATE TABLE `ps_attribute_group` (
  `id_attribute_group` int(11) NOT NULL,
  `is_color_group` tinyint(1) NOT NULL,
  `group_type` varchar(255) NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_attribute_group`
--

INSERT INTO `ps_attribute_group` (`id_attribute_group`, `is_color_group`, `group_type`, `position`) VALUES
(15, 0, 'select', 0),
(16, 0, 'select', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_attribute_group_lang`
--

CREATE TABLE `ps_attribute_group_lang` (
  `id_attribute_group` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `public_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_attribute_group_lang`
--

INSERT INTO `ps_attribute_group_lang` (`id_attribute_group`, `id_lang`, `name`, `public_name`) VALUES
(15, 1, 'Materiały', 'Materiały'),
(16, 1, 'Certyfikaty', 'Certyfikaty');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_attribute_group_shop`
--

CREATE TABLE `ps_attribute_group_shop` (
  `id_attribute_group` int(11) NOT NULL,
  `id_shop` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_attribute_group_shop`
--

INSERT INTO `ps_attribute_group_shop` (`id_attribute_group`, `id_shop`) VALUES
(15, 1),
(16, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_attribute_impact`
--

CREATE TABLE `ps_attribute_impact` (
  `id_attribute_impact` int(10) UNSIGNED NOT NULL,
  `id_product` int(11) UNSIGNED NOT NULL,
  `id_attribute` int(11) UNSIGNED NOT NULL,
  `weight` decimal(20,6) NOT NULL,
  `price` decimal(20,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_attribute_lang`
--

CREATE TABLE `ps_attribute_lang` (
  `id_attribute` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_attribute_lang`
--

INSERT INTO `ps_attribute_lang` (`id_attribute`, `id_lang`, `name`) VALUES
(46, 1, 'Z materiałami'),
(47, 1, 'Bez materiałów'),
(48, 1, 'Z certyfikatem'),
(49, 1, 'Bez certyfikatu');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_attribute_shop`
--

CREATE TABLE `ps_attribute_shop` (
  `id_attribute` int(11) NOT NULL,
  `id_shop` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_attribute_shop`
--

INSERT INTO `ps_attribute_shop` (`id_attribute`, `id_shop`) VALUES
(46, 1),
(47, 1),
(48, 1),
(49, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_authorization_role`
--

CREATE TABLE `ps_authorization_role` (
  `id_authorization_role` int(10) UNSIGNED NOT NULL,
  `slug` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_authorization_role`
--

INSERT INTO `ps_authorization_role` (`id_authorization_role`, `slug`) VALUES
(837, 'ROLE_MOD_MODULE_BLOCKREASSURANCE_CREATE'),
(840, 'ROLE_MOD_MODULE_BLOCKREASSURANCE_DELETE'),
(838, 'ROLE_MOD_MODULE_BLOCKREASSURANCE_READ'),
(839, 'ROLE_MOD_MODULE_BLOCKREASSURANCE_UPDATE'),
(497, 'ROLE_MOD_MODULE_BLOCKWISHLIST_CREATE'),
(500, 'ROLE_MOD_MODULE_BLOCKWISHLIST_DELETE'),
(498, 'ROLE_MOD_MODULE_BLOCKWISHLIST_READ'),
(499, 'ROLE_MOD_MODULE_BLOCKWISHLIST_UPDATE'),
(501, 'ROLE_MOD_MODULE_CONTACTFORM_CREATE'),
(504, 'ROLE_MOD_MODULE_CONTACTFORM_DELETE'),
(502, 'ROLE_MOD_MODULE_CONTACTFORM_READ'),
(503, 'ROLE_MOD_MODULE_CONTACTFORM_UPDATE'),
(505, 'ROLE_MOD_MODULE_DASHACTIVITY_CREATE'),
(508, 'ROLE_MOD_MODULE_DASHACTIVITY_DELETE'),
(506, 'ROLE_MOD_MODULE_DASHACTIVITY_READ'),
(507, 'ROLE_MOD_MODULE_DASHACTIVITY_UPDATE'),
(517, 'ROLE_MOD_MODULE_DASHGOALS_CREATE'),
(520, 'ROLE_MOD_MODULE_DASHGOALS_DELETE'),
(518, 'ROLE_MOD_MODULE_DASHGOALS_READ'),
(519, 'ROLE_MOD_MODULE_DASHGOALS_UPDATE'),
(521, 'ROLE_MOD_MODULE_DASHPRODUCTS_CREATE'),
(524, 'ROLE_MOD_MODULE_DASHPRODUCTS_DELETE'),
(522, 'ROLE_MOD_MODULE_DASHPRODUCTS_READ'),
(523, 'ROLE_MOD_MODULE_DASHPRODUCTS_UPDATE'),
(509, 'ROLE_MOD_MODULE_DASHTRENDS_CREATE'),
(512, 'ROLE_MOD_MODULE_DASHTRENDS_DELETE'),
(510, 'ROLE_MOD_MODULE_DASHTRENDS_READ'),
(511, 'ROLE_MOD_MODULE_DASHTRENDS_UPDATE'),
(737, 'ROLE_MOD_MODULE_GAMIFICATION_CREATE'),
(740, 'ROLE_MOD_MODULE_GAMIFICATION_DELETE'),
(738, 'ROLE_MOD_MODULE_GAMIFICATION_READ'),
(739, 'ROLE_MOD_MODULE_GAMIFICATION_UPDATE'),
(525, 'ROLE_MOD_MODULE_GRAPHNVD3_CREATE'),
(528, 'ROLE_MOD_MODULE_GRAPHNVD3_DELETE'),
(526, 'ROLE_MOD_MODULE_GRAPHNVD3_READ'),
(527, 'ROLE_MOD_MODULE_GRAPHNVD3_UPDATE'),
(529, 'ROLE_MOD_MODULE_GRIDHTML_CREATE'),
(532, 'ROLE_MOD_MODULE_GRIDHTML_DELETE'),
(530, 'ROLE_MOD_MODULE_GRIDHTML_READ'),
(531, 'ROLE_MOD_MODULE_GRIDHTML_UPDATE'),
(533, 'ROLE_MOD_MODULE_GSITEMAP_CREATE'),
(536, 'ROLE_MOD_MODULE_GSITEMAP_DELETE'),
(534, 'ROLE_MOD_MODULE_GSITEMAP_READ'),
(535, 'ROLE_MOD_MODULE_GSITEMAP_UPDATE'),
(537, 'ROLE_MOD_MODULE_PAGESNOTFOUND_CREATE'),
(540, 'ROLE_MOD_MODULE_PAGESNOTFOUND_DELETE'),
(538, 'ROLE_MOD_MODULE_PAGESNOTFOUND_READ'),
(539, 'ROLE_MOD_MODULE_PAGESNOTFOUND_UPDATE'),
(541, 'ROLE_MOD_MODULE_PRODUCTCOMMENTS_CREATE'),
(544, 'ROLE_MOD_MODULE_PRODUCTCOMMENTS_DELETE'),
(542, 'ROLE_MOD_MODULE_PRODUCTCOMMENTS_READ'),
(543, 'ROLE_MOD_MODULE_PRODUCTCOMMENTS_UPDATE'),
(741, 'ROLE_MOD_MODULE_PSADDONSCONNECT_CREATE'),
(744, 'ROLE_MOD_MODULE_PSADDONSCONNECT_DELETE'),
(742, 'ROLE_MOD_MODULE_PSADDONSCONNECT_READ'),
(743, 'ROLE_MOD_MODULE_PSADDONSCONNECT_UPDATE'),
(745, 'ROLE_MOD_MODULE_PSGDPR_CREATE'),
(748, 'ROLE_MOD_MODULE_PSGDPR_DELETE'),
(746, 'ROLE_MOD_MODULE_PSGDPR_READ'),
(747, 'ROLE_MOD_MODULE_PSGDPR_UPDATE'),
(833, 'ROLE_MOD_MODULE_PSXMARKETINGWITHGOOGLE_CREATE'),
(836, 'ROLE_MOD_MODULE_PSXMARKETINGWITHGOOGLE_DELETE'),
(834, 'ROLE_MOD_MODULE_PSXMARKETINGWITHGOOGLE_READ'),
(835, 'ROLE_MOD_MODULE_PSXMARKETINGWITHGOOGLE_UPDATE'),
(545, 'ROLE_MOD_MODULE_PS_BANNER_CREATE'),
(548, 'ROLE_MOD_MODULE_PS_BANNER_DELETE'),
(546, 'ROLE_MOD_MODULE_PS_BANNER_READ'),
(547, 'ROLE_MOD_MODULE_PS_BANNER_UPDATE'),
(777, 'ROLE_MOD_MODULE_PS_BUYBUTTONLITE_CREATE'),
(780, 'ROLE_MOD_MODULE_PS_BUYBUTTONLITE_DELETE'),
(778, 'ROLE_MOD_MODULE_PS_BUYBUTTONLITE_READ'),
(779, 'ROLE_MOD_MODULE_PS_BUYBUTTONLITE_UPDATE'),
(853, 'ROLE_MOD_MODULE_PS_CASHONDELIVERY_CREATE'),
(856, 'ROLE_MOD_MODULE_PS_CASHONDELIVERY_DELETE'),
(854, 'ROLE_MOD_MODULE_PS_CASHONDELIVERY_READ'),
(855, 'ROLE_MOD_MODULE_PS_CASHONDELIVERY_UPDATE'),
(549, 'ROLE_MOD_MODULE_PS_CATEGORYTREE_CREATE'),
(552, 'ROLE_MOD_MODULE_PS_CATEGORYTREE_DELETE'),
(550, 'ROLE_MOD_MODULE_PS_CATEGORYTREE_READ'),
(551, 'ROLE_MOD_MODULE_PS_CATEGORYTREE_UPDATE'),
(785, 'ROLE_MOD_MODULE_PS_CHECKOUT_CREATE'),
(788, 'ROLE_MOD_MODULE_PS_CHECKOUT_DELETE'),
(786, 'ROLE_MOD_MODULE_PS_CHECKOUT_READ'),
(787, 'ROLE_MOD_MODULE_PS_CHECKOUT_UPDATE'),
(557, 'ROLE_MOD_MODULE_PS_CONTACTINFO_CREATE'),
(560, 'ROLE_MOD_MODULE_PS_CONTACTINFO_DELETE'),
(558, 'ROLE_MOD_MODULE_PS_CONTACTINFO_READ'),
(559, 'ROLE_MOD_MODULE_PS_CONTACTINFO_UPDATE'),
(561, 'ROLE_MOD_MODULE_PS_CROSSSELLING_CREATE'),
(564, 'ROLE_MOD_MODULE_PS_CROSSSELLING_DELETE'),
(562, 'ROLE_MOD_MODULE_PS_CROSSSELLING_READ'),
(563, 'ROLE_MOD_MODULE_PS_CROSSSELLING_UPDATE'),
(565, 'ROLE_MOD_MODULE_PS_CURRENCYSELECTOR_CREATE'),
(568, 'ROLE_MOD_MODULE_PS_CURRENCYSELECTOR_DELETE'),
(566, 'ROLE_MOD_MODULE_PS_CURRENCYSELECTOR_READ'),
(567, 'ROLE_MOD_MODULE_PS_CURRENCYSELECTOR_UPDATE'),
(569, 'ROLE_MOD_MODULE_PS_CUSTOMERACCOUNTLINKS_CREATE'),
(572, 'ROLE_MOD_MODULE_PS_CUSTOMERACCOUNTLINKS_DELETE'),
(570, 'ROLE_MOD_MODULE_PS_CUSTOMERACCOUNTLINKS_READ'),
(571, 'ROLE_MOD_MODULE_PS_CUSTOMERACCOUNTLINKS_UPDATE'),
(573, 'ROLE_MOD_MODULE_PS_CUSTOMERSIGNIN_CREATE'),
(576, 'ROLE_MOD_MODULE_PS_CUSTOMERSIGNIN_DELETE'),
(574, 'ROLE_MOD_MODULE_PS_CUSTOMERSIGNIN_READ'),
(575, 'ROLE_MOD_MODULE_PS_CUSTOMERSIGNIN_UPDATE'),
(577, 'ROLE_MOD_MODULE_PS_CUSTOMTEXT_CREATE'),
(580, 'ROLE_MOD_MODULE_PS_CUSTOMTEXT_DELETE'),
(578, 'ROLE_MOD_MODULE_PS_CUSTOMTEXT_READ'),
(579, 'ROLE_MOD_MODULE_PS_CUSTOMTEXT_UPDATE'),
(581, 'ROLE_MOD_MODULE_PS_DATAPRIVACY_CREATE'),
(584, 'ROLE_MOD_MODULE_PS_DATAPRIVACY_DELETE'),
(582, 'ROLE_MOD_MODULE_PS_DATAPRIVACY_READ'),
(583, 'ROLE_MOD_MODULE_PS_DATAPRIVACY_UPDATE'),
(585, 'ROLE_MOD_MODULE_PS_EMAILSUBSCRIPTION_CREATE'),
(588, 'ROLE_MOD_MODULE_PS_EMAILSUBSCRIPTION_DELETE'),
(586, 'ROLE_MOD_MODULE_PS_EMAILSUBSCRIPTION_READ'),
(587, 'ROLE_MOD_MODULE_PS_EMAILSUBSCRIPTION_UPDATE'),
(821, 'ROLE_MOD_MODULE_PS_FACEBOOK_CREATE'),
(824, 'ROLE_MOD_MODULE_PS_FACEBOOK_DELETE'),
(822, 'ROLE_MOD_MODULE_PS_FACEBOOK_READ'),
(823, 'ROLE_MOD_MODULE_PS_FACEBOOK_UPDATE'),
(845, 'ROLE_MOD_MODULE_PS_FACETEDSEARCH_CREATE'),
(848, 'ROLE_MOD_MODULE_PS_FACETEDSEARCH_DELETE'),
(846, 'ROLE_MOD_MODULE_PS_FACETEDSEARCH_READ'),
(847, 'ROLE_MOD_MODULE_PS_FACETEDSEARCH_UPDATE'),
(593, 'ROLE_MOD_MODULE_PS_FAVICONNOTIFICATIONBO_CREATE'),
(596, 'ROLE_MOD_MODULE_PS_FAVICONNOTIFICATIONBO_DELETE'),
(594, 'ROLE_MOD_MODULE_PS_FAVICONNOTIFICATIONBO_READ'),
(595, 'ROLE_MOD_MODULE_PS_FAVICONNOTIFICATIONBO_UPDATE'),
(601, 'ROLE_MOD_MODULE_PS_FEATUREDPRODUCTS_CREATE'),
(604, 'ROLE_MOD_MODULE_PS_FEATUREDPRODUCTS_DELETE'),
(602, 'ROLE_MOD_MODULE_PS_FEATUREDPRODUCTS_READ'),
(603, 'ROLE_MOD_MODULE_PS_FEATUREDPRODUCTS_UPDATE'),
(849, 'ROLE_MOD_MODULE_PS_GOOGLEANALYTICS_CREATE'),
(852, 'ROLE_MOD_MODULE_PS_GOOGLEANALYTICS_DELETE'),
(850, 'ROLE_MOD_MODULE_PS_GOOGLEANALYTICS_READ'),
(851, 'ROLE_MOD_MODULE_PS_GOOGLEANALYTICS_UPDATE'),
(605, 'ROLE_MOD_MODULE_PS_IMAGESLIDER_CREATE'),
(608, 'ROLE_MOD_MODULE_PS_IMAGESLIDER_DELETE'),
(606, 'ROLE_MOD_MODULE_PS_IMAGESLIDER_READ'),
(607, 'ROLE_MOD_MODULE_PS_IMAGESLIDER_UPDATE'),
(609, 'ROLE_MOD_MODULE_PS_LANGUAGESELECTOR_CREATE'),
(612, 'ROLE_MOD_MODULE_PS_LANGUAGESELECTOR_DELETE'),
(610, 'ROLE_MOD_MODULE_PS_LANGUAGESELECTOR_READ'),
(611, 'ROLE_MOD_MODULE_PS_LANGUAGESELECTOR_UPDATE'),
(613, 'ROLE_MOD_MODULE_PS_LINKLIST_CREATE'),
(616, 'ROLE_MOD_MODULE_PS_LINKLIST_DELETE'),
(614, 'ROLE_MOD_MODULE_PS_LINKLIST_READ'),
(615, 'ROLE_MOD_MODULE_PS_LINKLIST_UPDATE'),
(617, 'ROLE_MOD_MODULE_PS_MAINMENU_CREATE'),
(620, 'ROLE_MOD_MODULE_PS_MAINMENU_DELETE'),
(618, 'ROLE_MOD_MODULE_PS_MAINMENU_READ'),
(619, 'ROLE_MOD_MODULE_PS_MAINMENU_UPDATE'),
(757, 'ROLE_MOD_MODULE_PS_MBO_CREATE'),
(760, 'ROLE_MOD_MODULE_PS_MBO_DELETE'),
(758, 'ROLE_MOD_MODULE_PS_MBO_READ'),
(759, 'ROLE_MOD_MODULE_PS_MBO_UPDATE'),
(797, 'ROLE_MOD_MODULE_PS_METRICS_CREATE'),
(800, 'ROLE_MOD_MODULE_PS_METRICS_DELETE'),
(798, 'ROLE_MOD_MODULE_PS_METRICS_READ'),
(799, 'ROLE_MOD_MODULE_PS_METRICS_UPDATE'),
(621, 'ROLE_MOD_MODULE_PS_SEARCHBAR_CREATE'),
(624, 'ROLE_MOD_MODULE_PS_SEARCHBAR_DELETE'),
(622, 'ROLE_MOD_MODULE_PS_SEARCHBAR_READ'),
(623, 'ROLE_MOD_MODULE_PS_SEARCHBAR_UPDATE'),
(625, 'ROLE_MOD_MODULE_PS_SHAREBUTTONS_CREATE'),
(628, 'ROLE_MOD_MODULE_PS_SHAREBUTTONS_DELETE'),
(626, 'ROLE_MOD_MODULE_PS_SHAREBUTTONS_READ'),
(627, 'ROLE_MOD_MODULE_PS_SHAREBUTTONS_UPDATE'),
(629, 'ROLE_MOD_MODULE_PS_SHOPPINGCART_CREATE'),
(632, 'ROLE_MOD_MODULE_PS_SHOPPINGCART_DELETE'),
(630, 'ROLE_MOD_MODULE_PS_SHOPPINGCART_READ'),
(631, 'ROLE_MOD_MODULE_PS_SHOPPINGCART_UPDATE'),
(633, 'ROLE_MOD_MODULE_PS_SOCIALFOLLOW_CREATE'),
(636, 'ROLE_MOD_MODULE_PS_SOCIALFOLLOW_DELETE'),
(634, 'ROLE_MOD_MODULE_PS_SOCIALFOLLOW_READ'),
(635, 'ROLE_MOD_MODULE_PS_SOCIALFOLLOW_UPDATE'),
(637, 'ROLE_MOD_MODULE_PS_THEMECUSTO_CREATE'),
(640, 'ROLE_MOD_MODULE_PS_THEMECUSTO_DELETE'),
(638, 'ROLE_MOD_MODULE_PS_THEMECUSTO_READ'),
(639, 'ROLE_MOD_MODULE_PS_THEMECUSTO_UPDATE'),
(653, 'ROLE_MOD_MODULE_PS_WIREPAYMENT_CREATE'),
(656, 'ROLE_MOD_MODULE_PS_WIREPAYMENT_DELETE'),
(654, 'ROLE_MOD_MODULE_PS_WIREPAYMENT_READ'),
(655, 'ROLE_MOD_MODULE_PS_WIREPAYMENT_UPDATE'),
(657, 'ROLE_MOD_MODULE_STATSBESTCATEGORIES_CREATE'),
(660, 'ROLE_MOD_MODULE_STATSBESTCATEGORIES_DELETE'),
(658, 'ROLE_MOD_MODULE_STATSBESTCATEGORIES_READ'),
(659, 'ROLE_MOD_MODULE_STATSBESTCATEGORIES_UPDATE'),
(661, 'ROLE_MOD_MODULE_STATSBESTCUSTOMERS_CREATE'),
(664, 'ROLE_MOD_MODULE_STATSBESTCUSTOMERS_DELETE'),
(662, 'ROLE_MOD_MODULE_STATSBESTCUSTOMERS_READ'),
(663, 'ROLE_MOD_MODULE_STATSBESTCUSTOMERS_UPDATE'),
(665, 'ROLE_MOD_MODULE_STATSBESTPRODUCTS_CREATE'),
(668, 'ROLE_MOD_MODULE_STATSBESTPRODUCTS_DELETE'),
(666, 'ROLE_MOD_MODULE_STATSBESTPRODUCTS_READ'),
(667, 'ROLE_MOD_MODULE_STATSBESTPRODUCTS_UPDATE'),
(669, 'ROLE_MOD_MODULE_STATSBESTSUPPLIERS_CREATE'),
(672, 'ROLE_MOD_MODULE_STATSBESTSUPPLIERS_DELETE'),
(670, 'ROLE_MOD_MODULE_STATSBESTSUPPLIERS_READ'),
(671, 'ROLE_MOD_MODULE_STATSBESTSUPPLIERS_UPDATE'),
(673, 'ROLE_MOD_MODULE_STATSBESTVOUCHERS_CREATE'),
(676, 'ROLE_MOD_MODULE_STATSBESTVOUCHERS_DELETE'),
(674, 'ROLE_MOD_MODULE_STATSBESTVOUCHERS_READ'),
(675, 'ROLE_MOD_MODULE_STATSBESTVOUCHERS_UPDATE'),
(677, 'ROLE_MOD_MODULE_STATSCARRIER_CREATE'),
(680, 'ROLE_MOD_MODULE_STATSCARRIER_DELETE'),
(678, 'ROLE_MOD_MODULE_STATSCARRIER_READ'),
(679, 'ROLE_MOD_MODULE_STATSCARRIER_UPDATE'),
(681, 'ROLE_MOD_MODULE_STATSCATALOG_CREATE'),
(684, 'ROLE_MOD_MODULE_STATSCATALOG_DELETE'),
(682, 'ROLE_MOD_MODULE_STATSCATALOG_READ'),
(683, 'ROLE_MOD_MODULE_STATSCATALOG_UPDATE'),
(685, 'ROLE_MOD_MODULE_STATSCHECKUP_CREATE'),
(688, 'ROLE_MOD_MODULE_STATSCHECKUP_DELETE'),
(686, 'ROLE_MOD_MODULE_STATSCHECKUP_READ'),
(687, 'ROLE_MOD_MODULE_STATSCHECKUP_UPDATE'),
(689, 'ROLE_MOD_MODULE_STATSDATA_CREATE'),
(692, 'ROLE_MOD_MODULE_STATSDATA_DELETE'),
(690, 'ROLE_MOD_MODULE_STATSDATA_READ'),
(691, 'ROLE_MOD_MODULE_STATSDATA_UPDATE'),
(693, 'ROLE_MOD_MODULE_STATSFORECAST_CREATE'),
(696, 'ROLE_MOD_MODULE_STATSFORECAST_DELETE'),
(694, 'ROLE_MOD_MODULE_STATSFORECAST_READ'),
(695, 'ROLE_MOD_MODULE_STATSFORECAST_UPDATE'),
(697, 'ROLE_MOD_MODULE_STATSNEWSLETTER_CREATE'),
(700, 'ROLE_MOD_MODULE_STATSNEWSLETTER_DELETE'),
(698, 'ROLE_MOD_MODULE_STATSNEWSLETTER_READ'),
(699, 'ROLE_MOD_MODULE_STATSNEWSLETTER_UPDATE'),
(701, 'ROLE_MOD_MODULE_STATSPERSONALINFOS_CREATE'),
(704, 'ROLE_MOD_MODULE_STATSPERSONALINFOS_DELETE'),
(702, 'ROLE_MOD_MODULE_STATSPERSONALINFOS_READ'),
(703, 'ROLE_MOD_MODULE_STATSPERSONALINFOS_UPDATE'),
(705, 'ROLE_MOD_MODULE_STATSPRODUCT_CREATE'),
(708, 'ROLE_MOD_MODULE_STATSPRODUCT_DELETE'),
(706, 'ROLE_MOD_MODULE_STATSPRODUCT_READ'),
(707, 'ROLE_MOD_MODULE_STATSPRODUCT_UPDATE'),
(709, 'ROLE_MOD_MODULE_STATSREGISTRATIONS_CREATE'),
(712, 'ROLE_MOD_MODULE_STATSREGISTRATIONS_DELETE'),
(710, 'ROLE_MOD_MODULE_STATSREGISTRATIONS_READ'),
(711, 'ROLE_MOD_MODULE_STATSREGISTRATIONS_UPDATE'),
(713, 'ROLE_MOD_MODULE_STATSSALES_CREATE'),
(716, 'ROLE_MOD_MODULE_STATSSALES_DELETE'),
(714, 'ROLE_MOD_MODULE_STATSSALES_READ'),
(715, 'ROLE_MOD_MODULE_STATSSALES_UPDATE'),
(717, 'ROLE_MOD_MODULE_STATSSEARCH_CREATE'),
(720, 'ROLE_MOD_MODULE_STATSSEARCH_DELETE'),
(718, 'ROLE_MOD_MODULE_STATSSEARCH_READ'),
(719, 'ROLE_MOD_MODULE_STATSSEARCH_UPDATE'),
(721, 'ROLE_MOD_MODULE_STATSSTOCK_CREATE'),
(724, 'ROLE_MOD_MODULE_STATSSTOCK_DELETE'),
(722, 'ROLE_MOD_MODULE_STATSSTOCK_READ'),
(723, 'ROLE_MOD_MODULE_STATSSTOCK_UPDATE'),
(725, 'ROLE_MOD_MODULE_WELCOME_CREATE'),
(728, 'ROLE_MOD_MODULE_WELCOME_DELETE'),
(726, 'ROLE_MOD_MODULE_WELCOME_READ'),
(727, 'ROLE_MOD_MODULE_WELCOME_UPDATE'),
(1, 'ROLE_MOD_TAB_ADMINACCESS_CREATE'),
(4, 'ROLE_MOD_TAB_ADMINACCESS_DELETE'),
(2, 'ROLE_MOD_TAB_ADMINACCESS_READ'),
(3, 'ROLE_MOD_TAB_ADMINACCESS_UPDATE'),
(5, 'ROLE_MOD_TAB_ADMINADDONSCATALOG_CREATE'),
(8, 'ROLE_MOD_TAB_ADMINADDONSCATALOG_DELETE'),
(6, 'ROLE_MOD_TAB_ADMINADDONSCATALOG_READ'),
(7, 'ROLE_MOD_TAB_ADMINADDONSCATALOG_UPDATE'),
(9, 'ROLE_MOD_TAB_ADMINADDRESSES_CREATE'),
(12, 'ROLE_MOD_TAB_ADMINADDRESSES_DELETE'),
(10, 'ROLE_MOD_TAB_ADMINADDRESSES_READ'),
(11, 'ROLE_MOD_TAB_ADMINADDRESSES_UPDATE'),
(13, 'ROLE_MOD_TAB_ADMINADMINPREFERENCES_CREATE'),
(16, 'ROLE_MOD_TAB_ADMINADMINPREFERENCES_DELETE'),
(14, 'ROLE_MOD_TAB_ADMINADMINPREFERENCES_READ'),
(15, 'ROLE_MOD_TAB_ADMINADMINPREFERENCES_UPDATE'),
(17, 'ROLE_MOD_TAB_ADMINADVANCEDPARAMETERS_CREATE'),
(20, 'ROLE_MOD_TAB_ADMINADVANCEDPARAMETERS_DELETE'),
(18, 'ROLE_MOD_TAB_ADMINADVANCEDPARAMETERS_READ'),
(19, 'ROLE_MOD_TAB_ADMINADVANCEDPARAMETERS_UPDATE'),
(789, 'ROLE_MOD_TAB_ADMINAJAXPRESTASHOPCHECKOUT_CREATE'),
(792, 'ROLE_MOD_TAB_ADMINAJAXPRESTASHOPCHECKOUT_DELETE'),
(790, 'ROLE_MOD_TAB_ADMINAJAXPRESTASHOPCHECKOUT_READ'),
(791, 'ROLE_MOD_TAB_ADMINAJAXPRESTASHOPCHECKOUT_UPDATE'),
(817, 'ROLE_MOD_TAB_ADMINAJAXPSFACEBOOK_CREATE'),
(820, 'ROLE_MOD_TAB_ADMINAJAXPSFACEBOOK_DELETE'),
(818, 'ROLE_MOD_TAB_ADMINAJAXPSFACEBOOK_READ'),
(819, 'ROLE_MOD_TAB_ADMINAJAXPSFACEBOOK_UPDATE'),
(749, 'ROLE_MOD_TAB_ADMINAJAXPSGDPR_CREATE'),
(752, 'ROLE_MOD_TAB_ADMINAJAXPSGDPR_DELETE'),
(750, 'ROLE_MOD_TAB_ADMINAJAXPSGDPR_READ'),
(751, 'ROLE_MOD_TAB_ADMINAJAXPSGDPR_UPDATE'),
(829, 'ROLE_MOD_TAB_ADMINAJAXPSXMKTGWITHGOOGLE_CREATE'),
(832, 'ROLE_MOD_TAB_ADMINAJAXPSXMKTGWITHGOOGLE_DELETE'),
(830, 'ROLE_MOD_TAB_ADMINAJAXPSXMKTGWITHGOOGLE_READ'),
(831, 'ROLE_MOD_TAB_ADMINAJAXPSXMKTGWITHGOOGLE_UPDATE'),
(781, 'ROLE_MOD_TAB_ADMINAJAXPS_BUYBUTTONLITE_CREATE'),
(784, 'ROLE_MOD_TAB_ADMINAJAXPS_BUYBUTTONLITE_DELETE'),
(782, 'ROLE_MOD_TAB_ADMINAJAXPS_BUYBUTTONLITE_READ'),
(783, 'ROLE_MOD_TAB_ADMINAJAXPS_BUYBUTTONLITE_UPDATE'),
(21, 'ROLE_MOD_TAB_ADMINATTACHMENTS_CREATE'),
(24, 'ROLE_MOD_TAB_ADMINATTACHMENTS_DELETE'),
(22, 'ROLE_MOD_TAB_ADMINATTACHMENTS_READ'),
(23, 'ROLE_MOD_TAB_ADMINATTACHMENTS_UPDATE'),
(25, 'ROLE_MOD_TAB_ADMINATTRIBUTESGROUPS_CREATE'),
(28, 'ROLE_MOD_TAB_ADMINATTRIBUTESGROUPS_DELETE'),
(26, 'ROLE_MOD_TAB_ADMINATTRIBUTESGROUPS_READ'),
(27, 'ROLE_MOD_TAB_ADMINATTRIBUTESGROUPS_UPDATE'),
(29, 'ROLE_MOD_TAB_ADMINBACKUP_CREATE'),
(32, 'ROLE_MOD_TAB_ADMINBACKUP_DELETE'),
(30, 'ROLE_MOD_TAB_ADMINBACKUP_READ'),
(31, 'ROLE_MOD_TAB_ADMINBACKUP_UPDATE'),
(841, 'ROLE_MOD_TAB_ADMINBLOCKLISTING_CREATE'),
(844, 'ROLE_MOD_TAB_ADMINBLOCKLISTING_DELETE'),
(842, 'ROLE_MOD_TAB_ADMINBLOCKLISTING_READ'),
(843, 'ROLE_MOD_TAB_ADMINBLOCKLISTING_UPDATE'),
(33, 'ROLE_MOD_TAB_ADMINCARRIERS_CREATE'),
(36, 'ROLE_MOD_TAB_ADMINCARRIERS_DELETE'),
(34, 'ROLE_MOD_TAB_ADMINCARRIERS_READ'),
(35, 'ROLE_MOD_TAB_ADMINCARRIERS_UPDATE'),
(37, 'ROLE_MOD_TAB_ADMINCARTRULES_CREATE'),
(40, 'ROLE_MOD_TAB_ADMINCARTRULES_DELETE'),
(38, 'ROLE_MOD_TAB_ADMINCARTRULES_READ'),
(39, 'ROLE_MOD_TAB_ADMINCARTRULES_UPDATE'),
(41, 'ROLE_MOD_TAB_ADMINCARTS_CREATE'),
(44, 'ROLE_MOD_TAB_ADMINCARTS_DELETE'),
(42, 'ROLE_MOD_TAB_ADMINCARTS_READ'),
(43, 'ROLE_MOD_TAB_ADMINCARTS_UPDATE'),
(45, 'ROLE_MOD_TAB_ADMINCATALOG_CREATE'),
(48, 'ROLE_MOD_TAB_ADMINCATALOG_DELETE'),
(46, 'ROLE_MOD_TAB_ADMINCATALOG_READ'),
(47, 'ROLE_MOD_TAB_ADMINCATALOG_UPDATE'),
(49, 'ROLE_MOD_TAB_ADMINCATEGORIES_CREATE'),
(52, 'ROLE_MOD_TAB_ADMINCATEGORIES_DELETE'),
(50, 'ROLE_MOD_TAB_ADMINCATEGORIES_READ'),
(51, 'ROLE_MOD_TAB_ADMINCATEGORIES_UPDATE'),
(53, 'ROLE_MOD_TAB_ADMINCMSCONTENT_CREATE'),
(56, 'ROLE_MOD_TAB_ADMINCMSCONTENT_DELETE'),
(54, 'ROLE_MOD_TAB_ADMINCMSCONTENT_READ'),
(55, 'ROLE_MOD_TAB_ADMINCMSCONTENT_UPDATE'),
(597, 'ROLE_MOD_TAB_ADMINCONFIGUREFAVICONBO_CREATE'),
(600, 'ROLE_MOD_TAB_ADMINCONFIGUREFAVICONBO_DELETE'),
(598, 'ROLE_MOD_TAB_ADMINCONFIGUREFAVICONBO_READ'),
(599, 'ROLE_MOD_TAB_ADMINCONFIGUREFAVICONBO_UPDATE'),
(57, 'ROLE_MOD_TAB_ADMINCONTACTS_CREATE'),
(60, 'ROLE_MOD_TAB_ADMINCONTACTS_DELETE'),
(58, 'ROLE_MOD_TAB_ADMINCONTACTS_READ'),
(59, 'ROLE_MOD_TAB_ADMINCONTACTS_UPDATE'),
(61, 'ROLE_MOD_TAB_ADMINCOUNTRIES_CREATE'),
(64, 'ROLE_MOD_TAB_ADMINCOUNTRIES_DELETE'),
(62, 'ROLE_MOD_TAB_ADMINCOUNTRIES_READ'),
(63, 'ROLE_MOD_TAB_ADMINCOUNTRIES_UPDATE'),
(65, 'ROLE_MOD_TAB_ADMINCURRENCIES_CREATE'),
(68, 'ROLE_MOD_TAB_ADMINCURRENCIES_DELETE'),
(66, 'ROLE_MOD_TAB_ADMINCURRENCIES_READ'),
(67, 'ROLE_MOD_TAB_ADMINCURRENCIES_UPDATE'),
(69, 'ROLE_MOD_TAB_ADMINCUSTOMERPREFERENCES_CREATE'),
(72, 'ROLE_MOD_TAB_ADMINCUSTOMERPREFERENCES_DELETE'),
(70, 'ROLE_MOD_TAB_ADMINCUSTOMERPREFERENCES_READ'),
(71, 'ROLE_MOD_TAB_ADMINCUSTOMERPREFERENCES_UPDATE'),
(73, 'ROLE_MOD_TAB_ADMINCUSTOMERS_CREATE'),
(76, 'ROLE_MOD_TAB_ADMINCUSTOMERS_DELETE'),
(74, 'ROLE_MOD_TAB_ADMINCUSTOMERS_READ'),
(75, 'ROLE_MOD_TAB_ADMINCUSTOMERS_UPDATE'),
(77, 'ROLE_MOD_TAB_ADMINCUSTOMERTHREADS_CREATE'),
(80, 'ROLE_MOD_TAB_ADMINCUSTOMERTHREADS_DELETE'),
(78, 'ROLE_MOD_TAB_ADMINCUSTOMERTHREADS_READ'),
(79, 'ROLE_MOD_TAB_ADMINCUSTOMERTHREADS_UPDATE'),
(81, 'ROLE_MOD_TAB_ADMINDASHBOARD_CREATE'),
(84, 'ROLE_MOD_TAB_ADMINDASHBOARD_DELETE'),
(82, 'ROLE_MOD_TAB_ADMINDASHBOARD_READ'),
(83, 'ROLE_MOD_TAB_ADMINDASHBOARD_UPDATE'),
(513, 'ROLE_MOD_TAB_ADMINDASHGOALS_CREATE'),
(516, 'ROLE_MOD_TAB_ADMINDASHGOALS_DELETE'),
(514, 'ROLE_MOD_TAB_ADMINDASHGOALS_READ'),
(515, 'ROLE_MOD_TAB_ADMINDASHGOALS_UPDATE'),
(85, 'ROLE_MOD_TAB_ADMINDELIVERYSLIP_CREATE'),
(88, 'ROLE_MOD_TAB_ADMINDELIVERYSLIP_DELETE'),
(86, 'ROLE_MOD_TAB_ADMINDELIVERYSLIP_READ'),
(87, 'ROLE_MOD_TAB_ADMINDELIVERYSLIP_UPDATE'),
(753, 'ROLE_MOD_TAB_ADMINDOWNLOADINVOICESPSGDPR_CREATE'),
(756, 'ROLE_MOD_TAB_ADMINDOWNLOADINVOICESPSGDPR_DELETE'),
(754, 'ROLE_MOD_TAB_ADMINDOWNLOADINVOICESPSGDPR_READ'),
(755, 'ROLE_MOD_TAB_ADMINDOWNLOADINVOICESPSGDPR_UPDATE'),
(89, 'ROLE_MOD_TAB_ADMINEMAILS_CREATE'),
(92, 'ROLE_MOD_TAB_ADMINEMAILS_DELETE'),
(90, 'ROLE_MOD_TAB_ADMINEMAILS_READ'),
(91, 'ROLE_MOD_TAB_ADMINEMAILS_UPDATE'),
(93, 'ROLE_MOD_TAB_ADMINEMPLOYEES_CREATE'),
(96, 'ROLE_MOD_TAB_ADMINEMPLOYEES_DELETE'),
(94, 'ROLE_MOD_TAB_ADMINEMPLOYEES_READ'),
(95, 'ROLE_MOD_TAB_ADMINEMPLOYEES_UPDATE'),
(481, 'ROLE_MOD_TAB_ADMINFEATUREFLAG_CREATE'),
(484, 'ROLE_MOD_TAB_ADMINFEATUREFLAG_DELETE'),
(482, 'ROLE_MOD_TAB_ADMINFEATUREFLAG_READ'),
(483, 'ROLE_MOD_TAB_ADMINFEATUREFLAG_UPDATE'),
(97, 'ROLE_MOD_TAB_ADMINFEATURES_CREATE'),
(100, 'ROLE_MOD_TAB_ADMINFEATURES_DELETE'),
(98, 'ROLE_MOD_TAB_ADMINFEATURES_READ'),
(99, 'ROLE_MOD_TAB_ADMINFEATURES_UPDATE'),
(733, 'ROLE_MOD_TAB_ADMINGAMIFICATION_CREATE'),
(736, 'ROLE_MOD_TAB_ADMINGAMIFICATION_DELETE'),
(734, 'ROLE_MOD_TAB_ADMINGAMIFICATION_READ'),
(735, 'ROLE_MOD_TAB_ADMINGAMIFICATION_UPDATE'),
(101, 'ROLE_MOD_TAB_ADMINGENDERS_CREATE'),
(104, 'ROLE_MOD_TAB_ADMINGENDERS_DELETE'),
(102, 'ROLE_MOD_TAB_ADMINGENDERS_READ'),
(103, 'ROLE_MOD_TAB_ADMINGENDERS_UPDATE'),
(105, 'ROLE_MOD_TAB_ADMINGEOLOCATION_CREATE'),
(108, 'ROLE_MOD_TAB_ADMINGEOLOCATION_DELETE'),
(106, 'ROLE_MOD_TAB_ADMINGEOLOCATION_READ'),
(107, 'ROLE_MOD_TAB_ADMINGEOLOCATION_UPDATE'),
(109, 'ROLE_MOD_TAB_ADMINGROUPS_CREATE'),
(112, 'ROLE_MOD_TAB_ADMINGROUPS_DELETE'),
(110, 'ROLE_MOD_TAB_ADMINGROUPS_READ'),
(111, 'ROLE_MOD_TAB_ADMINGROUPS_UPDATE'),
(113, 'ROLE_MOD_TAB_ADMINIMAGES_CREATE'),
(116, 'ROLE_MOD_TAB_ADMINIMAGES_DELETE'),
(114, 'ROLE_MOD_TAB_ADMINIMAGES_READ'),
(115, 'ROLE_MOD_TAB_ADMINIMAGES_UPDATE'),
(117, 'ROLE_MOD_TAB_ADMINIMPORT_CREATE'),
(120, 'ROLE_MOD_TAB_ADMINIMPORT_DELETE'),
(118, 'ROLE_MOD_TAB_ADMINIMPORT_READ'),
(119, 'ROLE_MOD_TAB_ADMINIMPORT_UPDATE'),
(121, 'ROLE_MOD_TAB_ADMININFORMATION_CREATE'),
(124, 'ROLE_MOD_TAB_ADMININFORMATION_DELETE'),
(122, 'ROLE_MOD_TAB_ADMININFORMATION_READ'),
(123, 'ROLE_MOD_TAB_ADMININFORMATION_UPDATE'),
(125, 'ROLE_MOD_TAB_ADMININTERNATIONAL_CREATE'),
(128, 'ROLE_MOD_TAB_ADMININTERNATIONAL_DELETE'),
(126, 'ROLE_MOD_TAB_ADMININTERNATIONAL_READ'),
(127, 'ROLE_MOD_TAB_ADMININTERNATIONAL_UPDATE'),
(129, 'ROLE_MOD_TAB_ADMININVOICES_CREATE'),
(132, 'ROLE_MOD_TAB_ADMININVOICES_DELETE'),
(130, 'ROLE_MOD_TAB_ADMININVOICES_READ'),
(131, 'ROLE_MOD_TAB_ADMININVOICES_UPDATE'),
(133, 'ROLE_MOD_TAB_ADMINLANGUAGES_CREATE'),
(136, 'ROLE_MOD_TAB_ADMINLANGUAGES_DELETE'),
(134, 'ROLE_MOD_TAB_ADMINLANGUAGES_READ'),
(135, 'ROLE_MOD_TAB_ADMINLANGUAGES_UPDATE'),
(137, 'ROLE_MOD_TAB_ADMINLINKWIDGET_CREATE'),
(140, 'ROLE_MOD_TAB_ADMINLINKWIDGET_DELETE'),
(138, 'ROLE_MOD_TAB_ADMINLINKWIDGET_READ'),
(139, 'ROLE_MOD_TAB_ADMINLINKWIDGET_UPDATE'),
(141, 'ROLE_MOD_TAB_ADMINLOCALIZATION_CREATE'),
(144, 'ROLE_MOD_TAB_ADMINLOCALIZATION_DELETE'),
(142, 'ROLE_MOD_TAB_ADMINLOCALIZATION_READ'),
(143, 'ROLE_MOD_TAB_ADMINLOCALIZATION_UPDATE'),
(145, 'ROLE_MOD_TAB_ADMINLOGS_CREATE'),
(148, 'ROLE_MOD_TAB_ADMINLOGS_DELETE'),
(146, 'ROLE_MOD_TAB_ADMINLOGS_READ'),
(147, 'ROLE_MOD_TAB_ADMINLOGS_UPDATE'),
(465, 'ROLE_MOD_TAB_ADMINMAILTHEME_CREATE'),
(468, 'ROLE_MOD_TAB_ADMINMAILTHEME_DELETE'),
(466, 'ROLE_MOD_TAB_ADMINMAILTHEME_READ'),
(467, 'ROLE_MOD_TAB_ADMINMAILTHEME_UPDATE'),
(149, 'ROLE_MOD_TAB_ADMINMAINTENANCE_CREATE'),
(152, 'ROLE_MOD_TAB_ADMINMAINTENANCE_DELETE'),
(150, 'ROLE_MOD_TAB_ADMINMAINTENANCE_READ'),
(151, 'ROLE_MOD_TAB_ADMINMAINTENANCE_UPDATE'),
(153, 'ROLE_MOD_TAB_ADMINMANUFACTURERS_CREATE'),
(156, 'ROLE_MOD_TAB_ADMINMANUFACTURERS_DELETE'),
(154, 'ROLE_MOD_TAB_ADMINMANUFACTURERS_READ'),
(155, 'ROLE_MOD_TAB_ADMINMANUFACTURERS_UPDATE'),
(157, 'ROLE_MOD_TAB_ADMINMETA_CREATE'),
(160, 'ROLE_MOD_TAB_ADMINMETA_DELETE'),
(158, 'ROLE_MOD_TAB_ADMINMETA_READ'),
(159, 'ROLE_MOD_TAB_ADMINMETA_UPDATE'),
(805, 'ROLE_MOD_TAB_ADMINMETRICSCONTROLLER_CREATE'),
(808, 'ROLE_MOD_TAB_ADMINMETRICSCONTROLLER_DELETE'),
(806, 'ROLE_MOD_TAB_ADMINMETRICSCONTROLLER_READ'),
(807, 'ROLE_MOD_TAB_ADMINMETRICSCONTROLLER_UPDATE'),
(801, 'ROLE_MOD_TAB_ADMINMETRICSLEGACYSTATSCONTROLLER_CREATE'),
(804, 'ROLE_MOD_TAB_ADMINMETRICSLEGACYSTATSCONTROLLER_DELETE'),
(802, 'ROLE_MOD_TAB_ADMINMETRICSLEGACYSTATSCONTROLLER_READ'),
(803, 'ROLE_MOD_TAB_ADMINMETRICSLEGACYSTATSCONTROLLER_UPDATE'),
(473, 'ROLE_MOD_TAB_ADMINMODULESCATALOG_CREATE'),
(476, 'ROLE_MOD_TAB_ADMINMODULESCATALOG_DELETE'),
(474, 'ROLE_MOD_TAB_ADMINMODULESCATALOG_READ'),
(475, 'ROLE_MOD_TAB_ADMINMODULESCATALOG_UPDATE'),
(469, 'ROLE_MOD_TAB_ADMINMODULESMANAGE_CREATE'),
(472, 'ROLE_MOD_TAB_ADMINMODULESMANAGE_DELETE'),
(470, 'ROLE_MOD_TAB_ADMINMODULESMANAGE_READ'),
(471, 'ROLE_MOD_TAB_ADMINMODULESMANAGE_UPDATE'),
(173, 'ROLE_MOD_TAB_ADMINMODULESNOTIFICATIONS_CREATE'),
(176, 'ROLE_MOD_TAB_ADMINMODULESNOTIFICATIONS_DELETE'),
(174, 'ROLE_MOD_TAB_ADMINMODULESNOTIFICATIONS_READ'),
(175, 'ROLE_MOD_TAB_ADMINMODULESNOTIFICATIONS_UPDATE'),
(165, 'ROLE_MOD_TAB_ADMINMODULESPOSITIONS_CREATE'),
(168, 'ROLE_MOD_TAB_ADMINMODULESPOSITIONS_DELETE'),
(166, 'ROLE_MOD_TAB_ADMINMODULESPOSITIONS_READ'),
(167, 'ROLE_MOD_TAB_ADMINMODULESPOSITIONS_UPDATE'),
(177, 'ROLE_MOD_TAB_ADMINMODULESSF_CREATE'),
(180, 'ROLE_MOD_TAB_ADMINMODULESSF_DELETE'),
(178, 'ROLE_MOD_TAB_ADMINMODULESSF_READ'),
(179, 'ROLE_MOD_TAB_ADMINMODULESSF_UPDATE'),
(169, 'ROLE_MOD_TAB_ADMINMODULESUPDATES_CREATE'),
(172, 'ROLE_MOD_TAB_ADMINMODULESUPDATES_DELETE'),
(170, 'ROLE_MOD_TAB_ADMINMODULESUPDATES_READ'),
(171, 'ROLE_MOD_TAB_ADMINMODULESUPDATES_UPDATE'),
(161, 'ROLE_MOD_TAB_ADMINMODULES_CREATE'),
(164, 'ROLE_MOD_TAB_ADMINMODULES_DELETE'),
(162, 'ROLE_MOD_TAB_ADMINMODULES_READ'),
(163, 'ROLE_MOD_TAB_ADMINMODULES_UPDATE'),
(181, 'ROLE_MOD_TAB_ADMINORDERMESSAGE_CREATE'),
(184, 'ROLE_MOD_TAB_ADMINORDERMESSAGE_DELETE'),
(182, 'ROLE_MOD_TAB_ADMINORDERMESSAGE_READ'),
(183, 'ROLE_MOD_TAB_ADMINORDERMESSAGE_UPDATE'),
(185, 'ROLE_MOD_TAB_ADMINORDERPREFERENCES_CREATE'),
(188, 'ROLE_MOD_TAB_ADMINORDERPREFERENCES_DELETE'),
(186, 'ROLE_MOD_TAB_ADMINORDERPREFERENCES_READ'),
(187, 'ROLE_MOD_TAB_ADMINORDERPREFERENCES_UPDATE'),
(189, 'ROLE_MOD_TAB_ADMINORDERS_CREATE'),
(192, 'ROLE_MOD_TAB_ADMINORDERS_DELETE'),
(190, 'ROLE_MOD_TAB_ADMINORDERS_READ'),
(191, 'ROLE_MOD_TAB_ADMINORDERS_UPDATE'),
(193, 'ROLE_MOD_TAB_ADMINOUTSTANDING_CREATE'),
(196, 'ROLE_MOD_TAB_ADMINOUTSTANDING_DELETE'),
(194, 'ROLE_MOD_TAB_ADMINOUTSTANDING_READ'),
(195, 'ROLE_MOD_TAB_ADMINOUTSTANDING_UPDATE'),
(197, 'ROLE_MOD_TAB_ADMINPARENTATTRIBUTESGROUPS_CREATE'),
(200, 'ROLE_MOD_TAB_ADMINPARENTATTRIBUTESGROUPS_DELETE'),
(198, 'ROLE_MOD_TAB_ADMINPARENTATTRIBUTESGROUPS_READ'),
(199, 'ROLE_MOD_TAB_ADMINPARENTATTRIBUTESGROUPS_UPDATE'),
(201, 'ROLE_MOD_TAB_ADMINPARENTCARTRULES_CREATE'),
(204, 'ROLE_MOD_TAB_ADMINPARENTCARTRULES_DELETE'),
(202, 'ROLE_MOD_TAB_ADMINPARENTCARTRULES_READ'),
(203, 'ROLE_MOD_TAB_ADMINPARENTCARTRULES_UPDATE'),
(205, 'ROLE_MOD_TAB_ADMINPARENTCOUNTRIES_CREATE'),
(208, 'ROLE_MOD_TAB_ADMINPARENTCOUNTRIES_DELETE'),
(206, 'ROLE_MOD_TAB_ADMINPARENTCOUNTRIES_READ'),
(207, 'ROLE_MOD_TAB_ADMINPARENTCOUNTRIES_UPDATE'),
(213, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMERPREFERENCES_CREATE'),
(216, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMERPREFERENCES_DELETE'),
(214, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMERPREFERENCES_READ'),
(215, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMERPREFERENCES_UPDATE'),
(217, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMERTHREADS_CREATE'),
(220, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMERTHREADS_DELETE'),
(218, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMERTHREADS_READ'),
(219, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMERTHREADS_UPDATE'),
(209, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMER_CREATE'),
(212, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMER_DELETE'),
(210, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMER_READ'),
(211, 'ROLE_MOD_TAB_ADMINPARENTCUSTOMER_UPDATE'),
(221, 'ROLE_MOD_TAB_ADMINPARENTEMPLOYEES_CREATE'),
(224, 'ROLE_MOD_TAB_ADMINPARENTEMPLOYEES_DELETE'),
(222, 'ROLE_MOD_TAB_ADMINPARENTEMPLOYEES_READ'),
(223, 'ROLE_MOD_TAB_ADMINPARENTEMPLOYEES_UPDATE'),
(225, 'ROLE_MOD_TAB_ADMINPARENTLOCALIZATION_CREATE'),
(228, 'ROLE_MOD_TAB_ADMINPARENTLOCALIZATION_DELETE'),
(226, 'ROLE_MOD_TAB_ADMINPARENTLOCALIZATION_READ'),
(227, 'ROLE_MOD_TAB_ADMINPARENTLOCALIZATION_UPDATE'),
(461, 'ROLE_MOD_TAB_ADMINPARENTMAILTHEME_CREATE'),
(464, 'ROLE_MOD_TAB_ADMINPARENTMAILTHEME_DELETE'),
(462, 'ROLE_MOD_TAB_ADMINPARENTMAILTHEME_READ'),
(463, 'ROLE_MOD_TAB_ADMINPARENTMAILTHEME_UPDATE'),
(229, 'ROLE_MOD_TAB_ADMINPARENTMANUFACTURERS_CREATE'),
(232, 'ROLE_MOD_TAB_ADMINPARENTMANUFACTURERS_DELETE'),
(230, 'ROLE_MOD_TAB_ADMINPARENTMANUFACTURERS_READ'),
(231, 'ROLE_MOD_TAB_ADMINPARENTMANUFACTURERS_UPDATE'),
(237, 'ROLE_MOD_TAB_ADMINPARENTMETA_CREATE'),
(240, 'ROLE_MOD_TAB_ADMINPARENTMETA_DELETE'),
(238, 'ROLE_MOD_TAB_ADMINPARENTMETA_READ'),
(239, 'ROLE_MOD_TAB_ADMINPARENTMETA_UPDATE'),
(477, 'ROLE_MOD_TAB_ADMINPARENTMODULESCATALOG_CREATE'),
(480, 'ROLE_MOD_TAB_ADMINPARENTMODULESCATALOG_DELETE'),
(478, 'ROLE_MOD_TAB_ADMINPARENTMODULESCATALOG_READ'),
(479, 'ROLE_MOD_TAB_ADMINPARENTMODULESCATALOG_UPDATE'),
(233, 'ROLE_MOD_TAB_ADMINPARENTMODULESSF_CREATE'),
(236, 'ROLE_MOD_TAB_ADMINPARENTMODULESSF_DELETE'),
(234, 'ROLE_MOD_TAB_ADMINPARENTMODULESSF_READ'),
(235, 'ROLE_MOD_TAB_ADMINPARENTMODULESSF_UPDATE'),
(241, 'ROLE_MOD_TAB_ADMINPARENTMODULES_CREATE'),
(244, 'ROLE_MOD_TAB_ADMINPARENTMODULES_DELETE'),
(242, 'ROLE_MOD_TAB_ADMINPARENTMODULES_READ'),
(243, 'ROLE_MOD_TAB_ADMINPARENTMODULES_UPDATE'),
(245, 'ROLE_MOD_TAB_ADMINPARENTORDERPREFERENCES_CREATE'),
(248, 'ROLE_MOD_TAB_ADMINPARENTORDERPREFERENCES_DELETE'),
(246, 'ROLE_MOD_TAB_ADMINPARENTORDERPREFERENCES_READ'),
(247, 'ROLE_MOD_TAB_ADMINPARENTORDERPREFERENCES_UPDATE'),
(249, 'ROLE_MOD_TAB_ADMINPARENTORDERS_CREATE'),
(252, 'ROLE_MOD_TAB_ADMINPARENTORDERS_DELETE'),
(250, 'ROLE_MOD_TAB_ADMINPARENTORDERS_READ'),
(251, 'ROLE_MOD_TAB_ADMINPARENTORDERS_UPDATE'),
(253, 'ROLE_MOD_TAB_ADMINPARENTPAYMENT_CREATE'),
(256, 'ROLE_MOD_TAB_ADMINPARENTPAYMENT_DELETE'),
(254, 'ROLE_MOD_TAB_ADMINPARENTPAYMENT_READ'),
(255, 'ROLE_MOD_TAB_ADMINPARENTPAYMENT_UPDATE'),
(257, 'ROLE_MOD_TAB_ADMINPARENTPREFERENCES_CREATE'),
(260, 'ROLE_MOD_TAB_ADMINPARENTPREFERENCES_DELETE'),
(258, 'ROLE_MOD_TAB_ADMINPARENTPREFERENCES_READ'),
(259, 'ROLE_MOD_TAB_ADMINPARENTPREFERENCES_UPDATE'),
(261, 'ROLE_MOD_TAB_ADMINPARENTREQUESTSQL_CREATE'),
(264, 'ROLE_MOD_TAB_ADMINPARENTREQUESTSQL_DELETE'),
(262, 'ROLE_MOD_TAB_ADMINPARENTREQUESTSQL_READ'),
(263, 'ROLE_MOD_TAB_ADMINPARENTREQUESTSQL_UPDATE'),
(265, 'ROLE_MOD_TAB_ADMINPARENTSEARCHCONF_CREATE'),
(268, 'ROLE_MOD_TAB_ADMINPARENTSEARCHCONF_DELETE'),
(266, 'ROLE_MOD_TAB_ADMINPARENTSEARCHCONF_READ'),
(267, 'ROLE_MOD_TAB_ADMINPARENTSEARCHCONF_UPDATE'),
(269, 'ROLE_MOD_TAB_ADMINPARENTSHIPPING_CREATE'),
(272, 'ROLE_MOD_TAB_ADMINPARENTSHIPPING_DELETE'),
(270, 'ROLE_MOD_TAB_ADMINPARENTSHIPPING_READ'),
(271, 'ROLE_MOD_TAB_ADMINPARENTSHIPPING_UPDATE'),
(273, 'ROLE_MOD_TAB_ADMINPARENTSTOCKMANAGEMENT_CREATE'),
(276, 'ROLE_MOD_TAB_ADMINPARENTSTOCKMANAGEMENT_DELETE'),
(274, 'ROLE_MOD_TAB_ADMINPARENTSTOCKMANAGEMENT_READ'),
(275, 'ROLE_MOD_TAB_ADMINPARENTSTOCKMANAGEMENT_UPDATE'),
(277, 'ROLE_MOD_TAB_ADMINPARENTSTORES_CREATE'),
(280, 'ROLE_MOD_TAB_ADMINPARENTSTORES_DELETE'),
(278, 'ROLE_MOD_TAB_ADMINPARENTSTORES_READ'),
(279, 'ROLE_MOD_TAB_ADMINPARENTSTORES_UPDATE'),
(281, 'ROLE_MOD_TAB_ADMINPARENTTAXES_CREATE'),
(284, 'ROLE_MOD_TAB_ADMINPARENTTAXES_DELETE'),
(282, 'ROLE_MOD_TAB_ADMINPARENTTAXES_READ'),
(283, 'ROLE_MOD_TAB_ADMINPARENTTAXES_UPDATE'),
(285, 'ROLE_MOD_TAB_ADMINPARENTTHEMES_CREATE'),
(288, 'ROLE_MOD_TAB_ADMINPARENTTHEMES_DELETE'),
(286, 'ROLE_MOD_TAB_ADMINPARENTTHEMES_READ'),
(287, 'ROLE_MOD_TAB_ADMINPARENTTHEMES_UPDATE'),
(293, 'ROLE_MOD_TAB_ADMINPAYMENTPREFERENCES_CREATE'),
(296, 'ROLE_MOD_TAB_ADMINPAYMENTPREFERENCES_DELETE'),
(294, 'ROLE_MOD_TAB_ADMINPAYMENTPREFERENCES_READ'),
(295, 'ROLE_MOD_TAB_ADMINPAYMENTPREFERENCES_UPDATE'),
(289, 'ROLE_MOD_TAB_ADMINPAYMENT_CREATE'),
(292, 'ROLE_MOD_TAB_ADMINPAYMENT_DELETE'),
(290, 'ROLE_MOD_TAB_ADMINPAYMENT_READ'),
(291, 'ROLE_MOD_TAB_ADMINPAYMENT_UPDATE'),
(793, 'ROLE_MOD_TAB_ADMINPAYPALONBOARDINGPRESTASHOPCHECKOUT_CREATE'),
(796, 'ROLE_MOD_TAB_ADMINPAYPALONBOARDINGPRESTASHOPCHECKOUT_DELETE'),
(794, 'ROLE_MOD_TAB_ADMINPAYPALONBOARDINGPRESTASHOPCHECKOUT_READ'),
(795, 'ROLE_MOD_TAB_ADMINPAYPALONBOARDINGPRESTASHOPCHECKOUT_UPDATE'),
(297, 'ROLE_MOD_TAB_ADMINPERFORMANCE_CREATE'),
(300, 'ROLE_MOD_TAB_ADMINPERFORMANCE_DELETE'),
(298, 'ROLE_MOD_TAB_ADMINPERFORMANCE_READ'),
(299, 'ROLE_MOD_TAB_ADMINPERFORMANCE_UPDATE'),
(301, 'ROLE_MOD_TAB_ADMINPPREFERENCES_CREATE'),
(304, 'ROLE_MOD_TAB_ADMINPPREFERENCES_DELETE'),
(302, 'ROLE_MOD_TAB_ADMINPPREFERENCES_READ'),
(303, 'ROLE_MOD_TAB_ADMINPPREFERENCES_UPDATE'),
(305, 'ROLE_MOD_TAB_ADMINPREFERENCES_CREATE'),
(308, 'ROLE_MOD_TAB_ADMINPREFERENCES_DELETE'),
(306, 'ROLE_MOD_TAB_ADMINPREFERENCES_READ'),
(307, 'ROLE_MOD_TAB_ADMINPREFERENCES_UPDATE'),
(309, 'ROLE_MOD_TAB_ADMINPRODUCTS_CREATE'),
(312, 'ROLE_MOD_TAB_ADMINPRODUCTS_DELETE'),
(310, 'ROLE_MOD_TAB_ADMINPRODUCTS_READ'),
(311, 'ROLE_MOD_TAB_ADMINPRODUCTS_UPDATE'),
(313, 'ROLE_MOD_TAB_ADMINPROFILES_CREATE'),
(316, 'ROLE_MOD_TAB_ADMINPROFILES_DELETE'),
(314, 'ROLE_MOD_TAB_ADMINPROFILES_READ'),
(315, 'ROLE_MOD_TAB_ADMINPROFILES_UPDATE'),
(813, 'ROLE_MOD_TAB_ADMINPSFACEBOOKMODULE_CREATE'),
(816, 'ROLE_MOD_TAB_ADMINPSFACEBOOKMODULE_DELETE'),
(814, 'ROLE_MOD_TAB_ADMINPSFACEBOOKMODULE_READ'),
(815, 'ROLE_MOD_TAB_ADMINPSFACEBOOKMODULE_UPDATE'),
(765, 'ROLE_MOD_TAB_ADMINPSMBOADDONS_CREATE'),
(768, 'ROLE_MOD_TAB_ADMINPSMBOADDONS_DELETE'),
(766, 'ROLE_MOD_TAB_ADMINPSMBOADDONS_READ'),
(767, 'ROLE_MOD_TAB_ADMINPSMBOADDONS_UPDATE'),
(761, 'ROLE_MOD_TAB_ADMINPSMBOMODULE_CREATE'),
(764, 'ROLE_MOD_TAB_ADMINPSMBOMODULE_DELETE'),
(762, 'ROLE_MOD_TAB_ADMINPSMBOMODULE_READ'),
(763, 'ROLE_MOD_TAB_ADMINPSMBOMODULE_UPDATE'),
(769, 'ROLE_MOD_TAB_ADMINPSMBORECOMMENDED_CREATE'),
(772, 'ROLE_MOD_TAB_ADMINPSMBORECOMMENDED_DELETE'),
(770, 'ROLE_MOD_TAB_ADMINPSMBORECOMMENDED_READ'),
(771, 'ROLE_MOD_TAB_ADMINPSMBORECOMMENDED_UPDATE'),
(773, 'ROLE_MOD_TAB_ADMINPSMBOTHEME_CREATE'),
(776, 'ROLE_MOD_TAB_ADMINPSMBOTHEME_DELETE'),
(774, 'ROLE_MOD_TAB_ADMINPSMBOTHEME_READ'),
(775, 'ROLE_MOD_TAB_ADMINPSMBOTHEME_UPDATE'),
(649, 'ROLE_MOD_TAB_ADMINPSTHEMECUSTOADVANCED_CREATE'),
(652, 'ROLE_MOD_TAB_ADMINPSTHEMECUSTOADVANCED_DELETE'),
(650, 'ROLE_MOD_TAB_ADMINPSTHEMECUSTOADVANCED_READ'),
(651, 'ROLE_MOD_TAB_ADMINPSTHEMECUSTOADVANCED_UPDATE'),
(645, 'ROLE_MOD_TAB_ADMINPSTHEMECUSTOCONFIGURATION_CREATE'),
(648, 'ROLE_MOD_TAB_ADMINPSTHEMECUSTOCONFIGURATION_DELETE'),
(646, 'ROLE_MOD_TAB_ADMINPSTHEMECUSTOCONFIGURATION_READ'),
(647, 'ROLE_MOD_TAB_ADMINPSTHEMECUSTOCONFIGURATION_UPDATE'),
(825, 'ROLE_MOD_TAB_ADMINPSXMKTGWITHGOOGLEMODULE_CREATE'),
(828, 'ROLE_MOD_TAB_ADMINPSXMKTGWITHGOOGLEMODULE_DELETE'),
(826, 'ROLE_MOD_TAB_ADMINPSXMKTGWITHGOOGLEMODULE_READ'),
(827, 'ROLE_MOD_TAB_ADMINPSXMKTGWITHGOOGLEMODULE_UPDATE'),
(317, 'ROLE_MOD_TAB_ADMINREFERRERS_CREATE'),
(320, 'ROLE_MOD_TAB_ADMINREFERRERS_DELETE'),
(318, 'ROLE_MOD_TAB_ADMINREFERRERS_READ'),
(319, 'ROLE_MOD_TAB_ADMINREFERRERS_UPDATE'),
(321, 'ROLE_MOD_TAB_ADMINREQUESTSQL_CREATE'),
(324, 'ROLE_MOD_TAB_ADMINREQUESTSQL_DELETE'),
(322, 'ROLE_MOD_TAB_ADMINREQUESTSQL_READ'),
(323, 'ROLE_MOD_TAB_ADMINREQUESTSQL_UPDATE'),
(325, 'ROLE_MOD_TAB_ADMINRETURN_CREATE'),
(328, 'ROLE_MOD_TAB_ADMINRETURN_DELETE'),
(326, 'ROLE_MOD_TAB_ADMINRETURN_READ'),
(327, 'ROLE_MOD_TAB_ADMINRETURN_UPDATE'),
(329, 'ROLE_MOD_TAB_ADMINSEARCHCONF_CREATE'),
(332, 'ROLE_MOD_TAB_ADMINSEARCHCONF_DELETE'),
(330, 'ROLE_MOD_TAB_ADMINSEARCHCONF_READ'),
(331, 'ROLE_MOD_TAB_ADMINSEARCHCONF_UPDATE'),
(333, 'ROLE_MOD_TAB_ADMINSEARCHENGINES_CREATE'),
(336, 'ROLE_MOD_TAB_ADMINSEARCHENGINES_DELETE'),
(334, 'ROLE_MOD_TAB_ADMINSEARCHENGINES_READ'),
(335, 'ROLE_MOD_TAB_ADMINSEARCHENGINES_UPDATE'),
(337, 'ROLE_MOD_TAB_ADMINSHIPPING_CREATE'),
(340, 'ROLE_MOD_TAB_ADMINSHIPPING_DELETE'),
(338, 'ROLE_MOD_TAB_ADMINSHIPPING_READ'),
(339, 'ROLE_MOD_TAB_ADMINSHIPPING_UPDATE'),
(341, 'ROLE_MOD_TAB_ADMINSHOPGROUP_CREATE'),
(344, 'ROLE_MOD_TAB_ADMINSHOPGROUP_DELETE'),
(342, 'ROLE_MOD_TAB_ADMINSHOPGROUP_READ'),
(343, 'ROLE_MOD_TAB_ADMINSHOPGROUP_UPDATE'),
(345, 'ROLE_MOD_TAB_ADMINSHOPURL_CREATE'),
(348, 'ROLE_MOD_TAB_ADMINSHOPURL_DELETE'),
(346, 'ROLE_MOD_TAB_ADMINSHOPURL_READ'),
(347, 'ROLE_MOD_TAB_ADMINSHOPURL_UPDATE'),
(349, 'ROLE_MOD_TAB_ADMINSLIP_CREATE'),
(352, 'ROLE_MOD_TAB_ADMINSLIP_DELETE'),
(350, 'ROLE_MOD_TAB_ADMINSLIP_READ'),
(351, 'ROLE_MOD_TAB_ADMINSLIP_UPDATE'),
(353, 'ROLE_MOD_TAB_ADMINSPECIFICPRICERULE_CREATE'),
(356, 'ROLE_MOD_TAB_ADMINSPECIFICPRICERULE_DELETE'),
(354, 'ROLE_MOD_TAB_ADMINSPECIFICPRICERULE_READ'),
(355, 'ROLE_MOD_TAB_ADMINSPECIFICPRICERULE_UPDATE'),
(357, 'ROLE_MOD_TAB_ADMINSTATES_CREATE'),
(360, 'ROLE_MOD_TAB_ADMINSTATES_DELETE'),
(358, 'ROLE_MOD_TAB_ADMINSTATES_READ'),
(359, 'ROLE_MOD_TAB_ADMINSTATES_UPDATE'),
(361, 'ROLE_MOD_TAB_ADMINSTATS_CREATE'),
(364, 'ROLE_MOD_TAB_ADMINSTATS_DELETE'),
(362, 'ROLE_MOD_TAB_ADMINSTATS_READ'),
(363, 'ROLE_MOD_TAB_ADMINSTATS_UPDATE'),
(365, 'ROLE_MOD_TAB_ADMINSTATUSES_CREATE'),
(368, 'ROLE_MOD_TAB_ADMINSTATUSES_DELETE'),
(366, 'ROLE_MOD_TAB_ADMINSTATUSES_READ'),
(367, 'ROLE_MOD_TAB_ADMINSTATUSES_UPDATE'),
(373, 'ROLE_MOD_TAB_ADMINSTOCKCONFIGURATION_CREATE'),
(376, 'ROLE_MOD_TAB_ADMINSTOCKCONFIGURATION_DELETE'),
(374, 'ROLE_MOD_TAB_ADMINSTOCKCONFIGURATION_READ'),
(375, 'ROLE_MOD_TAB_ADMINSTOCKCONFIGURATION_UPDATE'),
(377, 'ROLE_MOD_TAB_ADMINSTOCKCOVER_CREATE'),
(380, 'ROLE_MOD_TAB_ADMINSTOCKCOVER_DELETE'),
(378, 'ROLE_MOD_TAB_ADMINSTOCKCOVER_READ'),
(379, 'ROLE_MOD_TAB_ADMINSTOCKCOVER_UPDATE'),
(381, 'ROLE_MOD_TAB_ADMINSTOCKINSTANTSTATE_CREATE'),
(384, 'ROLE_MOD_TAB_ADMINSTOCKINSTANTSTATE_DELETE'),
(382, 'ROLE_MOD_TAB_ADMINSTOCKINSTANTSTATE_READ'),
(383, 'ROLE_MOD_TAB_ADMINSTOCKINSTANTSTATE_UPDATE'),
(385, 'ROLE_MOD_TAB_ADMINSTOCKMANAGEMENT_CREATE'),
(388, 'ROLE_MOD_TAB_ADMINSTOCKMANAGEMENT_DELETE'),
(386, 'ROLE_MOD_TAB_ADMINSTOCKMANAGEMENT_READ'),
(387, 'ROLE_MOD_TAB_ADMINSTOCKMANAGEMENT_UPDATE'),
(389, 'ROLE_MOD_TAB_ADMINSTOCKMVT_CREATE'),
(392, 'ROLE_MOD_TAB_ADMINSTOCKMVT_DELETE'),
(390, 'ROLE_MOD_TAB_ADMINSTOCKMVT_READ'),
(391, 'ROLE_MOD_TAB_ADMINSTOCKMVT_UPDATE'),
(369, 'ROLE_MOD_TAB_ADMINSTOCK_CREATE'),
(372, 'ROLE_MOD_TAB_ADMINSTOCK_DELETE'),
(370, 'ROLE_MOD_TAB_ADMINSTOCK_READ'),
(371, 'ROLE_MOD_TAB_ADMINSTOCK_UPDATE'),
(393, 'ROLE_MOD_TAB_ADMINSTORES_CREATE'),
(396, 'ROLE_MOD_TAB_ADMINSTORES_DELETE'),
(394, 'ROLE_MOD_TAB_ADMINSTORES_READ'),
(395, 'ROLE_MOD_TAB_ADMINSTORES_UPDATE'),
(397, 'ROLE_MOD_TAB_ADMINSUPPLIERS_CREATE'),
(400, 'ROLE_MOD_TAB_ADMINSUPPLIERS_DELETE'),
(398, 'ROLE_MOD_TAB_ADMINSUPPLIERS_READ'),
(399, 'ROLE_MOD_TAB_ADMINSUPPLIERS_UPDATE'),
(401, 'ROLE_MOD_TAB_ADMINSUPPLYORDERS_CREATE'),
(404, 'ROLE_MOD_TAB_ADMINSUPPLYORDERS_DELETE'),
(402, 'ROLE_MOD_TAB_ADMINSUPPLYORDERS_READ'),
(403, 'ROLE_MOD_TAB_ADMINSUPPLYORDERS_UPDATE'),
(405, 'ROLE_MOD_TAB_ADMINTAGS_CREATE'),
(408, 'ROLE_MOD_TAB_ADMINTAGS_DELETE'),
(406, 'ROLE_MOD_TAB_ADMINTAGS_READ'),
(407, 'ROLE_MOD_TAB_ADMINTAGS_UPDATE'),
(409, 'ROLE_MOD_TAB_ADMINTAXES_CREATE'),
(412, 'ROLE_MOD_TAB_ADMINTAXES_DELETE'),
(410, 'ROLE_MOD_TAB_ADMINTAXES_READ'),
(411, 'ROLE_MOD_TAB_ADMINTAXES_UPDATE'),
(413, 'ROLE_MOD_TAB_ADMINTAXRULESGROUP_CREATE'),
(416, 'ROLE_MOD_TAB_ADMINTAXRULESGROUP_DELETE'),
(414, 'ROLE_MOD_TAB_ADMINTAXRULESGROUP_READ'),
(415, 'ROLE_MOD_TAB_ADMINTAXRULESGROUP_UPDATE'),
(421, 'ROLE_MOD_TAB_ADMINTHEMESCATALOG_CREATE'),
(424, 'ROLE_MOD_TAB_ADMINTHEMESCATALOG_DELETE'),
(422, 'ROLE_MOD_TAB_ADMINTHEMESCATALOG_READ'),
(423, 'ROLE_MOD_TAB_ADMINTHEMESCATALOG_UPDATE'),
(641, 'ROLE_MOD_TAB_ADMINTHEMESPARENT_CREATE'),
(644, 'ROLE_MOD_TAB_ADMINTHEMESPARENT_DELETE'),
(642, 'ROLE_MOD_TAB_ADMINTHEMESPARENT_READ'),
(643, 'ROLE_MOD_TAB_ADMINTHEMESPARENT_UPDATE'),
(417, 'ROLE_MOD_TAB_ADMINTHEMES_CREATE'),
(420, 'ROLE_MOD_TAB_ADMINTHEMES_DELETE'),
(418, 'ROLE_MOD_TAB_ADMINTHEMES_READ'),
(419, 'ROLE_MOD_TAB_ADMINTHEMES_UPDATE'),
(425, 'ROLE_MOD_TAB_ADMINTRACKING_CREATE'),
(428, 'ROLE_MOD_TAB_ADMINTRACKING_DELETE'),
(426, 'ROLE_MOD_TAB_ADMINTRACKING_READ'),
(427, 'ROLE_MOD_TAB_ADMINTRACKING_UPDATE'),
(429, 'ROLE_MOD_TAB_ADMINTRANSLATIONS_CREATE'),
(432, 'ROLE_MOD_TAB_ADMINTRANSLATIONS_DELETE'),
(430, 'ROLE_MOD_TAB_ADMINTRANSLATIONS_READ'),
(431, 'ROLE_MOD_TAB_ADMINTRANSLATIONS_UPDATE'),
(433, 'ROLE_MOD_TAB_ADMINWAREHOUSES_CREATE'),
(436, 'ROLE_MOD_TAB_ADMINWAREHOUSES_DELETE'),
(434, 'ROLE_MOD_TAB_ADMINWAREHOUSES_READ'),
(435, 'ROLE_MOD_TAB_ADMINWAREHOUSES_UPDATE'),
(437, 'ROLE_MOD_TAB_ADMINWEBSERVICE_CREATE'),
(440, 'ROLE_MOD_TAB_ADMINWEBSERVICE_DELETE'),
(438, 'ROLE_MOD_TAB_ADMINWEBSERVICE_READ'),
(439, 'ROLE_MOD_TAB_ADMINWEBSERVICE_UPDATE'),
(729, 'ROLE_MOD_TAB_ADMINWELCOME_CREATE'),
(732, 'ROLE_MOD_TAB_ADMINWELCOME_DELETE'),
(730, 'ROLE_MOD_TAB_ADMINWELCOME_READ'),
(731, 'ROLE_MOD_TAB_ADMINWELCOME_UPDATE'),
(441, 'ROLE_MOD_TAB_ADMINZONES_CREATE'),
(444, 'ROLE_MOD_TAB_ADMINZONES_DELETE'),
(442, 'ROLE_MOD_TAB_ADMINZONES_READ'),
(443, 'ROLE_MOD_TAB_ADMINZONES_UPDATE'),
(445, 'ROLE_MOD_TAB_CONFIGURE_CREATE'),
(448, 'ROLE_MOD_TAB_CONFIGURE_DELETE'),
(446, 'ROLE_MOD_TAB_CONFIGURE_READ'),
(447, 'ROLE_MOD_TAB_CONFIGURE_UPDATE'),
(449, 'ROLE_MOD_TAB_IMPROVE_CREATE'),
(452, 'ROLE_MOD_TAB_IMPROVE_DELETE'),
(450, 'ROLE_MOD_TAB_IMPROVE_READ'),
(451, 'ROLE_MOD_TAB_IMPROVE_UPDATE'),
(809, 'ROLE_MOD_TAB_MARKETING_CREATE'),
(812, 'ROLE_MOD_TAB_MARKETING_DELETE'),
(810, 'ROLE_MOD_TAB_MARKETING_READ'),
(811, 'ROLE_MOD_TAB_MARKETING_UPDATE'),
(453, 'ROLE_MOD_TAB_SELL_CREATE'),
(456, 'ROLE_MOD_TAB_SELL_DELETE'),
(454, 'ROLE_MOD_TAB_SELL_READ'),
(455, 'ROLE_MOD_TAB_SELL_UPDATE'),
(457, 'ROLE_MOD_TAB_SHOPPARAMETERS_CREATE'),
(460, 'ROLE_MOD_TAB_SHOPPARAMETERS_DELETE'),
(458, 'ROLE_MOD_TAB_SHOPPARAMETERS_READ'),
(459, 'ROLE_MOD_TAB_SHOPPARAMETERS_UPDATE'),
(489, 'ROLE_MOD_TAB_WISHLISTCONFIGURATIONADMINCONTROLLER_CREATE'),
(492, 'ROLE_MOD_TAB_WISHLISTCONFIGURATIONADMINCONTROLLER_DELETE'),
(490, 'ROLE_MOD_TAB_WISHLISTCONFIGURATIONADMINCONTROLLER_READ'),
(491, 'ROLE_MOD_TAB_WISHLISTCONFIGURATIONADMINCONTROLLER_UPDATE'),
(485, 'ROLE_MOD_TAB_WISHLISTCONFIGURATIONADMINPARENTCONTROLLER_CREATE'),
(488, 'ROLE_MOD_TAB_WISHLISTCONFIGURATIONADMINPARENTCONTROLLER_DELETE'),
(486, 'ROLE_MOD_TAB_WISHLISTCONFIGURATIONADMINPARENTCONTROLLER_READ'),
(487, 'ROLE_MOD_TAB_WISHLISTCONFIGURATIONADMINPARENTCONTROLLER_UPDATE'),
(493, 'ROLE_MOD_TAB_WISHLISTSTATISTICSADMINCONTROLLER_CREATE'),
(496, 'ROLE_MOD_TAB_WISHLISTSTATISTICSADMINCONTROLLER_DELETE'),
(494, 'ROLE_MOD_TAB_WISHLISTSTATISTICSADMINCONTROLLER_READ'),
(495, 'ROLE_MOD_TAB_WISHLISTSTATISTICSADMINCONTROLLER_UPDATE');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_badge`
--

CREATE TABLE `ps_badge` (
  `id_badge` int(11) NOT NULL,
  `id_ps_badge` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `id_group` int(11) NOT NULL,
  `group_position` int(11) NOT NULL,
  `scoring` int(11) NOT NULL,
  `awb` int(11) DEFAULT 0,
  `validated` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_badge`
--

INSERT INTO `ps_badge` (`id_badge`, `id_ps_badge`, `type`, `id_group`, `group_position`, `scoring`, `awb`, `validated`) VALUES
(1, 159, 'feature', 41, 1, 5, 1, 0),
(2, 160, 'feature', 41, 2, 10, 1, 0),
(3, 161, 'feature', 41, 3, 15, 1, 0),
(4, 162, 'feature', 41, 4, 20, 1, 0),
(5, 163, 'feature', 41, 1, 5, 1, 0),
(6, 164, 'feature', 41, 2, 10, 1, 0),
(7, 165, 'feature', 41, 3, 15, 1, 0),
(8, 166, 'feature', 41, 4, 20, 1, 0),
(9, 195, 'feature', 41, 1, 5, 1, 0),
(10, 196, 'feature', 41, 2, 10, 1, 0),
(11, 229, 'feature', 41, 1, 5, 1, 0),
(12, 230, 'feature', 41, 2, 10, 1, 0),
(13, 231, 'feature', 41, 3, 15, 1, 0),
(14, 232, 'feature', 41, 4, 20, 1, 0),
(15, 233, 'feature', 41, 1, 5, 1, 0),
(16, 234, 'feature', 41, 2, 10, 1, 0),
(17, 235, 'feature', 41, 3, 15, 1, 0),
(18, 236, 'feature', 41, 4, 20, 1, 0),
(19, 241, 'feature', 41, 1, 5, 1, 0),
(20, 242, 'feature', 41, 2, 10, 1, 0),
(21, 243, 'feature', 41, 3, 15, 1, 0),
(22, 244, 'feature', 41, 4, 20, 1, 0),
(23, 249, 'feature', 41, 1, 5, 1, 0),
(24, 250, 'feature', 41, 2, 10, 1, 0),
(25, 251, 'feature', 41, 3, 15, 1, 0),
(26, 252, 'feature', 41, 4, 20, 1, 0),
(27, 253, 'feature', 41, 1, 5, 1, 0),
(28, 254, 'feature', 41, 2, 10, 1, 0),
(29, 255, 'feature', 41, 3, 15, 1, 0),
(30, 256, 'feature', 41, 4, 20, 1, 0),
(31, 261, 'feature', 41, 1, 5, 1, 0),
(32, 262, 'feature', 41, 2, 10, 1, 0),
(33, 269, 'feature', 41, 1, 5, 1, 0),
(34, 270, 'feature', 41, 2, 10, 1, 0),
(35, 271, 'feature', 41, 3, 15, 1, 0),
(36, 272, 'feature', 41, 4, 20, 1, 0),
(37, 273, 'feature', 41, 1, 5, 1, 0),
(38, 274, 'feature', 41, 2, 10, 1, 0),
(39, 275, 'feature', 41, 3, 15, 1, 0),
(40, 276, 'feature', 41, 4, 20, 1, 0),
(41, 277, 'feature', 41, 1, 5, 1, 0),
(42, 278, 'feature', 41, 2, 10, 1, 0),
(43, 279, 'feature', 41, 3, 15, 1, 0),
(44, 280, 'feature', 41, 4, 20, 1, 0),
(45, 281, 'feature', 41, 1, 5, 1, 0),
(46, 282, 'feature', 41, 2, 10, 1, 0),
(47, 283, 'feature', 41, 3, 15, 1, 0),
(48, 284, 'feature', 41, 4, 20, 1, 0),
(49, 285, 'feature', 41, 1, 5, 1, 0),
(50, 286, 'feature', 41, 2, 10, 1, 0),
(51, 287, 'feature', 41, 3, 15, 1, 0),
(52, 288, 'feature', 41, 4, 20, 1, 0),
(53, 289, 'feature', 41, 1, 5, 1, 0),
(54, 290, 'feature', 41, 2, 10, 1, 0),
(55, 291, 'feature', 41, 3, 15, 1, 0),
(56, 292, 'feature', 41, 4, 20, 1, 0),
(57, 293, 'feature', 41, 1, 5, 1, 0),
(58, 294, 'feature', 41, 2, 10, 1, 0),
(59, 295, 'feature', 41, 3, 15, 1, 0),
(60, 296, 'feature', 41, 4, 20, 1, 0),
(61, 297, 'feature', 41, 1, 5, 1, 0),
(62, 298, 'feature', 41, 2, 10, 1, 0),
(63, 299, 'feature', 41, 3, 15, 1, 0),
(64, 300, 'feature', 41, 4, 20, 1, 0),
(65, 301, 'feature', 41, 1, 5, 1, 0),
(66, 302, 'feature', 41, 2, 10, 1, 0),
(67, 303, 'feature', 41, 3, 15, 1, 0),
(68, 304, 'feature', 41, 4, 20, 1, 0),
(69, 305, 'feature', 41, 1, 5, 1, 0),
(70, 306, 'feature', 41, 2, 10, 1, 0),
(71, 307, 'feature', 41, 3, 15, 1, 0),
(72, 308, 'feature', 41, 4, 20, 1, 0),
(73, 309, 'feature', 41, 1, 5, 1, 0),
(74, 310, 'feature', 41, 2, 10, 1, 0),
(75, 311, 'feature', 41, 3, 15, 1, 0),
(76, 312, 'feature', 41, 4, 20, 1, 0),
(77, 313, 'feature', 41, 1, 5, 1, 0),
(78, 314, 'feature', 41, 2, 10, 1, 1),
(79, 315, 'feature', 41, 3, 15, 1, 0),
(80, 316, 'feature', 41, 4, 20, 1, 0),
(81, 317, 'feature', 41, 1, 5, 1, 0),
(82, 318, 'feature', 41, 2, 10, 1, 0),
(83, 319, 'feature', 41, 3, 15, 1, 0),
(84, 320, 'feature', 41, 4, 20, 1, 0),
(85, 321, 'feature', 41, 1, 5, 1, 0),
(86, 322, 'feature', 41, 2, 10, 1, 0),
(87, 323, 'feature', 41, 3, 15, 1, 0),
(88, 324, 'feature', 41, 4, 20, 1, 0),
(89, 325, 'feature', 41, 1, 5, 1, 0),
(90, 326, 'feature', 41, 2, 10, 1, 0),
(91, 327, 'feature', 41, 3, 15, 1, 0),
(92, 328, 'feature', 41, 4, 20, 1, 0),
(93, 329, 'feature', 41, 1, 5, 1, 0),
(94, 330, 'feature', 41, 2, 10, 1, 0),
(95, 331, 'feature', 41, 3, 15, 1, 0),
(96, 332, 'feature', 41, 4, 20, 1, 0),
(97, 333, 'feature', 41, 1, 5, 1, 0),
(98, 334, 'feature', 41, 2, 10, 1, 0),
(99, 335, 'feature', 41, 3, 15, 1, 0),
(100, 336, 'feature', 41, 4, 20, 1, 0),
(101, 337, 'feature', 41, 1, 5, 1, 0),
(102, 338, 'feature', 41, 2, 10, 1, 0),
(103, 339, 'feature', 41, 3, 15, 1, 0),
(104, 340, 'feature', 41, 4, 20, 1, 0),
(105, 341, 'feature', 41, 1, 5, 1, 0),
(106, 342, 'feature', 41, 2, 10, 1, 0),
(107, 343, 'feature', 41, 3, 15, 1, 0),
(108, 344, 'feature', 41, 4, 20, 1, 0),
(109, 345, 'feature', 41, 1, 5, 1, 0),
(110, 346, 'feature', 41, 2, 10, 1, 0),
(111, 347, 'feature', 41, 3, 15, 1, 0),
(112, 348, 'feature', 41, 4, 20, 1, 0),
(113, 349, 'feature', 41, 1, 5, 1, 0),
(114, 350, 'feature', 41, 2, 10, 1, 0),
(115, 351, 'feature', 41, 3, 15, 1, 0),
(116, 352, 'feature', 41, 4, 20, 1, 0),
(117, 353, 'feature', 41, 1, 5, 1, 0),
(118, 354, 'feature', 41, 2, 10, 1, 0),
(119, 355, 'feature', 41, 3, 15, 1, 0),
(120, 356, 'feature', 41, 4, 20, 1, 0),
(121, 357, 'feature', 41, 1, 5, 1, 0),
(122, 358, 'feature', 41, 2, 10, 1, 0),
(123, 359, 'feature', 41, 3, 15, 1, 0),
(124, 360, 'feature', 41, 4, 20, 1, 0),
(125, 1, 'feature', 1, 1, 10, 0, 1),
(126, 2, 'feature', 2, 1, 10, 0, 0),
(127, 3, 'feature', 2, 2, 15, 0, 0),
(128, 4, 'feature', 3, 1, 15, 0, 0),
(129, 5, 'feature', 3, 2, 15, 0, 0),
(130, 6, 'feature', 4, 1, 15, 0, 1),
(131, 7, 'feature', 4, 2, 15, 0, 1),
(132, 8, 'feature', 5, 1, 5, 0, 1),
(133, 9, 'feature', 5, 2, 10, 0, 1),
(134, 10, 'feature', 6, 1, 15, 0, 1),
(135, 11, 'feature', 6, 2, 10, 0, 0),
(136, 12, 'feature', 6, 3, 10, 0, 0),
(137, 13, 'feature', 5, 3, 10, 0, 0),
(138, 14, 'feature', 5, 4, 15, 0, 0),
(139, 15, 'feature', 5, 5, 20, 0, 0),
(140, 16, 'feature', 5, 6, 20, 0, 0),
(141, 17, 'achievement', 7, 1, 5, 0, 1),
(142, 18, 'achievement', 7, 2, 10, 0, 0),
(143, 19, 'feature', 8, 1, 15, 0, 1),
(144, 20, 'feature', 8, 2, 15, 0, 0),
(145, 21, 'feature', 9, 1, 15, 0, 0),
(146, 22, 'feature', 10, 1, 10, 0, 0),
(147, 23, 'feature', 10, 2, 10, 0, 0),
(148, 24, 'feature', 10, 3, 10, 0, 0),
(149, 25, 'feature', 10, 4, 10, 0, 0),
(150, 26, 'feature', 10, 5, 10, 0, 0),
(151, 27, 'feature', 4, 3, 10, 0, 0),
(152, 28, 'feature', 3, 3, 10, 0, 0),
(153, 29, 'achievement', 11, 1, 5, 0, 0),
(154, 30, 'achievement', 11, 2, 10, 0, 0),
(155, 31, 'achievement', 11, 3, 15, 0, 0),
(156, 32, 'achievement', 11, 4, 20, 0, 0),
(157, 33, 'achievement', 11, 5, 25, 0, 0),
(158, 34, 'achievement', 11, 6, 30, 0, 0),
(159, 35, 'achievement', 7, 3, 15, 0, 0),
(160, 36, 'achievement', 7, 4, 20, 0, 0),
(161, 37, 'achievement', 7, 5, 25, 0, 0),
(162, 38, 'achievement', 7, 6, 30, 0, 0),
(163, 39, 'achievement', 12, 1, 5, 0, 0),
(164, 40, 'achievement', 12, 2, 10, 0, 0),
(165, 41, 'achievement', 12, 3, 15, 0, 0),
(166, 42, 'achievement', 12, 4, 20, 0, 0),
(167, 43, 'achievement', 12, 5, 25, 0, 0),
(168, 44, 'achievement', 12, 6, 30, 0, 0),
(169, 45, 'achievement', 13, 1, 5, 0, 1),
(170, 46, 'achievement', 13, 2, 10, 0, 0),
(171, 47, 'achievement', 13, 3, 15, 0, 0),
(172, 48, 'achievement', 13, 4, 20, 0, 0),
(173, 49, 'achievement', 13, 5, 25, 0, 0),
(174, 50, 'achievement', 13, 6, 30, 0, 0),
(175, 51, 'achievement', 14, 1, 5, 0, 1),
(176, 52, 'achievement', 14, 2, 10, 0, 0),
(177, 53, 'achievement', 14, 3, 15, 0, 0),
(178, 54, 'achievement', 14, 4, 20, 0, 0),
(179, 55, 'achievement', 14, 5, 25, 0, 0),
(180, 56, 'achievement', 14, 6, 30, 0, 0),
(181, 57, 'achievement', 15, 1, 5, 0, 0),
(182, 58, 'achievement', 15, 2, 10, 0, 0),
(183, 59, 'achievement', 15, 3, 15, 0, 0),
(184, 60, 'achievement', 15, 4, 20, 0, 0),
(185, 61, 'achievement', 15, 5, 25, 0, 0),
(186, 62, 'achievement', 15, 6, 30, 0, 0),
(187, 63, 'achievement', 16, 1, 5, 0, 1),
(188, 64, 'achievement', 16, 2, 10, 0, 0),
(189, 65, 'achievement', 16, 3, 15, 0, 0),
(190, 66, 'achievement', 16, 4, 20, 0, 0),
(191, 67, 'achievement', 16, 5, 25, 0, 0),
(192, 68, 'achievement', 16, 6, 30, 0, 0),
(193, 74, 'international', 22, 1, 10, 0, 0),
(194, 75, 'international', 23, 1, 10, 0, 0),
(195, 83, 'international', 31, 1, 10, 0, 0),
(196, 84, 'international', 25, 1, 10, 0, 0),
(197, 85, 'international', 32, 1, 10, 0, 0),
(198, 86, 'international', 33, 1, 10, 0, 0),
(199, 87, 'international', 34, 1, 10, 0, 0),
(200, 88, 'feature', 35, 1, 5, 0, 0),
(201, 89, 'feature', 35, 2, 10, 0, 0),
(202, 90, 'feature', 35, 3, 10, 0, 0),
(203, 91, 'feature', 35, 4, 10, 0, 0),
(204, 92, 'feature', 35, 5, 10, 0, 0),
(205, 93, 'feature', 35, 6, 10, 0, 0),
(206, 94, 'feature', 36, 1, 5, 0, 1),
(207, 95, 'feature', 36, 2, 5, 0, 0),
(208, 96, 'feature', 36, 3, 10, 0, 0),
(209, 97, 'feature', 36, 4, 10, 0, 0),
(210, 98, 'feature', 36, 5, 20, 0, 0),
(211, 99, 'feature', 36, 6, 20, 0, 0),
(212, 100, 'feature', 8, 3, 15, 0, 0),
(213, 101, 'achievement', 37, 1, 5, 0, 0),
(214, 102, 'achievement', 37, 2, 5, 0, 0),
(215, 103, 'achievement', 37, 3, 10, 0, 0),
(216, 104, 'achievement', 37, 4, 10, 0, 0),
(217, 105, 'achievement', 37, 5, 15, 0, 0),
(218, 106, 'achievement', 37, 6, 15, 0, 0),
(219, 107, 'achievement', 38, 1, 10, 0, 0),
(220, 108, 'achievement', 38, 2, 10, 0, 0),
(221, 109, 'achievement', 38, 3, 15, 0, 0),
(222, 110, 'achievement', 38, 4, 20, 0, 0),
(223, 111, 'achievement', 38, 5, 25, 0, 0),
(224, 112, 'achievement', 38, 6, 30, 0, 0),
(225, 113, 'achievement', 39, 1, 10, 0, 0),
(226, 114, 'achievement', 39, 2, 20, 0, 0),
(227, 115, 'achievement', 39, 3, 30, 0, 0),
(228, 116, 'achievement', 39, 4, 40, 0, 0),
(229, 117, 'achievement', 39, 5, 50, 0, 0),
(230, 118, 'achievement', 39, 6, 50, 0, 0),
(231, 119, 'feature', 40, 1, 10, 0, 0),
(232, 120, 'feature', 40, 2, 15, 0, 0),
(233, 121, 'feature', 40, 3, 20, 0, 0),
(234, 122, 'feature', 40, 4, 25, 0, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_badge_lang`
--

CREATE TABLE `ps_badge_lang` (
  `id_badge` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `group_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_badge_lang`
--

INSERT INTO `ps_badge_lang` (`id_badge`, `id_lang`, `name`, `description`, `group_name`) VALUES
(1, 1, 'Shopgate installed', 'You have installed the Shopgate module', 'Partners'),
(2, 1, 'Shopgate configured', 'You have configured the Shopgate module', 'Partners'),
(3, 1, 'Shopgate active', 'Your Shopgate module is active', 'Partners'),
(4, 1, 'Shopgate very active', 'Your Shopgate module is very active', 'Partners'),
(5, 1, 'Skrill installed', 'You have installed the Skrill module', 'Partners'),
(6, 1, 'Skrill configured', 'You have configured the Skrill module', 'Partners'),
(7, 1, 'Skrill active', 'Your Skrill module is active', 'Partners'),
(8, 1, 'Skrill very active', 'Your Skrill module is very active', 'Partners'),
(9, 1, 'Shopping Feed installed', 'You have installed the Shopping Feed module', 'Partners'),
(10, 1, 'Shopping Feed configured', 'You have configured the Shopping Feed module', 'Partners'),
(11, 1, 'Alliance Payment installed', 'You have installed the Alliance Payment module', 'Partners'),
(12, 1, 'Alliance Payment configured', 'You have configured the Alliance Payment module', 'Partners'),
(13, 1, 'Alliance Payment active', 'Your Alliance Payment module is active', 'Partners'),
(14, 1, 'Alliance Payment very active', 'Your Alliance Payment module is very active', 'Partners'),
(15, 1, 'Authorize Aim installed', 'You have installed the Authorize Aim module', 'Partners'),
(16, 1, 'Authorize Aim configured', 'You have configured the Authorize Aim module', 'Partners'),
(17, 1, 'Authorize Aim active', 'Your Authorize Aim module is active', 'Partners'),
(18, 1, 'Authorize Aim very active', 'Your Authorize Aim module is very active', 'Partners'),
(19, 1, 'Blue Pay installed', 'You have installed the Blue Pay module', 'Partners'),
(20, 1, 'Blue Pay configured', 'You have configured the Blue Pay module', 'Partners'),
(21, 1, 'Blue Pay active', 'Your Blue Pay module is active', 'Partners'),
(22, 1, 'Blue Pay very active', 'Your Blue Pay module is very active', 'Partners'),
(23, 1, 'Ebay installed', 'You have installed the Ebay module', 'Partners'),
(24, 1, 'Ebay configured', 'You have configured the Ebay module', 'Partners'),
(25, 1, 'Ebay active', 'Your Ebay module is active', 'Partners'),
(26, 1, 'Ebay very active', 'Your Ebay module is very active', 'Partners'),
(27, 1, 'PayPlug installed', 'You have installed the PayPlug module', 'Partners'),
(28, 1, 'PayPlug configured', 'You have configured the PayPlug module', 'Partners'),
(29, 1, 'PayPlug active', 'Your PayPlug module is active', 'Partners'),
(30, 1, 'PayPlug very active', 'Your PayPlug module is very active', 'Partners'),
(31, 1, 'Affinity Items installed', 'You have installed the Affinity Items module', 'Partners'),
(32, 1, 'Affinity Items configured', 'You have configured the Affinity Items module', 'Partners'),
(33, 1, 'DPD Poland installed', 'You have installed the DPD Poland module', 'Partners'),
(34, 1, 'DPD Poland configured', 'You have configured the DPD Poland module', 'Partners'),
(35, 1, 'DPD Poland active', 'Your DPD Poland module is active', 'Partners'),
(36, 1, 'DPD Poland very active', 'Your DPD Poland module is very active', 'Partners'),
(37, 1, 'Envoimoinscher installed', 'You have installed the Envoimoinscher module', 'Partners'),
(38, 1, 'Envoimoinscher configured', 'You have configured the Envoimoinscher module', 'Partners'),
(39, 1, 'Envoimoinscher active', 'Your Envoimoinscher module is active', 'Partners'),
(40, 1, 'Envoimoinscher very active', 'Your Envoimoinscher module is very active', 'Partners'),
(41, 1, 'Klik&Pay installed', 'You have installed the Klik&Pay module', 'Partners'),
(42, 1, 'Klik&Pay configured', 'You have configured the Klik&Pay module', 'Partners'),
(43, 1, 'Klik&Pay active', 'Your Klik&Pay module is active', 'Partners'),
(44, 1, 'Klik&Pay very active', 'Your Klik&Pay module is very active', 'Partners'),
(45, 1, 'Clickline installed', 'You have installed the Clickline module', 'Partners'),
(46, 1, 'Clickline configured', 'You have configured the Clickline module', 'Partners'),
(47, 1, 'Clickline active', 'Your Clickline module is active', 'Partners'),
(48, 1, 'Clickline very active', 'Your Clickline module is very active', 'Partners'),
(49, 1, 'CDiscount installed', 'You have installed the CDiscount module', 'Partners'),
(50, 1, 'CDiscount configured', 'You have configured the CDiscount module', 'Partners'),
(51, 1, 'CDiscount active', 'Your CDiscount module is active', 'Partners'),
(52, 1, 'CDiscount very active', 'Your CDiscount module is very active', 'Partners'),
(53, 1, 'illicoPresta installed', 'You have installed the illicoPresta module', 'Partners'),
(54, 1, 'illicoPresta configured', 'You have configured the illicoPresta module', 'Partners'),
(55, 1, 'illicoPresta active', 'Your illicoPresta module is active', 'Partners'),
(56, 1, 'illicoPresta very active', 'Your illicoPresta module is very active', 'Partners'),
(57, 1, 'NetReviews installed', 'You have installed the NetReviews module', 'Partners'),
(58, 1, 'NetReviews configured', 'You have configured the NetReviews module', 'Partners'),
(59, 1, 'NetReviews active', 'Your NetReviews module is active', 'Partners'),
(60, 1, 'NetReviews very active', 'Your NetReviews module is very active', 'Partners'),
(61, 1, 'Bluesnap installed', 'You have installed the Bluesnap module', 'Partners'),
(62, 1, 'Bluesnap configured', 'You have configured the Bluesnap module', 'Partners'),
(63, 1, 'Bluesnap active', 'Your Bluesnap module is active', 'Partners'),
(64, 1, 'Bluesnap very active', 'Your Bluesnap module is very active', 'Partners'),
(65, 1, 'Desjardins installed', 'You have installed the Desjardins module', 'Partners'),
(66, 1, 'Desjardins configured', 'You have configured the Desjardins module', 'Partners'),
(67, 1, 'Desjardins active', 'Your Desjardins module is active', 'Partners'),
(68, 1, 'Desjardins very active', 'Your Desjardins module is very active', 'Partners'),
(69, 1, 'First Data installed', 'You have installed the First Data module', 'Partners'),
(70, 1, 'First Data configured', 'You have configured the First Data module', 'Partners'),
(71, 1, 'First Data active', 'Your First Data module is active', 'Partners'),
(72, 1, 'First Data very active', 'Your First Data module is very active', 'Partners'),
(73, 1, 'Give.it installed', 'You have installed the Give.it module', 'Partners'),
(74, 1, 'Give.it configured', 'You have configured the Give.it module', 'Partners'),
(75, 1, 'Give.it active', 'Your Give.it module is active', 'Partners'),
(76, 1, 'Give.it very active', 'Your Give.it module is very active', 'Partners'),
(77, 1, 'Google Analytics installed', 'You have installed the Google Analytics module', 'Partners'),
(78, 1, 'Google Analytics configured', 'You have configured the Google Analytics module', 'Partners'),
(79, 1, 'Google Analytics active', 'Your Google Analytics module is active', 'Partners'),
(80, 1, 'Google Analytics very active', 'Your Google Analytics module is very active', 'Partners'),
(81, 1, 'PagSeguro installed', 'You have installed the PagSeguro module', 'Partners'),
(82, 1, 'PagSeguro configured', 'You have configured the PagSeguro module', 'Partners'),
(83, 1, 'PagSeguro active', 'Your PagSeguro module is active', 'Partners'),
(84, 1, 'PagSeguro very active', 'Your PagSeguro module is very active', 'Partners'),
(85, 1, 'Paypal MX installed', 'You have installed the Paypal MX module', 'Partners'),
(86, 1, 'Paypal MX configured', 'You have configured the Paypal MX module', 'Partners'),
(87, 1, 'Paypal MX active', 'Your Paypal MX module is active', 'Partners'),
(88, 1, 'Paypal MX very active', 'Your Paypal MX module is very active', 'Partners'),
(89, 1, 'Paypal USA installed', 'You have installed the Paypal USA module', 'Partners'),
(90, 1, 'Paypal USA configured', 'You have configured the Paypal USA module', 'Partners'),
(91, 1, 'Paypal USA active', 'Your Paypal USA module is active', 'Partners'),
(92, 1, 'Paypal USA very active', 'Your Paypal USA module is very active', 'Partners'),
(93, 1, 'PayULatam installed', 'You have installed the PayULatam module', 'Partners'),
(94, 1, 'PayULatam configured', 'You have configured the PayULatam module', 'Partners'),
(95, 1, 'PayULatam active', 'Your PayULatam module is active', 'Partners'),
(96, 1, 'PayULatam very active', 'Your PayULatam module is very active', 'Partners'),
(97, 1, 'PrestaStats installed', 'You have installed the PrestaStats module', 'Partners'),
(98, 1, 'PrestaStats configured', 'You have configured the PrestaStats module', 'Partners'),
(99, 1, 'PrestaStats active', 'Your PrestaStats module is active', 'Partners'),
(100, 1, 'PrestaStats very active', 'Your PrestaStats module is very active', 'Partners'),
(101, 1, 'Riskified installed', 'You have installed the Riskified module', 'Partners'),
(102, 1, 'Riskified configured', 'You have configured the Riskified module', 'Partners'),
(103, 1, 'Riskified active', 'Your Riskified module is active', 'Partners'),
(104, 1, 'Riskified very active', 'Your Riskified module is very active', 'Partners'),
(105, 1, 'Simplify installed', 'You have installed the Simplify module', 'Partners'),
(106, 1, 'Simplify configured', 'You have configured the Simplify module', 'Partners'),
(107, 1, 'Simplify active', 'Your Simplify module is active', 'Partners'),
(108, 1, 'Simplify very active', 'Your Simplify module is very active', 'Partners'),
(109, 1, 'VTPayment installed', 'You have installed the VTPayment module', 'Partners'),
(110, 1, 'VTPayment configured', 'You have configured the VTPayment module', 'Partners'),
(111, 1, 'VTPayment active', 'Your VTPayment module is active', 'Partners'),
(112, 1, 'VTPayment very active', 'Your VTPayment module is very active', 'Partners'),
(113, 1, 'Yotpo installed', 'You have installed the Yotpo module', 'Partners'),
(114, 1, 'Yotpo configured', 'You have configured the Yotpo module', 'Partners'),
(115, 1, 'Yotpo active', 'Your Yotpo module is active', 'Partners'),
(116, 1, 'Yotpo very active', 'Your Yotpo module is very active', 'Partners'),
(117, 1, 'Youstice installed', 'You have installed the Youstice module', 'Partners'),
(118, 1, 'Youstice configured', 'You have configured the Youstice module', 'Partners'),
(119, 1, 'Youstice active', 'Your Youstice module is active', 'Partners'),
(120, 1, 'Youstice very active', 'Your Youstice module is very active', 'Partners'),
(121, 1, 'Loyalty Lion installed', 'You have installed the Loyalty Lion module', 'Partners'),
(122, 1, 'Loyalty Lion configured', 'You have configured the Loyalty Lion module', 'Partners'),
(123, 1, 'Loyalty Lion active', 'Your Loyalty Lion module is active', 'Partners'),
(124, 1, 'Loyalty Lion very active', 'Your Loyalty Lion module is very active', 'Partners'),
(125, 1, 'SEO', 'You enabled the URL rewriting through the tab \"Preferences > SEO and URLs\".', 'SEO'),
(126, 1, 'Site Performance', 'You enabled CCC (Combine, Compress and Cache), Rijndael and Smarty through the tab \r\nAdvanced Parameters > Performance.', 'Site Performance'),
(127, 1, 'Site Performance', 'You enabled media servers through the tab \"Advanced parameters > Performance\".', 'Site Performance'),
(128, 1, 'Payment', 'You configured a payment solution on your shop.', 'Payment'),
(129, 1, 'Payment', 'You offer two different payment methods to your customers.', 'Payment'),
(130, 1, 'Shipping', 'You configured a carrier on your shop.', 'Shipping'),
(131, 1, 'Shipping', 'You offer two shipping solutions (carriers) to your customers.', 'Shipping'),
(132, 1, 'Catalog Size', 'You added your first product to your catalog!', 'Catalog Size'),
(133, 1, 'Catalog Size', 'You have 10 products within your catalog.', 'Catalog Size'),
(134, 1, 'Contact information', 'You configured your phone number so your customers can reach you!', 'Contact information'),
(135, 1, 'Contact information', 'You added a third email address to your contact form.', 'Contact information'),
(136, 1, 'Contact information', 'You suggest a total of 5 departments to be reached by your customers via your contact form.', 'Contact information'),
(137, 1, 'Catalog Size', 'You have 100 products within your catalog.', 'Catalog Size'),
(138, 1, 'Catalog Size', 'You have 1,000 products within your catalog.', 'Catalog Size'),
(139, 1, 'Catalog Size', 'You have 10,000 products within your catalog.', 'Catalog Size'),
(140, 1, 'Catalog Size', 'You have 100,000 products within your catalog.', 'Catalog Size'),
(141, 1, 'Days of Experience', 'You just installed PrestaShop!', 'Days of Experience'),
(142, 1, 'Days of Experience', 'You installed PrestaShop a week ago!', 'Days of Experience'),
(143, 1, 'Customization', 'You uploaded your own logo.', 'Customization'),
(144, 1, 'Customization', 'You installed a new template.', 'Customization'),
(145, 1, 'Addons', 'You connected your back-office to the Addons platform using your PrestaShop Addons account.', 'Addons'),
(146, 1, 'Multistores', 'You enabled the Multistores feature.', 'Multistores'),
(147, 1, 'Multistores', 'You manage two shops with the Multistores feature.', 'Multistores'),
(148, 1, 'Multistores', 'You manage two different groups of shops using the Multistores feature.', 'Multistores'),
(149, 1, 'Multistores', 'You manage five shops with the Multistores feature.', 'Multistores'),
(150, 1, 'Multistores', 'You manage five different groups of shops using the Multistores feature.', 'Multistores'),
(151, 1, 'Shipping', 'You offer three different shipping solutions (carriers) to your customers.', 'Shipping'),
(152, 1, 'Payment', 'You offer three different payment methods to your customers.', 'Payment'),
(153, 1, 'Revenue', 'You get this badge when you reach 200 USD in sales.', 'Revenue'),
(154, 1, 'Revenue', 'You get this badge when you reach 1000 USD in sales.', 'Revenue'),
(155, 1, 'Revenue', 'You get this badge when you reach 1000 USD in sales.', 'Revenue'),
(156, 1, 'Revenue', 'You get this badge when you reach 200 USD in sales.', 'Revenue'),
(157, 1, 'Revenue', 'You get this badge when you reach 1000 USD in sales.', 'Revenue'),
(158, 1, 'Revenue', 'You get this badge when you reach 1000 USD in sales.', 'Revenue'),
(159, 1, 'Days of Experience', 'You installed PrestaShop a month ago!', 'Days of Experience'),
(160, 1, 'Days of Experience', 'You installed PrestaShop six months ago!', 'Days of Experience'),
(161, 1, 'Days of Experience', 'You installed PrestaShop a year ago!', 'Days of Experience'),
(162, 1, 'Days of Experience', 'You installed PrestaShop two years ago!', 'Days of Experience'),
(163, 1, 'Visitors', 'You reached 10 visitors!', 'Visitors'),
(164, 1, 'Visitors', 'You reached 100 visitors!', 'Visitors'),
(165, 1, 'Visitors', 'You reached 1,000 visitors!', 'Visitors'),
(166, 1, 'Visitors', 'You reached 10,000 visitors!', 'Visitors'),
(167, 1, 'Visitors', 'You reached 100,000 visitors!', 'Visitors'),
(168, 1, 'Visitors', 'You reached 1,000,000 visitors!', 'Visitors'),
(169, 1, 'Customer Carts', 'Two carts have been created by visitors', 'Customer Carts'),
(170, 1, 'Customer Carts', 'Ten carts have been created by visitors.', 'Customer Carts'),
(171, 1, 'Customer Carts', 'A hundred carts have been created by visitors on your shop.', 'Customer Carts'),
(172, 1, 'Customer Carts', 'A thousand carts have been created by visitors on your shop.', 'Customer Carts'),
(173, 1, 'Customer Carts', '10,000 carts have been created by visitors.', 'Customer Carts'),
(174, 1, 'Customer Carts', '100,000 carts have been created by visitors.', 'Customer Carts'),
(175, 1, 'Orders', 'You received your first order.', 'Orders'),
(176, 1, 'Orders', '10 orders have been placed through your online shop.', 'Orders'),
(177, 1, 'Orders', 'You received 100 orders through your online shop!', 'Orders'),
(178, 1, 'Orders', 'You received 1,000 orders through your online shop, congrats!', 'Orders'),
(179, 1, 'Orders', 'You received 10,000 orders through your online shop, cheers!', 'Orders'),
(180, 1, 'Orders', 'You received 100,000 orders through your online shop!', 'Orders'),
(181, 1, 'Customer Service Threads', 'You received  your first customer\'s message.', 'Customer Service Threads'),
(182, 1, 'Customer Service Threads', 'You received 10 messages from your customers.', 'Customer Service Threads'),
(183, 1, 'Customer Service Threads', 'You received 100 messages from your customers.', 'Customer Service Threads'),
(184, 1, 'Customer Service Threads', 'You received 1,000 messages from your customers.', 'Customer Service Threads'),
(185, 1, 'Customer Service Threads', 'You received 10,000 messages from your customers.', 'Customer Service Threads'),
(186, 1, 'Customer Service Threads', 'You received 100,000 messages from your customers.', 'Customer Service Threads'),
(187, 1, 'Customers', 'You got the first customer registered on your shop!', 'Customers'),
(188, 1, 'Customers', 'You have over 10 customers registered on your shop.', 'Customers'),
(189, 1, 'Customers', 'You have over 100 customers registered on your shop.', 'Customers'),
(190, 1, 'Customers', 'You have over 1,000 customers registered on your shop.', 'Customers'),
(191, 1, 'Customers', 'You have over 10,000 customers registered on your shop.', 'Customers'),
(192, 1, 'Customers', 'You have over 100,000 customers registered on your shop.', 'Customers'),
(193, 1, 'North America', 'You got your first sale in North America', 'North America'),
(194, 1, 'Oceania', 'You got your first sale in Oceania', 'Oceania'),
(195, 1, 'Asia', 'You got your first sale in Asia', 'Asia'),
(196, 1, 'South America', 'You got your first sale in South America', 'South America'),
(197, 1, 'Europe', 'You got your first sale in  Europe!', 'Europe'),
(198, 1, 'Africa', 'You got your first sale in Africa', 'Africa'),
(199, 1, 'Maghreb', 'You got your first sale in Maghreb', 'Maghreb'),
(200, 1, 'Your Team\'s Employees', 'First employee account added to your shop', 'Your Team\'s Employees'),
(201, 1, 'Your Team\'s Employees', '3 employee accounts added to your shop', 'Your Team\'s Employees'),
(202, 1, 'Your Team\'s Employees', '5 employee accounts added to your shop', 'Your Team\'s Employees'),
(203, 1, 'Your Team\'s Employees', '10 employee accounts added to your shop', 'Your Team\'s Employees'),
(204, 1, 'Your Team\'s Employees', '20 employee accounts added to your shop', 'Your Team\'s Employees'),
(205, 1, 'Your Team\'s Employees', '40 employee accounts added to your shop', 'Your Team\'s Employees'),
(206, 1, 'Product Pictures', 'First photo added to your catalog', 'Product Pictures'),
(207, 1, 'Product Pictures', '50 photos added to your catalog', 'Product Pictures'),
(208, 1, 'Product Pictures', '100 photos added to your catalog', 'Product Pictures'),
(209, 1, 'Product Pictures', '1,000 photos added to your catalog', 'Product Pictures'),
(210, 1, 'Product Pictures', '10,000 photos added to your catalog', 'Product Pictures'),
(211, 1, 'Product Pictures', '50,000 photos added to your catalog', 'Product Pictures'),
(212, 1, 'Customization', 'First CMS page added to your catalog', 'Customization'),
(213, 1, 'Cart Rules', 'First cart rules configured on your shop', 'Cart Rules'),
(214, 1, 'Cart Rules', 'You have 10 cart rules configured on your shop', 'Cart Rules'),
(215, 1, 'Cart Rules', 'You have 100 cart rules configured on your shop', 'Cart Rules'),
(216, 1, 'Cart Rules', 'You have 500 cart rules configured on your shop', 'Cart Rules'),
(217, 1, 'Cart Rules', 'You have 1,000 cart rules configured on your shop', 'Cart Rules'),
(218, 1, 'Cart Rules', 'You have 5,000 cart rules configured on your shop', 'Cart Rules'),
(219, 1, 'International Orders', 'First international order placed on your shop.', 'International Orders'),
(220, 1, 'International Orders', '10 international orders placed on your shop.', 'International Orders'),
(221, 1, 'International Orders', '100 international orders placed on your shop!', 'International Orders'),
(222, 1, 'International Orders', '1,000 international orders placed on your shop!', 'International Orders'),
(223, 1, 'International Orders', '5,000 international orders placed on your shop!', 'International Orders'),
(224, 1, 'International Orders', '10,000 international orders placed on your shop!', 'International Orders'),
(225, 1, 'Store', 'First store configured on your shop!', 'Store'),
(226, 1, 'Store', 'You have 2 stores configured on your shop', 'Store'),
(227, 1, 'Store', 'You have 5 stores configured on your shop', 'Store'),
(228, 1, 'Store', 'You have 10 stores configured on your shop', 'Store'),
(229, 1, 'Store', 'You have 20 stores configured on your shop', 'Store'),
(230, 1, 'Store', 'You have 50 stores configured on your shop', 'Store'),
(231, 1, 'Webservice x1', 'First webservice account added to your shop', 'WebService'),
(232, 1, 'Webservice x2', '2 webservice accounts added to your shop', 'WebService'),
(233, 1, 'Webservice x3', '3 webservice accounts added to your shop', 'WebService'),
(234, 1, 'Webservice x4', '4 webservice accounts added to your shop', 'WebService');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_blockwishlist_statistics`
--

CREATE TABLE `ps_blockwishlist_statistics` (
  `id_statistics` int(10) UNSIGNED NOT NULL,
  `id_cart` int(10) UNSIGNED DEFAULT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_product_attribute` int(10) UNSIGNED NOT NULL,
  `date_add` datetime NOT NULL,
  `id_shop` int(10) UNSIGNED DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_carrier`
--

CREATE TABLE `ps_carrier` (
  `id_carrier` int(10) UNSIGNED NOT NULL,
  `id_reference` int(10) UNSIGNED NOT NULL,
  `id_tax_rules_group` int(10) UNSIGNED DEFAULT 0,
  `name` varchar(64) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `shipping_handling` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `range_behavior` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `is_module` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `is_free` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `shipping_external` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `need_range` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `external_module_name` varchar(64) DEFAULT NULL,
  `shipping_method` int(2) NOT NULL DEFAULT 0,
  `position` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `max_width` int(10) DEFAULT 0,
  `max_height` int(10) DEFAULT 0,
  `max_depth` int(10) DEFAULT 0,
  `max_weight` decimal(20,6) DEFAULT 0.000000,
  `grade` int(10) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_carrier`
--

INSERT INTO `ps_carrier` (`id_carrier`, `id_reference`, `id_tax_rules_group`, `name`, `url`, `active`, `deleted`, `shipping_handling`, `range_behavior`, `is_module`, `is_free`, `shipping_external`, `need_range`, `external_module_name`, `shipping_method`, `position`, `max_width`, `max_height`, `max_depth`, `max_weight`, `grade`) VALUES
(1, 1, 0, '0', '', 1, 0, 0, 0, 0, 1, 0, 0, '', 0, 0, 0, 0, 0, '0.000000', 0),
(2, 2, 0, 'My carrier', '', 1, 0, 1, 0, 0, 0, 0, 0, '', 0, 1, 0, 0, 0, '0.000000', 0),
(3, 3, 0, 'My cheap carrier', '', 0, 0, 1, 0, 0, 0, 0, 0, '', 2, 2, 0, 0, 0, '0.000000', 0),
(4, 4, 0, 'My light carrier', '', 0, 0, 1, 0, 0, 0, 0, 0, '', 1, 3, 0, 0, 0, '0.000000', 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_carrier_group`
--

CREATE TABLE `ps_carrier_group` (
  `id_carrier` int(10) UNSIGNED NOT NULL,
  `id_group` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_carrier_group`
--

INSERT INTO `ps_carrier_group` (`id_carrier`, `id_group`) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 1),
(2, 2),
(2, 3),
(3, 1),
(3, 2),
(3, 3),
(4, 1),
(4, 2),
(4, 3);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_carrier_lang`
--

CREATE TABLE `ps_carrier_lang` (
  `id_carrier` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `delay` varchar(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_carrier_lang`
--

INSERT INTO `ps_carrier_lang` (`id_carrier`, `id_shop`, `id_lang`, `delay`) VALUES
(1, 1, 1, 'Odbiór w sklepie'),
(2, 1, 1, 'Dostawa następnego dnia!'),
(3, 1, 1, 'Buy more to pay less!'),
(4, 1, 1, 'The lighter the cheaper!');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_carrier_shop`
--

CREATE TABLE `ps_carrier_shop` (
  `id_carrier` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_carrier_shop`
--

INSERT INTO `ps_carrier_shop` (`id_carrier`, `id_shop`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_carrier_tax_rules_group_shop`
--

CREATE TABLE `ps_carrier_tax_rules_group_shop` (
  `id_carrier` int(11) UNSIGNED NOT NULL,
  `id_tax_rules_group` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_carrier_tax_rules_group_shop`
--

INSERT INTO `ps_carrier_tax_rules_group_shop` (`id_carrier`, `id_tax_rules_group`, `id_shop`) VALUES
(1, 1, 1),
(2, 1, 1),
(3, 1, 1),
(4, 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_carrier_zone`
--

CREATE TABLE `ps_carrier_zone` (
  `id_carrier` int(10) UNSIGNED NOT NULL,
  `id_zone` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_carrier_zone`
--

INSERT INTO `ps_carrier_zone` (`id_carrier`, `id_zone`) VALUES
(1, 1),
(2, 1),
(2, 2),
(3, 1),
(3, 2),
(4, 1),
(4, 2);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart`
--

CREATE TABLE `ps_cart` (
  `id_cart` int(10) UNSIGNED NOT NULL,
  `id_shop_group` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_carrier` int(10) UNSIGNED NOT NULL,
  `delivery_option` text NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `id_address_delivery` int(10) UNSIGNED NOT NULL,
  `id_address_invoice` int(10) UNSIGNED NOT NULL,
  `id_currency` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED NOT NULL,
  `id_guest` int(10) UNSIGNED NOT NULL,
  `secure_key` varchar(32) NOT NULL DEFAULT '-1',
  `recyclable` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `gift` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `gift_message` text DEFAULT NULL,
  `mobile_theme` tinyint(1) NOT NULL DEFAULT 0,
  `allow_seperated_package` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `checkout_session_data` mediumtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_cart`
--

INSERT INTO `ps_cart` (`id_cart`, `id_shop_group`, `id_shop`, `id_carrier`, `delivery_option`, `id_lang`, `id_address_delivery`, `id_address_invoice`, `id_currency`, `id_customer`, `id_guest`, `secure_key`, `recyclable`, `gift`, `gift_message`, `mobile_theme`, `allow_seperated_package`, `date_add`, `date_upd`, `checkout_session_data`) VALUES
(1, 1, 1, 2, '{\"3\":\"2,\"}', 1, 5, 5, 1, 2, 1, 'b44a6d9efd7a0076a0fbce6b15eaf3b1', 0, 0, '', 0, 0, '2022-12-08 17:57:53', '2022-12-08 17:57:53', NULL),
(2, 1, 1, 2, '{\"3\":\"2,\"}', 1, 5, 5, 1, 2, 1, 'b44a6d9efd7a0076a0fbce6b15eaf3b1', 0, 0, '', 0, 0, '2022-12-08 17:57:53', '2022-12-08 17:57:53', NULL),
(3, 1, 1, 2, '{\"3\":\"2,\"}', 1, 5, 5, 1, 2, 1, 'b44a6d9efd7a0076a0fbce6b15eaf3b1', 0, 0, '', 0, 0, '2022-12-08 17:57:53', '2022-12-08 17:57:53', NULL),
(4, 1, 1, 2, '{\"3\":\"2,\"}', 1, 5, 5, 1, 2, 1, 'b44a6d9efd7a0076a0fbce6b15eaf3b1', 0, 0, '', 0, 0, '2022-12-08 17:57:53', '2022-12-08 17:57:53', NULL),
(5, 1, 1, 2, '{\"3\":\"2,\"}', 1, 5, 5, 1, 2, 1, 'b44a6d9efd7a0076a0fbce6b15eaf3b1', 0, 0, '', 0, 0, '2022-12-08 17:57:53', '2022-12-08 17:57:53', NULL),
(6, 1, 1, 1, '{\"7\":\"1,\"}', 1, 7, 7, 1, 3, 5, 'b885af361da62e482e0e364032815c50', 0, 0, '', 0, 0, '2022-12-11 22:12:00', '2022-12-11 22:12:56', '{\"checkout-personal-information-step\":{\"step_is_reachable\":true,\"step_is_complete\":true},\"checkout-addresses-step\":{\"step_is_reachable\":true,\"step_is_complete\":true,\"use_same_address\":true},\"checkout-delivery-step\":{\"step_is_reachable\":true,\"step_is_complete\":true},\"checkout-payment-step\":{\"step_is_reachable\":true,\"step_is_complete\":false},\"checksum\":\"5e50c3329807886b43e00ad1610ede9ee1e5678d\"}'),
(7, 1, 1, 1, '{\"8\":\"1,\"}', 1, 8, 8, 1, 4, 5, '863d7e3c891ee774ba8d40fc9c7ce121', 0, 0, '', 0, 0, '2022-12-11 22:15:37', '2022-12-11 22:16:06', '{\"checkout-personal-information-step\":{\"step_is_reachable\":true,\"step_is_complete\":true},\"checkout-addresses-step\":{\"step_is_reachable\":true,\"step_is_complete\":true,\"use_same_address\":true},\"checkout-delivery-step\":{\"step_is_reachable\":true,\"step_is_complete\":true},\"checkout-payment-step\":{\"step_is_reachable\":true,\"step_is_complete\":false},\"checksum\":\"9905c94ca6d9f5de0a7db1f2d2b0a3362ae7f8c3\"}');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_cart_rule`
--

CREATE TABLE `ps_cart_cart_rule` (
  `id_cart` int(10) UNSIGNED NOT NULL,
  `id_cart_rule` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_product`
--

CREATE TABLE `ps_cart_product` (
  `id_cart` int(10) UNSIGNED NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_address_delivery` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_shop` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `id_product_attribute` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_customization` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_rule`
--

CREATE TABLE `ps_cart_rule` (
  `id_cart_rule` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_from` datetime NOT NULL,
  `date_to` datetime NOT NULL,
  `description` text DEFAULT NULL,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `quantity_per_user` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `priority` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `partial_use` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `code` varchar(254) NOT NULL,
  `minimum_amount` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minimum_amount_tax` tinyint(1) NOT NULL DEFAULT 0,
  `minimum_amount_currency` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `minimum_amount_shipping` tinyint(1) NOT NULL DEFAULT 0,
  `country_restriction` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `carrier_restriction` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `group_restriction` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `cart_rule_restriction` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `product_restriction` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `shop_restriction` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `free_shipping` tinyint(1) NOT NULL DEFAULT 0,
  `reduction_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `reduction_amount` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `reduction_tax` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `reduction_currency` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `reduction_product` int(10) NOT NULL DEFAULT 0,
  `reduction_exclude_special` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `gift_product` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `gift_product_attribute` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `highlight` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_rule_carrier`
--

CREATE TABLE `ps_cart_rule_carrier` (
  `id_cart_rule` int(10) UNSIGNED NOT NULL,
  `id_carrier` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_rule_combination`
--

CREATE TABLE `ps_cart_rule_combination` (
  `id_cart_rule_1` int(10) UNSIGNED NOT NULL,
  `id_cart_rule_2` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_rule_country`
--

CREATE TABLE `ps_cart_rule_country` (
  `id_cart_rule` int(10) UNSIGNED NOT NULL,
  `id_country` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_rule_group`
--

CREATE TABLE `ps_cart_rule_group` (
  `id_cart_rule` int(10) UNSIGNED NOT NULL,
  `id_group` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_rule_lang`
--

CREATE TABLE `ps_cart_rule_lang` (
  `id_cart_rule` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(254) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_rule_product_rule`
--

CREATE TABLE `ps_cart_rule_product_rule` (
  `id_product_rule` int(10) UNSIGNED NOT NULL,
  `id_product_rule_group` int(10) UNSIGNED NOT NULL,
  `type` enum('products','categories','attributes','manufacturers','suppliers') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_rule_product_rule_group`
--

CREATE TABLE `ps_cart_rule_product_rule_group` (
  `id_product_rule_group` int(10) UNSIGNED NOT NULL,
  `id_cart_rule` int(10) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_rule_product_rule_value`
--

CREATE TABLE `ps_cart_rule_product_rule_value` (
  `id_product_rule` int(10) UNSIGNED NOT NULL,
  `id_item` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cart_rule_shop`
--

CREATE TABLE `ps_cart_rule_shop` (
  `id_cart_rule` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_category`
--

CREATE TABLE `ps_category` (
  `id_category` int(10) UNSIGNED NOT NULL,
  `id_parent` int(10) UNSIGNED NOT NULL,
  `id_shop_default` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `level_depth` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `nleft` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `nright` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_root_category` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_category`
--

INSERT INTO `ps_category` (`id_category`, `id_parent`, `id_shop_default`, `level_depth`, `nleft`, `nright`, `active`, `date_add`, `date_upd`, `position`, `is_root_category`) VALUES
(1, 0, 1, 0, 1, 18, 1, '2022-12-08 17:56:28', '2022-12-08 17:56:28', 0, 0),
(2, 1, 1, 1, 2, 17, 1, '2022-12-08 17:56:29', '2022-12-08 17:56:29', 0, 1),
(33, 2, 1, 2, 3, 16, 1, '2022-12-11 22:54:04', '2022-12-11 22:54:04', 0, 0),
(34, 33, 1, 3, 4, 15, 1, '2022-12-11 22:54:04', '2022-12-11 22:54:04', 0, 0),
(35, 34, 1, 4, 5, 6, 1, '2022-12-11 22:54:04', '2022-12-11 22:54:04', 0, 0),
(36, 34, 1, 4, 7, 8, 1, '2022-12-11 22:54:04', '2022-12-11 22:54:04', 1, 0),
(37, 34, 1, 4, 9, 10, 1, '2022-12-11 22:54:04', '2022-12-11 22:54:04', 2, 0),
(38, 34, 1, 4, 11, 12, 1, '2022-12-11 22:54:04', '2022-12-11 22:54:04', 3, 0),
(39, 34, 1, 4, 13, 14, 1, '2022-12-11 22:54:04', '2022-12-11 22:54:04', 4, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_category_group`
--

CREATE TABLE `ps_category_group` (
  `id_category` int(10) UNSIGNED NOT NULL,
  `id_group` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_category_group`
--

INSERT INTO `ps_category_group` (`id_category`, `id_group`) VALUES
(2, 0),
(2, 1),
(2, 2),
(2, 3),
(33, 1),
(33, 2),
(33, 3),
(34, 1),
(34, 2),
(34, 3),
(35, 1),
(35, 2),
(35, 3),
(36, 1),
(36, 2),
(36, 3),
(37, 1),
(37, 2),
(37, 3),
(38, 1),
(38, 2),
(38, 3),
(39, 1),
(39, 2),
(39, 3);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_category_lang`
--

CREATE TABLE `ps_category_lang` (
  `id_category` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `link_rewrite` varchar(128) NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_category_lang`
--

INSERT INTO `ps_category_lang` (`id_category`, `id_shop`, `id_lang`, `name`, `description`, `link_rewrite`, `meta_title`, `meta_keywords`, `meta_description`) VALUES
(1, 1, 1, 'Baza', '', 'baza', '', '', ''),
(2, 1, 1, 'Strona główna', '', 'strona-glowna', '', '', ''),
(33, 1, 1, 'Kategorie', '', 'kategorie', '', '', ''),
(34, 1, 1, 'Projektowanie', '', 'projektowanie', '', '', ''),
(35, 1, 1, 'Projektowanie graficzne i ilustrowanie', '', 'projektowanie-graficzne-i-ilustrowanie', '', '', ''),
(36, 1, 1, 'Projektowanie stron internetowych', '', 'projektowanie-stron-internetowych', '', '', ''),
(37, 1, 1, 'Narzędzia projektowe', '', 'narzedzia-projektowe', '', '', ''),
(38, 1, 1, 'Projektowanie doświadczeń użytkownika', '', 'projektowanie-doswiadczen-uzytkownika', '', '', ''),
(39, 1, 1, '3D i animacja', '', '3d-i-animacja', '', '', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_category_product`
--

CREATE TABLE `ps_category_product` (
  `id_category` int(10) UNSIGNED NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_category_product`
--

INSERT INTO `ps_category_product` (`id_category`, `id_product`, `position`) VALUES
(1, 25, 1),
(1, 26, 2),
(1, 27, 3),
(1, 28, 4),
(1, 29, 5),
(1, 30, 6),
(1, 31, 7),
(1, 32, 8),
(1, 33, 9),
(1, 34, 10),
(1, 35, 11),
(1, 36, 12),
(1, 37, 13),
(1, 38, 14),
(2, 25, 1),
(2, 26, 2),
(2, 27, 3),
(2, 28, 4),
(2, 29, 5),
(2, 30, 6),
(2, 31, 7),
(2, 32, 8),
(2, 33, 9),
(2, 34, 10),
(2, 35, 11),
(2, 36, 12),
(2, 37, 13),
(2, 38, 14),
(33, 25, 1),
(33, 26, 2),
(33, 27, 3),
(33, 28, 4),
(33, 29, 5),
(33, 30, 6),
(33, 31, 7),
(33, 32, 8),
(33, 33, 9),
(33, 34, 10),
(33, 35, 11),
(33, 36, 12),
(33, 37, 13),
(33, 38, 14),
(34, 25, 1),
(34, 26, 2),
(34, 27, 3),
(34, 28, 4),
(34, 29, 5),
(34, 30, 6),
(34, 31, 7),
(34, 32, 8),
(34, 33, 9),
(34, 34, 10),
(34, 35, 11),
(34, 36, 12),
(34, 37, 13),
(34, 38, 14),
(35, 25, 1),
(35, 26, 2),
(35, 28, 3),
(35, 30, 4),
(35, 33, 5),
(36, 27, 1),
(36, 36, 2),
(36, 37, 3),
(36, 38, 4),
(37, 29, 1),
(37, 35, 2),
(38, 31, 1),
(39, 32, 1),
(39, 34, 2);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_category_shop`
--

CREATE TABLE `ps_category_shop` (
  `id_category` int(11) NOT NULL,
  `id_shop` int(11) NOT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_category_shop`
--

INSERT INTO `ps_category_shop` (`id_category`, `id_shop`, `position`) VALUES
(1, 1, 0),
(2, 1, 0),
(33, 1, 0),
(34, 1, 0),
(35, 1, 0),
(36, 1, 1),
(37, 1, 2),
(38, 1, 3),
(39, 1, 4);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cms`
--

CREATE TABLE `ps_cms` (
  `id_cms` int(10) UNSIGNED NOT NULL,
  `id_cms_category` int(10) UNSIGNED NOT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `indexation` tinyint(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_cms`
--

INSERT INTO `ps_cms` (`id_cms`, `id_cms_category`, `position`, `active`, `indexation`) VALUES
(1, 1, 0, 1, 0),
(2, 1, 1, 1, 0),
(3, 1, 2, 1, 0),
(4, 1, 3, 1, 0),
(5, 1, 4, 1, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cms_category`
--

CREATE TABLE `ps_cms_category` (
  `id_cms_category` int(10) UNSIGNED NOT NULL,
  `id_parent` int(10) UNSIGNED NOT NULL,
  `level_depth` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_cms_category`
--

INSERT INTO `ps_cms_category` (`id_cms_category`, `id_parent`, `level_depth`, `active`, `date_add`, `date_upd`, `position`) VALUES
(1, 0, 1, 1, '2022-12-08 17:56:29', '2022-12-08 17:56:29', 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cms_category_lang`
--

CREATE TABLE `ps_cms_category_lang` (
  `id_cms_category` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `link_rewrite` varchar(128) NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_cms_category_lang`
--

INSERT INTO `ps_cms_category_lang` (`id_cms_category`, `id_lang`, `id_shop`, `name`, `description`, `link_rewrite`, `meta_title`, `meta_keywords`, `meta_description`) VALUES
(1, 1, 1, 'Strona główna', '', 'strona-glowna', '', '', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cms_category_shop`
--

CREATE TABLE `ps_cms_category_shop` (
  `id_cms_category` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_cms_category_shop`
--

INSERT INTO `ps_cms_category_shop` (`id_cms_category`, `id_shop`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cms_lang`
--

CREATE TABLE `ps_cms_lang` (
  `id_cms` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `meta_title` varchar(255) NOT NULL,
  `head_seo_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(512) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `link_rewrite` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_cms_lang`
--

INSERT INTO `ps_cms_lang` (`id_cms`, `id_lang`, `id_shop`, `meta_title`, `head_seo_title`, `meta_description`, `meta_keywords`, `content`, `link_rewrite`) VALUES
(1, 1, 1, 'Delivery', '', 'Our terms and conditions of delivery', 'conditions, delivery, delay, shipment, pack', '<h2>Shipments and returns</h2><h3>Your pack shipment</h3><p>Packages are generally dispatched within 2 days after receipt of payment and are shipped via UPS with tracking and drop-off without signature. If you prefer delivery by UPS Extra with required signature, an additional cost will be applied, so please contact us before choosing this method. Whichever shipment choice you make, we will provide you with a link to track your package online.</p><p>Shipping fees include handling and packing fees as well as postage costs. Handling fees are fixed, whereas transport fees vary according to total weight of the shipment. We advise you to group your items in one order. We cannot group two distinct orders placed separately, and shipping fees will apply to each of them. Your package will be dispatched at your own risk, but special care is taken to protect fragile objects.<br /><br />Boxes are amply sized and your items are well-protected.</p>', 'delivery'),
(2, 1, 1, 'Legal Notice', '', 'Legal notice', 'notice, legal, credits', '<h2>Legal</h2><h3>Credits</h3><p>Concept and production:</p><p>This Web site was created using <a href=\"http://www.prestashop.com\">PrestaShop</a>&trade; open-source software.</p>', 'legal-notice'),
(3, 1, 1, 'Terms and conditions of use', '', 'Our terms and conditions of use', 'conditions, terms, use, sell', '<h2>Your terms and conditions of use</h2><h3>Rule 1</h3><p>Here is the rule 1 content</p>\r\n<h3>Rule 2</h3><p>Here is the rule 2 content</p>\r\n<h3>Rule 3</h3><p>Here is the rule 3 content</p>', 'terms-and-conditions-of-use'),
(4, 1, 1, 'About us', '', 'Learn more about us', 'about us, informations', '<h2>About us</h2>\r\n<h3>Our company</h3><p>Our company</p>\r\n<h3>Our team</h3><p>Our team</p>\r\n<h3>Informations</h3><p>Informations</p>', 'about-us'),
(5, 1, 1, 'Secure payment', '', 'Our secure payment mean', 'secure payment, ssl, visa, mastercard, paypal', '<h2>Secure payment</h2>\r\n<h3>Our secure payment</h3><p>With SSL</p>\r\n<h3>Using Visa/Mastercard/Paypal</h3><p>About this services</p>', 'secure-payment');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cms_role`
--

CREATE TABLE `ps_cms_role` (
  `id_cms_role` int(11) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `id_cms` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_cms_role`
--

INSERT INTO `ps_cms_role` (`id_cms_role`, `name`, `id_cms`) VALUES
(1, 'LEGAL_CONDITIONS', 3),
(2, 'LEGAL_NOTICE', 2);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cms_role_lang`
--

CREATE TABLE `ps_cms_role_lang` (
  `id_cms_role` int(11) UNSIGNED NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_cms_shop`
--

CREATE TABLE `ps_cms_shop` (
  `id_cms` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_cms_shop`
--

INSERT INTO `ps_cms_shop` (`id_cms`, `id_shop`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_condition`
--

CREATE TABLE `ps_condition` (
  `id_condition` int(11) NOT NULL,
  `id_ps_condition` int(11) NOT NULL,
  `type` enum('configuration','install','sql') NOT NULL,
  `request` text DEFAULT NULL,
  `operator` varchar(32) DEFAULT NULL,
  `value` varchar(64) DEFAULT NULL,
  `result` varchar(64) DEFAULT NULL,
  `calculation_type` enum('hook','time') DEFAULT NULL,
  `calculation_detail` varchar(64) DEFAULT NULL,
  `validated` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_condition`
--

INSERT INTO `ps_condition` (`id_condition`, `id_ps_condition`, `type`, `request`, `operator`, `value`, `result`, `calculation_type`, `calculation_detail`, `validated`, `date_add`, `date_upd`) VALUES
(1, 1, 'configuration', 'PS_REWRITING_SETTINGS', '==', '1', '1', 'hook', 'actionAdminMetaControllerUpdate_optionsAfter', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(2, 2, 'configuration', 'PS_SMARTY_FORCE_COMPILE', '!=', '2', '1', 'hook', 'actionAdminPerformanceControllerSaveAfter', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(3, 3, 'configuration', 'PS_CSS_THEME_CACHE', '==', '1', '', 'hook', 'actionAdminPerformanceControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(4, 4, 'configuration', 'PS_CIPHER_ALGORITHM', '==', '1', '1', 'hook', 'actionAdminPerformanceControllerSaveAfter', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(5, 5, 'configuration', 'PS_MEDIA_SERVERS', '==', '1', '', 'hook', 'actionAdminPerformanceControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(6, 6, 'sql', 'SELECT COUNT(distinct m.id_module) FROM PREFIX_hook h LEFT JOIN PREFIX_hook_module hm ON h.id_hook = hm.id_hook LEFT JOIN PREFIX_module m ON hm.id_module = m.id_module\r\nWHERE (h.name = \"displayPayment\" OR h.name = \"payment\") AND m.name NOT IN (\"bankwire\", \"cheque\", \"cashondelivery\")', '>', '0', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(7, 7, 'sql', 'SELECT COUNT(distinct m.id_module) FROM PREFIX_hook h LEFT JOIN PREFIX_hook_module hm ON h.id_hook = hm.id_hook LEFT JOIN PREFIX_module m ON hm.id_module = m.id_module\r\nWHERE (h.name = \"displayPayment\" OR h.name = \"payment\") AND m.name NOT IN (\"bankwire\", \"cheque\", \"cashondelivery\")', '>', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(8, 8, 'sql', 'SELECT COUNT(*) FROM PREFIX_carrier WHERE name NOT IN (\"0\", \"My carrier\")', '>', '0', '2', 'hook', 'actionObjectCarrierAddAfter', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(9, 9, 'sql', 'SELECT COUNT(*) FROM PREFIX_carrier WHERE name NOT IN (\"0\", \"My carrier\")', '>', '1', '2', 'hook', 'actionObjectCarrierAddAfter', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(10, 10, 'sql', 'SELECT COUNT(*) FROM PREFIX_product WHERE reference NOT LIKE \"demo_%\"', '>', '0', '1', 'hook', 'actionObjectProductAddAfter', 1, '2022-12-08 18:28:25', '2022-12-11 22:48:33'),
(11, 11, 'sql', 'SELECT COUNT(*) FROM PREFIX_product WHERE reference NOT LIKE \"demo_%\"', '>', '9', '10', 'hook', 'actionObjectProductAddAfter', 1, '2022-12-08 18:28:25', '2022-12-11 22:54:22'),
(12, 12, 'sql', 'SELECT COUNT(*) FROM PREFIX_product WHERE reference NOT LIKE \"demo_%\"', '>', '99', '14', 'hook', 'actionObjectProductAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:55:05'),
(13, 13, 'sql', 'SELECT COUNT(*) FROM PREFIX_product WHERE reference NOT LIKE \"demo_%\"', '>', '999', '14', 'hook', 'actionObjectProductAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:55:05'),
(14, 14, 'sql', 'SELECT COUNT(*) FROM PREFIX_product WHERE reference NOT LIKE \"demo_%\"', '>', '9999', '14', 'hook', 'actionObjectProductAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:55:05'),
(15, 15, 'sql', 'SELECT COUNT(*) FROM PREFIX_product WHERE reference NOT LIKE \"demo_%\"', '>', '99999', '14', 'hook', 'actionObjectProductAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:55:05'),
(16, 16, 'configuration', 'PS_SHOP_PHONE', '!=', '0', '1', 'hook', 'actionAdminStoresControllerUpdate_optionsAfter', 1, '2022-12-08 18:28:25', '2022-12-11 22:42:57'),
(17, 17, 'sql', 'SELECT COUNT(*) FROM PREFIX_contact', '>', '2', '2', 'hook', 'actionObjectContactAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:42:57'),
(18, 18, 'sql', 'SELECT COUNT(*) FROM PREFIX_contact', '>', '4', '2', 'hook', 'actionObjectContactAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:42:57'),
(19, 19, 'install', '', '>', '0', '1', 'time', '1', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(20, 20, 'install', '', '>=', '7', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(21, 21, 'configuration', 'PS_LOGO', '!=', 'logo.jpg', '1', 'hook', 'actionAdminThemesControllerUpdate_optionsAfter', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(22, 22, 'sql', 'SELECT COUNT(*) FROM PREFIX_theme WHERE directory != \"default\" AND directory != \"prestashop\" AND directory ! \"default-bootstrap\"', '>', '0', '', 'hook', 'actionObjectShopUpdateAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:25'),
(23, 23, 'configuration', 'PS_LOGGED_ON_ADDONS', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(24, 24, 'configuration', 'PS_MULTISHOP_FEATURE_ACTIVE', '==', '1', '', 'hook', 'actionAdminPreferencesControllerUpdate_optionsAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(25, 25, 'sql', 'SELECT COUNT(*) FROM PREFIX_shop', '>', '1', '1', 'hook', 'actionObjectShopAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(26, 26, 'sql', 'SELECT COUNT(*) FROM PREFIX_shop', '>', '4', '1', 'hook', 'actionObjectShopAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(27, 27, 'sql', 'SELECT COUNT(*) FROM PREFIX_shop_group', '>', '5', '1', 'hook', 'actionObjectShopGroupAddAfter 	', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(28, 28, 'sql', 'SELECT COUNT(*) FROM PREFIX_shop_group', '>', '1', '1', 'hook', 'actionObjectShopGroupAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(29, 29, 'sql', 'SELECT COUNT(distinct m.id_module) FROM PREFIX_hook h LEFT JOIN PREFIX_hook_module hm ON h.id_hook = hm.id_hook LEFT JOIN PREFIX_module m ON hm.id_module = m.id_module\r\nWHERE (h.name = \"displayPayment\" OR h.name = \"payment\") AND m.name NOT IN (\"bankwire\", \"cheque\", \"cashondelivery\")', '>', '2', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(30, 30, 'sql', 'SELECT COUNT(*) FROM PREFIX_carrier WHERE name NOT IN (\"0\", \"My carrier\")', '>', '2', '2', 'hook', 'actionObjectCarrierAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:28'),
(31, 31, 'sql', 'SELECT SUM(total_paid_tax_excl / c.conversion_rate)\r\nFROM PREFIX_orders o INNER JOIN PREFIX_currency c ON c.id_currency = o.id_currency WHERE valid = 1 AND reference != \"XKBKNABJK\"', '>=', '200', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(32, 32, 'sql', ' 	SELECT SUM(total_paid_tax_excl / c.conversion_rate) FROM PREFIX_orders o INNER JOIN PREFIX_currency c ON c.id_currency = o.id_currency WHERE valid = 1 AND reference != \"XKBKNABJK\"', '>=', '2000', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(33, 33, 'sql', ' 	SELECT SUM(total_paid_tax_excl / c.conversion_rate) FROM PREFIX_orders o INNER JOIN PREFIX_currency c ON c.id_currency = o.id_currency WHERE valid = 1 AND reference != \"XKBKNABJK\"', '>=', '20000', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(34, 34, 'sql', ' 	SELECT SUM(total_paid_tax_excl / c.conversion_rate) FROM PREFIX_orders o INNER JOIN PREFIX_currency c ON c.id_currency = o.id_currency WHERE valid = 1', '>=', '200000', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(35, 35, 'sql', ' 	SELECT SUM(total_paid_tax_excl / c.conversion_rate) FROM PREFIX_orders o INNER JOIN PREFIX_currency c ON c.id_currency = o.id_currency WHERE valid = 1', '>=', '2000000', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(36, 36, 'sql', ' 	SELECT SUM(total_paid_tax_excl / c.conversion_rate) FROM PREFIX_orders o INNER JOIN PREFIX_currency c ON c.id_currency = o.id_currency WHERE valid = 1', '>=', '20000000', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(37, 37, 'install', '', '>=', '30', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(38, 38, 'install', '', '>=', '182', '', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(39, 39, 'install', '', '>=', '365', '', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(40, 40, 'install', '', '>=', '730', '', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(41, 41, 'sql', 'SELECT COUNT(*) FROM PREFIX_guest', '>=', '10', '4', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(42, 42, 'sql', 'SELECT COUNT(*) FROM PREFIX_guest', '>=', '100', '4', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(43, 43, 'sql', 'SELECT COUNT(*) FROM PREFIX_guest', '>=', '1000', '4', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(44, 44, 'sql', 'SELECT COUNT(*) FROM PREFIX_guest', '>=', '10000', '4', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(45, 45, 'sql', 'SELECT COUNT(*) FROM PREFIX_guest', '>=', '100000', '4', 'time', '3', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(46, 46, 'sql', 'SELECT COUNT(*) FROM PREFIX_guest', '>=', '1000000', '3', 'time', '4', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(47, 47, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart WHERE secure_key != \"b44a6d9efd7a0076a0fbce6b15eaf3b1\"', '>=', '2', '2', 'hook', 'actionObjectCartAddAfter', 1, '2022-12-08 18:28:25', '2022-12-11 22:15:37'),
(48, 48, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart WHERE secure_key != \"b44a6d9efd7a0076a0fbce6b15eaf3b1\"', '>=', '10', '2', 'hook', 'actionObjectCartAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:17:14'),
(49, 49, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart WHERE secure_key != \"b44a6d9efd7a0076a0fbce6b15eaf3b1\"', '>=', '100', '2', 'hook', 'actionObjectCartAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:17:14'),
(50, 50, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart WHERE secure_key != \"b44a6d9efd7a0076a0fbce6b15eaf3b1\"', '>=', '1000', '2', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:17:14'),
(51, 51, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart WHERE secure_key != \"b44a6d9efd7a0076a0fbce6b15eaf3b1\"', '>=', '10000', '2', 'time', '4', 0, '2022-12-08 18:28:25', '2022-12-11 22:17:14'),
(52, 52, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart WHERE secure_key != \"b44a6d9efd7a0076a0fbce6b15eaf3b1\"', '>=', '100000', '2', 'time', '8', 0, '2022-12-08 18:28:25', '2022-12-11 22:17:14'),
(53, 53, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders WHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\")', '>=', '1', '1', 'hook', 'actionObjectOrderAddAfter', 1, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(54, 54, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders WHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\")', '>=', '10', '1', 'hook', 'actionObjectOrderAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:14:16'),
(55, 55, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders WHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\")', '>=', '100', '1', 'hook', 'actionObjectOrderAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:14:16'),
(56, 56, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders WHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\")', '>=', '1000', '1', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:14:16'),
(57, 57, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders WHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\")', '>=', '10000', '1', 'time', '4', 0, '2022-12-08 18:28:25', '2022-12-11 22:14:16'),
(58, 58, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders WHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\")', '>=', '100000', '1', 'time', '8', 0, '2022-12-08 18:28:25', '2022-12-11 22:14:16'),
(59, 59, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer WHERE email != \"pub@prestashop.com\"', '>=', '1', '1', 'hook', 'actionObjectCustomerAddAfter', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(60, 60, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer WHERE email != \"pub@prestashop.com\"', '>=', '10', '3', 'hook', 'actionObjectCustomerAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:54'),
(61, 61, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer WHERE email != \"pub@prestashop.com\"', '>=', '100', '3', 'hook', 'actionObjectCustomerAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:54'),
(62, 62, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer WHERE email != \"pub@prestashop.com\"', '>=', '1000', '1', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(63, 63, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer WHERE email != \"pub@prestashop.com\"', '>=', '10000', '1', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(64, 64, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer WHERE email != \"pub@prestashop.com\"', '>=', '100000', '1', 'time', '4', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:28'),
(65, 65, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer_thread', '>=', '1', '0', 'hook', 'actionObjectCustomerThreadAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(66, 66, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer_thread', '>=', '10', '0', 'hook', 'actionObjectCustomerThreadAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(67, 67, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer_thread', '>=', '100', '0', 'hook', 'actionObjectCustomerThreadAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(68, 68, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer_thread', '>=', '1000', '0', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(69, 69, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer_thread', '>=', '10000', '0', 'time', '4', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(70, 70, 'sql', 'SELECT COUNT(*) FROM PREFIX_customer_thread', '>=', '100000', '0', 'time', '8', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(71, 76, 'sql', 'SELECT IFNULL(id_order, 0) FROM PREFIX_orders o LEFT JOIN PREFIX_address a ON o.id_address_delivery = a.id_address LEFT JOIN PREFIX_country c ON c.id_country = a.id_country WHERE o.valid = 1 AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\" AND c.iso_code IN (\r\n\"CA\",\r\n\"GL\",\r\n\"PM\",\r\n\"US\"\r\n)', '!=', '0', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(72, 79, 'sql', 'SELECT IFNULL(id_order, 0) FROM PREFIX_orders o LEFT JOIN PREFIX_address a ON o.id_address_delivery = a.id_address LEFT JOIN PREFIX_country c ON c.id_country = a.id_country WHERE o.valid = 1 AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\" AND c.iso_code IN (\r\n\"UM\",\r\n\"AS\",\r\n\"AU\",\r\n\"CK\",\r\n\"FJ\",\r\n\"FM\",\r\n\"GU\",\r\n\"KI\",\r\n\"MH,\"\r\n\"MP\",\r\n\"NC\",\r\n\"NF\",\r\n\"NR\",\r\n\"NU\",\r\n\"NZ\",\r\n\"PF\",\r\n\"PG\",\r\n\"PN\",\r\n\"PW\",\r\n\"SB\",\r\n\"TK\",\r\n\"TO\",\r\n\"TV\",\r\n\"VU\",\r\n\"WF\",\r\n\"WS\"\r\n)', '!=', '0', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(73, 85, 'sql', 'SELECT IFNULL(id_order, 0) FROM PREFIX_orders o LEFT JOIN PREFIX_address a ON o.id_address_delivery = a.id_address LEFT JOIN PREFIX_country c ON c.id_country = a.id_country WHERE o.valid = 1 AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\" AND c.iso_code IN (\r\n\"KG\",\r\n\"KZ\",\r\n\"TJ\",\r\n\"TM\",\r\n\"UZ\",\r\n\"AE\",\r\n\"AM\",\r\n\"AZ\",\r\n\"BH\",\r\n\"CY\",\r\n\"GE\",\r\n\"IL\",\r\n\"IQ\",\r\n\"IR\",\r\n\"JO\",\r\n\"KW\",\r\n\"LB\",\r\n\"OM\",\r\n\"QA\",\r\n\"SA\",\r\n\"SY\",\r\n\"TR\",\r\n\"YE\",\r\n\"AF\",\r\n\"BD\",\r\n\"BT\",\r\n\"IN\",\r\n\"IO\",\r\n\"LK\",\r\n\"MV\",\r\n\"NP\",\r\n\"PK\",\r\n\"CN\",\r\n\"HK\",\r\n\"JP\",\r\n\"KP\",\r\n\"KR\",\r\n\"MO\",\r\n\"TW\",\r\n\"MN\",\r\n\"BN\",\r\n\"CC\",\r\n\"CX\",\r\n\"ID\",\r\n\"KH\",\r\n\"LA\",\r\n\"MM\",\r\n\"MY\",\r\n\"PH\",\r\n\"SG\",\r\n\"TH\",\r\n\"TP\",\r\n\"VN\"\r\n)', '!=', '0', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(74, 86, 'sql', 'SELECT IFNULL(id_order, 0) FROM PREFIX_orders o LEFT JOIN PREFIX_address a ON o.id_address_delivery = a.id_address LEFT JOIN PREFIX_country c ON c.id_country = a.id_country WHERE o.valid = 1 AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\" AND c.iso_code IN (\r\n\"BZ\",\r\n\"CR\",\r\n\"GT\",\r\n\"HN\",\r\n\"MX\",\r\n\"NI\",\r\n\"PA\",\r\n\"SV\",\r\n\"AG\",\r\n\"AI\",\r\n\"AN\",\r\n\"AW\",\r\n\"BB\",\r\n\"BM\",\r\n\"BS\",\r\n\"CU\",\r\n\"DM\",\r\n\"DO\",\r\n\"GD\",\r\n\"GP\",\r\n\"HT\",\r\n\"JM\",\r\n\"KN\",\r\n\"KY\",\r\n\"LC\",\r\n\"MQ\",\r\n\"MS\",\r\n\"PR\",\r\n\"TC\",\r\n\"TT\",\r\n\"VC\",\r\n\"VG\",\r\n\"VI\",\r\n\"AR\",\r\n\"BO\",\r\n\"BR\",\r\n\"CL\",\r\n\"CO\",\r\n\"EC\",\r\n\"FK\",\r\n\"GF\",\r\n\"GY\",\r\n\"PE\",\r\n\"PY\",\r\n\"SR\",\r\n\"UY\",\r\n\"VE\"\r\n)', '!=', '0', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(75, 87, 'sql', 'SELECT IFNULL(id_order, 0) FROM PREFIX_orders o LEFT JOIN PREFIX_address a ON o.id_address_delivery = a.id_address LEFT JOIN PREFIX_country c ON c.id_country = a.id_country WHERE o.valid = 1 AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\" AND c.iso_code IN (\r\n\"BE\",\r\n\"DE\",\r\n\"FR\",\r\n\"FX\",\r\n\"GB\",\r\n\"IE\",\r\n\"LU\",\r\n\"MC\",\r\n\"NL\",\r\n\"IT\",\r\n\"MT\",\r\n\"SM\",\r\n\"VA\",\r\n\"AD\",\r\n\"ES\",\r\n\"GI\",\r\n\"PT\",\r\n\"BY\",\r\n\"EE\",\r\n\"LT\",\r\n\"LV\",\r\n\"MD\",\r\n\"PL\",\r\n\"UA\",\r\n\"AL\",\r\n\"BA\",\r\n\"BG\",\r\n\"GR\",\r\n\"HR\",\r\n\"MK\",\r\n\"RO\",\r\n\"SI\",\r\n\"YU\",\r\n\"RU\",\r\n\"AT\",\r\n\"CH\",\r\n\"CZ\",\r\n\"HU\",\r\n\"LI\",\r\n\"SK\",\r\n\"DK\",\r\n\"FI\",\r\n\"FO\",\r\n\"IS\",\r\n\"NO\",\r\n\"SE\",\r\n\"SJ\"\r\n)', '!=', '0', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(76, 88, 'sql', 'SELECT IFNULL(id_order, 0) FROM PREFIX_orders o LEFT JOIN PREFIX_address a ON o.id_address_delivery = a.id_address LEFT JOIN PREFIX_country c ON c.id_country = a.id_country WHERE o.valid = 1 AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\" AND c.iso_code IN (\r\n\"BI\",\r\n\"CF\",\r\n\"CG\",\r\n\"RW\",\r\n\"TD\",\r\n\"ZR\",\r\n\"DJ\",\r\n\"ER\",\r\n\"ET\",\r\n\"KE\",\r\n\"SO\",\r\n\"TZ\",\r\n\"UG\",\r\n\"KM\",\r\n\"MG\",\r\n\"MU\",\r\n\"RE\",\r\n\"SC\",\r\n\"YT\",\r\n\"AO\",\r\n\"BW\",\r\n\"LS\",\r\n\"MW\",\r\n\"MZ\",\r\n\"NA\",\r\n\"SZ\",\r\n\"ZA\",\r\n\"ZM\",\r\n\"ZW\",\r\n\"BF\",\r\n\"BJ\",\r\n\"CI\",\r\n\"CM\",\r\n\"CV\",\r\n\"GA\",\r\n\"GH\",\r\n\"GM\",\r\n\"GN\",\r\n\"GQ\",\r\n\"GW\",\r\n\"LR\",\r\n\"ML\",\r\n\"MR\",\r\n\"NE\",\r\n\"NG\",\r\n\"SL\",\r\n\"SN\",\r\n\"ST\",\r\n\"TG\"\r\n)', '!=', '0', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(77, 89, 'sql', 'SELECT IFNULL(id_order, 0) FROM PREFIX_orders o LEFT JOIN PREFIX_address a ON o.id_address_delivery = a.id_address LEFT JOIN PREFIX_country c ON c.id_country = a.id_country WHERE o.valid = 1 AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\" AND c.iso_code IN (\r\n\"DZ\",\r\n\"EG\",\r\n\"EH\",\r\n\"LY\",\r\n\"MA\",\r\n\"SD\",\r\n\"TN\"\r\n)', '!=', '0', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(78, 90, 'sql', 'SELECT COUNT(*) FROM PREFIX_employee', '>=', '2', '1', 'hook', 'actionObjectEmployeeAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(79, 91, 'sql', 'SELECT COUNT(*) FROM PREFIX_employee', '>=', '3', '1', 'hook', 'actionObjectEmployeeAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(80, 92, 'sql', 'SELECT COUNT(*) FROM PREFIX_employee', '>=', '5', '1', 'hook', 'actionObjectEmployeeAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(81, 93, 'sql', 'SELECT COUNT(*) FROM PREFIX_employee', '>=', '10', '1', 'hook', 'actionObjectEmployeeAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(82, 94, 'sql', 'SELECT COUNT(*) FROM PREFIX_employee', '>=', '20', '1', 'hook', 'actionObjectEmployeeAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(83, 95, 'sql', 'SELECT COUNT(*) FROM PREFIX_employee', '>=', '40', '1', 'hook', 'actionObjectEmployeeAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(84, 96, 'sql', 'SELECT id_image FROM PREFIX_image WHERE id_image > 26', '>', '0', '27', 'hook', 'actionObjectImageAddAfter', 1, '2022-12-08 18:28:25', '2022-12-11 22:52:21'),
(85, 97, 'sql', 'SELECT COUNT(*) FROM PREFIX_image', '>=', '50', '14', 'hook', 'actionObjectImageAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:54:31'),
(86, 98, 'sql', 'SELECT COUNT(*) FROM PREFIX_image', '>=', '100', '14', 'hook', 'actionObjectImageAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:54:31'),
(87, 99, 'sql', 'SELECT COUNT(*) FROM PREFIX_image', '>=', '1000', '0', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:53:35'),
(88, 100, 'sql', 'SELECT COUNT(*) FROM PREFIX_image', '>=', '10000', '0', 'time', '4', 0, '2022-12-08 18:28:25', '2022-12-11 22:53:35'),
(89, 101, 'sql', 'SELECT COUNT(*) FROM PREFIX_image', '>=', '50000', '0', 'time', '8', 0, '2022-12-08 18:28:25', '2022-12-11 22:53:35'),
(90, 102, 'sql', 'SELECT id_cms FROM PREFIX_cms WHERE id_cms > 5', '>', '0', '0', 'hook', 'actionObjectCMSAddAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:28'),
(91, 103, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart_rule', '>=', '1', '0', 'hook', 'actionObjectCartRuleAddAfter 	', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(92, 104, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart_rule', '>=', '10', '0', 'hook', 'actionObjectCartRuleAddAfter 	', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(93, 105, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart_rule', '>=', '100', '0', 'hook', 'actionObjectCartRuleAddAfter 	', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(94, 106, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart_rule', '>=', '1000', '0', 'hook', 'actionObjectCartRuleAddAfter 	', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(95, 107, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart_rule', '>=', '500', '0', 'hook', 'actionObjectCartRuleAddAfter 	', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(96, 108, 'sql', 'SELECT COUNT(*) FROM PREFIX_cart_rule', '>=', '5000', '0', 'hook', 'actionObjectCartRuleAddAfter 	', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(97, 109, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o INNER JOIN PREFIX_address a ON a.id_address = o.id_address_delivery\r\nWHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\") AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\"', '>=', '1', '0', 'hook', 'newOrder', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(98, 110, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o INNER JOIN PREFIX_address a ON a.id_address = o.id_address_delivery\r\nWHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\") AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\"', '>=', '10', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(99, 111, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o INNER JOIN PREFIX_address a ON a.id_address = o.id_address_delivery\r\nWHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\") AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\"', '>=', '100', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(100, 112, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o INNER JOIN PREFIX_address a ON a.id_address = o.id_address_delivery\r\nWHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\") AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\"', '>=', '10000', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(101, 113, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o INNER JOIN PREFIX_address a ON a.id_address = o.id_address_delivery\r\nWHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\") AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\"', '>=', '1000', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(102, 114, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o INNER JOIN PREFIX_address a ON a.id_address = o.id_address_delivery\r\nWHERE reference NOT IN (\"XKBKNABJK\", \"OHSATSERP\", \"FFATNOMMJ\", \"UOYEVOLI\", \"KHWLILZLL\") AND a.id_country != \"{config}PS_COUNTRY_DEFAULT{/config}\"', '>=', '5000', '0', 'hook', 'actionOrderStatusUpdate', 0, '2022-12-08 18:28:25', '2022-12-11 22:12:59'),
(103, 132, 'sql', 'SELECT count(id_configuration) FROM PREFIX_configuration WHERE `name` = \'PS_SHOP_DOMAIN\' AND value IN (\'127.0.0.1\', \'localhost\' )', '==', '1', '1', 'time', '1', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(104, 136, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%ebay%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(105, 140, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%moneybookers%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(106, 142, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%paypal%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(107, 158, 'install', '', '>=', '90', '', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:01'),
(108, 159, 'install', '', '<=', '90', '1', 'time', '2', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(109, 165, 'sql', 'SELECT COUNT(s.`id_store`) FROM PREFIX_store s WHERE `latitude` NOT IN (\'25.76500500\', \'26.13793600\', \'26.00998700\', \'25.73629600\', \'25.88674000\') AND `longitude` NOT IN (\'-80.24379700\', \'-80.13943500\', \'-80.29447200\', \'-80.24479700\', \'-80.16329200\')', '>', '0', '0', 'hook', 'actionAdminStoresControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(110, 166, 'sql', 'SELECT COUNT(s.`id_store`) FROM PREFIX_store s WHERE `latitude` NOT IN (\'25.76500500\', \'26.13793600\', \'26.00998700\', \'25.73629600\', \'25.88674000\') AND `longitude` NOT IN (\'-80.24379700\', \'-80.13943500\', \'-80.29447200\', \'-80.24479700\', \'-80.16329200\')', '>', '1', '0', 'hook', 'actionAdminStoresControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(111, 167, 'sql', 'SELECT COUNT(s.`id_store`) FROM PREFIX_store s WHERE `latitude` NOT IN (\'25.76500500\', \'26.13793600\', \'26.00998700\', \'25.73629600\', \'25.88674000\') AND `longitude` NOT IN (\'-80.24379700\', \'-80.13943500\', \'-80.29447200\', \'-80.24479700\', \'-80.16329200\')', '>', '4', '0', 'hook', 'actionAdminStoresControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(112, 168, 'sql', 'SELECT COUNT(s.`id_store`) FROM PREFIX_store s WHERE `latitude` NOT IN (\'25.76500500\', \'26.13793600\', \'26.00998700\', \'25.73629600\', \'25.88674000\') AND `longitude` NOT IN (\'-80.24379700\', \'-80.13943500\', \'-80.29447200\', \'-80.24479700\', \'-80.16329200\')', '>', '9', '0', 'hook', 'actionAdminStoresControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(113, 169, 'sql', 'SELECT COUNT(s.`id_store`) FROM PREFIX_store s WHERE `latitude` NOT IN (\'25.76500500\', \'26.13793600\', \'26.00998700\', \'25.73629600\', \'25.88674000\') AND `longitude` NOT IN (\'-80.24379700\', \'-80.13943500\', \'-80.29447200\', \'-80.24479700\', \'-80.16329200\')', '>', '19', '0', 'hook', 'actionAdminStoresControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(114, 170, 'sql', 'SELECT COUNT(s.`id_store`) FROM PREFIX_store s WHERE `latitude` NOT IN (\'25.76500500\', \'26.13793600\', \'26.00998700\', \'25.73629600\', \'25.88674000\') AND `longitude` NOT IN (\'-80.24379700\', \'-80.13943500\', \'-80.29447200\', \'-80.24479700\', \'-80.16329200\')', '>', '49', '0', 'hook', 'actionAdminStoresControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(115, 171, 'sql', 'SELECT COUNT(*) FROM PREFIX_webservice_account', '>=', '1', '0', 'hook', 'actionAdminWebserviceControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(116, 172, 'sql', 'SELECT COUNT(*) FROM PREFIX_webservice_account', '>=', '2', '0', 'hook', 'actionAdminWebserviceControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(117, 173, 'sql', 'SELECT COUNT(*) FROM PREFIX_webservice_account', '>=', '3', '0', 'hook', 'actionAdminWebserviceControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(118, 174, 'sql', 'SELECT COUNT(*) FROM PREFIX_webservice_account', '>=', '4', '0', 'hook', 'actionAdminWebserviceControllerSaveAfter', 0, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(119, 175, 'sql', 'SELECT count(*) FROM	 PREFIX_configuration WHERE name = \'PS_HOSTED_MODE\'', '==', '0', '0', 'time', '1', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(120, 209, 'configuration', 'EBAY_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(121, 320, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%shopgate%\" ', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(122, 322, 'configuration', 'SHOPGATE_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(123, 323, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%shoppingfluxexport%\" ', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(124, 324, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%shoppingfluxexport%\" ', '==', '0', '0', 'time', '1', 1, '2022-12-08 18:28:25', '2022-12-08 18:28:27'),
(125, 325, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE name LIKE \'SHOPPINGFLUXEXPORT_CONFIGURATION_OK\' OR name LIKE \'SHOPPINGFLUXEXPORT_CONFIGURED\'', '>=', '1', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(126, 326, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'MONEYBOOKERS_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'MB_PAY_TO_EMAIL \') AND ( value != \'testaccount2@moneybookers.com \'))', '==', '2', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(127, 358, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%ebay%\" AND os.logable = 1', '>=', '1', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(128, 359, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%ebay%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(129, 375, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%shopgate%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '1', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(130, 376, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%shopgate%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(131, 377, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%moneybookers%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '1', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(132, 394, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%sofortbanking%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(133, 399, 'sql', 'SELECT COUNT(*) FROM PREFIX_product WHERE reference NOT LIKE \"demo_%\"', '>', '499', '14', 'hook', 'actionObjectProductAddAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:54:31'),
(134, 424, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%alliance3%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(135, 425, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'ALLIANCE3_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'ALLIANCE_DEMO\') AND ( value = \'0\'))', '==', '2', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(136, 426, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%alliance3%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(137, 427, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%alliance3%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(138, 428, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%authorizeaim%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(139, 429, 'configuration', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'AUTHORIZEAIM_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'AUTHORIZE_AIM_SANDBOX\') AND ( value = \'0\'))', '==', '2', '', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(140, 430, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%authorizeaim%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(141, 431, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%authorizeaim%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(142, 434, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%bluepay%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(143, 435, 'configuration', 'BLUEPAY_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(144, 436, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%bluepay%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(145, 437, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%bluepay%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(146, 438, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%payplug%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(147, 439, 'configuration', 'PAYPLUG_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(148, 440, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%payplug%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(149, 441, 'sql', 'SELECT SUM(o.total_paid) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%payplug%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '10000', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(150, 442, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%affinityitems%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(151, 443, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE name LIKE \'AFFINITYITEMS_CONFIGURATION_OK\' AND value = \'1\'', '==', '1', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(152, 446, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%dpdpoland%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(153, 447, 'configuration', 'DPDPOLAND_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(154, 448, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state LEFT JOIN PREFIX_carrier c ON c.id_carrier = o.id_carrier WHERE c.name like \"%dpdpoland%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(155, 449, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state LEFT JOIN PREFIX_carrier c ON c.id_carrier = o.id_carrier WHERE c.name like \"%dpdpoland%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '100', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(156, 450, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%envoimoinscher%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(157, 451, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'ENVOIMOINSCHER_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'EMC_ENV \') AND ( value != \'TEST\'))', '==', '2', '0', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(158, 452, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state LEFT JOIN PREFIX_carrier c ON c.id_carrier = o.id_carrier WHERE c.name like \"%envoimoinscher%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(159, 453, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state LEFT JOIN PREFIX_carrier c ON c.id_carrier = o.id_carrier WHERE c.name like \"%envoimoinscher%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '100', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(160, 454, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%klikandpay%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(161, 455, 'configuration', 'KLIKANDPAY_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(162, 456, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%klikandpay%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(163, 457, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%klikandpay%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(164, 458, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%clickline%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(165, 459, 'configuration', 'CLICKLINE_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(166, 460, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state LEFT JOIN PREFIX_carrier c ON c.id_carrier = o.id_carrier WHERE c.name like \"%clickline%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(167, 461, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state LEFT JOIN PREFIX_carrier c ON c.id_carrier = o.id_carrier WHERE c.name like \"%clickline%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '100', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(168, 462, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%cdiscount%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(169, 463, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '100', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(170, 464, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%cdiscount%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(171, 465, 'sql', 'SELECT SUM(o.total_paid) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%cdiscount%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 365 DAY)', '>=', '500', '0', 'time', '7', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(172, 467, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%erpillicopresta%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(173, 468, 'configuration', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'ERPILLICOPRESTA_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'ERP_LICENCE_VALIDITY \') AND ( value == \'1\')) OR (( name LIKE \'ERP_MONTH_FREE_ACTIVE \') AND ( value == \'0\'))', '==', '3', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-11 22:09:00'),
(174, 469, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '100', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(175, 470, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '100', 0, '2022-12-08 18:28:25', '2022-12-09 16:15:44'),
(176, 471, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%netreviews%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:25', '2022-12-11 22:15:27'),
(177, 472, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'NETREVIEWS_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'AVISVERIFIES_URLCERTIFICAT \') AND ( value IS NOT LIKE \'%preprod%\'))', '==', '2', '', 'time', '1', 0, '2022-12-08 18:28:25', '2022-12-07 18:28:25'),
(178, 473, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '100', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(179, 474, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '100', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(180, 475, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%bluesnap%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(181, 476, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'BLUESNAP_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'BLUESNAP_SANDBOX \') AND ( value NOT LIKE \'%sandbox%\'))', '==', '2', '0', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:00'),
(182, 477, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%bluesnap%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(183, 478, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%bluesnap%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(184, 479, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%desjardins%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(185, 480, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'DESJARDINS_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'DESJARDINS_MODE \') AND ( value NOT LIKE \'%test%\'))', '==', '2', '0', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(186, 481, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%desjardins%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(187, 482, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%desjardins%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(188, 483, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%firstdata%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(189, 484, 'configuration', 'FIRSTDATA_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(190, 485, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%firstdata%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(191, 486, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%firstdata%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(192, 487, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%giveit%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(193, 488, 'sql', 'GIVEIT_CONFIGURATION_OK', '>=', '1', '', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-07 18:28:26'),
(194, 489, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '365', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(195, 490, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '365', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(196, 491, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%ganalytics%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(197, 492, 'configuration', 'GANALYTICS_CONFIGURATION_OK', '==', '1', '1', 'time', '1', 1, '2022-12-08 18:28:26', '2022-12-09 16:15:43'),
(198, 493, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(199, 494, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '365', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(200, 496, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%pagseguro%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(201, 497, 'configuration', 'PAGSEGURO_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(202, 498, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%pagseguro%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(203, 499, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%pagseguro%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(204, 500, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%paypalmx%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(205, 501, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'PAYPALMX_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'PAYPAL_MX_SANDBOX\') AND ( value = \'0\'))', '==', '2', '0', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(206, 502, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%paypalmx%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(207, 503, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%paypalmx%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(208, 505, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%paypalusa%\"', '==', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(209, 506, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'PAYPALUSA_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'PAYPAL_USA_SANDBOX\') AND ( value = \'0\'))', '==', '2', '0', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(210, 507, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%paypalusa%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01');
INSERT INTO `ps_condition` (`id_condition`, `id_ps_condition`, `type`, `request`, `operator`, `value`, `result`, `calculation_type`, `calculation_detail`, `validated`, `date_add`, `date_upd`) VALUES
(211, 508, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%paypalmx%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(212, 509, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%payulatam%\"', '==', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(213, 510, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'PAYULATAM_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'PAYU_LATAM_TEST\') AND ( value = \'1\'))', '==', '2', '0', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(214, 511, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%payulatam%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(215, 512, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%payulatam%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(216, 513, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%prestastats%\"', '==', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(217, 514, 'configuration', 'PRESTASTATS_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(218, 515, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '365', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(219, 516, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '365', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(220, 517, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%riskified%\"', '==', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(221, 518, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'RISKIFIED_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'RISKIFIED_MODE\') AND ( value = \'1\'))', '==', '2', '0', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(222, 519, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%riskified%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(223, 520, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%riskified%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(224, 521, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%simplifycommerce%\"', '==', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(225, 522, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'SIMPLIFY_CONFIGURATION_OK\') AND ( value = \'1\')) OR (( name LIKE \'SIMPLIFY_MODE\') AND ( value = \'1\'))', '==', '2', '0', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(226, 523, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%simplifycommerce%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(227, 524, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%simplifycommerce%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(228, 525, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%vtpayment%\"', '==', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(229, 526, 'configuration', 'VTPAYMENT_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(230, 527, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%vtpayment%\" AND os.logable = 1', '>=', '1', '0', 'time', '2', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(231, 528, 'sql', 'SELECT COUNT(*) FROM PREFIX_orders o LEFT JOIN PREFIX_order_state os ON os.id_order_state = o.current_state WHERE o.module like \"%vtpayment%\" AND os.logable = 1 AND o.date_add > DATE_SUB(NOW(), INTERVAL 90 DAY)', '>=', '30', '0', 'time', '7', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(232, 529, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%yotpo%\"', '==', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(233, 530, 'configuration', 'YOTPO_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(234, 531, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '365', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(235, 532, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '365', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(236, 533, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%yotpo%\"', '==', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(237, 534, 'sql', 'SELECT COUNT(*) FROM PREFIX_configuration WHERE (( name LIKE \'YOUSTICERESOLUTIONSYSTEM_CONF_OK\') AND ( value = \'1\')) OR (( name LIKE \'YRS_SANDBOX\') AND ( value = \'0\'))', '==', '2', '0', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(238, 535, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '365', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(239, 536, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '365', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(240, 537, 'sql', 'SELECT COUNT( id_module ) FROM PREFIX_module WHERE `name` like \"%loyaltylion%\"', '>=', '1', '0', 'hook', 'actionModuleInstallAfter', 0, '2022-12-08 18:28:26', '2022-12-11 22:15:27'),
(241, 538, 'configuration', 'LOYALTYLION_CONFIGURATION_OK', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-11 22:09:01'),
(242, 539, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '365', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(243, 540, 'sql', 'SELECT 1', '!=', '1', '1', 'time', '365', 0, '2022-12-08 18:28:26', '2022-12-09 16:15:44'),
(244, 542, 'sql', 'SELECT \'{config} PS_VERSION_DB{/config}\' >= \'1.7.0.0\' AND < \'1.8.0.0\'', '==', '1', '', 'time', '1', 0, '2022-12-08 18:28:26', '2022-12-07 18:28:26');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_condition_advice`
--

CREATE TABLE `ps_condition_advice` (
  `id_condition` int(11) NOT NULL,
  `id_advice` int(11) NOT NULL,
  `display` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_condition_badge`
--

CREATE TABLE `ps_condition_badge` (
  `id_condition` int(11) NOT NULL,
  `id_badge` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_condition_badge`
--

INSERT INTO `ps_condition_badge` (`id_condition`, `id_badge`) VALUES
(1, 125),
(2, 126),
(3, 126),
(4, 126),
(5, 127),
(6, 128),
(7, 129),
(8, 130),
(9, 131),
(10, 132),
(11, 133),
(12, 137),
(13, 138),
(14, 139),
(15, 140),
(16, 134),
(17, 135),
(18, 136),
(19, 141),
(20, 142),
(21, 143),
(22, 144),
(23, 145),
(24, 146),
(25, 147),
(26, 149),
(27, 150),
(28, 148),
(29, 152),
(30, 151),
(31, 153),
(32, 154),
(33, 155),
(34, 156),
(35, 157),
(36, 158),
(37, 159),
(38, 160),
(39, 161),
(40, 162),
(41, 163),
(42, 164),
(43, 165),
(44, 166),
(45, 167),
(46, 168),
(47, 169),
(48, 170),
(49, 171),
(50, 172),
(51, 173),
(52, 174),
(53, 175),
(54, 176),
(55, 177),
(56, 178),
(57, 179),
(58, 180),
(59, 187),
(60, 188),
(61, 189),
(62, 190),
(63, 191),
(64, 192),
(65, 181),
(66, 182),
(67, 183),
(68, 184),
(69, 185),
(70, 186),
(71, 193),
(72, 194),
(73, 195),
(74, 196),
(75, 197),
(76, 198),
(77, 199),
(78, 200),
(79, 201),
(80, 202),
(81, 203),
(82, 204),
(83, 205),
(84, 206),
(85, 207),
(86, 208),
(87, 209),
(88, 210),
(89, 211),
(90, 212),
(91, 213),
(92, 214),
(93, 215),
(94, 217),
(95, 216),
(96, 218),
(97, 219),
(98, 220),
(99, 221),
(100, 224),
(101, 222),
(102, 223),
(104, 23),
(105, 5),
(109, 225),
(110, 226),
(111, 227),
(112, 228),
(113, 229),
(114, 230),
(115, 231),
(116, 232),
(117, 233),
(118, 234),
(120, 24),
(121, 1),
(122, 2),
(123, 9),
(125, 10),
(126, 6),
(127, 25),
(128, 26),
(129, 3),
(130, 4),
(131, 7),
(132, 8),
(134, 11),
(135, 12),
(136, 13),
(137, 14),
(138, 15),
(139, 16),
(140, 17),
(141, 18),
(142, 19),
(143, 20),
(144, 21),
(145, 22),
(146, 27),
(147, 28),
(148, 29),
(149, 30),
(150, 31),
(151, 32),
(152, 33),
(153, 34),
(154, 35),
(155, 36),
(156, 37),
(157, 38),
(158, 39),
(159, 40),
(160, 41),
(161, 42),
(162, 43),
(163, 44),
(164, 45),
(165, 46),
(166, 47),
(167, 48),
(168, 49),
(169, 50),
(170, 51),
(171, 52),
(172, 53),
(173, 54),
(174, 55),
(175, 56),
(176, 57),
(177, 58),
(178, 59),
(179, 60),
(180, 61),
(181, 62),
(182, 63),
(183, 64),
(184, 65),
(185, 66),
(186, 67),
(187, 68),
(188, 69),
(189, 70),
(190, 71),
(191, 72),
(192, 73),
(193, 74),
(194, 75),
(195, 76),
(196, 77),
(197, 78),
(198, 79),
(199, 80),
(200, 81),
(201, 82),
(202, 83),
(203, 84),
(204, 85),
(205, 86),
(206, 87),
(207, 88),
(208, 89),
(209, 90),
(210, 91),
(211, 92),
(212, 93),
(213, 94),
(214, 95),
(215, 96),
(216, 97),
(217, 98),
(218, 99),
(219, 100),
(220, 101),
(221, 102),
(222, 103),
(223, 104),
(224, 105),
(225, 106),
(226, 107),
(227, 108),
(228, 109),
(229, 110),
(230, 111),
(231, 112),
(232, 113),
(233, 114),
(234, 115),
(235, 116),
(236, 117),
(237, 118),
(238, 119),
(239, 120),
(240, 121),
(241, 122),
(242, 123),
(243, 124);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_configuration`
--

CREATE TABLE `ps_configuration` (
  `id_configuration` int(10) UNSIGNED NOT NULL,
  `id_shop_group` int(11) UNSIGNED DEFAULT NULL,
  `id_shop` int(11) UNSIGNED DEFAULT NULL,
  `name` varchar(254) NOT NULL,
  `value` text DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_configuration`
--

INSERT INTO `ps_configuration` (`id_configuration`, `id_shop_group`, `id_shop`, `name`, `value`, `date_add`, `date_upd`) VALUES
(1, NULL, NULL, 'PS_LANG_DEFAULT', '1', '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(2, NULL, NULL, 'PS_VERSION_DB', '1.7.8.7', '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(3, NULL, NULL, 'PS_INSTALL_VERSION', '1.7.8.7', '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(4, NULL, NULL, 'PS_CARRIER_DEFAULT', '1', '2022-12-08 17:56:28', '2022-12-08 17:56:28'),
(5, NULL, NULL, 'PS_GROUP_FEATURE_ACTIVE', '1', '2022-12-08 17:56:28', '2022-12-08 17:56:28'),
(6, NULL, NULL, 'PS_CURRENCY_DEFAULT', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, NULL, NULL, 'PS_COUNTRY_DEFAULT', '14', '0000-00-00 00:00:00', '2022-12-08 17:56:30'),
(8, NULL, NULL, 'PS_REWRITING_SETTINGS', '1', '0000-00-00 00:00:00', '2022-12-08 17:56:30'),
(9, NULL, NULL, 'PS_ORDER_OUT_OF_STOCK', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, NULL, NULL, 'PS_LAST_QTIES', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, NULL, NULL, 'PS_CONDITIONS', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, NULL, NULL, 'PS_RECYCLABLE_PACK', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, NULL, NULL, 'PS_GIFT_WRAPPING', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, NULL, NULL, 'PS_GIFT_WRAPPING_PRICE', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, NULL, NULL, 'PS_STOCK_MANAGEMENT', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, NULL, NULL, 'PS_NAVIGATION_PIPE', '>', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, NULL, NULL, 'PS_PRODUCTS_PER_PAGE', '12', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, NULL, NULL, 'PS_PURCHASE_MINIMUM', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, NULL, NULL, 'PS_PRODUCTS_ORDER_WAY', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, NULL, NULL, 'PS_PRODUCTS_ORDER_BY', '4', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, NULL, NULL, 'PS_DISPLAY_QTIES', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, NULL, NULL, 'PS_SHIPPING_HANDLING', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(23, NULL, NULL, 'PS_SHIPPING_FREE_PRICE', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(24, NULL, NULL, 'PS_SHIPPING_FREE_WEIGHT', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(25, NULL, NULL, 'PS_SHIPPING_METHOD', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, NULL, NULL, 'PS_TAX', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, NULL, NULL, 'PS_SHOP_ENABLE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(28, NULL, NULL, 'PS_NB_DAYS_NEW_PRODUCT', '20', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(29, NULL, NULL, 'PS_SSL_ENABLED', NULL, '0000-00-00 00:00:00', '2022-12-11 22:49:27'),
(30, NULL, NULL, 'PS_WEIGHT_UNIT', 'kg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(31, NULL, NULL, 'PS_BLOCK_CART_AJAX', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(32, NULL, NULL, 'PS_ORDER_RETURN', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(33, NULL, NULL, 'PS_ORDER_RETURN_NB_DAYS', '14', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, NULL, NULL, 'PS_MAIL_TYPE', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, NULL, NULL, 'PS_PRODUCT_PICTURE_MAX_SIZE', '8388608', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(36, NULL, NULL, 'PS_PRODUCT_PICTURE_WIDTH', '64', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, NULL, NULL, 'PS_PRODUCT_PICTURE_HEIGHT', '64', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, NULL, NULL, 'PS_INVOICE_PREFIX', '#IN', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, NULL, NULL, 'PS_INVCE_INVOICE_ADDR_RULES', '{\"avoid\":[]}', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(40, NULL, NULL, 'PS_INVCE_DELIVERY_ADDR_RULES', '{\"avoid\":[]}', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(41, NULL, NULL, 'PS_DELIVERY_PREFIX', '#DE', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(42, NULL, NULL, 'PS_DELIVERY_NUMBER', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(43, NULL, NULL, 'PS_RETURN_PREFIX', '#RE', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(44, NULL, NULL, 'PS_INVOICE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(45, NULL, NULL, 'PS_PASSWD_TIME_BACK', '360', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(46, NULL, NULL, 'PS_PASSWD_TIME_FRONT', '360', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(47, NULL, NULL, 'PS_PASSWD_RESET_VALIDITY', '1440', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(48, NULL, NULL, 'PS_DISP_UNAVAILABLE_ATTR', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(49, NULL, NULL, 'PS_SEARCH_INDEXATION', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(50, NULL, NULL, 'PS_SEARCH_FUZZY', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(51, NULL, NULL, 'PS_SEARCH_FUZZY_MAX_LOOP', '4', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(52, NULL, NULL, 'PS_SEARCH_MAX_WORD_LENGTH', '15', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(53, NULL, NULL, 'PS_SEARCH_MINWORDLEN', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(54, NULL, NULL, 'PS_SEARCH_BLACKLIST', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(55, NULL, NULL, 'PS_SEARCH_WEIGHT_PNAME', '6', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(56, NULL, NULL, 'PS_SEARCH_WEIGHT_REF', '10', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(57, NULL, NULL, 'PS_SEARCH_WEIGHT_SHORTDESC', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(58, NULL, NULL, 'PS_SEARCH_WEIGHT_DESC', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(59, NULL, NULL, 'PS_SEARCH_WEIGHT_CNAME', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(60, NULL, NULL, 'PS_SEARCH_WEIGHT_MNAME', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(61, NULL, NULL, 'PS_SEARCH_WEIGHT_TAG', '4', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(62, NULL, NULL, 'PS_SEARCH_WEIGHT_ATTRIBUTE', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(63, NULL, NULL, 'PS_SEARCH_WEIGHT_FEATURE', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(64, NULL, NULL, 'PS_SEARCH_AJAX', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(65, NULL, NULL, 'PS_TIMEZONE', 'Europe/Warsaw', '0000-00-00 00:00:00', '2022-12-08 17:56:30'),
(66, NULL, NULL, 'PS_THEME_V11', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(67, NULL, NULL, 'PRESTASTORE_LIVE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(68, NULL, NULL, 'PS_TIN_ACTIVE', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(69, NULL, NULL, 'PS_SHOW_ALL_MODULES', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(70, NULL, NULL, 'PS_BACKUP_ALL', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(71, NULL, NULL, 'PS_1_3_UPDATE_DATE', '2011-12-27 10:20:42', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(72, NULL, NULL, 'PS_PRICE_ROUND_MODE', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(73, NULL, NULL, 'PS_1_3_2_UPDATE_DATE', '2011-12-27 10:20:42', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(74, NULL, NULL, 'PS_CONDITIONS_CMS_ID', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(75, NULL, NULL, 'TRACKING_DIRECT_TRAFFIC', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(76, NULL, NULL, 'PS_VOLUME_UNIT', 'l', '0000-00-00 00:00:00', '2022-12-08 18:32:54'),
(77, NULL, NULL, 'PS_CIPHER_ALGORITHM', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(78, NULL, NULL, 'PS_ATTRIBUTE_CATEGORY_DISPLAY', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(79, NULL, NULL, 'PS_CUSTOMER_SERVICE_FILE_UPLOAD', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(80, NULL, NULL, 'PS_CUSTOMER_SERVICE_SIGNATURE', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(81, NULL, NULL, 'PS_BLOCK_BESTSELLERS_DISPLAY', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(82, NULL, NULL, 'PS_BLOCK_NEWPRODUCTS_DISPLAY', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(83, NULL, NULL, 'PS_BLOCK_SPECIALS_DISPLAY', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(84, NULL, NULL, 'PS_STOCK_MVT_REASON_DEFAULT', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(85, NULL, NULL, 'PS_SPECIFIC_PRICE_PRIORITIES', 'id_shop;id_currency;id_country;id_group', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(86, NULL, NULL, 'PS_TAX_DISPLAY', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(87, NULL, NULL, 'PS_SMARTY_FORCE_COMPILE', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(88, NULL, NULL, 'PS_DISTANCE_UNIT', 'km', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(89, NULL, NULL, 'PS_STORES_DISPLAY_CMS', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(90, NULL, NULL, 'SHOP_LOGO_WIDTH', '200', '0000-00-00 00:00:00', '2022-12-11 22:37:55'),
(91, NULL, NULL, 'SHOP_LOGO_HEIGHT', '40', '0000-00-00 00:00:00', '2022-12-11 22:37:55'),
(92, NULL, NULL, 'EDITORIAL_IMAGE_WIDTH', '530', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(93, NULL, NULL, 'EDITORIAL_IMAGE_HEIGHT', '228', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(94, NULL, NULL, 'PS_STATSDATA_CUSTOMER_PAGESVIEWS', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(95, NULL, NULL, 'PS_STATSDATA_PAGESVIEWS', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(96, NULL, NULL, 'PS_STATSDATA_PLUGINS', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(97, NULL, NULL, 'PS_GEOLOCATION_ENABLED', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(98, NULL, NULL, 'PS_ALLOWED_COUNTRIES', 'AF;ZA;AX;AL;DZ;DE;AD;AO;AI;AQ;AG;AN;SA;AR;AM;AW;AU;AT;AZ;BS;BH;BD;BB;BY;BE;BZ;BJ;BM;BT;BO;BA;BW;BV;BR;BN;BG;BF;MM;BI;KY;KH;CM;CA;CV;CF;CL;CN;CX;CY;CC;CO;KM;CG;CD;CK;KR;KP;CR;CI;HR;CU;DK;DJ;DM;EG;IE;SV;AE;EC;ER;ES;EE;ET;FK;FO;FJ;FI;FR;GA;GM;GE;GS;GH;GI;GR;GD;GL;GP;GU;GT;GG;GN;GQ;GW;GY;GF;HT;HM;HN;HK;HU;IM;MU;VG;VI;IN;ID;IR;IQ;IS;IL;IT;JM;JP;JE;JO;KZ;KE;KG;KI;KW;LA;LS;LV;LB;LR;LY;LI;LT;LU;MO;MK;MG;MY;MW;MV;ML;MT;MP;MA;MH;MQ;MR;YT;MX;FM;MD;MC;MN;ME;MS;MZ;NA;NR;NP;NI;NE;NG;NU;NF;NO;NC;NZ;IO;OM;UG;UZ;PK;PW;PS;PA;PG;PY;NL;PE;PH;PN;PL;PF;PR;PT;QA;DO;CZ;RE;RO;GB;RU;RW;EH;BL;KN;SM;MF;PM;VA;VC;LC;SB;WS;AS;ST;SN;RS;SC;SL;SG;SK;SI;SO;SD;LK;SE;CH;SR;SJ;SZ;SY;TJ;TW;TZ;TD;TF;TH;TL;TG;TK;TO;TT;TN;TM;TC;TR;TV;UA;UY;US;VU;VE;VN;WF;YE;ZM;ZW', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(99, NULL, NULL, 'PS_GEOLOCATION_BEHAVIOR', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(100, NULL, NULL, 'PS_LOCALE_LANGUAGE', 'pl', '0000-00-00 00:00:00', '2022-12-08 17:56:30'),
(101, NULL, NULL, 'PS_LOCALE_COUNTRY', 'pl', '0000-00-00 00:00:00', '2022-12-08 17:56:30'),
(102, NULL, NULL, 'PS_ATTACHMENT_MAXIMUM_SIZE', '8', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(103, NULL, NULL, 'PS_SMARTY_CACHE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(104, NULL, NULL, 'PS_DIMENSION_UNIT', 'cm', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(105, NULL, NULL, 'PS_GUEST_CHECKOUT_ENABLED', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(106, NULL, NULL, 'PS_DISPLAY_SUPPLIERS', NULL, '0000-00-00 00:00:00', '2022-12-11 22:49:27'),
(107, NULL, NULL, 'PS_DISPLAY_MANUFACTURERS', '1', '0000-00-00 00:00:00', '2022-12-11 22:49:27'),
(108, NULL, NULL, 'PS_DISPLAY_BEST_SELLERS', '1', '0000-00-00 00:00:00', '2022-12-11 22:49:27'),
(109, NULL, NULL, 'PS_CATALOG_MODE', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(110, NULL, NULL, 'PS_GEOLOCATION_WHITELIST', '127;::1;188.165.122;209.185.108;209.185.253;209.85.238;209.85.238.11;209.85.238.4;216.239.33.96;216.239.33.97;216.239.33.98;216.239.33.99;216.239.37.98;216.239.37.99;216.239.39.98;216.239.39.99;216.239.41.96;216.239.41.97;216.239.41.98;216.239.41.99;216.239.45.4;216.239.46;216.239.51.96;216.239.51.97;216.239.51.98;216.239.51.99;216.239.53.98;216.239.53.99;216.239.57.96;91.240.109;216.239.57.97;216.239.57.98;216.239.57.99;216.239.59.98;216.239.59.99;216.33.229.163;64.233.173.193;64.233.173.194;64.233.173.195;64.233.173.196;64.233.173.197;64.233.173.198;64.233.173.199;64.233.173.200;64.233.173.201;64.233.173.202;64.233.173.203;64.233.173.204;64.233.173.205;64.233.173.206;64.233.173.207;64.233.173.208;64.233.173.209;64.233.173.210;64.233.173.211;64.233.173.212;64.233.173.213;64.233.173.214;64.233.173.215;64.233.173.216;64.233.173.217;64.233.173.218;64.233.173.219;64.233.173.220;64.233.173.221;64.233.173.222;64.233.173.223;64.233.173.224;64.233.173.225;64.233.173.226;64.233.173.227;64.233.173.228;64.233.173.229;64.233.173.230;64.233.173.231;64.233.173.232;64.233.173.233;64.233.173.234;64.233.173.235;64.233.173.236;64.233.173.237;64.233.173.238;64.233.173.239;64.233.173.240;64.233.173.241;64.233.173.242;64.233.173.243;64.233.173.244;64.233.173.245;64.233.173.246;64.233.173.247;64.233.173.248;64.233.173.249;64.233.173.250;64.233.173.251;64.233.173.252;64.233.173.253;64.233.173.254;64.233.173.255;64.68.80;64.68.81;64.68.82;64.68.83;64.68.84;64.68.85;64.68.86;64.68.87;64.68.88;64.68.89;64.68.90.1;64.68.90.10;64.68.90.11;64.68.90.12;64.68.90.129;64.68.90.13;64.68.90.130;64.68.90.131;64.68.90.132;64.68.90.133;64.68.90.134;64.68.90.135;64.68.90.136;64.68.90.137;64.68.90.138;64.68.90.139;64.68.90.14;64.68.90.140;64.68.90.141;64.68.90.142;64.68.90.143;64.68.90.144;64.68.90.145;64.68.90.146;64.68.90.147;64.68.90.148;64.68.90.149;64.68.90.15;64.68.90.150;64.68.90.151;64.68.90.152;64.68.90.153;64.68.90.154;64.68.90.155;64.68.90.156;64.68.90.157;64.68.90.158;64.68.90.159;64.68.90.16;64.68.90.160;64.68.90.161;64.68.90.162;64.68.90.163;64.68.90.164;64.68.90.165;64.68.90.166;64.68.90.167;64.68.90.168;64.68.90.169;64.68.90.17;64.68.90.170;64.68.90.171;64.68.90.172;64.68.90.173;64.68.90.174;64.68.90.175;64.68.90.176;64.68.90.177;64.68.90.178;64.68.90.179;64.68.90.18;64.68.90.180;64.68.90.181;64.68.90.182;64.68.90.183;64.68.90.184;64.68.90.185;64.68.90.186;64.68.90.187;64.68.90.188;64.68.90.189;64.68.90.19;64.68.90.190;64.68.90.191;64.68.90.192;64.68.90.193;64.68.90.194;64.68.90.195;64.68.90.196;64.68.90.197;64.68.90.198;64.68.90.199;64.68.90.2;64.68.90.20;64.68.90.200;64.68.90.201;64.68.90.202;64.68.90.203;64.68.90.204;64.68.90.205;64.68.90.206;64.68.90.207;64.68.90.208;64.68.90.21;64.68.90.22;64.68.90.23;64.68.90.24;64.68.90.25;64.68.90.26;64.68.90.27;64.68.90.28;64.68.90.29;64.68.90.3;64.68.90.30;64.68.90.31;64.68.90.32;64.68.90.33;64.68.90.34;64.68.90.35;64.68.90.36;64.68.90.37;64.68.90.38;64.68.90.39;64.68.90.4;64.68.90.40;64.68.90.41;64.68.90.42;64.68.90.43;64.68.90.44;64.68.90.45;64.68.90.46;64.68.90.47;64.68.90.48;64.68.90.49;64.68.90.5;64.68.90.50;64.68.90.51;64.68.90.52;64.68.90.53;64.68.90.54;64.68.90.55;64.68.90.56;64.68.90.57;64.68.90.58;64.68.90.59;64.68.90.6;64.68.90.60;64.68.90.61;64.68.90.62;64.68.90.63;64.68.90.64;64.68.90.65;64.68.90.66;64.68.90.67;64.68.90.68;64.68.90.69;64.68.90.7;64.68.90.70;64.68.90.71;64.68.90.72;64.68.90.73;64.68.90.74;64.68.90.75;64.68.90.76;64.68.90.77;64.68.90.78;64.68.90.79;64.68.90.8;64.68.90.80;64.68.90.9;64.68.91;64.68.92;66.249.64;66.249.65;66.249.66;66.249.67;66.249.68;66.249.69;66.249.70;66.249.71;66.249.72;66.249.73;66.249.78;66.249.79;72.14.199;8.6.48', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(111, NULL, NULL, 'PS_LOGS_BY_EMAIL', '4', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(112, NULL, NULL, 'PS_COOKIE_CHECKIP', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(113, NULL, NULL, 'PS_COOKIE_SAMESITE', 'Lax', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(114, NULL, NULL, 'PS_USE_ECOTAX', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(115, NULL, NULL, 'PS_CANONICAL_REDIRECT', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(116, NULL, NULL, 'PS_IMG_UPDATE_TIME', '1670794873', '0000-00-00 00:00:00', '2022-12-11 22:41:13'),
(117, NULL, NULL, 'PS_BACKUP_DROP_TABLE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(118, NULL, NULL, 'PS_OS_CHEQUE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(119, NULL, NULL, 'PS_OS_PAYMENT', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(120, NULL, NULL, 'PS_OS_PREPARATION', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(121, NULL, NULL, 'PS_OS_SHIPPING', '4', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(122, NULL, NULL, 'PS_OS_DELIVERED', '5', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(123, NULL, NULL, 'PS_OS_CANCELED', '6', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(124, NULL, NULL, 'PS_OS_REFUND', '7', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(125, NULL, NULL, 'PS_OS_ERROR', '8', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(126, NULL, NULL, 'PS_OS_OUTOFSTOCK', '9', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(127, NULL, NULL, 'PS_OS_BANKWIRE', '10', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(128, NULL, NULL, 'PS_OS_WS_PAYMENT', '11', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(129, NULL, NULL, 'PS_OS_OUTOFSTOCK_PAID', '9', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(130, NULL, NULL, 'PS_OS_OUTOFSTOCK_UNPAID', '12', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(131, NULL, NULL, 'PS_OS_COD_VALIDATION', '13', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(132, NULL, NULL, 'PS_LEGACY_IMAGES', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(133, NULL, NULL, 'PS_IMAGE_QUALITY', 'png', '0000-00-00 00:00:00', '2022-12-08 17:57:37'),
(134, NULL, NULL, 'PS_PNG_QUALITY', '7', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(135, NULL, NULL, 'PS_JPEG_QUALITY', '90', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(136, NULL, NULL, 'PS_COOKIE_LIFETIME_FO', '480', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(137, NULL, NULL, 'PS_COOKIE_LIFETIME_BO', '480', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(138, NULL, NULL, 'PS_RESTRICT_DELIVERED_COUNTRIES', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(139, NULL, NULL, 'PS_SHOW_NEW_ORDERS', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(140, NULL, NULL, 'PS_SHOW_NEW_CUSTOMERS', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(141, NULL, NULL, 'PS_SHOW_NEW_MESSAGES', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(142, NULL, NULL, 'PS_FEATURE_FEATURE_ACTIVE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(143, NULL, NULL, 'PS_COMBINATION_FEATURE_ACTIVE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(144, NULL, NULL, 'PS_SPECIFIC_PRICE_FEATURE_ACTIVE', NULL, '0000-00-00 00:00:00', '2022-12-11 22:53:24'),
(145, NULL, NULL, 'PS_VIRTUAL_PROD_FEATURE_ACTIVE', '1', '0000-00-00 00:00:00', '2022-12-08 17:57:53'),
(146, NULL, NULL, 'PS_CUSTOMIZATION_FEATURE_ACTIVE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(147, NULL, NULL, 'PS_CART_RULE_FEATURE_ACTIVE', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(148, NULL, NULL, 'PS_PACK_FEATURE_ACTIVE', NULL, '0000-00-00 00:00:00', '2022-12-11 22:54:34'),
(149, NULL, NULL, 'PS_ALIAS_FEATURE_ACTIVE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(150, NULL, NULL, 'PS_TAX_ADDRESS_TYPE', 'id_address_delivery', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(151, NULL, NULL, 'PS_SHOP_DEFAULT', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(152, NULL, NULL, 'PS_CARRIER_DEFAULT_SORT', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(153, NULL, NULL, 'PS_STOCK_MVT_INC_REASON_DEFAULT', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(154, NULL, NULL, 'PS_STOCK_MVT_DEC_REASON_DEFAULT', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(155, NULL, NULL, 'PS_ADVANCED_STOCK_MANAGEMENT', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(156, NULL, NULL, 'PS_STOCK_MVT_TRANSFER_TO', '7', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(157, NULL, NULL, 'PS_STOCK_MVT_TRANSFER_FROM', '6', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(158, NULL, NULL, 'PS_CARRIER_DEFAULT_ORDER', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(159, NULL, NULL, 'PS_STOCK_MVT_SUPPLY_ORDER', '8', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(160, NULL, NULL, 'PS_STOCK_CUSTOMER_ORDER_CANCEL_REASON', '9', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(161, NULL, NULL, 'PS_STOCK_CUSTOMER_RETURN_REASON', '10', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(162, NULL, NULL, 'PS_STOCK_MVT_INC_EMPLOYEE_EDITION', '11', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(163, NULL, NULL, 'PS_STOCK_MVT_DEC_EMPLOYEE_EDITION', '12', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(164, NULL, NULL, 'PS_STOCK_CUSTOMER_ORDER_REASON', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(165, NULL, NULL, 'PS_UNIDENTIFIED_GROUP', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(166, NULL, NULL, 'PS_GUEST_GROUP', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(167, NULL, NULL, 'PS_CUSTOMER_GROUP', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(168, NULL, NULL, 'PS_SMARTY_CONSOLE', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(169, NULL, NULL, 'PS_INVOICE_MODEL', 'invoice', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(170, NULL, NULL, 'PS_LIMIT_UPLOAD_IMAGE_VALUE', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(171, NULL, NULL, 'PS_LIMIT_UPLOAD_FILE_VALUE', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(172, NULL, NULL, 'MB_PAY_TO_EMAIL', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(173, NULL, NULL, 'MB_SECRET_WORD', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(174, NULL, NULL, 'MB_HIDE_LOGIN', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(175, NULL, NULL, 'MB_ID_LOGO', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(176, NULL, NULL, 'MB_ID_LOGO_WALLET', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(177, NULL, NULL, 'MB_PARAMETERS', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(178, NULL, NULL, 'MB_PARAMETERS_2', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(179, NULL, NULL, 'MB_DISPLAY_MODE', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(180, NULL, NULL, 'MB_CANCEL_URL', 'http://www.yoursite.com', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(181, NULL, NULL, 'MB_LOCAL_METHODS', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(182, NULL, NULL, 'MB_INTER_METHODS', '5', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(183, NULL, NULL, 'BANK_WIRE_CURRENCIES', '2,1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(184, NULL, NULL, 'CHEQUE_CURRENCIES', '2,1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(185, NULL, NULL, 'PRODUCTS_VIEWED_NBR', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(186, NULL, NULL, 'BLOCK_CATEG_DHTML', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(187, NULL, NULL, 'BLOCK_CATEG_MAX_DEPTH', '4', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(188, NULL, NULL, 'MANUFACTURER_DISPLAY_FORM', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(189, NULL, NULL, 'MANUFACTURER_DISPLAY_TEXT', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(190, NULL, NULL, 'MANUFACTURER_DISPLAY_TEXT_NB', '5', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(191, NULL, NULL, 'NEW_PRODUCTS_NBR', '5', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(192, NULL, NULL, 'PS_TOKEN_ENABLE', '1', '0000-00-00 00:00:00', '2022-12-11 22:49:27'),
(193, NULL, NULL, 'PS_STATS_RENDER', 'graphnvd3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(194, NULL, NULL, 'PS_STATS_OLD_CONNECT_AUTO_CLEAN', 'never', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(195, NULL, NULL, 'PS_STATS_GRID_RENDER', 'gridhtml', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(196, NULL, NULL, 'BLOCKTAGS_NBR', '10', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(197, NULL, NULL, 'CHECKUP_DESCRIPTIONS_LT', '100', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(198, NULL, NULL, 'CHECKUP_DESCRIPTIONS_GT', '400', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(199, NULL, NULL, 'CHECKUP_IMAGES_LT', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(200, NULL, NULL, 'CHECKUP_IMAGES_GT', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(201, NULL, NULL, 'CHECKUP_SALES_LT', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(202, NULL, NULL, 'CHECKUP_SALES_GT', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(203, NULL, NULL, 'CHECKUP_STOCK_LT', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(204, NULL, NULL, 'CHECKUP_STOCK_GT', '3', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(205, NULL, NULL, 'FOOTER_CMS', '0_3|0_4', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(206, NULL, NULL, 'FOOTER_BLOCK_ACTIVATION', '0_3|0_4', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(207, NULL, NULL, 'FOOTER_POWEREDBY', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(208, NULL, NULL, 'BLOCKADVERT_LINK', 'https://www.prestashop.com', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(209, NULL, NULL, 'BLOCKSTORE_IMG', 'store.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(210, NULL, NULL, 'BLOCKADVERT_IMG_EXT', 'jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(211, NULL, NULL, 'MOD_BLOCKTOPMENU_ITEMS', 'CAT3,CAT6,CAT9', '0000-00-00 00:00:00', '2022-12-08 17:56:40'),
(212, NULL, NULL, 'MOD_BLOCKTOPMENU_SEARCH', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(213, NULL, NULL, 'BLOCKSOCIAL_FACEBOOK', NULL, '0000-00-00 00:00:00', '2022-12-08 17:56:40'),
(214, NULL, NULL, 'BLOCKSOCIAL_TWITTER', NULL, '0000-00-00 00:00:00', '2022-12-08 17:56:40'),
(215, NULL, NULL, 'BLOCKSOCIAL_RSS', NULL, '0000-00-00 00:00:00', '2022-12-08 17:56:40'),
(216, NULL, NULL, 'BLOCKCONTACTINFOS_COMPANY', 'Your company', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(217, NULL, NULL, 'BLOCKCONTACTINFOS_ADDRESS', 'Address line 1\nCity\nCountry', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(218, NULL, NULL, 'BLOCKCONTACTINFOS_PHONE', '0123-456-789', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(219, NULL, NULL, 'BLOCKCONTACTINFOS_EMAIL', 'pub@prestashop.com', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(220, NULL, NULL, 'BLOCKCONTACT_TELNUMBER', '0123-456-789', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(221, NULL, NULL, 'BLOCKCONTACT_EMAIL', 'pub@prestashop.com', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(222, NULL, NULL, 'SUPPLIER_DISPLAY_TEXT', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(223, NULL, NULL, 'SUPPLIER_DISPLAY_TEXT_NB', '5', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(224, NULL, NULL, 'SUPPLIER_DISPLAY_FORM', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(225, NULL, NULL, 'BLOCK_CATEG_NBR_COLUMN_FOOTER', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(226, NULL, NULL, 'UPGRADER_BACKUPDB_FILENAME', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(227, NULL, NULL, 'UPGRADER_BACKUPFILES_FILENAME', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(228, NULL, NULL, 'BLOCKREINSURANCE_NBBLOCKS', '5', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(229, NULL, NULL, 'HOMESLIDER_WIDTH', '535', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(230, NULL, NULL, 'HOMESLIDER_SPEED', '5000', '0000-00-00 00:00:00', '2022-12-08 17:56:39'),
(231, NULL, NULL, 'HOMESLIDER_PAUSE', '7700', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(232, NULL, NULL, 'HOMESLIDER_LOOP', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(233, NULL, NULL, 'PS_BASE_DISTANCE_UNIT', 'm', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(234, NULL, NULL, 'PS_SHOP_DOMAIN', 'localhost', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(235, NULL, NULL, 'PS_SHOP_DOMAIN_SSL', 'localhost', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(236, NULL, NULL, 'PS_SHOP_NAME', 'SuperKursy', '0000-00-00 00:00:00', '2022-12-11 22:42:57'),
(237, NULL, NULL, 'PS_SHOP_EMAIL', 'admin@admin.pl', '0000-00-00 00:00:00', '2022-12-08 17:56:32'),
(238, NULL, NULL, 'PS_MAIL_METHOD', '2', '0000-00-00 00:00:00', '2022-12-11 22:09:40'),
(239, NULL, NULL, 'PS_SHOP_ACTIVITY', NULL, '0000-00-00 00:00:00', '2022-12-11 22:49:27'),
(240, NULL, NULL, 'PS_LOGO', 'logo-1670794675.jpg', '0000-00-00 00:00:00', '2022-12-11 22:37:55'),
(241, NULL, NULL, 'PS_FAVICON', 'favicon.ico', '0000-00-00 00:00:00', '2022-12-11 22:41:13'),
(242, NULL, NULL, 'PS_STORES_ICON', 'logo_stores.png', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(243, NULL, NULL, 'PS_ROOT_CATEGORY', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(244, NULL, NULL, 'PS_HOME_CATEGORY', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(245, NULL, NULL, 'PS_CONFIGURATION_AGREMENT', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(246, NULL, NULL, 'PS_MAIL_SERVER', 'smtp.gmail.com', '0000-00-00 00:00:00', '2022-12-11 22:09:40'),
(247, NULL, NULL, 'PS_MAIL_USER', 'super.kursy.online@gmail.com', '0000-00-00 00:00:00', '2022-12-11 22:09:40'),
(248, NULL, NULL, 'PS_MAIL_PASSWD', 'vbbmngambzhofzbz', '0000-00-00 00:00:00', '2022-12-11 22:11:25'),
(249, NULL, NULL, 'PS_MAIL_SMTP_ENCRYPTION', 'tls', '0000-00-00 00:00:00', '2022-12-11 22:09:40'),
(250, NULL, NULL, 'PS_MAIL_SMTP_PORT', '587', '0000-00-00 00:00:00', '2022-12-11 22:09:40'),
(251, NULL, NULL, 'PS_MAIL_COLOR', '#db3484', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(252, NULL, NULL, 'NW_SALT', 'e7KcfcSdVWIYMBig', '0000-00-00 00:00:00', '2022-12-08 17:56:37'),
(253, NULL, NULL, 'PS_PAYMENT_LOGO_CMS_ID', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(254, NULL, NULL, 'HOME_FEATURED_NBR', '8', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(255, NULL, NULL, 'SEK_MIN_OCCURENCES', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(256, NULL, NULL, 'SEK_FILTER_KW', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(257, NULL, NULL, 'PS_ALLOW_MOBILE_DEVICE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(258, NULL, NULL, 'PS_CUSTOMER_CREATION_EMAIL', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(259, NULL, NULL, 'PS_SMARTY_CONSOLE_KEY', 'SMARTY_DEBUG', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(260, NULL, NULL, 'PS_DASHBOARD_USE_PUSH', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(261, NULL, NULL, 'PS_ATTRIBUTE_ANCHOR_SEPARATOR', '-', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(262, NULL, NULL, 'CONF_AVERAGE_PRODUCT_MARGIN', '40', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(263, NULL, NULL, 'PS_DASHBOARD_SIMULATION', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(264, NULL, NULL, 'PS_USE_HTMLPURIFIER', '1', '0000-00-00 00:00:00', '2022-12-11 22:49:27'),
(265, NULL, NULL, 'PS_SMARTY_CACHING_TYPE', 'filesystem', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(266, NULL, NULL, 'PS_SMARTY_LOCAL', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(267, NULL, NULL, 'PS_SMARTY_CLEAR_CACHE', 'everytime', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(268, NULL, NULL, 'PS_DETECT_LANG', '0', '0000-00-00 00:00:00', '2022-12-08 18:32:48'),
(269, NULL, NULL, 'PS_DETECT_COUNTRY', '0', '0000-00-00 00:00:00', '2022-12-08 18:32:48'),
(270, NULL, NULL, 'PS_ROUND_TYPE', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(271, NULL, NULL, 'PS_LOG_EMAILS', '1', '0000-00-00 00:00:00', '2022-12-11 22:11:25'),
(272, NULL, NULL, 'PS_CUSTOMER_OPTIN', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(273, NULL, NULL, 'PS_CUSTOMER_BIRTHDATE', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(274, NULL, NULL, 'PS_PACK_STOCK_TYPE', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(275, NULL, NULL, 'PS_LOG_MODULE_PERFS_MODULO', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(276, NULL, NULL, 'PS_DISALLOW_HISTORY_REORDERING', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(277, NULL, NULL, 'PS_DISPLAY_PRODUCT_WEIGHT', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(278, NULL, NULL, 'PS_PRODUCT_WEIGHT_PRECISION', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(279, NULL, NULL, 'PS_ACTIVE_CRONJOB_EXCHANGE_RATE', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(280, NULL, NULL, 'PS_ORDER_RECALCULATE_SHIPPING', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(281, NULL, NULL, 'PS_MAINTENANCE_TEXT', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(282, NULL, NULL, 'PS_PRODUCT_SHORT_DESC_LIMIT', '800', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(283, NULL, NULL, 'PS_LABEL_IN_STOCK_PRODUCTS', 'In Stock', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(284, NULL, NULL, 'PS_LABEL_OOS_PRODUCTS_BOA', 'Product available for orders', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(285, NULL, NULL, 'PS_LABEL_OOS_PRODUCTS_BOD', 'Out-of-Stock', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(286, NULL, NULL, 'PS_CATALOG_MODE_WITH_PRICES', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(287, NULL, NULL, 'PS_MAIL_THEME', 'modern', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(288, NULL, NULL, 'PS_ORDER_PRODUCTS_NB_PER_PAGE', '8', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(289, NULL, NULL, 'PS_LOGS_EMAIL_RECEIVERS', 'admin@admin.pl', '0000-00-00 00:00:00', '2022-12-08 17:56:32'),
(290, NULL, NULL, 'PS_SHOW_LABEL_OOS_LISTING_PAGES', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(291, NULL, NULL, 'ADDONS_API_MODULE_CHANNEL', 'stable', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(292, NULL, NULL, 'PS_SSL_ENABLED_EVERYWHERE', NULL, '2022-12-08 17:56:30', '2022-12-11 22:49:27'),
(293, NULL, NULL, 'blockwishlist_WishlistPageName', NULL, '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(294, NULL, NULL, 'blockwishlist_WishlistDefaultTitle', NULL, '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(295, NULL, NULL, 'blockwishlist_CreateButtonLabel', NULL, '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(296, NULL, NULL, 'DASHACTIVITY_CART_ACTIVE', '30', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(297, NULL, NULL, 'DASHACTIVITY_CART_ABANDONED_MIN', '24', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(298, NULL, NULL, 'DASHACTIVITY_CART_ABANDONED_MAX', '48', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(299, NULL, NULL, 'DASHACTIVITY_VISITOR_ONLINE', '30', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(300, NULL, NULL, 'PS_DASHGOALS_CURRENT_YEAR', '2022', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(301, NULL, NULL, 'DASHPRODUCT_NBR_SHOW_LAST_ORDER', '10', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(302, NULL, NULL, 'DASHPRODUCT_NBR_SHOW_BEST_SELLER', '10', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(303, NULL, NULL, 'DASHPRODUCT_NBR_SHOW_MOST_VIEWED', '10', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(304, NULL, NULL, 'DASHPRODUCT_NBR_SHOW_TOP_SEARCH', '10', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(305, NULL, NULL, 'GSITEMAP_PRIORITY_HOME', '1', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(306, NULL, NULL, 'GSITEMAP_PRIORITY_PRODUCT', '0.9', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(307, NULL, NULL, 'GSITEMAP_PRIORITY_CATEGORY', '0.8', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(308, NULL, NULL, 'GSITEMAP_PRIORITY_CMS', '0.7', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(309, NULL, NULL, 'GSITEMAP_FREQUENCY', 'weekly', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(310, NULL, NULL, 'PRODUCT_COMMENTS_MINIMAL_TIME', '30', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(311, NULL, NULL, 'PRODUCT_COMMENTS_ALLOW_GUESTS', '0', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(312, NULL, NULL, 'PRODUCT_COMMENTS_USEFULNESS', '1', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(313, NULL, NULL, 'PRODUCT_COMMENTS_COMMENTS_PER_PAGE', '5', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(314, NULL, NULL, 'PRODUCT_COMMENTS_ANONYMISATION', '0', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(315, NULL, NULL, 'PRODUCT_COMMENTS_MODERATE', '1', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(316, NULL, NULL, 'BANNER_IMG', NULL, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(317, NULL, NULL, 'BANNER_LINK', NULL, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(318, NULL, NULL, 'BANNER_DESC', NULL, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(319, NULL, NULL, 'BLOCK_CATEG_ROOT_CATEGORY', '1', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(320, NULL, NULL, 'CONF_PS_CHECKPAYMENT_FIXED', '0.2', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(321, NULL, NULL, 'CONF_PS_CHECKPAYMENT_VAR', '2', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(322, NULL, NULL, 'CONF_PS_CHECKPAYMENT_FIXED_FOREIGN', '0.2', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(323, NULL, NULL, 'CONF_PS_CHECKPAYMENT_VAR_FOREIGN', '2', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(324, NULL, NULL, 'PS_CONTACT_INFO_DISPLAY_EMAIL', '1', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(325, NULL, NULL, 'CROSSSELLING_DISPLAY_PRICE', '1', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(326, NULL, NULL, 'CROSSSELLING_NBR', '8', '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(327, NULL, NULL, 'CUSTPRIV_MSG_AUTH', NULL, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(328, NULL, NULL, 'PS_NEWSLETTER_RAND', '12676811131427290377', '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(329, NULL, NULL, 'NW_CONDITIONS', NULL, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(339, NULL, NULL, 'CHECKBOX_ORDER', '1', '2022-12-08 17:56:38', '2022-12-08 17:56:38'),
(340, NULL, NULL, 'CHECKBOX_CUSTOMER', '1', '2022-12-08 17:56:38', '2022-12-08 17:56:38'),
(341, NULL, NULL, 'CHECKBOX_MESSAGE', '1', '2022-12-08 17:56:38', '2022-12-08 17:56:38'),
(342, NULL, NULL, 'BACKGROUND_COLOR_FAVICONBO', '#DF0067', '2022-12-08 17:56:38', '2022-12-08 17:56:38'),
(343, NULL, NULL, 'TEXT_COLOR_FAVICONBO', '#FFFFFF', '2022-12-08 17:56:38', '2022-12-08 17:56:38'),
(344, NULL, NULL, 'HOME_FEATURED_CAT', '2', '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(345, NULL, NULL, 'HOMESLIDER_PAUSE_ON_HOVER', '1', '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(346, NULL, NULL, 'HOMESLIDER_WRAP', '1', '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(347, NULL, NULL, 'PS_SC_TWITTER', '1', '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(348, NULL, NULL, 'PS_SC_FACEBOOK', '1', '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(349, NULL, NULL, 'PS_SC_PINTEREST', '1', '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(350, NULL, NULL, 'BLOCKSOCIAL_YOUTUBE', NULL, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(351, NULL, NULL, 'BLOCKSOCIAL_PINTEREST', NULL, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(352, NULL, NULL, 'BLOCKSOCIAL_VIMEO', NULL, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(353, NULL, NULL, 'BLOCKSOCIAL_INSTAGRAM', NULL, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(354, NULL, NULL, 'BLOCKSOCIAL_LINKEDIN', NULL, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(355, NULL, NULL, 'BANK_WIRE_PAYMENT_INVITE', '1', '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(356, NULL, NULL, 'CONF_PS_WIREPAYMENT_FIXED', '0.2', '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(357, NULL, NULL, 'CONF_PS_WIREPAYMENT_VAR', '2', '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(358, NULL, NULL, 'CONF_PS_WIREPAYMENT_FIXED_FOREIGN', '0.2', '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(359, NULL, NULL, 'CONF_PS_WIREPAYMENT_VAR_FOREIGN', '2', '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(360, NULL, NULL, 'GF_INSTALL_CALC', '1', '2022-12-08 17:57:24', '2022-12-08 18:28:27'),
(361, NULL, NULL, 'GF_CURRENT_LEVEL', '2', '2022-12-08 17:57:24', '2022-12-11 22:42:57'),
(362, NULL, NULL, 'GF_CURRENT_LEVEL_PERCENT', '20', '2022-12-08 17:57:24', '2022-12-11 22:55:05'),
(363, NULL, NULL, 'GF_NOTIFICATION', '13', '2022-12-08 17:57:24', '2022-12-11 22:55:05'),
(364, NULL, NULL, 'PSGDPR_CREATION_FORM_SWITCH', '1', '2022-12-08 17:57:24', '2022-12-08 17:57:24'),
(365, NULL, NULL, 'PSGDPR_CREATION_FORM', NULL, '2022-12-08 17:57:24', '2022-12-08 17:57:24'),
(366, NULL, NULL, 'PSGDPR_CUSTOMER_FORM_SWITCH', '1', '2022-12-08 17:57:24', '2022-12-08 17:57:24'),
(367, NULL, NULL, 'PSGDPR_CUSTOMER_FORM', NULL, '2022-12-08 17:57:24', '2022-12-08 17:57:24'),
(368, NULL, NULL, 'PSGDPR_ANONYMOUS_CUSTOMER', '1', '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(369, NULL, NULL, 'PSGDPR_ANONYMOUS_ADDRESS', '1', '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(370, NULL, NULL, 'CONF_PS_CHECKOUT_FIXED', '0.2', '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(371, NULL, NULL, 'CONF_PS_CHECKOUT_VAR', '2', '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(372, NULL, NULL, 'CONF_PS_CHECKOUT_FIXED_FOREIGN', '0.2', '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(373, NULL, NULL, 'CONF_PS_CHECKOUT_VAR_FOREIGN', '2', '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(374, NULL, NULL, 'PS_CHECKOUT_INTENT', 'CAPTURE', '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(375, NULL, NULL, 'PS_CHECKOUT_MODE', 'LIVE', '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(376, NULL, NULL, 'PS_CHECKOUT_PAYMENT_METHODS_ORDER', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(377, NULL, NULL, 'PS_CHECKOUT_PAYPAL_ID_MERCHANT', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(378, NULL, NULL, 'PS_CHECKOUT_PAYPAL_EMAIL_MERCHANT', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(379, NULL, NULL, 'PS_CHECKOUT_PAYPAL_EMAIL_STATUS', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(380, NULL, NULL, 'PS_CHECKOUT_PAYPAL_PAYMENT_STATUS', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(381, NULL, NULL, 'PS_CHECKOUT_CARD_PAYMENT_STATUS', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(382, NULL, NULL, 'PS_CHECKOUT_CARD_PAYMENT_ENABLED', '1', '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(383, NULL, NULL, 'PS_PSX_FIREBASE_EMAIL', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(384, NULL, NULL, 'PS_PSX_FIREBASE_ID_TOKEN', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(385, NULL, NULL, 'PS_PSX_FIREBASE_LOCAL_ID', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(386, NULL, NULL, 'PS_PSX_FIREBASE_REFRESH_TOKEN', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(387, NULL, NULL, 'PS_PSX_FIREBASE_REFRESH_DATE', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(388, NULL, NULL, 'PS_CHECKOUT_PSX_FORM', NULL, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(389, NULL, NULL, 'PS_CHECKOUT_LOGGER_MAX_FILES', '15', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(390, NULL, NULL, 'PS_CHECKOUT_LOGGER_LEVEL', '400', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(391, NULL, NULL, 'PS_CHECKOUT_LOGGER_HTTP', '0', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(392, NULL, NULL, 'PS_CHECKOUT_LOGGER_HTTP_FORMAT', 'DEBUG', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(393, NULL, NULL, 'PS_CHECKOUT_INTEGRATION_DATE', '2022-14-06', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(394, NULL, NULL, 'PS_CHECKOUT_SHOP_UUID_V4', '71b0f4f8-7cc8-433e-b3f4-92476c25abc6', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(395, NULL, NULL, 'PS_CHECKOUT_STATE_WAITING_PAYPAL_PAYMENT', '14', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(396, NULL, NULL, 'PS_CHECKOUT_STATE_WAITING_CREDIT_CARD_PAYMENT', '15', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(397, NULL, NULL, 'PS_CHECKOUT_STATE_WAITING_LOCAL_PAYMENT', '16', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(398, NULL, NULL, 'PS_CHECKOUT_STATE_AUTHORIZED', '17', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(399, NULL, NULL, 'PS_CHECKOUT_STATE_PARTIAL_REFUND', '18', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(400, NULL, NULL, 'PS_CHECKOUT_STATE_WAITING_CAPTURE', '19', '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(401, NULL, NULL, '0', 'PS_FACEBOOK_PIXEL_ID', '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(402, NULL, NULL, '1', 'PS_FACEBOOK_ACCESS_TOKEN', '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(403, NULL, NULL, '2', 'PS_FACEBOOK_PROFILES', '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(404, NULL, NULL, '3', 'PS_FACEBOOK_PAGES', '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(405, NULL, NULL, '4', 'PS_FACEBOOK_BUSINESS_MANAGER_ID', '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(406, NULL, NULL, '5', 'PS_FACEBOOK_AD_ACCOUNT_ID', '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(407, NULL, NULL, '6', 'PS_FACEBOOK_CATALOG_ID', '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(408, NULL, NULL, '7', 'PS_FACEBOOK_EXTERNAL_BUSINESS_ID', '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(409, NULL, NULL, '8', 'PS_FACEBOOK_PIXEL_ENABLED', '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(410, NULL, NULL, '9', 'PS_FACEBOOK_PRODUCT_SYNC_FIRST_START', '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(411, NULL, NULL, '10', 'PS_FACEBOOK_PRODUCT_SYNC_ON', '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(412, NULL, NULL, 'PSR_HOOK_HEADER', '0', '2022-12-08 17:57:38', '2022-12-08 17:57:38'),
(413, NULL, NULL, 'PSR_HOOK_FOOTER', '0', '2022-12-08 17:57:38', '2022-12-08 17:57:38'),
(414, NULL, NULL, 'PSR_HOOK_PRODUCT', '1', '2022-12-08 17:57:38', '2022-12-08 17:57:38'),
(415, NULL, NULL, 'PSR_HOOK_CHECKOUT', '1', '2022-12-08 17:57:38', '2022-12-08 17:57:38'),
(416, NULL, NULL, 'PSR_ICON_COLOR', '#F19D76', '2022-12-08 17:57:38', '2022-12-08 17:57:38'),
(417, NULL, NULL, 'PSR_TEXT_COLOR', '#000000', '2022-12-08 17:57:38', '2022-12-08 17:57:38'),
(418, NULL, NULL, 'PS_LAYERED_CACHE_ENABLED', '1', '2022-12-08 17:57:59', '2022-12-08 17:57:59'),
(419, NULL, NULL, 'PS_LAYERED_SHOW_QTIES', '1', '2022-12-08 17:57:59', '2022-12-08 17:57:59'),
(420, NULL, NULL, 'PS_LAYERED_FULL_TREE', '1', '2022-12-08 17:57:59', '2022-12-08 17:57:59'),
(421, NULL, NULL, 'PS_LAYERED_FILTER_PRICE_USETAX', '1', '2022-12-08 17:57:59', '2022-12-08 17:57:59'),
(422, NULL, NULL, 'PS_LAYERED_FILTER_CATEGORY_DEPTH', '1', '2022-12-08 17:57:59', '2022-12-08 17:57:59'),
(423, NULL, NULL, 'PS_LAYERED_FILTER_PRICE_ROUNDING', '1', '2022-12-08 17:57:59', '2022-12-08 17:57:59'),
(424, NULL, NULL, 'PS_LAYERED_FILTER_SHOW_OUT_OF_STOCK_LAST', '0', '2022-12-08 17:57:59', '2022-12-08 17:57:59'),
(425, NULL, NULL, 'PS_LAYERED_FILTER_BY_DEFAULT_CATEGORY', '0', '2022-12-08 17:57:59', '2022-12-08 17:57:59'),
(426, NULL, NULL, 'PS_LAYERED_INDEXED', '1', '2022-12-08 17:58:00', '2022-12-08 17:58:00'),
(427, NULL, NULL, 'GF_NOT_VIEWED_BADGE', '133', '2022-12-08 18:28:28', '2022-12-11 22:55:05'),
(428, NULL, NULL, 'ONBOARDINGV2_SHUT_DOWN', '1', '2022-12-08 18:28:29', '2022-12-08 18:28:29'),
(429, NULL, NULL, 'GA_CANCELLED_STATES', '[\"6\"]', '2022-12-08 18:44:29', '2022-12-08 18:44:29'),
(430, NULL, NULL, 'GA_ACCOUNT_ID', 'UA-250948674-1', '2022-12-08 18:45:07', '2022-12-08 18:45:07'),
(431, NULL, NULL, 'GANALYTICS_CONFIGURATION_OK', '1', '2022-12-08 18:45:07', '2022-12-08 18:45:07'),
(432, NULL, NULL, 'GA_USERID_ENABLED', '1', '2022-12-08 18:45:07', '2022-12-08 18:45:07'),
(433, NULL, NULL, 'PS_MAIL_EMAIL_MESSAGE', '2', '2022-12-11 22:09:40', '2022-12-11 22:09:40'),
(434, NULL, NULL, 'PS_MAIL_DOMAIN', NULL, '2022-12-11 22:09:40', '2022-12-11 22:09:40'),
(435, NULL, NULL, 'CONF_PS_CASHONDELIVERY_FIXED', '0.2', '2022-12-11 22:15:27', '2022-12-11 22:15:27'),
(436, NULL, NULL, 'CONF_PS_CASHONDELIVERY_VAR', '2', '2022-12-11 22:15:27', '2022-12-11 22:15:27'),
(437, NULL, NULL, 'CONF_PS_CASHONDELIVERY_FIXED_FOREIGN', '0.2', '2022-12-11 22:15:27', '2022-12-11 22:15:27'),
(438, NULL, NULL, 'CONF_PS_CASHONDELIVERY_VAR_FOREIGN', '2', '2022-12-11 22:15:27', '2022-12-11 22:15:27'),
(439, NULL, NULL, 'PS_SHOP_DETAILS', NULL, '2022-12-11 22:42:57', '2022-12-11 22:42:57'),
(440, NULL, NULL, 'PS_SHOP_ADDR1', NULL, '2022-12-11 22:42:57', '2022-12-11 22:42:57'),
(441, NULL, NULL, 'PS_SHOP_ADDR2', NULL, '2022-12-11 22:42:57', '2022-12-11 22:42:57'),
(442, NULL, NULL, 'PS_SHOP_CODE', NULL, '2022-12-11 22:42:57', '2022-12-11 22:42:57'),
(443, NULL, NULL, 'PS_SHOP_CITY', 'Bydgoszcz', '2022-12-11 22:42:57', '2022-12-11 22:42:57'),
(444, NULL, NULL, 'PS_SHOP_COUNTRY_ID', '14', '2022-12-11 22:42:57', '2022-12-11 22:42:57'),
(445, NULL, NULL, 'PS_SHOP_COUNTRY', 'Polska', '2022-12-11 22:42:57', '2022-12-11 22:42:57'),
(446, NULL, NULL, 'PS_SHOP_PHONE', NULL, '2022-12-11 22:42:57', '2022-12-11 22:42:57'),
(447, NULL, NULL, 'PS_SHOP_FAX', NULL, '2022-12-11 22:42:57', '2022-12-11 22:42:57'),
(448, NULL, NULL, 'PS_WEBSERVICE', '1', '2022-12-11 22:45:29', '2022-12-11 22:45:29');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_configuration_kpi`
--

CREATE TABLE `ps_configuration_kpi` (
  `id_configuration_kpi` int(10) UNSIGNED NOT NULL,
  `id_shop_group` int(11) UNSIGNED DEFAULT NULL,
  `id_shop` int(11) UNSIGNED DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `value` text DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_configuration_kpi`
--

INSERT INTO `ps_configuration_kpi` (`id_configuration_kpi`, `id_shop_group`, `id_shop`, `name`, `value`, `date_add`, `date_upd`) VALUES
(1, NULL, NULL, 'DASHGOALS_TRAFFIC_01_2022', '600', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(2, NULL, NULL, 'DASHGOALS_CONVERSION_01_2022', '2', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(3, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_01_2022', '80', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(4, NULL, NULL, 'DASHGOALS_TRAFFIC_02_2022', '600', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(5, NULL, NULL, 'DASHGOALS_CONVERSION_02_2022', '2', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(6, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_02_2022', '80', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(7, NULL, NULL, 'DASHGOALS_TRAFFIC_03_2022', '600', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(8, NULL, NULL, 'DASHGOALS_CONVERSION_03_2022', '2', '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(9, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_03_2022', '80', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(10, NULL, NULL, 'DASHGOALS_TRAFFIC_04_2022', '600', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(11, NULL, NULL, 'DASHGOALS_CONVERSION_04_2022', '2', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(12, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_04_2022', '80', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(13, NULL, NULL, 'DASHGOALS_TRAFFIC_05_2022', '600', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(14, NULL, NULL, 'DASHGOALS_CONVERSION_05_2022', '2', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(15, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_05_2022', '80', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(16, NULL, NULL, 'DASHGOALS_TRAFFIC_06_2022', '600', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(17, NULL, NULL, 'DASHGOALS_CONVERSION_06_2022', '2', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(18, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_06_2022', '80', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(19, NULL, NULL, 'DASHGOALS_TRAFFIC_07_2022', '600', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(20, NULL, NULL, 'DASHGOALS_CONVERSION_07_2022', '2', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(21, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_07_2022', '80', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(22, NULL, NULL, 'DASHGOALS_TRAFFIC_08_2022', '600', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(23, NULL, NULL, 'DASHGOALS_CONVERSION_08_2022', '2', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(24, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_08_2022', '80', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(25, NULL, NULL, 'DASHGOALS_TRAFFIC_09_2022', '600', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(26, NULL, NULL, 'DASHGOALS_CONVERSION_09_2022', '2', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(27, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_09_2022', '80', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(28, NULL, NULL, 'DASHGOALS_TRAFFIC_10_2022', '600', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(29, NULL, NULL, 'DASHGOALS_CONVERSION_10_2022', '2', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(30, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_10_2022', '80', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(31, NULL, NULL, 'DASHGOALS_TRAFFIC_11_2022', '600', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(32, NULL, NULL, 'DASHGOALS_CONVERSION_11_2022', '2', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(33, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_11_2022', '80', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(34, NULL, NULL, 'DASHGOALS_TRAFFIC_12_2022', '600', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(35, NULL, NULL, 'DASHGOALS_CONVERSION_12_2022', '2', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(36, NULL, NULL, 'DASHGOALS_AVG_CART_VALUE_12_2022', '80', '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(37, NULL, NULL, 'MAIN_COUNTRY', NULL, '2022-12-11 22:17:14', '2022-12-11 22:17:14'),
(38, NULL, NULL, 'MAIN_COUNTRY_EXPIRE', NULL, '2022-12-11 22:17:14', '2022-12-11 22:17:14'),
(39, NULL, NULL, 'FRONTOFFICE_TRANSLATIONS', '0%', '2022-12-11 22:17:14', '2022-12-11 22:17:14'),
(40, NULL, NULL, 'FRONTOFFICE_TRANSLATIONS_EXPIRE', '1670793554', '2022-12-11 22:17:14', '2022-12-11 22:17:14'),
(41, NULL, NULL, 'ENABLED_LANGUAGES', '1', '2022-12-11 22:17:14', '2022-12-11 22:17:14'),
(42, NULL, NULL, 'ENABLED_LANGUAGES_EXPIRE', '1670793494', '2022-12-11 22:17:14', '2022-12-11 22:17:14');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_configuration_kpi_lang`
--

CREATE TABLE `ps_configuration_kpi_lang` (
  `id_configuration_kpi` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `value` text DEFAULT NULL,
  `date_upd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_configuration_kpi_lang`
--

INSERT INTO `ps_configuration_kpi_lang` (`id_configuration_kpi`, `id_lang`, `value`, `date_upd`) VALUES
(37, 1, 'Brak zamówień', '2022-12-11 22:17:14'),
(38, 1, '1670879834', '2022-12-11 22:17:14');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_configuration_lang`
--

CREATE TABLE `ps_configuration_lang` (
  `id_configuration` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `value` text DEFAULT NULL,
  `date_upd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_configuration_lang`
--

INSERT INTO `ps_configuration_lang` (`id_configuration`, `id_lang`, `value`, `date_upd`) VALUES
(38, 1, '#FV', NULL),
(41, 1, '#LP', NULL),
(43, 1, '#ZW', NULL),
(54, 1, 'ach|aj|albo|bardzo|bez|bo|być|ci|cię|ciebie|co|czy|daleko|dla|dlaczego|dlatego|do|dobrze|dokąd|dość|dużo|dwa|dwaj|dwie|dwoje|dziś|dzisiaj|gdyby|gdzie|go|ich|ile|im|inny|ja|ją|jak|jakby|jaki|je|jeden|jedna|jedno|jego|jej|jemu|jeśli|jest|jestem|jeżeli|już|każdy|kiedy|kierunku|kto|ku|lub|ma|mają|mam|mi|mną|mnie|moi|mój|moja|moje|może|mu|my|na|nam|nami|nas|nasi|nasz|nasza|nasze|natychmiast|nią|nic|nich|nie|niego|niej|niemu|nigdy|nim|nimi|niż|obok|od|okolo|on|ona|one|oni|ono|owszem|po|pod|ponieważ|przed|przedtem|są|sam|sama|się|skąd|tak|taki|tam|ten|to|tobą|tobie|tu|tutaj|twoi|twój|twoja|twoje|ty|wam|wami|was|wasi|wasz|wasza|wasze|we|więc|wszystko|wtedy|wy|żaden|zawsze|że', NULL),
(80, 1, 'Dear Customer,\r\n\r\nRegards,\r\nCustomer service', NULL),
(281, 1, 'We are currently updating our shop and will be back really soon.\r\nThanks for your patience.', NULL),
(283, 1, '', NULL),
(284, 1, '', NULL),
(285, 1, 'Obecnie brak na stanie', NULL),
(293, 1, 'Moje listy życzeń', '2022-12-08 17:56:34'),
(294, 1, 'Moja lista życzeń', '2022-12-08 17:56:34'),
(295, 1, 'Utwórz nową listę', '2022-12-08 17:56:34'),
(316, 1, 'ae0a34214a00c33494e172102e7cbe4d.png', '2022-12-11 21:14:39'),
(317, 1, 'example.com', '2022-12-11 21:14:39'),
(318, 1, 'Baner SuperKursów', '2022-12-11 21:14:39'),
(327, 1, 'Udostępnione przez Ciebie dane osobowe są wykorzystywane w celu udzielania odpowiedzi na zapytania, przetwarzania zamówień lub umożliwiania dostępu do konkretnych informacji. Przysługuje Ci prawo do modyfikowania oraz usuwania wszelkich danych osobowych zamieszczonych na stronie „Moje konto”.', '2022-12-08 17:56:37'),
(329, 1, 'Możesz zrezygnować w każdej chwili. W tym celu należy odnaleźć szczegóły w naszej informacji prawnej.', '2022-12-08 17:56:37'),
(365, 1, 'Akceptuję ogólne warunki użytkowania i politykę prywatności', '2022-12-08 17:57:24'),
(367, 1, 'Akceptuję ogólne warunki użytkowania i politykę prywatności', '2022-12-08 17:57:24');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_connections`
--

CREATE TABLE `ps_connections` (
  `id_connections` int(10) UNSIGNED NOT NULL,
  `id_shop_group` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_guest` int(10) UNSIGNED NOT NULL,
  `id_page` int(10) UNSIGNED NOT NULL,
  `ip_address` bigint(20) DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `http_referer` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_connections`
--

INSERT INTO `ps_connections` (`id_connections`, `id_shop_group`, `id_shop`, `id_guest`, `id_page`, `ip_address`, `date_add`, `http_referer`) VALUES
(1, 1, 1, 1, 1, 2130706433, '2022-12-08 17:57:54', 'https://www.prestashop.com'),
(2, 1, 1, 3, 1, 2886926337, '2022-12-08 17:58:53', ''),
(3, 1, 1, 3, 1, 2886926337, '2022-12-08 18:29:30', ''),
(4, 1, 1, 4, 1, 2886926337, '2022-12-08 18:47:26', ''),
(5, 1, 1, 5, 1, 3232247809, '2022-12-09 16:13:46', ''),
(6, 1, 1, 5, 1, 2886926337, '2022-12-11 22:08:39', ''),
(7, 1, 1, 5, 1, 2886926337, '2022-12-11 22:39:25', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_connections_page`
--

CREATE TABLE `ps_connections_page` (
  `id_connections` int(10) UNSIGNED NOT NULL,
  `id_page` int(10) UNSIGNED NOT NULL,
  `time_start` datetime NOT NULL,
  `time_end` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_connections_source`
--

CREATE TABLE `ps_connections_source` (
  `id_connections_source` int(10) UNSIGNED NOT NULL,
  `id_connections` int(10) UNSIGNED NOT NULL,
  `http_referer` varchar(255) DEFAULT NULL,
  `request_uri` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_contact`
--

CREATE TABLE `ps_contact` (
  `id_contact` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `customer_service` tinyint(1) NOT NULL DEFAULT 0,
  `position` tinyint(2) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_contact`
--

INSERT INTO `ps_contact` (`id_contact`, `email`, `customer_service`, `position`) VALUES
(1, 'admin@admin.pl', 1, 0),
(2, 'admin@admin.pl', 1, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_contact_lang`
--

CREATE TABLE `ps_contact_lang` (
  `id_contact` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_contact_lang`
--

INSERT INTO `ps_contact_lang` (`id_contact`, `id_lang`, `name`, `description`) VALUES
(1, 1, 'Webmaster', 'Jeśli pojawił się problem techniczny na tej stronie'),
(2, 1, 'Biuro Obsługi Klienta', 'Wszelkie pytania dotyczące produktów i zamówień');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_contact_shop`
--

CREATE TABLE `ps_contact_shop` (
  `id_contact` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_contact_shop`
--

INSERT INTO `ps_contact_shop` (`id_contact`, `id_shop`) VALUES
(1, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_country`
--

CREATE TABLE `ps_country` (
  `id_country` int(10) UNSIGNED NOT NULL,
  `id_zone` int(10) UNSIGNED NOT NULL,
  `id_currency` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `iso_code` varchar(3) NOT NULL,
  `call_prefix` int(10) NOT NULL DEFAULT 0,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `contains_states` tinyint(1) NOT NULL DEFAULT 0,
  `need_identification_number` tinyint(1) NOT NULL DEFAULT 0,
  `need_zip_code` tinyint(1) NOT NULL DEFAULT 1,
  `zip_code_format` varchar(12) NOT NULL DEFAULT '',
  `display_tax_label` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_country`
--

INSERT INTO `ps_country` (`id_country`, `id_zone`, `id_currency`, `iso_code`, `call_prefix`, `active`, `contains_states`, `need_identification_number`, `need_zip_code`, `zip_code_format`, `display_tax_label`) VALUES
(1, 1, 0, 'DE', 49, 0, 0, 0, 1, 'NNNNN', 1),
(2, 1, 0, 'AT', 43, 0, 0, 0, 1, 'NNNN', 1),
(3, 1, 0, 'BE', 32, 0, 0, 0, 1, 'NNNN', 1),
(4, 2, 0, 'CA', 1, 0, 1, 0, 1, 'LNL NLN', 0),
(5, 3, 0, 'CN', 86, 0, 0, 0, 1, 'NNNNNN', 1),
(6, 1, 0, 'ES', 34, 0, 0, 1, 1, 'NNNNN', 1),
(7, 1, 0, 'FI', 358, 0, 0, 0, 1, 'NNNNN', 1),
(8, 1, 0, 'FR', 33, 0, 0, 0, 1, 'NNNNN', 1),
(9, 1, 0, 'GR', 30, 0, 0, 0, 1, 'NNNNN', 1),
(10, 1, 0, 'IT', 39, 0, 1, 0, 1, 'NNNNN', 1),
(11, 3, 0, 'JP', 81, 0, 1, 0, 1, 'NNN-NNNN', 1),
(12, 1, 0, 'LU', 352, 0, 0, 0, 1, 'NNNN', 1),
(13, 1, 0, 'NL', 31, 0, 0, 0, 1, 'NNNN LL', 1),
(14, 1, 0, 'PL', 48, 1, 0, 0, 1, 'NN-NNN', 1),
(15, 1, 0, 'PT', 351, 0, 0, 0, 1, 'NNNN-NNN', 1),
(16, 1, 0, 'CZ', 420, 0, 0, 0, 1, 'NNN NN', 1),
(17, 7, 0, 'GB', 44, 0, 0, 0, 1, '', 1),
(18, 1, 0, 'SE', 46, 0, 0, 0, 1, 'NNN NN', 1),
(19, 7, 0, 'CH', 41, 0, 0, 0, 1, 'NNNN', 1),
(20, 1, 0, 'DK', 45, 0, 0, 0, 1, 'NNNN', 1),
(21, 2, 0, 'US', 1, 0, 1, 0, 1, 'NNNNN', 0),
(22, 3, 0, 'HK', 852, 0, 0, 0, 0, '', 1),
(23, 7, 0, 'NO', 47, 0, 0, 0, 1, 'NNNN', 1),
(24, 5, 0, 'AU', 61, 0, 1, 0, 1, 'NNNN', 1),
(25, 3, 0, 'SG', 65, 0, 0, 0, 1, 'NNNNNN', 1),
(26, 1, 0, 'IE', 353, 0, 0, 0, 0, '', 1),
(27, 5, 0, 'NZ', 64, 0, 0, 0, 1, 'NNNN', 1),
(28, 3, 0, 'KR', 82, 0, 0, 0, 1, 'NNNNN', 1),
(29, 3, 0, 'IL', 972, 0, 0, 0, 1, 'NNNNNNN', 1),
(30, 4, 0, 'ZA', 27, 0, 0, 0, 1, 'NNNN', 1),
(31, 4, 0, 'NG', 234, 0, 0, 0, 1, '', 1),
(32, 4, 0, 'CI', 225, 0, 0, 0, 1, '', 1),
(33, 4, 0, 'TG', 228, 0, 0, 0, 1, '', 1),
(34, 6, 0, 'BO', 591, 0, 0, 0, 1, '', 1),
(35, 4, 0, 'MU', 230, 0, 0, 0, 1, '', 1),
(36, 1, 0, 'RO', 40, 0, 0, 0, 1, 'NNNNNN', 1),
(37, 1, 0, 'SK', 421, 0, 0, 0, 1, 'NNN NN', 1),
(38, 4, 0, 'DZ', 213, 0, 0, 0, 1, 'NNNNN', 1),
(39, 2, 0, 'AS', 0, 0, 0, 0, 1, '', 1),
(40, 7, 0, 'AD', 376, 0, 0, 0, 1, 'CNNN', 1),
(41, 4, 0, 'AO', 244, 0, 0, 0, 0, '', 1),
(42, 8, 0, 'AI', 0, 0, 0, 0, 1, '', 1),
(43, 2, 0, 'AG', 0, 0, 0, 0, 1, '', 1),
(44, 6, 0, 'AR', 54, 0, 1, 0, 1, 'LNNNNLLL', 1),
(45, 3, 0, 'AM', 374, 0, 0, 0, 1, 'NNNN', 1),
(46, 8, 0, 'AW', 297, 0, 0, 0, 1, '', 1),
(47, 3, 0, 'AZ', 994, 0, 0, 0, 1, 'CNNNN', 1),
(48, 2, 0, 'BS', 0, 0, 0, 0, 1, '', 1),
(49, 3, 0, 'BH', 973, 0, 0, 0, 1, '', 1),
(50, 3, 0, 'BD', 880, 0, 0, 0, 1, 'NNNN', 1),
(51, 2, 0, 'BB', 0, 0, 0, 0, 1, 'CNNNNN', 1),
(52, 7, 0, 'BY', 0, 0, 0, 0, 1, 'NNNNNN', 1),
(53, 8, 0, 'BZ', 501, 0, 0, 0, 0, '', 1),
(54, 4, 0, 'BJ', 229, 0, 0, 0, 0, '', 1),
(55, 2, 0, 'BM', 0, 0, 0, 0, 1, '', 1),
(56, 3, 0, 'BT', 975, 0, 0, 0, 1, '', 1),
(57, 4, 0, 'BW', 267, 0, 0, 0, 1, '', 1),
(58, 6, 0, 'BR', 55, 0, 0, 0, 1, 'NNNNN-NNN', 1),
(59, 3, 0, 'BN', 673, 0, 0, 0, 1, 'LLNNNN', 1),
(60, 4, 0, 'BF', 226, 0, 0, 0, 1, '', 1),
(61, 3, 0, 'MM', 95, 0, 0, 0, 1, '', 1),
(62, 4, 0, 'BI', 257, 0, 0, 0, 1, '', 1),
(63, 3, 0, 'KH', 855, 0, 0, 0, 1, 'NNNNN', 1),
(64, 4, 0, 'CM', 237, 0, 0, 0, 1, '', 1),
(65, 4, 0, 'CV', 238, 0, 0, 0, 1, 'NNNN', 1),
(66, 4, 0, 'CF', 236, 0, 0, 0, 1, '', 1),
(67, 4, 0, 'TD', 235, 0, 0, 0, 1, '', 1),
(68, 6, 0, 'CL', 56, 0, 0, 0, 1, 'NNN-NNNN', 1),
(69, 6, 0, 'CO', 57, 0, 0, 0, 1, 'NNNNNN', 1),
(70, 4, 0, 'KM', 269, 0, 0, 0, 1, '', 1),
(71, 4, 0, 'CD', 243, 0, 0, 0, 1, '', 1),
(72, 4, 0, 'CG', 242, 0, 0, 0, 1, '', 1),
(73, 8, 0, 'CR', 506, 0, 0, 0, 1, 'NNNNN', 1),
(74, 1, 0, 'HR', 385, 0, 0, 0, 1, 'NNNNN', 1),
(75, 8, 0, 'CU', 53, 0, 0, 0, 1, '', 1),
(76, 1, 0, 'CY', 357, 0, 0, 0, 1, 'NNNN', 1),
(77, 4, 0, 'DJ', 253, 0, 0, 0, 1, '', 1),
(78, 8, 0, 'DM', 0, 0, 0, 0, 1, '', 1),
(79, 8, 0, 'DO', 0, 0, 0, 0, 1, '', 1),
(80, 3, 0, 'TL', 670, 0, 0, 0, 1, '', 1),
(81, 6, 0, 'EC', 593, 0, 0, 0, 1, 'CNNNNNN', 1),
(82, 4, 0, 'EG', 20, 0, 0, 0, 1, 'NNNNN', 1),
(83, 8, 0, 'SV', 503, 0, 0, 0, 1, '', 1),
(84, 4, 0, 'GQ', 240, 0, 0, 0, 1, '', 1),
(85, 4, 0, 'ER', 291, 0, 0, 0, 1, '', 1),
(86, 1, 0, 'EE', 372, 0, 0, 0, 1, 'NNNNN', 1),
(87, 4, 0, 'ET', 251, 0, 0, 0, 1, '', 1),
(88, 8, 0, 'FK', 0, 0, 0, 0, 1, 'LLLL NLL', 1),
(89, 7, 0, 'FO', 298, 0, 0, 0, 1, '', 1),
(90, 5, 0, 'FJ', 679, 0, 0, 0, 1, '', 1),
(91, 4, 0, 'GA', 241, 0, 0, 0, 1, '', 1),
(92, 4, 0, 'GM', 220, 0, 0, 0, 1, '', 1),
(93, 3, 0, 'GE', 995, 0, 0, 0, 1, 'NNNN', 1),
(94, 4, 0, 'GH', 233, 0, 0, 0, 1, '', 1),
(95, 8, 0, 'GD', 0, 0, 0, 0, 1, '', 1),
(96, 7, 0, 'GL', 299, 0, 0, 0, 1, '', 1),
(97, 7, 0, 'GI', 350, 0, 0, 0, 1, '', 1),
(98, 8, 0, 'GP', 590, 0, 0, 0, 1, '', 1),
(99, 5, 0, 'GU', 0, 0, 0, 0, 1, '', 1),
(100, 8, 0, 'GT', 502, 0, 0, 0, 1, '', 1),
(101, 7, 0, 'GG', 0, 0, 0, 0, 1, 'LLN NLL', 1),
(102, 4, 0, 'GN', 224, 0, 0, 0, 1, '', 1),
(103, 4, 0, 'GW', 245, 0, 0, 0, 1, '', 1),
(104, 6, 0, 'GY', 592, 0, 0, 0, 1, '', 1),
(105, 8, 0, 'HT', 509, 0, 0, 0, 1, '', 1),
(106, 7, 0, 'VA', 379, 0, 0, 0, 1, 'NNNNN', 1),
(107, 8, 0, 'HN', 504, 0, 0, 0, 1, '', 1),
(108, 7, 0, 'IS', 354, 0, 0, 0, 1, 'NNN', 1),
(109, 3, 0, 'IN', 91, 0, 1, 0, 1, 'NNN NNN', 1),
(110, 3, 0, 'ID', 62, 0, 1, 0, 1, 'NNNNN', 1),
(111, 3, 0, 'IR', 98, 0, 0, 0, 1, 'NNNNN-NNNNN', 1),
(112, 3, 0, 'IQ', 964, 0, 0, 0, 1, 'NNNNN', 1),
(113, 7, 0, 'IM', 0, 0, 0, 0, 1, 'CN NLL', 1),
(114, 8, 0, 'JM', 0, 0, 0, 0, 1, '', 1),
(115, 7, 0, 'JE', 0, 0, 0, 0, 1, 'CN NLL', 1),
(116, 3, 0, 'JO', 962, 0, 0, 0, 1, '', 1),
(117, 3, 0, 'KZ', 7, 0, 0, 0, 1, 'NNNNNN', 1),
(118, 4, 0, 'KE', 254, 0, 0, 0, 1, '', 1),
(119, 5, 0, 'KI', 686, 0, 0, 0, 1, '', 1),
(120, 3, 0, 'KP', 850, 0, 0, 0, 1, '', 1),
(121, 3, 0, 'KW', 965, 0, 0, 0, 1, '', 1),
(122, 3, 0, 'KG', 996, 0, 0, 0, 1, '', 1),
(123, 3, 0, 'LA', 856, 0, 0, 0, 1, '', 1),
(124, 1, 0, 'LV', 371, 0, 0, 0, 1, 'C-NNNN', 1),
(125, 3, 0, 'LB', 961, 0, 0, 0, 1, '', 1),
(126, 4, 0, 'LS', 266, 0, 0, 0, 1, '', 1),
(127, 4, 0, 'LR', 231, 0, 0, 0, 1, '', 1),
(128, 4, 0, 'LY', 218, 0, 0, 0, 1, '', 1),
(129, 7, 0, 'LI', 423, 0, 0, 0, 1, 'NNNN', 1),
(130, 1, 0, 'LT', 370, 0, 0, 0, 1, 'NNNNN', 1),
(131, 3, 0, 'MO', 853, 0, 0, 0, 0, '', 1),
(132, 7, 0, 'MK', 389, 0, 0, 0, 1, '', 1),
(133, 4, 0, 'MG', 261, 0, 0, 0, 1, '', 1),
(134, 4, 0, 'MW', 265, 0, 0, 0, 1, '', 1),
(135, 3, 0, 'MY', 60, 0, 0, 0, 1, 'NNNNN', 1),
(136, 3, 0, 'MV', 960, 0, 0, 0, 1, '', 1),
(137, 4, 0, 'ML', 223, 0, 0, 0, 1, '', 1),
(138, 1, 0, 'MT', 356, 0, 0, 0, 1, 'LLL NNNN', 1),
(139, 5, 0, 'MH', 692, 0, 0, 0, 1, '', 1),
(140, 8, 0, 'MQ', 596, 0, 0, 0, 1, '', 1),
(141, 4, 0, 'MR', 222, 0, 0, 0, 1, '', 1),
(142, 1, 0, 'HU', 36, 0, 0, 0, 1, 'NNNN', 1),
(143, 4, 0, 'YT', 262, 0, 0, 0, 1, '', 1),
(144, 2, 0, 'MX', 52, 0, 1, 1, 1, 'NNNNN', 1),
(145, 5, 0, 'FM', 691, 0, 0, 0, 1, '', 1),
(146, 7, 0, 'MD', 373, 0, 0, 0, 1, 'C-NNNN', 1),
(147, 7, 0, 'MC', 377, 0, 0, 0, 1, '980NN', 1),
(148, 3, 0, 'MN', 976, 0, 0, 0, 1, '', 1),
(149, 7, 0, 'ME', 382, 0, 0, 0, 1, 'NNNNN', 1),
(150, 8, 0, 'MS', 0, 0, 0, 0, 1, '', 1),
(151, 4, 0, 'MA', 212, 0, 0, 0, 1, 'NNNNN', 1),
(152, 4, 0, 'MZ', 258, 0, 0, 0, 1, '', 1),
(153, 4, 0, 'NA', 264, 0, 0, 0, 1, '', 1),
(154, 5, 0, 'NR', 674, 0, 0, 0, 1, '', 1),
(155, 3, 0, 'NP', 977, 0, 0, 0, 1, '', 1),
(156, 5, 0, 'NC', 687, 0, 0, 0, 1, '', 1),
(157, 8, 0, 'NI', 505, 0, 0, 0, 1, 'NNNNNN', 1),
(158, 4, 0, 'NE', 227, 0, 0, 0, 1, '', 1),
(159, 5, 0, 'NU', 683, 0, 0, 0, 1, '', 1),
(160, 5, 0, 'NF', 0, 0, 0, 0, 1, '', 1),
(161, 5, 0, 'MP', 0, 0, 0, 0, 1, '', 1),
(162, 3, 0, 'OM', 968, 0, 0, 0, 1, '', 1),
(163, 3, 0, 'PK', 92, 0, 0, 0, 1, '', 1),
(164, 5, 0, 'PW', 680, 0, 0, 0, 1, '', 1),
(165, 3, 0, 'PS', 0, 0, 0, 0, 1, '', 1),
(166, 8, 0, 'PA', 507, 0, 0, 0, 1, 'NNNNNN', 1),
(167, 5, 0, 'PG', 675, 0, 0, 0, 1, '', 1),
(168, 6, 0, 'PY', 595, 0, 0, 0, 1, '', 1),
(169, 6, 0, 'PE', 51, 0, 0, 0, 1, '', 1),
(170, 3, 0, 'PH', 63, 0, 0, 0, 1, 'NNNN', 1),
(171, 5, 0, 'PN', 0, 0, 0, 0, 1, 'LLLL NLL', 1),
(172, 8, 0, 'PR', 0, 0, 0, 0, 1, 'NNNNN', 1),
(173, 3, 0, 'QA', 974, 0, 0, 0, 1, '', 1),
(174, 4, 0, 'RE', 262, 0, 0, 0, 1, '', 1),
(175, 7, 0, 'RU', 7, 0, 0, 0, 1, 'NNNNNN', 1),
(176, 4, 0, 'RW', 250, 0, 0, 0, 1, '', 1),
(177, 8, 0, 'BL', 0, 0, 0, 0, 1, '', 1),
(178, 8, 0, 'KN', 0, 0, 0, 0, 1, '', 1),
(179, 8, 0, 'LC', 0, 0, 0, 0, 1, '', 1),
(180, 8, 0, 'MF', 0, 0, 0, 0, 1, '', 1),
(181, 8, 0, 'PM', 508, 0, 0, 0, 1, '', 1),
(182, 8, 0, 'VC', 0, 0, 0, 0, 1, '', 1),
(183, 5, 0, 'WS', 685, 0, 0, 0, 1, '', 1),
(184, 7, 0, 'SM', 378, 0, 0, 0, 1, 'NNNNN', 1),
(185, 4, 0, 'ST', 239, 0, 0, 0, 1, '', 1),
(186, 3, 0, 'SA', 966, 0, 0, 0, 1, '', 1),
(187, 4, 0, 'SN', 221, 0, 0, 0, 1, '', 1),
(188, 7, 0, 'RS', 381, 0, 0, 0, 1, 'NNNNN', 1),
(189, 4, 0, 'SC', 248, 0, 0, 0, 1, '', 1),
(190, 4, 0, 'SL', 232, 0, 0, 0, 1, '', 1),
(191, 1, 0, 'SI', 386, 0, 0, 0, 1, 'C-NNNN', 1),
(192, 5, 0, 'SB', 677, 0, 0, 0, 1, '', 1),
(193, 4, 0, 'SO', 252, 0, 0, 0, 1, '', 1),
(194, 8, 0, 'GS', 0, 0, 0, 0, 1, 'LLLL NLL', 1),
(195, 3, 0, 'LK', 94, 0, 0, 0, 1, 'NNNNN', 1),
(196, 4, 0, 'SD', 249, 0, 0, 0, 1, '', 1),
(197, 8, 0, 'SR', 597, 0, 0, 0, 1, '', 1),
(198, 7, 0, 'SJ', 0, 0, 0, 0, 1, '', 1),
(199, 4, 0, 'SZ', 268, 0, 0, 0, 1, '', 1),
(200, 3, 0, 'SY', 963, 0, 0, 0, 1, '', 1),
(201, 3, 0, 'TW', 886, 0, 0, 0, 1, 'NNNNN', 1),
(202, 3, 0, 'TJ', 992, 0, 0, 0, 1, '', 1),
(203, 4, 0, 'TZ', 255, 0, 0, 0, 1, '', 1),
(204, 3, 0, 'TH', 66, 0, 0, 0, 1, 'NNNNN', 1),
(205, 5, 0, 'TK', 690, 0, 0, 0, 1, '', 1),
(206, 5, 0, 'TO', 676, 0, 0, 0, 1, '', 1),
(207, 6, 0, 'TT', 0, 0, 0, 0, 1, '', 1),
(208, 4, 0, 'TN', 216, 0, 0, 0, 1, '', 1),
(209, 7, 0, 'TR', 90, 0, 0, 0, 1, 'NNNNN', 1),
(210, 3, 0, 'TM', 993, 0, 0, 0, 1, '', 1),
(211, 8, 0, 'TC', 0, 0, 0, 0, 1, 'LLLL NLL', 1),
(212, 5, 0, 'TV', 688, 0, 0, 0, 1, '', 1),
(213, 4, 0, 'UG', 256, 0, 0, 0, 1, '', 1),
(214, 7, 0, 'UA', 380, 0, 0, 0, 1, 'NNNNN', 1),
(215, 3, 0, 'AE', 971, 0, 0, 0, 1, '', 1),
(216, 6, 0, 'UY', 598, 0, 0, 0, 1, '', 1),
(217, 3, 0, 'UZ', 998, 0, 0, 0, 1, '', 1),
(218, 5, 0, 'VU', 678, 0, 0, 0, 1, '', 1),
(219, 6, 0, 'VE', 58, 0, 0, 0, 1, '', 1),
(220, 3, 0, 'VN', 84, 0, 0, 0, 1, 'NNNNNN', 1),
(221, 2, 0, 'VG', 0, 0, 0, 0, 1, 'CNNNN', 1),
(222, 2, 0, 'VI', 0, 0, 0, 0, 1, '', 1),
(223, 5, 0, 'WF', 681, 0, 0, 0, 1, '', 1),
(224, 4, 0, 'EH', 0, 0, 0, 0, 1, '', 1),
(225, 3, 0, 'YE', 967, 0, 0, 0, 1, '', 1),
(226, 4, 0, 'ZM', 260, 0, 0, 0, 1, '', 1),
(227, 4, 0, 'ZW', 263, 0, 0, 0, 1, '', 1),
(228, 7, 0, 'AL', 355, 0, 0, 0, 1, 'NNNN', 1),
(229, 3, 0, 'AF', 93, 0, 0, 0, 1, 'NNNN', 1),
(230, 5, 0, 'AQ', 0, 0, 0, 0, 1, '', 1),
(231, 7, 0, 'BA', 387, 0, 0, 0, 1, '', 1),
(232, 5, 0, 'IO', 0, 0, 0, 0, 1, 'LLLL NLL', 1),
(233, 1, 0, 'BG', 359, 0, 0, 0, 1, 'NNNN', 1),
(234, 8, 0, 'KY', 0, 0, 0, 0, 1, '', 1),
(235, 3, 0, 'CX', 0, 0, 0, 0, 1, '', 1),
(236, 3, 0, 'CC', 0, 0, 0, 0, 1, '', 1),
(237, 5, 0, 'CK', 682, 0, 0, 0, 1, '', 1),
(238, 6, 0, 'GF', 594, 0, 0, 0, 1, '', 1),
(239, 5, 0, 'PF', 689, 0, 0, 0, 1, '', 1),
(240, 5, 0, 'TF', 0, 0, 0, 0, 1, '', 1),
(241, 7, 0, 'AX', 0, 0, 0, 0, 1, 'NNNNN', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_country_lang`
--

CREATE TABLE `ps_country_lang` (
  `id_country` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_country_lang`
--

INSERT INTO `ps_country_lang` (`id_country`, `id_lang`, `name`) VALUES
(1, 1, 'Niemcy'),
(2, 1, 'Austria'),
(3, 1, 'Belgia'),
(4, 1, 'Kanada'),
(5, 1, 'Chiny'),
(6, 1, 'Hiszpania'),
(7, 1, 'Finlandia'),
(8, 1, 'Francja'),
(9, 1, 'Grecja'),
(10, 1, 'Włochy'),
(11, 1, 'Japonia'),
(12, 1, 'Luksemburg'),
(13, 1, 'Holandia'),
(14, 1, 'Polska'),
(15, 1, 'Portugalia'),
(16, 1, 'Czechy'),
(17, 1, 'Wielka Brytania'),
(18, 1, 'Szwecja'),
(19, 1, 'Szwajcaria'),
(20, 1, 'Dania'),
(21, 1, 'Stany Zjednoczone'),
(22, 1, 'SRA Hongkong (Chiny)'),
(23, 1, 'Norwegia'),
(24, 1, 'Australia'),
(25, 1, 'Singapur'),
(26, 1, 'Irlandia'),
(27, 1, 'Nowa Zelandia'),
(28, 1, 'Korea Południowa'),
(29, 1, 'Izrael'),
(30, 1, 'Republika Południowej Afryki'),
(31, 1, 'Nigeria'),
(32, 1, 'Côte d’Ivoire'),
(33, 1, 'Togo'),
(34, 1, 'Boliwia'),
(35, 1, 'Mauritius'),
(36, 1, 'Rumunia'),
(37, 1, 'Słowacja'),
(38, 1, 'Algieria'),
(39, 1, 'Samoa Amerykańskie'),
(40, 1, 'Andora'),
(41, 1, 'Angola'),
(42, 1, 'Anguilla'),
(43, 1, 'Antigua i Barbuda'),
(44, 1, 'Argentyna'),
(45, 1, 'Armenia'),
(46, 1, 'Aruba'),
(47, 1, 'Azerbejdżan'),
(48, 1, 'Bahamy'),
(49, 1, 'Bahrajn'),
(50, 1, 'Bangladesz'),
(51, 1, 'Barbados'),
(52, 1, 'Białoruś'),
(53, 1, 'Belize'),
(54, 1, 'Benin'),
(55, 1, 'Bermudy'),
(56, 1, 'Bhutan'),
(57, 1, 'Botswana'),
(58, 1, 'Brazylia'),
(59, 1, 'Brunei'),
(60, 1, 'Burkina Faso'),
(61, 1, 'Mjanma (Birma)'),
(62, 1, 'Burundi'),
(63, 1, 'Kambodża'),
(64, 1, 'Kamerun'),
(65, 1, 'Republika Zielonego Przylądka'),
(66, 1, 'Republika Środkowoafrykańska'),
(67, 1, 'Czad'),
(68, 1, 'Chile'),
(69, 1, 'Kolumbia'),
(70, 1, 'Komory'),
(71, 1, 'Demokratyczna Republika Konga'),
(72, 1, 'Kongo'),
(73, 1, 'Kostaryka'),
(74, 1, 'Chorwacja'),
(75, 1, 'Kuba'),
(76, 1, 'Cypr'),
(77, 1, 'Dżibuti'),
(78, 1, 'Dominika'),
(79, 1, 'Dominikana'),
(80, 1, 'Timor Wschodni'),
(81, 1, 'Ekwador'),
(82, 1, 'Egipt'),
(83, 1, 'Salwador'),
(84, 1, 'Gwinea Równikowa'),
(85, 1, 'Erytrea'),
(86, 1, 'Estonia'),
(87, 1, 'Etiopia'),
(88, 1, 'Falklandy'),
(89, 1, 'Wyspy Owcze'),
(90, 1, 'Fidżi'),
(91, 1, 'Gabon'),
(92, 1, 'Gambia'),
(93, 1, 'Gruzja'),
(94, 1, 'Ghana'),
(95, 1, 'Grenada'),
(96, 1, 'Grenlandia'),
(97, 1, 'Gibraltar'),
(98, 1, 'Gwadelupa'),
(99, 1, 'Guam'),
(100, 1, 'Gwatemala'),
(101, 1, 'Guernsey'),
(102, 1, 'Gwinea'),
(103, 1, 'Gwinea Bissau'),
(104, 1, 'Gujana'),
(105, 1, 'Haiti'),
(106, 1, 'Watykan'),
(107, 1, 'Honduras'),
(108, 1, 'Islandia'),
(109, 1, 'Indie'),
(110, 1, 'Indonezja'),
(111, 1, 'Iran'),
(112, 1, 'Irak'),
(113, 1, 'Wyspa Man'),
(114, 1, 'Jamajka'),
(115, 1, 'Jersey'),
(116, 1, 'Jordania'),
(117, 1, 'Kazachstan'),
(118, 1, 'Kenia'),
(119, 1, 'Kiribati'),
(120, 1, 'Korea Północna'),
(121, 1, 'Kuwejt'),
(122, 1, 'Kirgistan'),
(123, 1, 'Laos'),
(124, 1, 'Łotwa'),
(125, 1, 'Liban'),
(126, 1, 'Lesotho'),
(127, 1, 'Liberia'),
(128, 1, 'Libia'),
(129, 1, 'Liechtenstein'),
(130, 1, 'Litwa'),
(131, 1, 'SRA Makau (Chiny)'),
(132, 1, 'Macedonia Północna'),
(133, 1, 'Madagaskar'),
(134, 1, 'Malawi'),
(135, 1, 'Malezja'),
(136, 1, 'Malediwy'),
(137, 1, 'Mali'),
(138, 1, 'Malta'),
(139, 1, 'Wyspy Marshalla'),
(140, 1, 'Martynika'),
(141, 1, 'Mauretania'),
(142, 1, 'Węgry'),
(143, 1, 'Majotta'),
(144, 1, 'Meksyk'),
(145, 1, 'Mikronezja'),
(146, 1, 'Mołdawia'),
(147, 1, 'Monako'),
(148, 1, 'Mongolia'),
(149, 1, 'Czarnogóra'),
(150, 1, 'Montserrat'),
(151, 1, 'Maroko'),
(152, 1, 'Mozambik'),
(153, 1, 'Namibia'),
(154, 1, 'Nauru'),
(155, 1, 'Nepal'),
(156, 1, 'Nowa Kaledonia'),
(157, 1, 'Nikaragua'),
(158, 1, 'Niger'),
(159, 1, 'Niue'),
(160, 1, 'Norfolk'),
(161, 1, 'Mariany Północne'),
(162, 1, 'Oman'),
(163, 1, 'Pakistan'),
(164, 1, 'Palau'),
(165, 1, 'Terytoria Palestyńskie'),
(166, 1, 'Panama'),
(167, 1, 'Papua-Nowa Gwinea'),
(168, 1, 'Paragwaj'),
(169, 1, 'Peru'),
(170, 1, 'Filipiny'),
(171, 1, 'Pitcairn'),
(172, 1, 'Portoryko'),
(173, 1, 'Katar'),
(174, 1, 'Reunion'),
(175, 1, 'Rosja'),
(176, 1, 'Rwanda'),
(177, 1, 'Saint-Barthélemy'),
(178, 1, 'Saint Kitts i Nevis'),
(179, 1, 'Saint Lucia'),
(180, 1, 'Saint-Martin'),
(181, 1, 'Saint-Pierre i Miquelon'),
(182, 1, 'Saint Vincent i Grenadyny'),
(183, 1, 'Samoa'),
(184, 1, 'San Marino'),
(185, 1, 'Wyspy Świętego Tomasza i Książęca'),
(186, 1, 'Arabia Saudyjska'),
(187, 1, 'Senegal'),
(188, 1, 'Serbia'),
(189, 1, 'Seszele'),
(190, 1, 'Sierra Leone'),
(191, 1, 'Słowenia'),
(192, 1, 'Wyspy Salomona'),
(193, 1, 'Somalia'),
(194, 1, 'Georgia Południowa i Sandwich Południowy'),
(195, 1, 'Sri Lanka'),
(196, 1, 'Sudan'),
(197, 1, 'Surinam'),
(198, 1, 'Svalbard i Jan Mayen'),
(199, 1, 'Eswatini'),
(200, 1, 'Syria'),
(201, 1, 'Tajwan'),
(202, 1, 'Tadżykistan'),
(203, 1, 'Tanzania'),
(204, 1, 'Tajlandia'),
(205, 1, 'Tokelau'),
(206, 1, 'Tonga'),
(207, 1, 'Trynidad i Tobago'),
(208, 1, 'Tunezja'),
(209, 1, 'Turcja'),
(210, 1, 'Turkmenistan'),
(211, 1, 'Turks i Caicos'),
(212, 1, 'Tuvalu'),
(213, 1, 'Uganda'),
(214, 1, 'Ukraina'),
(215, 1, 'Zjednoczone Emiraty Arabskie'),
(216, 1, 'Urugwaj'),
(217, 1, 'Uzbekistan'),
(218, 1, 'Vanuatu'),
(219, 1, 'Wenezuela'),
(220, 1, 'Wietnam'),
(221, 1, 'Brytyjskie Wyspy Dziewicze'),
(222, 1, 'Wyspy Dziewicze Stanów Zjednoczonych'),
(223, 1, 'Wallis i Futuna'),
(224, 1, 'Sahara Zachodnia'),
(225, 1, 'Jemen'),
(226, 1, 'Zambia'),
(227, 1, 'Zimbabwe'),
(228, 1, 'Albania'),
(229, 1, 'Afganistan'),
(230, 1, 'Antarktyda'),
(231, 1, 'Bośnia i Hercegowina'),
(232, 1, 'Brytyjskie Terytorium Oceanu Indyjskiego'),
(233, 1, 'Bułgaria'),
(234, 1, 'Kajmany'),
(235, 1, 'Wyspa Bożego Narodzenia'),
(236, 1, 'Wyspy Kokosowe'),
(237, 1, 'Wyspy Cooka'),
(238, 1, 'Gujana Francuska'),
(239, 1, 'Polinezja Francuska'),
(240, 1, 'Francuskie Terytoria Południowe i Antarktyczne'),
(241, 1, 'Wyspy Alandzkie');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_country_shop`
--

CREATE TABLE `ps_country_shop` (
  `id_country` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_country_shop`
--

INSERT INTO `ps_country_shop` (`id_country`, `id_shop`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(64, 1),
(65, 1),
(66, 1),
(67, 1),
(68, 1),
(69, 1),
(70, 1),
(71, 1),
(72, 1),
(73, 1),
(74, 1),
(75, 1),
(76, 1),
(77, 1),
(78, 1),
(79, 1),
(80, 1),
(81, 1),
(82, 1),
(83, 1),
(84, 1),
(85, 1),
(86, 1),
(87, 1),
(88, 1),
(89, 1),
(90, 1),
(91, 1),
(92, 1),
(93, 1),
(94, 1),
(95, 1),
(96, 1),
(97, 1),
(98, 1),
(99, 1),
(100, 1),
(101, 1),
(102, 1),
(103, 1),
(104, 1),
(105, 1),
(106, 1),
(107, 1),
(108, 1),
(109, 1),
(110, 1),
(111, 1),
(112, 1),
(113, 1),
(114, 1),
(115, 1),
(116, 1),
(117, 1),
(118, 1),
(119, 1),
(120, 1),
(121, 1),
(122, 1),
(123, 1),
(124, 1),
(125, 1),
(126, 1),
(127, 1),
(128, 1),
(129, 1),
(130, 1),
(131, 1),
(132, 1),
(133, 1),
(134, 1),
(135, 1),
(136, 1),
(137, 1),
(138, 1),
(139, 1),
(140, 1),
(141, 1),
(142, 1),
(143, 1),
(144, 1),
(145, 1),
(146, 1),
(147, 1),
(148, 1),
(149, 1),
(150, 1),
(151, 1),
(152, 1),
(153, 1),
(154, 1),
(155, 1),
(156, 1),
(157, 1),
(158, 1),
(159, 1),
(160, 1),
(161, 1),
(162, 1),
(163, 1),
(164, 1),
(165, 1),
(166, 1),
(167, 1),
(168, 1),
(169, 1),
(170, 1),
(171, 1),
(172, 1),
(173, 1),
(174, 1),
(175, 1),
(176, 1),
(177, 1),
(178, 1),
(179, 1),
(180, 1),
(181, 1),
(182, 1),
(183, 1),
(184, 1),
(185, 1),
(186, 1),
(187, 1),
(188, 1),
(189, 1),
(190, 1),
(191, 1),
(192, 1),
(193, 1),
(194, 1),
(195, 1),
(196, 1),
(197, 1),
(198, 1),
(199, 1),
(200, 1),
(201, 1),
(202, 1),
(203, 1),
(204, 1),
(205, 1),
(206, 1),
(207, 1),
(208, 1),
(209, 1),
(210, 1),
(211, 1),
(212, 1),
(213, 1),
(214, 1),
(215, 1),
(216, 1),
(217, 1),
(218, 1),
(219, 1),
(220, 1),
(221, 1),
(222, 1),
(223, 1),
(224, 1),
(225, 1),
(226, 1),
(227, 1),
(228, 1),
(229, 1),
(230, 1),
(231, 1),
(232, 1),
(233, 1),
(234, 1),
(235, 1),
(236, 1),
(237, 1),
(238, 1),
(239, 1),
(240, 1),
(241, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_currency`
--

CREATE TABLE `ps_currency` (
  `id_currency` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL,
  `iso_code` varchar(3) NOT NULL DEFAULT '0',
  `numeric_iso_code` varchar(3) DEFAULT NULL,
  `precision` int(2) NOT NULL DEFAULT 6,
  `conversion_rate` decimal(13,6) NOT NULL,
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `unofficial` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `modified` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_currency`
--

INSERT INTO `ps_currency` (`id_currency`, `name`, `iso_code`, `numeric_iso_code`, `precision`, `conversion_rate`, `deleted`, `active`, `unofficial`, `modified`) VALUES
(1, '', 'PLN', '985', 2, '1.000000', 0, 1, 0, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_currency_lang`
--

CREATE TABLE `ps_currency_lang` (
  `id_currency` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `pattern` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_currency_lang`
--

INSERT INTO `ps_currency_lang` (`id_currency`, `id_lang`, `name`, `symbol`, `pattern`) VALUES
(1, 1, 'złoty polski', 'zł', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_currency_shop`
--

CREATE TABLE `ps_currency_shop` (
  `id_currency` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL,
  `conversion_rate` decimal(13,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_currency_shop`
--

INSERT INTO `ps_currency_shop` (`id_currency`, `id_shop`, `conversion_rate`) VALUES
(1, 1, '1.000000');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_customer`
--

CREATE TABLE `ps_customer` (
  `id_customer` int(10) UNSIGNED NOT NULL,
  `id_shop_group` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_gender` int(10) UNSIGNED NOT NULL,
  `id_default_group` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `id_lang` int(10) UNSIGNED DEFAULT NULL,
  `id_risk` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `company` varchar(255) DEFAULT NULL,
  `siret` varchar(14) DEFAULT NULL,
  `ape` varchar(5) DEFAULT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `passwd` varchar(255) NOT NULL,
  `last_passwd_gen` timestamp NOT NULL DEFAULT current_timestamp(),
  `birthday` date DEFAULT NULL,
  `newsletter` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `ip_registration_newsletter` varchar(15) DEFAULT NULL,
  `newsletter_date_add` datetime DEFAULT NULL,
  `optin` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `website` varchar(128) DEFAULT NULL,
  `outstanding_allow_amount` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `show_public_prices` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `max_payment_days` int(10) UNSIGNED NOT NULL DEFAULT 60,
  `secure_key` varchar(32) NOT NULL DEFAULT '-1',
  `note` text DEFAULT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `is_guest` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `reset_password_token` varchar(40) DEFAULT NULL,
  `reset_password_validity` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_customer`
--

INSERT INTO `ps_customer` (`id_customer`, `id_shop_group`, `id_shop`, `id_gender`, `id_default_group`, `id_lang`, `id_risk`, `company`, `siret`, `ape`, `firstname`, `lastname`, `email`, `passwd`, `last_passwd_gen`, `birthday`, `newsletter`, `ip_registration_newsletter`, `newsletter_date_add`, `optin`, `website`, `outstanding_allow_amount`, `show_public_prices`, `max_payment_days`, `secure_key`, `note`, `active`, `is_guest`, `deleted`, `date_add`, `date_upd`, `reset_password_token`, `reset_password_validity`) VALUES
(1, 1, 1, 1, 3, 1, 0, '', '', '', 'Anonymous', 'Anonymous', 'anonymous@psgdpr.com', '$2y$10$9WLNmPL/8e04/wt29u9qFODr4xHC3zKuHnNfrFmI9rvM7IuxY3Ng2', '2022-12-08 11:57:25', '0000-00-00', 0, '', '0000-00-00 00:00:00', 0, '', '0.000000', 0, 0, 'f22d9ebca183e2e9b727863e8e1edd61', '', 0, 0, 0, '2022-12-08 17:57:25', '2022-12-08 17:57:25', '', '0000-00-00 00:00:00'),
(2, 1, 1, 1, 3, 1, 0, '', '', '', 'John', 'DOE', 'pub@prestashop.com', 'efcb617030058c45b746a4831dc78403', '2022-12-08 11:57:52', '1970-01-15', 1, '', '2013-12-13 08:19:15', 1, '', '0.000000', 0, 0, 'ac8b2f84a86de0cfafb4989f0710a46d', '', 1, 0, 0, '2022-12-08 17:57:52', '2022-12-08 17:57:52', '', '0000-00-00 00:00:00'),
(3, 1, 1, 1, 2, 1, 0, '', '', '', 'Michał', 'Zieliński', 'michazieli@gmail.com', '$2y$10$Mo2Pr4nteAvjI.rd/S0LdezJiDCddRf/j4WWr7jq9vG4SWawZf0wa', '2022-12-11 16:12:40', '0000-00-00', 0, '', '0000-00-00 00:00:00', 1, '', '0.000000', 0, 0, 'b885af361da62e482e0e364032815c50', '', 1, 1, 0, '2022-12-11 22:12:40', '2022-12-11 22:12:40', '', '0000-00-00 00:00:00'),
(4, 1, 1, 1, 3, 1, 0, '', '', '', 'Michał', 'a', 'admin@admin.pl', '$2y$10$TruLGeTHXG8B7Pr4BwF9J.5E3x0AsI.UpsTZbVzxRx3anp5RoIbIC', '2022-12-11 16:15:54', '1970-06-25', 1, '', '2022-12-11 22:15:54', 1, '', '0.000000', 0, 0, '863d7e3c891ee774ba8d40fc9c7ce121', '', 1, 0, 0, '2022-12-11 22:15:54', '2022-12-11 22:15:54', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_customer_group`
--

CREATE TABLE `ps_customer_group` (
  `id_customer` int(10) UNSIGNED NOT NULL,
  `id_group` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_customer_group`
--

INSERT INTO `ps_customer_group` (`id_customer`, `id_group`) VALUES
(1, 3),
(2, 3),
(3, 2),
(4, 3);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_customer_message`
--

CREATE TABLE `ps_customer_message` (
  `id_customer_message` int(10) UNSIGNED NOT NULL,
  `id_customer_thread` int(11) DEFAULT NULL,
  `id_employee` int(10) UNSIGNED DEFAULT NULL,
  `message` mediumtext NOT NULL,
  `file_name` varchar(18) DEFAULT NULL,
  `ip_address` varchar(16) DEFAULT NULL,
  `user_agent` varchar(128) DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `private` tinyint(4) NOT NULL DEFAULT 0,
  `read` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_customer_message_sync_imap`
--

CREATE TABLE `ps_customer_message_sync_imap` (
  `md5_header` varbinary(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_customer_session`
--

CREATE TABLE `ps_customer_session` (
  `id_customer_session` int(11) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED DEFAULT NULL,
  `token` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_customer_session`
--

INSERT INTO `ps_customer_session` (`id_customer_session`, `id_customer`, `token`) VALUES
(2, 4, 'f6fc0f869c97a0f246795362e345484f79f9afdc');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_customer_thread`
--

CREATE TABLE `ps_customer_thread` (
  `id_customer_thread` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `id_contact` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED DEFAULT NULL,
  `id_order` int(10) UNSIGNED DEFAULT NULL,
  `id_product` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('open','closed','pending1','pending2') NOT NULL DEFAULT 'open',
  `email` varchar(255) NOT NULL,
  `token` varchar(12) DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_customization`
--

CREATE TABLE `ps_customization` (
  `id_customization` int(10) UNSIGNED NOT NULL,
  `id_product_attribute` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_address_delivery` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_cart` int(10) UNSIGNED NOT NULL,
  `id_product` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `quantity_refunded` int(11) NOT NULL DEFAULT 0,
  `quantity_returned` int(11) NOT NULL DEFAULT 0,
  `in_cart` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_customization_field`
--

CREATE TABLE `ps_customization_field` (
  `id_customization_field` int(10) UNSIGNED NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `is_module` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_customization_field_lang`
--

CREATE TABLE `ps_customization_field_lang` (
  `id_customization_field` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_customized_data`
--

CREATE TABLE `ps_customized_data` (
  `id_customization` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) NOT NULL,
  `index` int(3) NOT NULL,
  `value` varchar(255) NOT NULL,
  `id_module` int(10) NOT NULL DEFAULT 0,
  `price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `weight` decimal(20,6) NOT NULL DEFAULT 0.000000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_date_range`
--

CREATE TABLE `ps_date_range` (
  `id_date_range` int(10) UNSIGNED NOT NULL,
  `time_start` datetime NOT NULL,
  `time_end` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_delivery`
--

CREATE TABLE `ps_delivery` (
  `id_delivery` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED DEFAULT NULL,
  `id_shop_group` int(10) UNSIGNED DEFAULT NULL,
  `id_carrier` int(10) UNSIGNED NOT NULL,
  `id_range_price` int(10) UNSIGNED DEFAULT NULL,
  `id_range_weight` int(10) UNSIGNED DEFAULT NULL,
  `id_zone` int(10) UNSIGNED NOT NULL,
  `price` decimal(20,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_delivery`
--

INSERT INTO `ps_delivery` (`id_delivery`, `id_shop`, `id_shop_group`, `id_carrier`, `id_range_price`, `id_range_weight`, `id_zone`, `price`) VALUES
(1, NULL, NULL, 2, 0, 1, 1, '5.000000'),
(2, NULL, NULL, 2, 0, 1, 2, '5.000000'),
(3, NULL, NULL, 2, 1, 0, 1, '5.000000'),
(4, NULL, NULL, 2, 1, 0, 2, '5.000000'),
(5, NULL, NULL, 3, 2, 0, 1, '3.000000'),
(6, NULL, NULL, 3, 2, 0, 2, '4.000000'),
(7, NULL, NULL, 3, 3, 0, 1, '1.000000'),
(8, NULL, NULL, 3, 3, 0, 2, '2.000000'),
(9, NULL, NULL, 3, 4, 0, 1, '0.000000'),
(10, NULL, NULL, 3, 4, 0, 2, '0.000000'),
(11, NULL, NULL, 4, 0, 2, 1, '0.000000'),
(12, NULL, NULL, 4, 0, 2, 2, '0.000000'),
(13, NULL, NULL, 4, 0, 3, 1, '2.000000'),
(14, NULL, NULL, 4, 0, 3, 2, '3.000000'),
(15, NULL, NULL, 4, 0, 4, 1, '5.000000'),
(16, NULL, NULL, 4, 0, 4, 2, '6.000000');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_emailsubscription`
--

CREATE TABLE `ps_emailsubscription` (
  `id` int(6) NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `id_shop_group` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `email` varchar(255) NOT NULL,
  `newsletter_date_add` datetime DEFAULT NULL,
  `ip_registration_newsletter` varchar(15) NOT NULL,
  `http_referer` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `id_lang` int(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_employee`
--

CREATE TABLE `ps_employee` (
  `id_employee` int(10) UNSIGNED NOT NULL,
  `id_profile` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `lastname` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `passwd` varchar(255) NOT NULL,
  `last_passwd_gen` timestamp NOT NULL DEFAULT current_timestamp(),
  `stats_date_from` date DEFAULT NULL,
  `stats_date_to` date DEFAULT NULL,
  `stats_compare_from` date DEFAULT NULL,
  `stats_compare_to` date DEFAULT NULL,
  `stats_compare_option` int(1) UNSIGNED NOT NULL DEFAULT 1,
  `preselect_date_range` varchar(32) DEFAULT NULL,
  `bo_color` varchar(32) DEFAULT NULL,
  `bo_theme` varchar(32) DEFAULT NULL,
  `bo_css` varchar(64) DEFAULT NULL,
  `default_tab` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `bo_width` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `bo_menu` tinyint(1) NOT NULL DEFAULT 1,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `optin` tinyint(1) UNSIGNED DEFAULT NULL,
  `id_last_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_last_customer_message` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_last_customer` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `last_connection_date` date DEFAULT NULL,
  `reset_password_token` varchar(40) DEFAULT NULL,
  `reset_password_validity` datetime DEFAULT NULL,
  `has_enabled_gravatar` tinyint(3) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_employee`
--

INSERT INTO `ps_employee` (`id_employee`, `id_profile`, `id_lang`, `lastname`, `firstname`, `email`, `passwd`, `last_passwd_gen`, `stats_date_from`, `stats_date_to`, `stats_compare_from`, `stats_compare_to`, `stats_compare_option`, `preselect_date_range`, `bo_color`, `bo_theme`, `bo_css`, `default_tab`, `bo_width`, `bo_menu`, `active`, `optin`, `id_last_order`, `id_last_customer_message`, `id_last_customer`, `last_connection_date`, `reset_password_token`, `reset_password_validity`, `has_enabled_gravatar`) VALUES
(1, 1, 1, 'X', 'X', 'admin@admin.pl', '$2y$10$8pbIkma.40HDe9QH/HvJoOvWwAULmCsJ3VsM6qO5rJIKw2f3nn0eS', '2022-12-08 11:56:32', '2022-11-08', '2022-12-08', '0000-00-00', '0000-00-00', 1, NULL, NULL, 'default', 'theme.css', 1, 0, 1, 1, NULL, 5, 0, 0, '2022-12-11', NULL, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_employee_session`
--

CREATE TABLE `ps_employee_session` (
  `id_employee_session` int(11) UNSIGNED NOT NULL,
  `id_employee` int(10) UNSIGNED DEFAULT NULL,
  `token` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_employee_session`
--

INSERT INTO `ps_employee_session` (`id_employee_session`, `id_employee`, `token`) VALUES
(2, 1, '659fa69226dfc7e26b818b668b45178a28006e79'),
(3, 1, 'ebab52aaa60dd9d18005327503ae679ad73973c7'),
(4, 1, '220710ba117a67cbee45e718c2b88dcb51f1c2f1');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_employee_shop`
--

CREATE TABLE `ps_employee_shop` (
  `id_employee` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_employee_shop`
--

INSERT INTO `ps_employee_shop` (`id_employee`, `id_shop`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_fb_category_match`
--

CREATE TABLE `ps_fb_category_match` (
  `id_category` int(11) NOT NULL,
  `google_category_id` int(64) NOT NULL,
  `google_category_name` varchar(255) NOT NULL,
  `google_category_parent_id` int(64) NOT NULL,
  `google_category_parent_name` varchar(255) NOT NULL,
  `is_parent_category` tinyint(1) DEFAULT NULL,
  `id_shop` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_feature`
--

CREATE TABLE `ps_feature` (
  `id_feature` int(10) UNSIGNED NOT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_feature`
--

INSERT INTO `ps_feature` (`id_feature`, `position`) VALUES
(23, 0),
(24, 1),
(25, 2),
(26, 3);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_feature_flag`
--

CREATE TABLE `ps_feature_flag` (
  `id_feature_flag` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 0,
  `label_wording` varchar(191) NOT NULL DEFAULT '',
  `label_domain` varchar(255) NOT NULL DEFAULT '',
  `description_wording` varchar(191) NOT NULL DEFAULT '',
  `description_domain` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_feature_flag`
--

INSERT INTO `ps_feature_flag` (`id_feature_flag`, `name`, `state`, `label_wording`, `label_domain`, `description_wording`, `description_domain`) VALUES
(1, 'product_page_v2', 0, 'Experimental product page', 'Admin.Advparameters.Feature', 'This page benefits from increased performance and includes new features such as a new combination management system. Please note this is a work in progress and some features are not available', 'Admin.Advparameters.Help');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_feature_lang`
--

CREATE TABLE `ps_feature_lang` (
  `id_feature` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_feature_lang`
--

INSERT INTO `ps_feature_lang` (`id_feature`, `id_lang`, `name`) VALUES
(23, 1, 'Autor'),
(26, 1, 'Czas trwania'),
(25, 1, 'Ocena'),
(24, 1, 'Poziom');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_feature_product`
--

CREATE TABLE `ps_feature_product` (
  `id_feature` int(10) UNSIGNED NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_feature_value` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_feature_product`
--

INSERT INTO `ps_feature_product` (`id_feature`, `id_product`, `id_feature_value`) VALUES
(23, 25, 81),
(23, 26, 82),
(23, 27, 82),
(23, 28, 83),
(23, 29, 84),
(23, 30, 82),
(23, 31, 85),
(23, 32, 86),
(23, 33, 82),
(23, 34, 87),
(23, 35, 88),
(23, 36, 89),
(23, 37, 82),
(23, 38, 82),
(24, 25, 90),
(24, 26, 90),
(24, 27, 90),
(24, 28, 90),
(24, 29, 90),
(24, 30, 90),
(24, 31, 90),
(24, 32, 90),
(24, 33, 90),
(24, 34, 90),
(24, 35, 90),
(24, 36, 90),
(24, 37, 90),
(24, 38, 90),
(25, 25, 91),
(25, 26, 92),
(25, 27, 93),
(25, 28, 94),
(25, 29, 91),
(25, 30, 91),
(25, 31, 95),
(25, 32, 96),
(25, 33, 95),
(25, 34, 94),
(25, 35, 95),
(25, 36, 94),
(25, 37, 97),
(25, 38, 91),
(26, 25, 98),
(26, 26, 99),
(26, 27, 100),
(26, 28, 101),
(26, 29, 102),
(26, 30, 100),
(26, 31, 103),
(26, 32, 104),
(26, 33, 105),
(26, 34, 106),
(26, 35, 107),
(26, 36, 105),
(26, 37, 108),
(26, 38, 109);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_feature_shop`
--

CREATE TABLE `ps_feature_shop` (
  `id_feature` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_feature_shop`
--

INSERT INTO `ps_feature_shop` (`id_feature`, `id_shop`) VALUES
(23, 1),
(24, 1),
(25, 1),
(26, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_feature_value`
--

CREATE TABLE `ps_feature_value` (
  `id_feature_value` int(10) UNSIGNED NOT NULL,
  `id_feature` int(10) UNSIGNED NOT NULL,
  `custom` tinyint(3) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_feature_value`
--

INSERT INTO `ps_feature_value` (`id_feature_value`, `id_feature`, `custom`) VALUES
(81, 23, 0),
(82, 23, 0),
(83, 23, 0),
(84, 23, 0),
(85, 23, 0),
(86, 23, 0),
(87, 23, 0),
(88, 23, 0),
(89, 23, 0),
(90, 24, 0),
(91, 25, 0),
(92, 25, 0),
(93, 25, 0),
(94, 25, 0),
(95, 25, 0),
(96, 25, 0),
(97, 25, 0),
(98, 26, 0),
(99, 26, 0),
(100, 26, 0),
(101, 26, 0),
(102, 26, 0),
(103, 26, 0),
(104, 26, 0),
(105, 26, 0),
(106, 26, 0),
(107, 26, 0),
(108, 26, 0),
(109, 26, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_feature_value_lang`
--

CREATE TABLE `ps_feature_value_lang` (
  `id_feature_value` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_feature_value_lang`
--

INSERT INTO `ps_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES
(81, 1, 'Instruktor:\nSebastian Jezierski'),
(82, 1, 'Instruktor:\nKursy Wideo'),
(83, 1, 'Instruktor:\ncgwisdom - Kursy online online'),
(84, 1, 'Instruktor:\nPawel Zienowicz'),
(85, 1, 'Instruktor:\nRobert Ziobrowski'),
(86, 1, 'Instruktor:\nMepi.pl Video Tutorials'),
(87, 1, 'Instruktor:\nPikademia Edukacja XXIw.'),
(88, 1, 'Instruktor:\nDawid Tuminski'),
(89, 1, 'Instruktor:\nKamil Wdowczyk'),
(90, 1, 'Ekspert'),
(91, 1, '4,6'),
(92, 1, '4,7'),
(93, 1, '4,1'),
(94, 1, '4,8'),
(95, 1, '4,5'),
(96, 1, '3,7'),
(97, 1, '4,0'),
(98, 1, '12 godz. łącznie'),
(99, 1, '11,5 godzin(y)'),
(100, 1, '4,5 godzin(y)'),
(101, 1, '5,5 godz. łącznie'),
(102, 1, '5 godz. łącznie'),
(103, 1, '9,5 godzin(y)'),
(104, 1, '38,5 godz. łącznie'),
(105, 1, '4 godz. łącznie'),
(106, 1, '17 godz. łącznie'),
(107, 1, '2 godz. łącznie'),
(108, 1, '6 godz. łącznie'),
(109, 1, '6,5 godz. łącznie');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_ganalytics`
--

CREATE TABLE `ps_ganalytics` (
  `id_google_analytics` int(11) NOT NULL,
  `id_order` int(11) NOT NULL,
  `id_customer` int(10) NOT NULL,
  `id_shop` int(11) NOT NULL,
  `sent` tinyint(1) DEFAULT NULL,
  `refund_sent` tinyint(1) DEFAULT NULL,
  `date_add` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_ganalytics`
--

INSERT INTO `ps_ganalytics` (`id_google_analytics`, `id_order`, `id_customer`, `id_shop`, `sent`, `refund_sent`, `date_add`) VALUES
(1, 6, 0, 1, 0, NULL, '2022-12-11 21:13:02');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_ganalytics_data`
--

CREATE TABLE `ps_ganalytics_data` (
  `id_cart` int(11) NOT NULL,
  `id_shop` int(11) NOT NULL,
  `data` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_ganalytics_data`
--

INSERT INTO `ps_ganalytics_data` (`id_cart`, `id_shop`, `data`) VALUES
(6, 1, '[[[[[[[\"MBG.addCheckoutOption(2,\'\');\"]]]]]]]');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_gender`
--

CREATE TABLE `ps_gender` (
  `id_gender` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_gender`
--

INSERT INTO `ps_gender` (`id_gender`, `type`) VALUES
(1, 0),
(2, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_gender_lang`
--

CREATE TABLE `ps_gender_lang` (
  `id_gender` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_gender_lang`
--

INSERT INTO `ps_gender_lang` (`id_gender`, `id_lang`, `name`) VALUES
(1, 1, 'Pan'),
(2, 1, 'Pani');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_group`
--

CREATE TABLE `ps_group` (
  `id_group` int(10) UNSIGNED NOT NULL,
  `reduction` decimal(5,2) NOT NULL DEFAULT 0.00,
  `price_display_method` tinyint(4) NOT NULL DEFAULT 0,
  `show_prices` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_group`
--

INSERT INTO `ps_group` (`id_group`, `reduction`, `price_display_method`, `show_prices`, `date_add`, `date_upd`) VALUES
(1, '0.00', 0, 1, '2022-12-08 17:56:28', '2022-12-08 17:56:28'),
(2, '0.00', 0, 1, '2022-12-08 17:56:28', '2022-12-08 17:56:28'),
(3, '0.00', 0, 1, '2022-12-08 17:56:28', '2022-12-08 17:56:28');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_group_lang`
--

CREATE TABLE `ps_group_lang` (
  `id_group` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_group_lang`
--

INSERT INTO `ps_group_lang` (`id_group`, `id_lang`, `name`) VALUES
(1, 1, 'Odwiedzający'),
(2, 1, 'Gość'),
(3, 1, 'Klient');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_group_reduction`
--

CREATE TABLE `ps_group_reduction` (
  `id_group_reduction` mediumint(8) UNSIGNED NOT NULL,
  `id_group` int(10) UNSIGNED NOT NULL,
  `id_category` int(10) UNSIGNED NOT NULL,
  `reduction` decimal(5,4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_group_shop`
--

CREATE TABLE `ps_group_shop` (
  `id_group` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_group_shop`
--

INSERT INTO `ps_group_shop` (`id_group`, `id_shop`) VALUES
(1, 1),
(2, 1),
(3, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_gsitemap_sitemap`
--

CREATE TABLE `ps_gsitemap_sitemap` (
  `link` varchar(255) DEFAULT NULL,
  `id_shop` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_guest`
--

CREATE TABLE `ps_guest` (
  `id_guest` int(10) UNSIGNED NOT NULL,
  `id_operating_system` int(10) UNSIGNED DEFAULT NULL,
  `id_web_browser` int(10) UNSIGNED DEFAULT NULL,
  `id_customer` int(10) UNSIGNED DEFAULT NULL,
  `javascript` tinyint(1) DEFAULT 0,
  `screen_resolution_x` smallint(5) UNSIGNED DEFAULT NULL,
  `screen_resolution_y` smallint(5) UNSIGNED DEFAULT NULL,
  `screen_color` tinyint(3) UNSIGNED DEFAULT NULL,
  `sun_java` tinyint(1) DEFAULT NULL,
  `adobe_flash` tinyint(1) DEFAULT NULL,
  `adobe_director` tinyint(1) DEFAULT NULL,
  `apple_quicktime` tinyint(1) DEFAULT NULL,
  `real_player` tinyint(1) DEFAULT NULL,
  `windows_media` tinyint(1) DEFAULT NULL,
  `accept_language` varchar(8) DEFAULT NULL,
  `mobile_theme` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_guest`
--

INSERT INTO `ps_guest` (`id_guest`, `id_operating_system`, `id_web_browser`, `id_customer`, `javascript`, `screen_resolution_x`, `screen_resolution_y`, `screen_color`, `sun_java`, `adobe_flash`, `adobe_director`, `apple_quicktime`, `real_player`, `windows_media`, `accept_language`, `mobile_theme`) VALUES
(1, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
(2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
(3, 6, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'pl', 0),
(4, 6, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'pl', 0),
(5, 6, 11, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'pl', 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_homeslider`
--

CREATE TABLE `ps_homeslider` (
  `id_homeslider_slides` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_homeslider`
--

INSERT INTO `ps_homeslider` (`id_homeslider_slides`, `id_shop`) VALUES
(1, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_homeslider_slides`
--

CREATE TABLE `ps_homeslider_slides` (
  `id_homeslider_slides` int(10) UNSIGNED NOT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_homeslider_slides`
--

INSERT INTO `ps_homeslider_slides` (`id_homeslider_slides`, `position`, `active`) VALUES
(1, 1, 1),
(2, 2, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_homeslider_slides_lang`
--

CREATE TABLE `ps_homeslider_slides_lang` (
  `id_homeslider_slides` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `legend` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_homeslider_slides_lang`
--

INSERT INTO `ps_homeslider_slides_lang` (`id_homeslider_slides`, `id_lang`, `title`, `description`, `legend`, `url`, `image`) VALUES
(1, 1, '', '<h1><strong><span style=\"color:#00d3b3;\">Super kursy</span></strong></h1>\n<p><span style=\"color:#00d3b3;\">Nasze kursy są najlepsze.</span></p>', 'Ale one są wspaniałe', 'https://sjp.pl/najlepsze', '3d5adf287192111a33dde1cb963c4afbb06d2d68_e6cc1a30-2dec-4dc5-b0f2-c5b656909d5b.jpg'),
(2, 1, '', '<h3><span style=\"color:#ae542f;\">Ależ one są dobre</span></h3>\n<p><span style=\"color:#ae542f;\">Są tak dobre, że będziesz zadowolony.</span></p>', 'Ależ one są dobre', 'http://www.prestashop.com/?utm_source=back-office&utm_medium=v17_homeslider&utm_campaign=back-office-PL&utm_content=download', '516d5c048a6871b0a9b00e74bf2071bae7c5670b_7869fd17-9599-4a5e-9b03-4748a3dae016.png');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_hook`
--

CREATE TABLE `ps_hook` (
  `id_hook` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `position` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_hook`
--

INSERT INTO `ps_hook` (`id_hook`, `name`, `title`, `description`, `active`, `position`) VALUES
(1, 'actionValidateOrder', 'New orders', '', 1, 1),
(2, 'displayMaintenance', 'Maintenance Page', 'This hook displays new elements on the maintenance page', 1, 1),
(3, 'displayCartModalContent', 'Content of Add-to-cart modal', 'This hook displays content in the middle of the window that appears after adding product to cart', 1, 1),
(4, 'displayCartModalFooter', 'Bottom of Add-to-cart modal', 'This hook displays content in the bottom of window that appears after adding product to cart', 1, 1),
(5, 'displayProductPageDrawer', 'Product Page Drawer', 'This hook displays content in the right sidebar of the product page', 1, 1),
(6, 'actionPaymentConfirmation', 'Payment confirmation', 'This hook displays new elements after the payment is validated', 1, 1),
(7, 'displayPaymentReturn', 'Payment return', '', 1, 1),
(8, 'actionUpdateQuantity', 'Quantity update', 'Quantity is updated only when a customer effectively places their order', 1, 1),
(9, 'displayRightColumn', 'Right column blocks', 'This hook displays new elements in the right-hand column', 1, 1),
(10, 'displayWrapperTop', 'Main wrapper section (top)', 'This hook displays new elements in the top of the main wrapper', 1, 1),
(11, 'displayWrapperBottom', 'Main wrapper section (bottom)', 'This hook displays new elements in the bottom of the main wrapper', 1, 1),
(12, 'displayContentWrapperTop', 'Content wrapper section (top)', 'This hook displays new elements in the top of the content wrapper', 1, 1),
(13, 'displayContentWrapperBottom', 'Content wrapper section (bottom)', 'This hook displays new elements in the bottom of the content wrapper', 1, 1),
(14, 'displayLeftColumn', 'Left column blocks', 'This hook displays new elements in the left-hand column', 1, 1),
(15, 'displayHome', 'Homepage content', 'This hook displays new elements on the homepage', 1, 1),
(16, 'displayHeader', 'Pages html head section', 'This hook adds additional elements in the head section of your pages (head section of html)', 1, 1),
(17, 'actionCartSave', 'Cart creation and update', 'This hook is displayed when a product is added to the cart or if the cart\'s content is modified', 1, 1),
(18, 'actionAuthentication', 'Successful customer authentication', 'This hook is displayed after a customer successfully signs in', 1, 1),
(19, 'actionProductAdd', 'Product creation', 'This hook is displayed after a product is created', 1, 1),
(20, 'actionProductUpdate', 'Product update', 'This hook is displayed after a product has been updated', 1, 1),
(21, 'displayAfterTitleTag', 'After title tag', 'Use this hook to add content after title tag', 1, 1),
(22, 'displayAfterBodyOpeningTag', 'Very top of pages', 'Use this hook for advertisement or modals you want to load first', 1, 1),
(23, 'displayBanner', 'Very top of pages', 'Use this hook for banners on top of every pages', 1, 1),
(24, 'displayBeforeBodyClosingTag', 'Very bottom of pages', 'Use this hook for your modals or any content you want to load at the very end', 1, 1),
(25, 'displayTop', 'Top of pages', 'This hook displays additional elements at the top of your pages', 1, 1),
(26, 'displayNavFullWidth', 'Navigation', 'This hook displays full width navigation menu at the top of your pages', 1, 1),
(27, 'displayRightColumnProduct', 'New elements on the product page (right column)', 'This hook displays new elements in the right-hand column of the product page', 1, 1),
(28, 'actionProductDelete', 'Product deletion', 'This hook is called when a product is deleted', 1, 1),
(29, 'actionObjectProductInCartDeleteBefore', 'Cart product removal', 'This hook is called before a product is removed from a cart', 1, 1),
(30, 'actionObjectProductInCartDeleteAfter', 'Cart product removal', 'This hook is called after a product is removed from a cart', 1, 1),
(31, 'displayFooterProduct', 'Product footer', 'This hook adds new blocks under the product\'s description', 1, 1),
(32, 'displayInvoice', 'Invoice', 'This hook displays new blocks on the invoice (order)', 1, 1),
(33, 'actionOrderStatusUpdate', 'Order status update - Event', 'This hook launches modules when the status of an order changes', 1, 1),
(34, 'displayAdminGridTableBefore', 'Display before Grid table', 'This hook adds new blocks before Grid component table', 1, 1),
(35, 'displayAdminGridTableAfter', 'Display after Grid table', 'This hook adds new blocks after Grid component table', 1, 1),
(36, 'displayAdminOrder', 'Display new elements in the Back Office, tab AdminOrder', 'This hook launches modules when the AdminOrder tab is displayed in the Back Office', 1, 1),
(37, 'displayAdminOrderTabOrder', 'Display new elements in Back Office, AdminOrder, panel Order', 'This hook launches modules when the AdminOrder tab is displayed in the Back Office and extends / override Order panel tabs', 1, 1),
(38, 'displayAdminOrderTabShip', 'Display new elements in Back Office, AdminOrder, panel Shipping', 'This hook launches modules when the AdminOrder tab is displayed in the Back Office and extends / override Shipping panel tabs', 1, 1),
(39, 'displayAdminOrderContentOrder', 'Display new elements in Back Office, AdminOrder, panel Order', 'This hook launches modules when the AdminOrder tab is displayed in the Back Office and extends / override Order panel content', 1, 1),
(40, 'displayAdminOrderContentShip', 'Display new elements in Back Office, AdminOrder, panel Shipping', 'This hook launches modules when the AdminOrder tab is displayed in the Back Office and extends / override Shipping panel content', 1, 1),
(41, 'displayFooter', 'Footer', 'This hook displays new blocks in the footer', 1, 1),
(42, 'displayPDFInvoice', 'PDF Invoice', 'This hook allows you to display additional information on PDF invoices', 1, 1),
(43, 'displayInvoiceLegalFreeText', 'PDF Invoice - Legal Free Text', 'This hook allows you to modify the legal free text on PDF invoices', 1, 1),
(44, 'displayAdminCustomers', 'Display new elements in the Back Office, tab AdminCustomers', 'This hook launches modules when the AdminCustomers tab is displayed in the Back Office', 1, 1),
(45, 'displayAdminCustomersAddressesItemAction', 'Display new elements in the Back Office, tab AdminCustomers, Addresses actions', 'This hook launches modules when the Addresses list into the AdminCustomers tab is displayed in the Back Office', 1, 1),
(46, 'displayOrderConfirmation', 'Order confirmation page', 'This hook is called within an order\'s confirmation page', 1, 1),
(47, 'actionCustomerAccountAdd', 'Successful customer account creation', 'This hook is called when a new customer creates an account successfully', 1, 1),
(48, 'actionCustomerAccountUpdate', 'Successful customer account update', 'This hook is called when a customer updates its account successfully', 1, 1),
(49, 'displayCustomerAccount', 'Customer account displayed in Front Office', 'This hook displays new elements on the customer account page', 1, 1),
(50, 'actionOrderSlipAdd', 'Order slip creation', 'This hook is called when a new credit slip is added regarding client order', 1, 1),
(51, 'displayShoppingCartFooter', 'Shopping cart footer', 'This hook displays some specific information on the shopping cart\'s page', 1, 1),
(52, 'displayCreateAccountEmailFormBottom', 'Customer authentication form', 'This hook displays some information on the bottom of the email form', 1, 1),
(53, 'displayAuthenticateFormBottom', 'Customer authentication form', 'This hook displays some information on the bottom of the authentication form', 1, 1),
(54, 'displayCustomerAccountForm', 'Customer account creation form', 'This hook displays some information on the form to create a customer account', 1, 1),
(55, 'displayAdminStatsModules', 'Stats - Modules', '', 1, 1),
(56, 'displayAdminStatsGraphEngine', 'Graph engines', '', 1, 1),
(57, 'actionOrderReturn', 'Returned product', 'This hook is displayed when a customer returns a product ', 1, 1),
(58, 'displayProductAdditionalInfo', 'Product page additional info', 'This hook adds additional information on the product page', 1, 1),
(59, 'displayBackOfficeHome', 'Administration panel homepage', 'This hook is displayed on the admin panel\'s homepage', 1, 1),
(60, 'displayAdminStatsGridEngine', 'Grid engines', '', 1, 1),
(61, 'actionWatermark', 'Watermark', '', 1, 1),
(62, 'actionProductCancel', 'Product cancelled', 'This hook is called when you cancel a product in an order', 1, 1),
(63, 'displayLeftColumnProduct', 'New elements on the product page (left column)', 'This hook displays new elements in the left-hand column of the product page', 1, 1),
(64, 'actionProductOutOfStock', 'Out-of-stock product', 'This hook displays new action buttons if a product is out of stock', 1, 1),
(65, 'actionProductAttributeUpdate', 'Product attribute update', 'This hook is displayed when a product\'s attribute is updated', 1, 1),
(66, 'displayCarrierList', 'Extra carrier (module mode)', '', 1, 1),
(67, 'displayShoppingCart', 'Shopping cart - Additional button', 'This hook displays new action buttons within the shopping cart', 1, 1),
(68, 'actionCarrierUpdate', 'Carrier Update', 'This hook is called when a carrier is updated', 1, 1),
(69, 'actionOrderStatusPostUpdate', 'Post update of order status', '', 1, 1),
(70, 'displayCustomerAccountFormTop', 'Block above the form for create an account', 'This hook is displayed above the customer\'s account creation form', 1, 1),
(71, 'displayBackOfficeHeader', 'Administration panel header', 'This hook is displayed in the header of the admin panel', 1, 1),
(72, 'displayBackOfficeTop', 'Administration panel hover the tabs', 'This hook is displayed on the roll hover of the tabs within the admin panel', 1, 1),
(73, 'displayAdminEndContent', 'Administration end of content', 'This hook is displayed at the end of the main content, before the footer', 1, 1),
(74, 'displayBackOfficeFooter', 'Administration panel footer', 'This hook is displayed within the admin panel\'s footer', 1, 1),
(75, 'actionProductAttributeDelete', 'Product attribute deletion', 'This hook is displayed when a product\'s attribute is deleted', 1, 1),
(76, 'actionCarrierProcess', 'Carrier process', '', 1, 1),
(77, 'displayBeforeCarrier', 'Before carriers list', 'This hook is displayed before the carrier list in Front Office', 1, 1),
(78, 'displayAfterCarrier', 'After carriers list', 'This hook is displayed after the carrier list in Front Office', 1, 1),
(79, 'displayOrderDetail', 'Order detail', 'This hook is displayed within the order\'s details in Front Office', 1, 1),
(80, 'actionPaymentCCAdd', 'Payment CC added', '', 1, 1),
(81, 'actionCategoryAdd', 'Category creation', 'This hook is displayed when a category is created', 1, 1),
(82, 'actionCategoryUpdate', 'Category modification', 'This hook is displayed when a category is modified', 1, 1),
(83, 'actionCategoryDelete', 'Category deletion', 'This hook is displayed when a category is deleted', 1, 1),
(84, 'displayPaymentTop', 'Top of payment page', 'This hook is displayed at the top of the payment page', 1, 1),
(85, 'actionHtaccessCreate', 'After htaccess creation', 'This hook is displayed after the htaccess creation', 1, 1),
(86, 'actionAdminMetaSave', 'After saving the configuration in AdminMeta', 'This hook is displayed after saving the configuration in AdminMeta', 1, 1),
(87, 'displayAttributeGroupForm', 'Add fields to the form \'attribute group\'', 'This hook adds fields to the form \'attribute group\'', 1, 1),
(88, 'actionAttributeGroupSave', 'Saving an attribute group', 'This hook is called while saving an attributes group', 1, 1),
(89, 'actionAttributeGroupDelete', 'Deleting attribute group', 'This hook is called while deleting an attributes  group', 1, 1),
(90, 'displayFeatureForm', 'Add fields to the form \'feature\'', 'This hook adds fields to the form \'feature\'', 1, 1),
(91, 'actionFeatureSave', 'Saving attributes\' features', 'This hook is called while saving an attributes features', 1, 1),
(92, 'actionFeatureDelete', 'Deleting attributes\' features', 'This hook is called while deleting an attributes features', 1, 1),
(93, 'actionProductSave', 'Saving products', 'This hook is called while saving products', 1, 1),
(94, 'displayAttributeGroupPostProcess', 'On post-process in admin attribute group', 'This hook is called on post-process in admin attribute group', 1, 1),
(95, 'displayFeaturePostProcess', 'On post-process in admin feature', 'This hook is called on post-process in admin feature', 1, 1),
(96, 'displayFeatureValueForm', 'Add fields to the form \'feature value\'', 'This hook adds fields to the form \'feature value\'', 1, 1),
(97, 'displayFeatureValuePostProcess', 'On post-process in admin feature value', 'This hook is called on post-process in admin feature value', 1, 1),
(98, 'actionFeatureValueDelete', 'Deleting attributes\' features\' values', 'This hook is called while deleting an attributes features value', 1, 1),
(99, 'actionFeatureValueSave', 'Saving an attributes features value', 'This hook is called while saving an attributes features value', 1, 1),
(100, 'displayAttributeForm', 'Add fields to the form \'attribute value\'', 'This hook adds fields to the form \'attribute value\'', 1, 1),
(101, 'actionAttributePostProcess', 'On post-process in admin feature value', 'This hook is called on post-process in admin feature value', 1, 1),
(102, 'actionAttributeDelete', 'Deleting an attributes features value', 'This hook is called while deleting an attributes features value', 1, 1),
(103, 'actionAttributeSave', 'Saving an attributes features value', 'This hook is called while saving an attributes features value', 1, 1),
(104, 'actionTaxManager', 'Tax Manager Factory', '', 1, 1),
(105, 'displayMyAccountBlock', 'My account block', 'This hook displays extra information within the \'my account\' block\"', 1, 1),
(106, 'actionModuleInstallBefore', 'actionModuleInstallBefore', '', 1, 1),
(107, 'actionModuleInstallAfter', 'actionModuleInstallAfter', '', 1, 1),
(108, 'actionModuleUninstallBefore', 'actionModuleUninstallBefore', '', 1, 1),
(109, 'actionModuleUninstallAfter', 'actionModuleUninstallAfter', '', 1, 1),
(110, 'displayTopColumn', 'Top column blocks', 'This hook displays new elements in the top of columns', 1, 1),
(111, 'displayBackOfficeCategory', 'Display new elements in the Back Office, tab AdminCategories', 'This hook launches modules when the AdminCategories tab is displayed in the Back Office', 1, 1),
(112, 'displayProductListFunctionalButtons', 'Display new elements in the Front Office, products list', 'This hook launches modules when the products list is displayed in the Front Office', 1, 1),
(113, 'displayNav', 'Navigation', '', 1, 1),
(114, 'displayOverrideTemplate', 'Change the default template of current controller', '', 1, 1),
(115, 'actionAdminLoginControllerSetMedia', 'Set media on admin login page header', 'This hook is called after adding media to admin login page header', 1, 1),
(116, 'actionOrderEdited', 'Order edited', 'This hook is called when an order is edited', 1, 1),
(117, 'actionEmailAddBeforeContent', 'Add extra content before mail content', 'This hook is called just before fetching mail template', 1, 1),
(118, 'actionEmailAddAfterContent', 'Add extra content after mail content', 'This hook is called just after fetching mail template', 1, 1),
(119, 'sendMailAlterTemplateVars', 'Alter template vars on the fly', 'This hook is called when Mail::send() is called', 1, 1),
(120, 'displayCartExtraProductActions', 'Extra buttons in shopping cart', 'This hook adds extra buttons to the product lines, in the shopping cart', 1, 1),
(121, 'displayPaymentByBinaries', 'Payment form generated by binaries', 'This hook displays form generated by binaries during the checkout', 1, 1),
(122, 'additionalCustomerFormFields', 'Add fields to the Customer form', 'This hook returns an array of FormFields to add them to the customer registration form', 1, 1),
(123, 'additionalCustomerAddressFields', 'Add fields to the Customer address form', 'This hook returns an array of FormFields to add them to the customer address registration form', 1, 1),
(124, 'addWebserviceResources', 'Add extra webservice resource', 'This hook is called when webservice resources list in webservice controller', 1, 1),
(125, 'displayCustomerLoginFormAfter', 'Display elements after login form', 'This hook displays new elements after the login form', 1, 1),
(126, 'actionClearCache', 'Clear smarty cache', 'This hook is called when smarty\'s cache is cleared', 1, 1),
(127, 'actionClearCompileCache', 'Clear smarty compile cache', 'This hook is called when smarty\'s compile cache is cleared', 1, 1),
(128, 'actionClearSf2Cache', 'Clear Sf2 cache', 'This hook is called when the Symfony cache is cleared', 1, 1),
(129, 'actionValidateCustomerAddressForm', 'Customer address form validation', 'This hook is called when a customer submit its address form', 1, 1),
(130, 'displayCarrierExtraContent', 'Display additional content for a carrier (e.g pickup points)', 'This hook calls only the module related to the carrier, in order to add options when needed', 1, 1),
(131, 'validateCustomerFormFields', 'Customer registration form validation', 'This hook is called to a module when it has sent additional fields with additionalCustomerFormFields', 1, 1),
(132, 'displayProductExtraContent', 'Display extra content on the product page', 'This hook expects ProductExtraContent instances, which will be properly displayed by the template on the product page', 1, 1),
(133, 'filterCmsContent', 'Filter the content page', 'This hook is called just before fetching content page', 1, 1),
(134, 'filterCmsCategoryContent', 'Filter the content page category', 'This hook is called just before fetching content page category', 1, 1),
(135, 'filterProductContent', 'Filter the content page product', 'This hook is called just before fetching content page product', 1, 1),
(136, 'filterCategoryContent', 'Filter the content page category', 'This hook is called just before fetching content page category', 1, 1),
(137, 'filterManufacturerContent', 'Filter the content page manufacturer', 'This hook is called just before fetching content page manufacturer', 1, 1),
(138, 'filterSupplierContent', 'Filter the content page supplier', 'This hook is called just before fetching content page supplier', 1, 1),
(139, 'filterHtmlContent', 'Filter HTML field before rending a page', 'This hook is called just before fetching a page on HTML field', 1, 1),
(140, 'displayDashboardTop', 'Dashboard Top', 'Displays the content in the dashboard\'s top area', 1, 1),
(141, 'actionUpdateLangAfter', 'Update \"lang\" tables', 'Update \"lang\" tables after adding or updating a language', 1, 1),
(142, 'actionOutputHTMLBefore', 'Before HTML output', 'This hook is used to filter the whole HTML page before it is rendered (only front)', 1, 1),
(143, 'displayAfterProductThumbs', 'Display extra content below product thumbs', 'This hook displays new elements below product images ex. additional media', 1, 1),
(144, 'actionDispatcherBefore', 'Before dispatch', 'This hook is called at the beginning of the dispatch method of the Dispatcher', 1, 1),
(145, 'actionDispatcherAfter', 'After dispatch', 'This hook is called at the end of the dispatch method of the Dispatcher', 1, 1),
(146, 'filterProductSearch', 'Filter search products result', 'This hook is called in order to allow to modify search product result', 1, 1),
(147, 'actionProductSearchAfter', 'Event triggered after search product completed', 'This hook is called after the product search. Parameters are already filter', 1, 1),
(148, 'actionEmailSendBefore', 'Before sending an email', 'This hook is used to filter the content or the metadata of an email before sending it or even prevent its sending', 1, 1),
(149, 'displayAdminProductsMainStepLeftColumnMiddle', 'Display new elements in back office product page, left column of the Basic settings tab', 'This hook launches modules when the back office product page is displayed', 1, 1),
(150, 'displayAdminProductsMainStepLeftColumnBottom', 'Display new elements in back office product page, left column of the Basic settings tab', 'This hook launches modules when the back office product page is displayed', 1, 1),
(151, 'displayAdminProductsMainStepRightColumnBottom', 'Display new elements in back office product page, right column of the Basic settings tab', 'This hook launches modules when the back office product page is displayed', 1, 1),
(152, 'displayAdminProductsQuantitiesStepBottom', 'Display new elements in back office product page, Quantities/Combinations tab', 'This hook launches modules when the back office product page is displayed', 1, 1),
(153, 'displayAdminProductsPriceStepBottom', 'Display new elements in back office product page, Price tab', 'This hook launches modules when the back office product page is displayed', 1, 1),
(154, 'displayAdminProductsOptionsStepTop', 'Display new elements in back office product page, Options tab', 'This hook launches modules when the back office product page is displayed', 1, 1),
(155, 'displayAdminProductsOptionsStepBottom', 'Display new elements in back office product page, Options tab', 'This hook launches modules when the back office product page is displayed', 1, 1),
(156, 'displayAdminProductsSeoStepBottom', 'Display new elements in back office product page, SEO tab', 'This hook launches modules when the back office product page is displayed', 1, 1),
(157, 'displayAdminProductsShippingStepBottom', 'Display new elements in back office product page, Shipping tab', 'This hook launches modules when the back office product page is displayed', 1, 1),
(158, 'displayAdminProductsExtra', 'Admin Product Extra Module Tab', 'This hook displays extra content in the Module tab on the product edit page', 1, 1),
(159, 'displayAdminProductsCombinationBottom', 'Display new elements in back office product page, Combination tab', 'This hook launches modules when the back office product page is displayed', 1, 1),
(160, 'displayDashboardToolbarTopMenu', 'Display new elements in back office page with a dashboard, on top Menu', 'This hook launches modules when a page with a dashboard is displayed', 1, 1),
(161, 'displayDashboardToolbarIcons', 'Display new elements in back office page with dashboard, on icons list', 'This hook launches modules when the back office with dashboard is displayed', 1, 1),
(162, 'actionBuildFrontEndObject', 'Manage elements added to the \"prestashop\" javascript object', 'This hook allows you to customize the \"prestashop\" javascript object that is included in all front office pages', 1, 1),
(163, 'actionFrontControllerInitAfter', 'Perform actions after front office controller initialization', 'This hook is launched after the initialization of all front office controllers', 1, 1),
(164, 'actionFrontControllerInitBefore', 'Perform actions before front office controller initialization', 'This hook is launched before the initialization of all front office controllers', 1, 1),
(165, 'actionAdminControllerInitAfter', 'Perform actions after admin controller initialization', 'This hook is launched after the initialization of all admin controllers', 1, 1),
(166, 'actionAdminControllerInitBefore', 'Perform actions before admin controller initialization', 'This hook is launched before the initialization of all admin controllers', 1, 1),
(167, 'actionControllerInitAfter', 'Perform actions after controller initialization', 'This hook is launched after the initialization of all controllers', 1, 1),
(168, 'actionControllerInitBefore', 'Perform actions before controller initialization', 'This hook is launched before the initialization of all controllers', 1, 1),
(169, 'actionAdminLoginControllerBefore', 'Perform actions before admin login controller initialization', 'This hook is launched before the initialization of the login controller', 1, 1),
(170, 'actionAdminLoginControllerLoginBefore', 'Perform actions before admin login controller login action initialization', 'This hook is launched before the initialization of the login action in login controller', 1, 1),
(171, 'actionAdminLoginControllerLoginAfter', 'Perform actions after admin login controller login action initialization', 'This hook is launched after the initialization of the login action in login controller', 1, 1),
(172, 'actionAdminLoginControllerForgotBefore', 'Perform actions before admin login controller forgot action initialization', 'This hook is launched before the initialization of the forgot action in login controller', 1, 1),
(173, 'actionAdminLoginControllerForgotAfter', 'Perform actions after admin login controller forgot action initialization', 'This hook is launched after the initialization of the forgot action in login controller', 1, 1),
(174, 'actionAdminLoginControllerResetBefore', 'Perform actions before admin login controller reset action initialization', 'This hook is launched before the initialization of the reset action in login controller', 1, 1),
(175, 'actionAdminLoginControllerResetAfter', 'Perform actions after admin login controller reset action initialization', 'This hook is launched after the initialization of the reset action in login controller', 1, 1),
(176, 'actionAdministrationPageForm', 'Manage Administration Page form fields', 'This hook adds, update or remove fields of the Administration Page form', 1, 1),
(177, 'actionPerformancePageForm', 'Manage Performance Page form fields', 'This hook adds, update or remove fields of the Performance Page form', 1, 1),
(178, 'actionMaintenancePageForm', 'Manage Maintenance Page form fields', 'This hook adds, update or remove fields of the Maintenance Page form', 1, 1),
(179, 'actionWebserviceKeyGridPresenterModifier', 'Modify Webservice grid view data', 'This hook allows to alter presented Webservice grid data', 1, 1),
(180, 'actionWebserviceKeyGridDefinitionModifier', 'Modifying Webservice grid definition', 'This hook allows to alter Webservice grid columns, actions and filters', 1, 1),
(181, 'actionWebserviceKeyGridQueryBuilderModifier', 'Modify Webservice grid query builder', 'This hook allows to alter Doctrine query builder for Webservice grid', 1, 1),
(182, 'actionWebserviceKeyGridFilterFormModifier', 'Modify filters form for Webservice grid', 'This hook allows to alter filters form used in Webservice', 1, 1),
(183, 'actionSqlRequestGridPresenterModifier', 'Modify SQL Manager grid view data', 'This hook allows to alter presented SQL Manager grid data', 1, 1),
(184, 'actionSqlRequestGridDefinitionModifier', 'Modifying SQL Manager grid definition', 'This hook allows to alter SQL Manager grid columns, actions and filters', 1, 1),
(185, 'actionSqlRequestGridQueryBuilderModifier', 'Modify SQL Manager grid query builder', 'This hook allows to alter Doctrine query builder for SQL Manager grid', 1, 1),
(186, 'actionSqlRequestGridFilterFormModifier', 'Modify filters form for SQL Manager grid', 'This hook allows to alter filters form used in SQL Manager', 1, 1),
(187, 'actionMetaGridPresenterModifier', 'Modify SEO and URLs grid view data', 'This hook allows to alter presented SEO and URLs grid data', 1, 1),
(188, 'actionMetaGridDefinitionModifier', 'Modifying SEO and URLs grid definition', 'This hook allows to alter SEO and URLs grid columns, actions and filters', 1, 1),
(189, 'actionMetaGridQueryBuilderModifier', 'Modify SEO and URLs grid query builder', 'This hook allows to alter Doctrine query builder for SEO and URLs grid', 1, 1),
(190, 'actionMetaGridFilterFormModifier', 'Modify filters form for SEO and URLs grid', 'This hook allows to alter filters form used in SEO and URLs', 1, 1),
(191, 'actionLogsGridPresenterModifier', 'Modify Logs grid view data', 'This hook allows to alter presented Logs grid data', 1, 1),
(192, 'actionLogsGridDefinitionModifier', 'Modifying Logs grid definition', 'This hook allows to alter Logs grid columns, actions and filters', 1, 1),
(193, 'actionLogsGridQueryBuilderModifier', 'Modify Logs grid query builder', 'This hook allows to alter Doctrine query builder for Logs grid', 1, 1),
(194, 'actionLogsGridFilterFormModifier', 'Modify filters form for Logs grid', 'This hook allows to alter filters form used in Logs', 1, 1),
(195, 'actionEmailLogsGridPresenterModifier', 'Modify E-mail grid view data', 'This hook allows to alter presented E-mail grid data', 1, 1),
(196, 'actionEmailLogsGridDefinitionModifier', 'Modifying E-mail grid definition', 'This hook allows to alter E-mail grid columns, actions and filters', 1, 1),
(197, 'actionEmailLogsGridQueryBuilderModifier', 'Modify E-mail grid query builder', 'This hook allows to alter Doctrine query builder for E-mail grid', 1, 1),
(198, 'actionEmailLogsGridFilterFormModifier', 'Modify filters form for E-mail grid', 'This hook allows to alter filters form used in E-mail', 1, 1),
(199, 'actionBackupGridPresenterModifier', 'Modify DB Backup grid view data', 'This hook allows to alter presented DB Backup grid data', 1, 1),
(200, 'actionBackupGridDefinitionModifier', 'Modifying DB Backup grid definition', 'This hook allows to alter DB Backup grid columns, actions and filters', 1, 1),
(201, 'actionBackupGridFilterFormModifier', 'Modify filters form for DB Backup grid', 'This hook allows to alter filters form used in DB Backup', 1, 1),
(202, 'actionProductFlagsModifier', 'Customize product labels displayed on the product list on FO', 'This hook allows to add and remove product labels displayed on top of product images', 1, 1),
(203, 'actionListMailThemes', 'List the available email themes and layouts', 'This hook allows to add/remove available email themes (ThemeInterface) and/or to add/remove their layouts (LayoutInterface)', 1, 1),
(204, 'actionGetMailThemeFolder', 'Define the folder of an email theme', 'This hook allows to change the folder of an email theme (useful if you theme is in a module for example)', 1, 1),
(205, 'actionBuildMailLayoutVariables', 'Build the variables used in email layout rendering', 'This hook allows to change the variables used when an email layout is rendered', 1, 1),
(206, 'actionGetMailLayoutTransformations', 'Define the transformation to apply on layout', 'This hook allows to add/remove TransformationInterface used to generate an email layout', 1, 1),
(207, 'displayProductActions', 'Display additional action button on the product page', 'This hook allow additional actions to be triggered, near the add to cart button.', 1, 1),
(208, 'displayPersonalInformationTop', 'Content in the checkout funnel, on top of the personal information panel', 'Display actions or additional content in the personal details tab of the checkout funnel.', 1, 1),
(209, 'actionSqlRequestFormBuilderModifier', 'Modify sql request identifiable object form', 'This hook allows to modify sql request identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(210, 'actionCustomerFormBuilderModifier', 'Modify customer identifiable object form', 'This hook allows to modify customer identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(211, 'actionLanguageFormBuilderModifier', 'Modify language identifiable object form', 'This hook allows to modify language identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(212, 'actionCurrencyFormBuilderModifier', 'Modify currency identifiable object form', 'This hook allows to modify currency identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(213, 'actionWebserviceKeyFormBuilderModifier', 'Modify webservice key identifiable object form', 'This hook allows to modify webservice key identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(214, 'actionMetaFormBuilderModifier', 'Modify meta identifiable object form', 'This hook allows to modify meta identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(215, 'actionCategoryFormBuilderModifier', 'Modify category identifiable object form', 'This hook allows to modify category identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(216, 'actionRootCategoryFormBuilderModifier', 'Modify root category identifiable object form', 'This hook allows to modify root category identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(217, 'actionContactFormBuilderModifier', 'Modify contact identifiable object form', 'This hook allows to modify contact identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(218, 'actionCmsPageCategoryFormBuilderModifier', 'Modify cms page category identifiable object form', 'This hook allows to modify cms page category identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(219, 'actionTaxFormBuilderModifier', 'Modify tax identifiable object form', 'This hook allows to modify tax identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(220, 'actionManufacturerFormBuilderModifier', 'Modify manufacturer identifiable object form', 'This hook allows to modify manufacturer identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(221, 'actionEmployeeFormBuilderModifier', 'Modify employee identifiable object form', 'This hook allows to modify employee identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(222, 'actionProfileFormBuilderModifier', 'Modify profile identifiable object form', 'This hook allows to modify profile identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(223, 'actionCmsPageFormBuilderModifier', 'Modify cms page identifiable object form', 'This hook allows to modify cms page identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(224, 'actionManufacturerAddressFormBuilderModifier', 'Modify manufacturer address identifiable object form', 'This hook allows to modify manufacturer address identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(225, 'actionBeforeUpdateSqlRequestFormHandler', 'Modify sql request identifiable object data before updating it', 'This hook allows to modify sql request identifiable object forms data before it was updated', 1, 1),
(226, 'actionBeforeUpdateCustomerFormHandler', 'Modify customer identifiable object data before updating it', 'This hook allows to modify customer identifiable object forms data before it was updated', 1, 1),
(227, 'actionBeforeUpdateLanguageFormHandler', 'Modify language identifiable object data before updating it', 'This hook allows to modify language identifiable object forms data before it was updated', 1, 1),
(228, 'actionBeforeUpdateCurrencyFormHandler', 'Modify currency identifiable object data before updating it', 'This hook allows to modify currency identifiable object forms data before it was updated', 1, 1),
(229, 'actionBeforeUpdateWebserviceKeyFormHandler', 'Modify webservice key identifiable object data before updating it', 'This hook allows to modify webservice key identifiable object forms data before it was updated', 1, 1),
(230, 'actionBeforeUpdateMetaFormHandler', 'Modify meta identifiable object data before updating it', 'This hook allows to modify meta identifiable object forms data before it was updated', 1, 1),
(231, 'actionBeforeUpdateCategoryFormHandler', 'Modify category identifiable object data before updating it', 'This hook allows to modify category identifiable object forms data before it was updated', 1, 1),
(232, 'actionBeforeUpdateRootCategoryFormHandler', 'Modify root category identifiable object data before updating it', 'This hook allows to modify root category identifiable object forms data before it was updated', 1, 1),
(233, 'actionBeforeUpdateContactFormHandler', 'Modify contact identifiable object data before updating it', 'This hook allows to modify contact identifiable object forms data before it was updated', 1, 1),
(234, 'actionBeforeUpdateCmsPageCategoryFormHandler', 'Modify cms page category identifiable object data before updating it', 'This hook allows to modify cms page category identifiable object forms data before it was updated', 1, 1),
(235, 'actionBeforeUpdateTaxFormHandler', 'Modify tax identifiable object data before updating it', 'This hook allows to modify tax identifiable object forms data before it was updated', 1, 1),
(236, 'actionBeforeUpdateManufacturerFormHandler', 'Modify manufacturer identifiable object data before updating it', 'This hook allows to modify manufacturer identifiable object forms data before it was updated', 1, 1),
(237, 'actionBeforeUpdateEmployeeFormHandler', 'Modify employee identifiable object data before updating it', 'This hook allows to modify employee identifiable object forms data before it was updated', 1, 1),
(238, 'actionBeforeUpdateProfileFormHandler', 'Modify profile identifiable object data before updating it', 'This hook allows to modify profile identifiable object forms data before it was updated', 1, 1),
(239, 'actionBeforeUpdateCmsPageFormHandler', 'Modify cms page identifiable object data before updating it', 'This hook allows to modify cms page identifiable object forms data before it was updated', 1, 1),
(240, 'actionBeforeUpdateManufacturerAddressFormHandler', 'Modify manufacturer address identifiable object data before updating it', 'This hook allows to modify manufacturer address identifiable object forms data before it was updated', 1, 1),
(241, 'actionAfterUpdateSqlRequestFormHandler', 'Modify sql request identifiable object data after updating it', 'This hook allows to modify sql request identifiable object forms data after it was updated', 1, 1),
(242, 'actionAfterUpdateCustomerFormHandler', 'Modify customer identifiable object data after updating it', 'This hook allows to modify customer identifiable object forms data after it was updated', 1, 1),
(243, 'actionAfterUpdateLanguageFormHandler', 'Modify language identifiable object data after updating it', 'This hook allows to modify language identifiable object forms data after it was updated', 1, 1),
(244, 'actionAfterUpdateCurrencyFormHandler', 'Modify currency identifiable object data after updating it', 'This hook allows to modify currency identifiable object forms data after it was updated', 1, 1),
(245, 'actionAfterUpdateWebserviceKeyFormHandler', 'Modify webservice key identifiable object data after updating it', 'This hook allows to modify webservice key identifiable object forms data after it was updated', 1, 1),
(246, 'actionAfterUpdateMetaFormHandler', 'Modify meta identifiable object data after updating it', 'This hook allows to modify meta identifiable object forms data after it was updated', 1, 1),
(247, 'actionAfterUpdateCategoryFormHandler', 'Modify category identifiable object data after updating it', 'This hook allows to modify category identifiable object forms data after it was updated', 1, 1),
(248, 'actionAfterUpdateRootCategoryFormHandler', 'Modify root category identifiable object data after updating it', 'This hook allows to modify root category identifiable object forms data after it was updated', 1, 1),
(249, 'actionAfterUpdateContactFormHandler', 'Modify contact identifiable object data after updating it', 'This hook allows to modify contact identifiable object forms data after it was updated', 1, 1),
(250, 'actionAfterUpdateCmsPageCategoryFormHandler', 'Modify cms page category identifiable object data after updating it', 'This hook allows to modify cms page category identifiable object forms data after it was updated', 1, 1),
(251, 'actionAfterUpdateTaxFormHandler', 'Modify tax identifiable object data after updating it', 'This hook allows to modify tax identifiable object forms data after it was updated', 1, 1),
(252, 'actionAfterUpdateManufacturerFormHandler', 'Modify manufacturer identifiable object data after updating it', 'This hook allows to modify manufacturer identifiable object forms data after it was updated', 1, 1),
(253, 'actionAfterUpdateEmployeeFormHandler', 'Modify employee identifiable object data after updating it', 'This hook allows to modify employee identifiable object forms data after it was updated', 1, 1),
(254, 'actionAfterUpdateProfileFormHandler', 'Modify profile identifiable object data after updating it', 'This hook allows to modify profile identifiable object forms data after it was updated', 1, 1),
(255, 'actionAfterUpdateCmsPageFormHandler', 'Modify cms page identifiable object data after updating it', 'This hook allows to modify cms page identifiable object forms data after it was updated', 1, 1),
(256, 'actionAfterUpdateManufacturerAddressFormHandler', 'Modify manufacturer address identifiable object data after updating it', 'This hook allows to modify manufacturer address identifiable object forms data after it was updated', 1, 1),
(257, 'actionBeforeCreateSqlRequestFormHandler', 'Modify sql request identifiable object data before creating it', 'This hook allows to modify sql request identifiable object forms data before it was created', 1, 1),
(258, 'actionBeforeCreateCustomerFormHandler', 'Modify customer identifiable object data before creating it', 'This hook allows to modify customer identifiable object forms data before it was created', 1, 1),
(259, 'actionBeforeCreateLanguageFormHandler', 'Modify language identifiable object data before creating it', 'This hook allows to modify language identifiable object forms data before it was created', 1, 1),
(260, 'actionBeforeCreateCurrencyFormHandler', 'Modify currency identifiable object data before creating it', 'This hook allows to modify currency identifiable object forms data before it was created', 1, 1),
(261, 'actionBeforeCreateWebserviceKeyFormHandler', 'Modify webservice key identifiable object data before creating it', 'This hook allows to modify webservice key identifiable object forms data before it was created', 1, 1),
(262, 'actionBeforeCreateMetaFormHandler', 'Modify meta identifiable object data before creating it', 'This hook allows to modify meta identifiable object forms data before it was created', 1, 1),
(263, 'actionBeforeCreateCategoryFormHandler', 'Modify category identifiable object data before creating it', 'This hook allows to modify category identifiable object forms data before it was created', 1, 1),
(264, 'actionBeforeCreateRootCategoryFormHandler', 'Modify root category identifiable object data before creating it', 'This hook allows to modify root category identifiable object forms data before it was created', 1, 1),
(265, 'actionBeforeCreateContactFormHandler', 'Modify contact identifiable object data before creating it', 'This hook allows to modify contact identifiable object forms data before it was created', 1, 1),
(266, 'actionBeforeCreateCmsPageCategoryFormHandler', 'Modify cms page category identifiable object data before creating it', 'This hook allows to modify cms page category identifiable object forms data before it was created', 1, 1),
(267, 'actionBeforeCreateTaxFormHandler', 'Modify tax identifiable object data before creating it', 'This hook allows to modify tax identifiable object forms data before it was created', 1, 1),
(268, 'actionBeforeCreateManufacturerFormHandler', 'Modify manufacturer identifiable object data before creating it', 'This hook allows to modify manufacturer identifiable object forms data before it was created', 1, 1),
(269, 'actionBeforeCreateEmployeeFormHandler', 'Modify employee identifiable object data before creating it', 'This hook allows to modify employee identifiable object forms data before it was created', 1, 1),
(270, 'actionBeforeCreateProfileFormHandler', 'Modify profile identifiable object data before creating it', 'This hook allows to modify profile identifiable object forms data before it was created', 1, 1),
(271, 'actionBeforeCreateCmsPageFormHandler', 'Modify cms page identifiable object data before creating it', 'This hook allows to modify cms page identifiable object forms data before it was created', 1, 1),
(272, 'actionBeforeCreateManufacturerAddressFormHandler', 'Modify manufacturer address identifiable object data before creating it', 'This hook allows to modify manufacturer address identifiable object forms data before it was created', 1, 1),
(273, 'actionAfterCreateSqlRequestFormHandler', 'Modify sql request identifiable object data after creating it', 'This hook allows to modify sql request identifiable object forms data after it was created', 1, 1),
(274, 'actionAfterCreateCustomerFormHandler', 'Modify customer identifiable object data after creating it', 'This hook allows to modify customer identifiable object forms data after it was created', 1, 1),
(275, 'actionAfterCreateLanguageFormHandler', 'Modify language identifiable object data after creating it', 'This hook allows to modify language identifiable object forms data after it was created', 1, 1),
(276, 'actionAfterCreateCurrencyFormHandler', 'Modify currency identifiable object data after creating it', 'This hook allows to modify currency identifiable object forms data after it was created', 1, 1),
(277, 'actionAfterCreateWebserviceKeyFormHandler', 'Modify webservice key identifiable object data after creating it', 'This hook allows to modify webservice key identifiable object forms data after it was created', 1, 1),
(278, 'actionAfterCreateMetaFormHandler', 'Modify meta identifiable object data after creating it', 'This hook allows to modify meta identifiable object forms data after it was created', 1, 1),
(279, 'actionAfterCreateCategoryFormHandler', 'Modify category identifiable object data after creating it', 'This hook allows to modify category identifiable object forms data after it was created', 1, 1),
(280, 'actionAfterCreateRootCategoryFormHandler', 'Modify root category identifiable object data after creating it', 'This hook allows to modify root category identifiable object forms data after it was created', 1, 1),
(281, 'actionAfterCreateContactFormHandler', 'Modify contact identifiable object data after creating it', 'This hook allows to modify contact identifiable object forms data after it was created', 1, 1),
(282, 'actionAfterCreateCmsPageCategoryFormHandler', 'Modify cms page category identifiable object data after creating it', 'This hook allows to modify cms page category identifiable object forms data after it was created', 1, 1),
(283, 'actionAfterCreateTaxFormHandler', 'Modify tax identifiable object data after creating it', 'This hook allows to modify tax identifiable object forms data after it was created', 1, 1),
(284, 'actionAfterCreateManufacturerFormHandler', 'Modify manufacturer identifiable object data after creating it', 'This hook allows to modify manufacturer identifiable object forms data after it was created', 1, 1),
(285, 'actionAfterCreateEmployeeFormHandler', 'Modify employee identifiable object data after creating it', 'This hook allows to modify employee identifiable object forms data after it was created', 1, 1),
(286, 'actionAfterCreateProfileFormHandler', 'Modify profile identifiable object data after creating it', 'This hook allows to modify profile identifiable object forms data after it was created', 1, 1),
(287, 'actionAfterCreateCmsPageFormHandler', 'Modify cms page identifiable object data after creating it', 'This hook allows to modify cms page identifiable object forms data after it was created', 1, 1),
(288, 'actionAfterCreateManufacturerAddressFormHandler', 'Modify manufacturer address identifiable object data after creating it', 'This hook allows to modify manufacturer address identifiable object forms data after it was created', 1, 1),
(289, 'actionShippingPreferencesPageForm', 'Modify shipping preferences page options form content', 'This hook allows to modify shipping preferences page options form FormBuilder', 1, 1),
(290, 'actionOrdersInvoicesByDateForm', 'Modify orders invoices by date options form content', 'This hook allows to modify orders invoices by date options form FormBuilder', 1, 1),
(291, 'actionOrdersInvoicesByStatusForm', 'Modify orders invoices by status options form content', 'This hook allows to modify orders invoices by status options form FormBuilder', 1, 1),
(292, 'actionOrdersInvoicesOptionsForm', 'Modify orders invoices options options form content', 'This hook allows to modify orders invoices options options form FormBuilder', 1, 1),
(293, 'actionCustomerPreferencesPageForm', 'Modify customer preferences page options form content', 'This hook allows to modify customer preferences page options form FormBuilder', 1, 1),
(294, 'actionOrderPreferencesPageForm', 'Modify order preferences page options form content', 'This hook allows to modify order preferences page options form FormBuilder', 1, 1),
(295, 'actionProductPreferencesPageForm', 'Modify product preferences page options form content', 'This hook allows to modify product preferences page options form FormBuilder', 1, 1),
(296, 'actionGeneralPageForm', 'Modify general page options form content', 'This hook allows to modify general page options form FormBuilder', 1, 1),
(297, 'actionLogsPageForm', 'Modify logs page options form content', 'This hook allows to modify logs page options form FormBuilder', 1, 1),
(298, 'actionOrderDeliverySlipOptionsForm', 'Modify order delivery slip options options form content', 'This hook allows to modify order delivery slip options options form FormBuilder', 1, 1),
(299, 'actionOrderDeliverySlipPdfForm', 'Modify order delivery slip pdf options form content', 'This hook allows to modify order delivery slip pdf options form FormBuilder', 1, 1),
(300, 'actionGeolocationPageForm', 'Modify geolocation page options form content', 'This hook allows to modify geolocation page options form FormBuilder', 1, 1),
(301, 'actionLocalizationPageForm', 'Modify localization page options form content', 'This hook allows to modify localization page options form FormBuilder', 1, 1),
(302, 'actionPaymentPreferencesForm', 'Modify payment preferences options form content', 'This hook allows to modify payment preferences options form FormBuilder', 1, 1),
(303, 'actionEmailConfigurationForm', 'Modify email configuration options form content', 'This hook allows to modify email configuration options form FormBuilder', 1, 1);
INSERT INTO `ps_hook` (`id_hook`, `name`, `title`, `description`, `active`, `position`) VALUES
(304, 'actionRequestSqlForm', 'Modify request sql options form content', 'This hook allows to modify request sql options form FormBuilder', 1, 1),
(305, 'actionBackupForm', 'Modify backup options form content', 'This hook allows to modify backup options form FormBuilder', 1, 1),
(306, 'actionWebservicePageForm', 'Modify webservice page options form content', 'This hook allows to modify webservice page options form FormBuilder', 1, 1),
(307, 'actionMetaPageForm', 'Modify meta page options form content', 'This hook allows to modify meta page options form FormBuilder', 1, 1),
(308, 'actionEmployeeForm', 'Modify employee options form content', 'This hook allows to modify employee options form FormBuilder', 1, 1),
(309, 'actionCurrencyForm', 'Modify currency options form content', 'This hook allows to modify currency options form FormBuilder', 1, 1),
(310, 'actionShopLogoForm', 'Modify shop logo options form content', 'This hook allows to modify shop logo options form FormBuilder', 1, 1),
(311, 'actionTaxForm', 'Modify tax options form content', 'This hook allows to modify tax options form FormBuilder', 1, 1),
(312, 'actionMailThemeForm', 'Modify mail theme options form content', 'This hook allows to modify mail theme options form FormBuilder', 1, 1),
(313, 'actionPerformancePageSave', 'Modify performance page options form saved data', 'This hook allows to modify data of performance page options form after it was saved', 1, 1),
(314, 'actionMaintenancePageSave', 'Modify maintenance page options form saved data', 'This hook allows to modify data of maintenance page options form after it was saved', 1, 1),
(315, 'actionAdministrationPageSave', 'Modify administration page options form saved data', 'This hook allows to modify data of administration page options form after it was saved', 1, 1),
(316, 'actionShippingPreferencesPageSave', 'Modify shipping preferences page options form saved data', 'This hook allows to modify data of shipping preferences page options form after it was saved', 1, 1),
(317, 'actionOrdersInvoicesByDateSave', 'Modify orders invoices by date options form saved data', 'This hook allows to modify data of orders invoices by date options form after it was saved', 1, 1),
(318, 'actionOrdersInvoicesByStatusSave', 'Modify orders invoices by status options form saved data', 'This hook allows to modify data of orders invoices by status options form after it was saved', 1, 1),
(319, 'actionOrdersInvoicesOptionsSave', 'Modify orders invoices options options form saved data', 'This hook allows to modify data of orders invoices options options form after it was saved', 1, 1),
(320, 'actionCustomerPreferencesPageSave', 'Modify customer preferences page options form saved data', 'This hook allows to modify data of customer preferences page options form after it was saved', 1, 1),
(321, 'actionOrderPreferencesPageSave', 'Modify order preferences page options form saved data', 'This hook allows to modify data of order preferences page options form after it was saved', 1, 1),
(322, 'actionProductPreferencesPageSave', 'Modify product preferences page options form saved data', 'This hook allows to modify data of product preferences page options form after it was saved', 1, 1),
(323, 'actionGeneralPageSave', 'Modify general page options form saved data', 'This hook allows to modify data of general page options form after it was saved', 1, 1),
(324, 'actionLogsPageSave', 'Modify logs page options form saved data', 'This hook allows to modify data of logs page options form after it was saved', 1, 1),
(325, 'actionOrderDeliverySlipOptionsSave', 'Modify order delivery slip options options form saved data', 'This hook allows to modify data of order delivery slip options options form after it was saved', 1, 1),
(326, 'actionOrderDeliverySlipPdfSave', 'Modify order delivery slip pdf options form saved data', 'This hook allows to modify data of order delivery slip pdf options form after it was saved', 1, 1),
(327, 'actionGeolocationPageSave', 'Modify geolocation page options form saved data', 'This hook allows to modify data of geolocation page options form after it was saved', 1, 1),
(328, 'actionLocalizationPageSave', 'Modify localization page options form saved data', 'This hook allows to modify data of localization page options form after it was saved', 1, 1),
(329, 'actionPaymentPreferencesSave', 'Modify payment preferences options form saved data', 'This hook allows to modify data of payment preferences options form after it was saved', 1, 1),
(330, 'actionEmailConfigurationSave', 'Modify email configuration options form saved data', 'This hook allows to modify data of email configuration options form after it was saved', 1, 1),
(331, 'actionRequestSqlSave', 'Modify request sql options form saved data', 'This hook allows to modify data of request sql options form after it was saved', 1, 1),
(332, 'actionBackupSave', 'Modify backup options form saved data', 'This hook allows to modify data of backup options form after it was saved', 1, 1),
(333, 'actionWebservicePageSave', 'Modify webservice page options form saved data', 'This hook allows to modify data of webservice page options form after it was saved', 1, 1),
(334, 'actionMetaPageSave', 'Modify meta page options form saved data', 'This hook allows to modify data of meta page options form after it was saved', 1, 1),
(335, 'actionEmployeeSave', 'Modify employee options form saved data', 'This hook allows to modify data of employee options form after it was saved', 1, 1),
(336, 'actionCurrencySave', 'Modify currency options form saved data', 'This hook allows to modify data of currency options form after it was saved', 1, 1),
(337, 'actionShopLogoSave', 'Modify shop logo options form saved data', 'This hook allows to modify data of shop logo options form after it was saved', 1, 1),
(338, 'actionTaxSave', 'Modify tax options form saved data', 'This hook allows to modify data of tax options form after it was saved', 1, 1),
(339, 'actionMailThemeSave', 'Modify mail theme options form saved data', 'This hook allows to modify data of mail theme options form after it was saved', 1, 1),
(340, 'actionCategoryGridDefinitionModifier', 'Modify category grid definition', 'This hook allows to alter category grid columns, actions and filters', 1, 1),
(341, 'actionEmployeeGridDefinitionModifier', 'Modify employee grid definition', 'This hook allows to alter employee grid columns, actions and filters', 1, 1),
(342, 'actionContactGridDefinitionModifier', 'Modify contact grid definition', 'This hook allows to alter contact grid columns, actions and filters', 1, 1),
(343, 'actionCustomerGridDefinitionModifier', 'Modify customer grid definition', 'This hook allows to alter customer grid columns, actions and filters', 1, 1),
(344, 'actionLanguageGridDefinitionModifier', 'Modify language grid definition', 'This hook allows to alter language grid columns, actions and filters', 1, 1),
(345, 'actionCurrencyGridDefinitionModifier', 'Modify currency grid definition', 'This hook allows to alter currency grid columns, actions and filters', 1, 1),
(346, 'actionSupplierGridDefinitionModifier', 'Modify supplier grid definition', 'This hook allows to alter supplier grid columns, actions and filters', 1, 1),
(347, 'actionProfileGridDefinitionModifier', 'Modify profile grid definition', 'This hook allows to alter profile grid columns, actions and filters', 1, 1),
(348, 'actionCmsPageCategoryGridDefinitionModifier', 'Modify cms page category grid definition', 'This hook allows to alter cms page category grid columns, actions and filters', 1, 1),
(349, 'actionTaxGridDefinitionModifier', 'Modify tax grid definition', 'This hook allows to alter tax grid columns, actions and filters', 1, 1),
(350, 'actionManufacturerGridDefinitionModifier', 'Modify manufacturer grid definition', 'This hook allows to alter manufacturer grid columns, actions and filters', 1, 1),
(351, 'actionManufacturerAddressGridDefinitionModifier', 'Modify manufacturer address grid definition', 'This hook allows to alter manufacturer address grid columns, actions and filters', 1, 1),
(352, 'actionCmsPageGridDefinitionModifier', 'Modify cms page grid definition', 'This hook allows to alter cms page grid columns, actions and filters', 1, 1),
(353, 'actionBackupGridQueryBuilderModifier', 'Modify backup grid query builder', 'This hook allows to alter Doctrine query builder for backup grid', 1, 1),
(354, 'actionCategoryGridQueryBuilderModifier', 'Modify category grid query builder', 'This hook allows to alter Doctrine query builder for category grid', 1, 1),
(355, 'actionEmployeeGridQueryBuilderModifier', 'Modify employee grid query builder', 'This hook allows to alter Doctrine query builder for employee grid', 1, 1),
(356, 'actionContactGridQueryBuilderModifier', 'Modify contact grid query builder', 'This hook allows to alter Doctrine query builder for contact grid', 1, 1),
(357, 'actionCustomerGridQueryBuilderModifier', 'Modify customer grid query builder', 'This hook allows to alter Doctrine query builder for customer grid', 1, 1),
(358, 'actionLanguageGridQueryBuilderModifier', 'Modify language grid query builder', 'This hook allows to alter Doctrine query builder for language grid', 1, 1),
(359, 'actionCurrencyGridQueryBuilderModifier', 'Modify currency grid query builder', 'This hook allows to alter Doctrine query builder for currency grid', 1, 1),
(360, 'actionSupplierGridQueryBuilderModifier', 'Modify supplier grid query builder', 'This hook allows to alter Doctrine query builder for supplier grid', 1, 1),
(361, 'actionProfileGridQueryBuilderModifier', 'Modify profile grid query builder', 'This hook allows to alter Doctrine query builder for profile grid', 1, 1),
(362, 'actionCmsPageCategoryGridQueryBuilderModifier', 'Modify cms page category grid query builder', 'This hook allows to alter Doctrine query builder for cms page category grid', 1, 1),
(363, 'actionTaxGridQueryBuilderModifier', 'Modify tax grid query builder', 'This hook allows to alter Doctrine query builder for tax grid', 1, 1),
(364, 'actionManufacturerGridQueryBuilderModifier', 'Modify manufacturer grid query builder', 'This hook allows to alter Doctrine query builder for manufacturer grid', 1, 1),
(365, 'actionManufacturerAddressGridQueryBuilderModifier', 'Modify manufacturer address grid query builder', 'This hook allows to alter Doctrine query builder for manufacturer address grid', 1, 1),
(366, 'actionCmsPageGridQueryBuilderModifier', 'Modify cms page grid query builder', 'This hook allows to alter Doctrine query builder for cms page grid', 1, 1),
(367, 'actionLogsGridDataModifier', 'Modify logs grid data', 'This hook allows to modify logs grid data', 1, 1),
(368, 'actionEmailLogsGridDataModifier', 'Modify email logs grid data', 'This hook allows to modify email logs grid data', 1, 1),
(369, 'actionSqlRequestGridDataModifier', 'Modify sql request grid data', 'This hook allows to modify sql request grid data', 1, 1),
(370, 'actionBackupGridDataModifier', 'Modify backup grid data', 'This hook allows to modify backup grid data', 1, 1),
(371, 'actionWebserviceKeyGridDataModifier', 'Modify webservice key grid data', 'This hook allows to modify webservice key grid data', 1, 1),
(372, 'actionMetaGridDataModifier', 'Modify meta grid data', 'This hook allows to modify meta grid data', 1, 1),
(373, 'actionCategoryGridDataModifier', 'Modify category grid data', 'This hook allows to modify category grid data', 1, 1),
(374, 'actionEmployeeGridDataModifier', 'Modify employee grid data', 'This hook allows to modify employee grid data', 1, 1),
(375, 'actionContactGridDataModifier', 'Modify contact grid data', 'This hook allows to modify contact grid data', 1, 1),
(376, 'actionCustomerGridDataModifier', 'Modify customer grid data', 'This hook allows to modify customer grid data', 1, 1),
(377, 'actionLanguageGridDataModifier', 'Modify language grid data', 'This hook allows to modify language grid data', 1, 1),
(378, 'actionCurrencyGridDataModifier', 'Modify currency grid data', 'This hook allows to modify currency grid data', 1, 1),
(379, 'actionSupplierGridDataModifier', 'Modify supplier grid data', 'This hook allows to modify supplier grid data', 1, 1),
(380, 'actionProfileGridDataModifier', 'Modify profile grid data', 'This hook allows to modify profile grid data', 1, 1),
(381, 'actionCmsPageCategoryGridDataModifier', 'Modify cms page category grid data', 'This hook allows to modify cms page category grid data', 1, 1),
(382, 'actionTaxGridDataModifier', 'Modify tax grid data', 'This hook allows to modify tax grid data', 1, 1),
(383, 'actionManufacturerGridDataModifier', 'Modify manufacturer grid data', 'This hook allows to modify manufacturer grid data', 1, 1),
(384, 'actionManufacturerAddressGridDataModifier', 'Modify manufacturer address grid data', 'This hook allows to modify manufacturer address grid data', 1, 1),
(385, 'actionCmsPageGridDataModifier', 'Modify cms page grid data', 'This hook allows to modify cms page grid data', 1, 1),
(386, 'actionCategoryGridFilterFormModifier', 'Modify category grid filters', 'This hook allows to modify filters for category grid', 1, 1),
(387, 'actionEmployeeGridFilterFormModifier', 'Modify employee grid filters', 'This hook allows to modify filters for employee grid', 1, 1),
(388, 'actionContactGridFilterFormModifier', 'Modify contact grid filters', 'This hook allows to modify filters for contact grid', 1, 1),
(389, 'actionCustomerGridFilterFormModifier', 'Modify customer grid filters', 'This hook allows to modify filters for customer grid', 1, 1),
(390, 'actionLanguageGridFilterFormModifier', 'Modify language grid filters', 'This hook allows to modify filters for language grid', 1, 1),
(391, 'actionCurrencyGridFilterFormModifier', 'Modify currency grid filters', 'This hook allows to modify filters for currency grid', 1, 1),
(392, 'actionSupplierGridFilterFormModifier', 'Modify supplier grid filters', 'This hook allows to modify filters for supplier grid', 1, 1),
(393, 'actionProfileGridFilterFormModifier', 'Modify profile grid filters', 'This hook allows to modify filters for profile grid', 1, 1),
(394, 'actionCmsPageCategoryGridFilterFormModifier', 'Modify cms page category grid filters', 'This hook allows to modify filters for cms page category grid', 1, 1),
(395, 'actionTaxGridFilterFormModifier', 'Modify tax grid filters', 'This hook allows to modify filters for tax grid', 1, 1),
(396, 'actionManufacturerGridFilterFormModifier', 'Modify manufacturer grid filters', 'This hook allows to modify filters for manufacturer grid', 1, 1),
(397, 'actionManufacturerAddressGridFilterFormModifier', 'Modify manufacturer address grid filters', 'This hook allows to modify filters for manufacturer address grid', 1, 1),
(398, 'actionCmsPageGridFilterFormModifier', 'Modify cms page grid filters', 'This hook allows to modify filters for cms page grid', 1, 1),
(399, 'actionCategoryGridPresenterModifier', 'Modify category grid template data', 'This hook allows to modify data which is about to be used in template for category grid', 1, 1),
(400, 'actionEmployeeGridPresenterModifier', 'Modify employee grid template data', 'This hook allows to modify data which is about to be used in template for employee grid', 1, 1),
(401, 'actionContactGridPresenterModifier', 'Modify contact grid template data', 'This hook allows to modify data which is about to be used in template for contact grid', 1, 1),
(402, 'actionCustomerGridPresenterModifier', 'Modify customer grid template data', 'This hook allows to modify data which is about to be used in template for customer grid', 1, 1),
(403, 'actionLanguageGridPresenterModifier', 'Modify language grid template data', 'This hook allows to modify data which is about to be used in template for language grid', 1, 1),
(404, 'actionCurrencyGridPresenterModifier', 'Modify currency grid template data', 'This hook allows to modify data which is about to be used in template for currency grid', 1, 1),
(405, 'actionSupplierGridPresenterModifier', 'Modify supplier grid template data', 'This hook allows to modify data which is about to be used in template for supplier grid', 1, 1),
(406, 'actionProfileGridPresenterModifier', 'Modify profile grid template data', 'This hook allows to modify data which is about to be used in template for profile grid', 1, 1),
(407, 'actionCmsPageCategoryGridPresenterModifier', 'Modify cms page category grid template data', 'This hook allows to modify data which is about to be used in template for cms page category grid', 1, 1),
(408, 'actionTaxGridPresenterModifier', 'Modify tax grid template data', 'This hook allows to modify data which is about to be used in template for tax grid', 1, 1),
(409, 'actionManufacturerGridPresenterModifier', 'Modify manufacturer grid template data', 'This hook allows to modify data which is about to be used in template for manufacturer grid', 1, 1),
(410, 'actionManufacturerAddressGridPresenterModifier', 'Modify manufacturer address grid template data', 'This hook allows to modify data which is about to be used in template for manufacturer address grid', 1, 1),
(411, 'actionCmsPageGridPresenterModifier', 'Modify cms page grid template data', 'This hook allows to modify data which is about to be used in template for cms page grid', 1, 1),
(412, 'displayAdminOrderTop', 'Admin Order Top', 'This hook displays content at the top of the order view page', 1, 1),
(413, 'displayBackOfficeOrderActions', 'Admin Order Actions', 'This hook displays content in the order view page after action buttons (or aliased to side column in migrated page)', 1, 1),
(414, 'displayAdminOrderSide', 'Admin Order Side Column', 'This hook displays content in the order view page in the side column under the customer view', 1, 1),
(415, 'displayAdminOrderBottom', 'Admin Order Side Column Bottom', 'This hook displays content in the order view page at the bottom of the side column', 1, 1),
(416, 'displayAdminOrderMain', 'Admin Order Main Column', 'This hook displays content in the order view page in the main column under the details view', 1, 1),
(417, 'displayAdminOrderMainBottom', 'Admin Order Main Column Bottom', 'This hook displays content in the order view page at the bottom of the main column', 1, 1),
(418, 'displayAdminOrderTabLink', 'Admin Order Tab Link', 'This hook displays new tab links on the order view page', 1, 1),
(419, 'displayAdminOrderTabContent', 'Admin Order Tab Content', 'This hook displays new tab contents on the order view page', 1, 1),
(420, 'actionGetAdminOrderButtons', 'Admin Order Buttons', 'This hook is used to generate the buttons collection on the order view page (see ActionsBarButtonsCollection)', 1, 1),
(421, 'actionPresentCart', 'Cart Presenter', 'This hook is called before a cart is presented', 1, 1),
(422, 'actionPresentOrder', 'Order Presenter', 'This hook is called before an order is presented', 1, 1),
(423, 'actionPresentOrderReturn', 'Order Return Presenter', 'This hook is called before an order return is presented', 1, 1),
(424, 'actionPresentProduct', 'Product Presenter', 'This hook is called before a product is presented', 1, 1),
(425, 'actionAdminAdminPreferencesControllerPostProcessBefore', 'On post-process in Admin Preferences', 'This hook is called on Admin Preferences post-process before processing the form', 1, 1),
(426, 'actionFeatureFormBuilderModifier', 'Modify feature identifiable object form', 'This hook allows to modify feature identifiable object forms content by modifying form builder data\n      or FormBuilder itself', 1, 1),
(427, 'actionOrderMessageFormBuilderModifier', 'Modify order message identifiable object form', 'This hook allows to modify order message identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(428, 'actionCatalogPriceRuleFormBuilderModifier', 'Modify catalog price rule identifiable object form', 'This hook allows to modify catalog price rule identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(429, 'actionAttachmentFormBuilderModifier', 'Modify attachment identifiable object form', 'This hook allows to modify attachment identifiable object forms content by modifying form builder data or FormBuilder itself', 1, 1),
(430, 'actionBeforeUpdateFeatureFormHandler', 'Modify feature identifiable object data before updating it', 'This hook allows to modify feature identifiable object forms data before it was updated', 1, 1),
(431, 'actionBeforeUpdateOrderMessageFormHandler', 'Modify order message identifiable object data before updating it', 'This hook allows to modify order message identifiable object forms data before it was updated', 1, 1),
(432, 'actionBeforeUpdateCatalogPriceRuleFormHandler', 'Modify catalog price rule identifiable object data before updating it', 'This hook allows to modify catalog price rule identifiable object forms data before it was updated', 1, 1),
(433, 'actionBeforeUpdateAttachmentFormHandler', 'Modify attachment identifiable object data before updating it', 'This hook allows to modify attachment identifiable object forms data before it was updated', 1, 1),
(434, 'actionAfterUpdateFeatureFormHandler', 'Modify feature identifiable object data after updating it', 'This hook allows to modify feature identifiable object forms data after it was updated', 1, 1),
(435, 'actionAfterUpdateOrderMessageFormHandler', 'Modify order message identifiable object data after updating it', 'This hook allows to modify order message identifiable object forms data after it was updated', 1, 1),
(436, 'actionAfterUpdateCatalogPriceRuleFormHandler', 'Modify catalog price rule identifiable object data after updating it', 'This hook allows to modify catalog price rule identifiable object forms data after it was updated', 1, 1),
(437, 'actionAfterUpdateAttachmentFormHandler', 'Modify attachment identifiable object data after updating it', 'This hook allows to modify attachment identifiable object forms data after it was updated', 1, 1),
(438, 'actionBeforeCreateFeatureFormHandler', 'Modify feature identifiable object data before creating it', 'This hook allows to modify feature identifiable object forms data before it was created', 1, 1),
(439, 'actionBeforeCreateOrderMessageFormHandler', 'Modify order message identifiable object data before creating it', 'This hook allows to modify order message identifiable object forms data before it was created', 1, 1),
(440, 'actionBeforeCreateCatalogPriceRuleFormHandler', 'Modify catalog price rule identifiable object data before creating it', 'This hook allows to modify catalog price rule identifiable object forms data before it was created', 1, 1),
(441, 'actionBeforeCreateAttachmentFormHandler', 'Modify attachment identifiable object data before creating it', 'This hook allows to modify attachment identifiable object forms data before it was created', 1, 1),
(442, 'actionAfterCreateFeatureFormHandler', 'Modify feature identifiable object data after creating it', 'This hook allows to modify feature identifiable object forms data after it was created', 1, 1),
(443, 'actionAfterCreateOrderMessageFormHandler', 'Modify order message identifiable object data after creating it', 'This hook allows to modify order message identifiable object forms data after it was created', 1, 1),
(444, 'actionAfterCreateCatalogPriceRuleFormHandler', 'Modify catalog price rule identifiable object data after creating it', 'This hook allows to modify catalog price rule identifiable object forms data after it was created', 1, 1),
(445, 'actionAfterCreateAttachmentFormHandler', 'Modify attachment identifiable object data after creating it', 'This hook allows to modify attachment identifiable object forms data after it was created', 1, 1),
(446, 'actionMerchandiseReturnForm', 'Modify merchandise return options form content', 'This hook allows to modify merchandise return options form FormBuilder', 1, 1),
(447, 'actionCreditSlipForm', 'Modify credit slip options form content', 'This hook allows to modify credit slip options form FormBuilder', 1, 1),
(448, 'actionMerchandiseReturnSave', 'Modify merchandise return options form saved data', 'This hook allows to modify data of merchandise return options form after it was saved', 1, 1),
(449, 'actionCreditSlipSave', 'Modify credit slip options form saved data', 'This hook allows to modify data of credit slip options form after it was saved', 1, 1),
(450, 'actionEmptyCategoryGridDefinitionModifier', 'Modify empty category grid definition', 'This hook allows to alter empty category grid columns, actions and filters', 1, 1),
(451, 'actionNoQtyProductWithCombinationGridDefinitionModifier', 'Modify no qty product with combination grid definition', 'This hook allows to alter no qty product with combination grid columns, actions and filters\n      ', 1, 1),
(452, 'actionNoQtyProductWithoutCombinationGridDefinitionModifier', 'Modify no qty product without combination grid definition', 'This hook allows to alter no qty product without combination grid columns, actions and filters\n      ', 1, 1),
(453, 'actionDisabledProductGridDefinitionModifier', 'Modify disabled product grid definition', 'This hook allows to alter disabled product grid columns, actions and filters', 1, 1),
(454, 'actionProductWithoutImageGridDefinitionModifier', 'Modify product without image grid definition', 'This hook allows to alter product without image grid columns, actions and filters', 1, 1),
(455, 'actionProductWithoutDescriptionGridDefinitionModifier', 'Modify product without description grid definition', 'This hook allows to alter product without description grid columns, actions and filters', 1, 1),
(456, 'actionProductWithoutPriceGridDefinitionModifier', 'Modify product without price grid definition', 'This hook allows to alter product without price grid columns, actions and filters', 1, 1),
(457, 'actionOrderGridDefinitionModifier', 'Modify order grid definition', 'This hook allows to alter order grid columns, actions and filters', 1, 1),
(458, 'actionCatalogPriceRuleGridDefinitionModifier', 'Modify catalog price rule grid definition', 'This hook allows to alter catalog price rule grid columns, actions and filters', 1, 1),
(459, 'actionOrderMessageGridDefinitionModifier', 'Modify order message grid definition', 'This hook allows to alter order message grid columns, actions and filters', 1, 1),
(460, 'actionAttachmentGridDefinitionModifier', 'Modify attachment grid definition', 'This hook allows to alter attachment grid columns, actions and filters', 1, 1),
(461, 'actionAttributeGroupGridDefinitionModifier', 'Modify attribute group grid definition', 'This hook allows to alter attribute group grid columns, actions and filters', 1, 1),
(462, 'actionMerchandiseReturnGridDefinitionModifier', 'Modify merchandise return grid definition', 'This hook allows to alter merchandise return grid columns, actions and filters', 1, 1),
(463, 'actionTaxRulesGroupGridDefinitionModifier', 'Modify tax rules group grid definition', 'This hook allows to alter tax rules group grid columns, actions and filters', 1, 1),
(464, 'actionAddressGridDefinitionModifier', 'Modify address grid definition', 'This hook allows to alter address grid columns, actions and filters', 1, 1),
(465, 'actionCreditSlipGridDefinitionModifier', 'Modify credit slip grid definition', 'This hook allows to alter credit slip grid columns, actions and filters', 1, 1),
(466, 'actionEmptyCategoryGridQueryBuilderModifier', 'Modify empty category grid query builder', 'This hook allows to alter Doctrine query builder for empty category grid', 1, 1),
(467, 'actionNoQtyProductWithCombinationGridQueryBuilderModifier', 'Modify no qty product with combination grid query builder', 'This hook allows to alter Doctrine query builder for no qty product with combination grid', 1, 1),
(468, 'actionNoQtyProductWithoutCombinationGridQueryBuilderModifier', 'Modify no qty product without combination grid query builder', 'This hook allows to alter Doctrine query builder for no qty product without combination grid', 1, 1),
(469, 'actionDisabledProductGridQueryBuilderModifier', 'Modify disabled product grid query builder', 'This hook allows to alter Doctrine query builder for disabled product grid', 1, 1),
(470, 'actionProductWithoutImageGridQueryBuilderModifier', 'Modify product without image grid query builder', 'This hook allows to alter Doctrine query builder for product without image grid', 1, 1),
(471, 'actionProductWithoutDescriptionGridQueryBuilderModifier', 'Modify product without description grid query builder', 'This hook allows to alter Doctrine query builder for product without description grid', 1, 1),
(472, 'actionProductWithoutPriceGridQueryBuilderModifier', 'Modify product without price grid query builder', 'This hook allows to alter Doctrine query builder for product without price grid', 1, 1),
(473, 'actionOrderGridQueryBuilderModifier', 'Modify order grid query builder', 'This hook allows to alter Doctrine query builder for order grid', 1, 1),
(474, 'actionCatalogPriceRuleGridQueryBuilderModifier', 'Modify catalog price rule grid query builder', 'This hook allows to alter Doctrine query builder for catalog price rule grid', 1, 1),
(475, 'actionOrderMessageGridQueryBuilderModifier', 'Modify order message grid query builder', 'This hook allows to alter Doctrine query builder for order message grid', 1, 1),
(476, 'actionAttachmentGridQueryBuilderModifier', 'Modify attachment grid query builder', 'This hook allows to alter Doctrine query builder for attachment grid', 1, 1),
(477, 'actionAttributeGroupGridQueryBuilderModifier', 'Modify attribute group grid query builder', 'This hook allows to alter Doctrine query builder for attribute group grid', 1, 1),
(478, 'actionMerchandiseReturnGridQueryBuilderModifier', 'Modify merchandise return grid query builder', 'This hook allows to alter Doctrine query builder for merchandise return grid', 1, 1),
(479, 'actionTaxRulesGroupGridQueryBuilderModifier', 'Modify tax rules group grid query builder', 'This hook allows to alter Doctrine query builder for tax rules group grid', 1, 1),
(480, 'actionAddressGridQueryBuilderModifier', 'Modify address grid query builder', 'This hook allows to alter Doctrine query builder for address grid', 1, 1),
(481, 'actionCreditSlipGridQueryBuilderModifier', 'Modify credit slip grid query builder', 'This hook allows to alter Doctrine query builder for credit slip grid', 1, 1),
(482, 'actionEmptyCategoryGridDataModifier', 'Modify empty category grid data', 'This hook allows to modify empty category grid data', 1, 1),
(483, 'actionNoQtyProductWithCombinationGridDataModifier', 'Modify no qty product with combination grid data', 'This hook allows to modify no qty product with combination grid data', 1, 1),
(484, 'actionNoQtyProductWithoutCombinationGridDataModifier', 'Modify no qty product without combination grid data', 'This hook allows to modify no qty product without combination grid data', 1, 1),
(485, 'actionDisabledProductGridDataModifier', 'Modify disabled product grid data', 'This hook allows to modify disabled product grid data', 1, 1),
(486, 'actionProductWithoutImageGridDataModifier', 'Modify product without image grid data', 'This hook allows to modify product without image grid data', 1, 1),
(487, 'actionProductWithoutDescriptionGridDataModifier', 'Modify product without description grid data', 'This hook allows to modify product without description grid data', 1, 1),
(488, 'actionProductWithoutPriceGridDataModifier', 'Modify product without price grid data', 'This hook allows to modify product without price grid data', 1, 1),
(489, 'actionOrderGridDataModifier', 'Modify order grid data', 'This hook allows to modify order grid data', 1, 1),
(490, 'actionCatalogPriceRuleGridDataModifier', 'Modify catalog price rule grid data', 'This hook allows to modify catalog price rule grid data', 1, 1),
(491, 'actionOrderMessageGridDataModifier', 'Modify order message grid data', 'This hook allows to modify order message grid data', 1, 1),
(492, 'actionAttachmentGridDataModifier', 'Modify attachment grid data', 'This hook allows to modify attachment grid data', 1, 1),
(493, 'actionAttributeGroupGridDataModifier', 'Modify attribute group grid data', 'This hook allows to modify attribute group grid data', 1, 1),
(494, 'actionMerchandiseReturnGridDataModifier', 'Modify merchandise return grid data', 'This hook allows to modify merchandise return grid data', 1, 1),
(495, 'actionTaxRulesGroupGridDataModifier', 'Modify tax rules group grid data', 'This hook allows to modify tax rules group grid data', 1, 1),
(496, 'actionAddressGridDataModifier', 'Modify address grid data', 'This hook allows to modify address grid data', 1, 1),
(497, 'actionCreditSlipGridDataModifier', 'Modify credit slip grid data', 'This hook allows to modify credit slip grid data', 1, 1),
(498, 'actionEmptyCategoryGridFilterFormModifier', 'Modify empty category grid filters', 'This hook allows to modify filters for empty category grid', 1, 1),
(499, 'actionNoQtyProductWithCombinationGridFilterFormModifier', 'Modify no qty product with combination grid filters', 'This hook allows to modify filters for no qty product with combination grid', 1, 1),
(500, 'actionNoQtyProductWithoutCombinationGridFilterFormModifier', 'Modify no qty product without combination grid filters', 'This hook allows to modify filters for no qty product without combination grid', 1, 1),
(501, 'actionDisabledProductGridFilterFormModifier', 'Modify disabled product grid filters', 'This hook allows to modify filters for disabled product grid', 1, 1),
(502, 'actionProductWithoutImageGridFilterFormModifier', 'Modify product without image grid filters', 'This hook allows to modify filters for product without image grid', 1, 1),
(503, 'actionProductWithoutDescriptionGridFilterFormModifier', 'Modify product without description grid filters', 'This hook allows to modify filters for product without description grid', 1, 1),
(504, 'actionProductWithoutPriceGridFilterFormModifier', 'Modify product without price grid filters', 'This hook allows to modify filters for product without price grid', 1, 1),
(505, 'actionOrderGridFilterFormModifier', 'Modify order grid filters', 'This hook allows to modify filters for order grid', 1, 1),
(506, 'actionCatalogPriceRuleGridFilterFormModifier', 'Modify catalog price rule grid filters', 'This hook allows to modify filters for catalog price rule grid', 1, 1),
(507, 'actionOrderMessageGridFilterFormModifier', 'Modify order message grid filters', 'This hook allows to modify filters for order message grid', 1, 1),
(508, 'actionAttachmentGridFilterFormModifier', 'Modify attachment grid filters', 'This hook allows to modify filters for attachment grid', 1, 1),
(509, 'actionAttributeGroupGridFilterFormModifier', 'Modify attribute group grid filters', 'This hook allows to modify filters for attribute group grid', 1, 1),
(510, 'actionMerchandiseReturnGridFilterFormModifier', 'Modify merchandise return grid filters', 'This hook allows to modify filters for merchandise return grid', 1, 1),
(511, 'actionTaxRulesGroupGridFilterFormModifier', 'Modify tax rules group grid filters', 'This hook allows to modify filters for tax rules group grid', 1, 1),
(512, 'actionAddressGridFilterFormModifier', 'Modify address grid filters', 'This hook allows to modify filters for address grid', 1, 1),
(513, 'actionCreditSlipGridFilterFormModifier', 'Modify credit slip grid filters', 'This hook allows to modify filters for credit slip grid', 1, 1),
(514, 'actionEmptyCategoryGridPresenterModifier', 'Modify empty category grid template data', 'This hook allows to modify data which is about to be used in template for empty category grid', 1, 1),
(515, 'actionNoQtyProductWithCombinationGridPresenterModifier', 'Modify no qty product with combination grid template data', 'This hook allows to modify data which is about to be used in template for no qty product with combination grid', 1, 1),
(516, 'actionNoQtyProductWithoutCombinationGridPresenterModifier', 'Modify no qty product without combination grid template data', 'This hook allows to modify data which is about to be used in template for no qty product without combination grid', 1, 1),
(517, 'actionDisabledProductGridPresenterModifier', 'Modify disabled product grid template data', 'This hook allows to modify data which is about to be used in template for disabled product grid', 1, 1),
(518, 'actionProductWithoutImageGridPresenterModifier', 'Modify product without image grid template data', 'This hook allows to modify data which is about to be used in template for product without image grid', 1, 1),
(519, 'actionProductWithoutDescriptionGridPresenterModifier', 'Modify product without description grid template data', 'This hook allows to modify data which is about to be used in template for product without description grid', 1, 1),
(520, 'actionProductWithoutPriceGridPresenterModifier', 'Modify product without price grid template data', 'This hook allows to modify data which is about to be used in template for product without price grid', 1, 1),
(521, 'actionOrderGridPresenterModifier', 'Modify order grid template data', 'This hook allows to modify data which is about to be used in template for order grid', 1, 1),
(522, 'actionCatalogPriceRuleGridPresenterModifier', 'Modify catalog price rule grid template data', 'This hook allows to modify data which is about to be used in template for catalog price rule grid', 1, 1),
(523, 'actionOrderMessageGridPresenterModifier', 'Modify order message grid template data', 'This hook allows to modify data which is about to be used in template for order message grid', 1, 1),
(524, 'actionAttachmentGridPresenterModifier', 'Modify attachment grid template data', 'This hook allows to modify data which is about to be used in template for attachment grid', 1, 1),
(525, 'actionAttributeGroupGridPresenterModifier', 'Modify attribute group grid template data', 'This hook allows to modify data which is about to be used in template for attribute group grid', 1, 1),
(526, 'actionMerchandiseReturnGridPresenterModifier', 'Modify merchandise return grid template data', 'This hook allows to modify data which is about to be used in template for merchandise return grid', 1, 1),
(527, 'actionTaxRulesGroupGridPresenterModifier', 'Modify tax rules group grid template data', 'This hook allows to modify data which is about to be used in template for tax rules group grid', 1, 1),
(528, 'actionAddressGridPresenterModifier', 'Modify address grid template data', 'This hook allows to modify data which is about to be used in template for address grid', 1, 1),
(529, 'actionCreditSlipGridPresenterModifier', 'Modify credit slip grid template data', 'This hook allows to modify data which is about to be used in template for credit slip grid', 1, 1),
(530, 'displayAdditionalCustomerAddressFields', 'Display additional customer address fields', 'This hook allows to display extra field values added in an address form using hook \'additionalCustomerAddressFields\'', 1, 1),
(531, 'displayFooterCategory', 'Category footer', 'This hook adds new blocks under the products listing in a category/search', 1, 1),
(532, 'displayHeaderCategory', 'Category header', 'This hook adds new blocks above the products listing in a category/search', 1, 1),
(533, 'actionAdminAdministrationControllerPostProcessBefore', 'On post-process in Admin Configure Advanced Parameters Administration Controller', 'This hook is called on Admin Configure Advanced Parameters Administration post-process before processing any form', 1, 1),
(534, 'actionAdminAdministrationControllerPostProcessGeneralBefore', 'On post-process in Admin Configure Advanced Parameters Administration Controller', 'This hook is called on Admin Configure Advanced Parameters Administration post-process before processing the General form', 1, 1),
(535, 'actionAdminAdministrationControllerPostProcessUploadQuotaBefore', 'On post-process in Admin Configure Advanced Parameters Administration Controller', 'This hook is called on Admin Configure Advanced Parameters Administration post-process before processing the Upload Quota form', 1, 1),
(536, 'actionAdminAdministrationControllerPostProcessNotificationsBefore', 'On post-process in Admin Configure Advanced Parameters Administration Controller', 'This hook is called on Admin Configure Advanced Parameters Administration post-process before processing the Notifications form', 1, 1),
(537, 'actionAdminAdvancedParametersPerformanceControllerPostProcessSmartyBefore', 'On post-process in Admin Configure Advanced Parameters Performance Controller', 'This hook is called on Admin Configure Advanced Parameters Performance post-process before processing the Smarty form', 1, 1),
(538, 'actionAdminAdvancedParametersPerformanceControllerPostProcessDebugModeBefore', 'On post-process in Admin Configure Advanced Parameters Performance Controller', 'This hook is called on Admin Configure Advanced Parameters Performance post-process before processing the Debug Mode form', 1, 1),
(539, 'actionAdminAdvancedParametersPerformanceControllerPostProcessOptionalFeaturesBefore', 'On post-process in Admin Configure Advanced Parameters Performance Controller', 'This hook is called on Admin Configure Advanced Parameters Performance post-process before processing the Optional Features form', 1, 1),
(540, 'actionAdminAdvancedParametersPerformanceControllerPostProcessCombineCompressCacheBefore', 'On post-process in Admin Configure Advanced Parameters Performance Controller', 'This hook is called on Admin Configure Advanced Parameters Performance post-process before processing the Combine Compress Cache form', 1, 1),
(541, 'actionAdminAdvancedParametersPerformanceControllerPostProcessMediaServersBefore', 'On post-process in Admin Configure Advanced Parameters Performance Controller', 'This hook is called on Admin Configure Advanced Parameters Performance post-process before processing the Media Servers form', 1, 1),
(542, 'actionAdminAdvancedParametersPerformanceControllerPostProcessCachingBefore', 'On post-process in Admin Configure Advanced Parameters Performance Controller', 'This hook is called on Admin Configure Advanced Parameters Performance post-process before processing the Caching form', 1, 1),
(543, 'actionAdminAdvancedParametersPerformanceControllerPostProcessBefore', 'On post-process in Admin Configure Advanced Parameters Performance Controller', 'This hook is called on Admin Configure Advanced Parameters Performance post-process before processing any form', 1, 1),
(544, 'actionAdminShopParametersMetaControllerPostProcessSetUpUrlsBefore', 'On post-process in Admin Configure Shop Parameters Meta Controller', 'This hook is called on Admin Configure Shop Parameters Meta post-process before processing the SetUp Urls form', 1, 1),
(545, 'actionAdminShopParametersMetaControllerPostProcessShopUrlsBefore', 'On post-process in Admin Configure Shop Parameters Meta Controller', 'This hook is called on Admin Configure Shop Parameters Meta post-process before processing the Shop Urls form', 1, 1),
(546, 'actionAdminShopParametersMetaControllerPostProcessUrlSchemaBefore', 'On post-process in Admin Configure Shop Parameters Meta Controller', 'This hook is called on Admin Configure Shop Parameters Meta post-process before processing the Url Schema form', 1, 1),
(547, 'actionAdminShopParametersMetaControllerPostProcessSeoOptionsBefore', 'On post-process in Admin Configure Shop Parameters Meta Controller', 'This hook is called on Admin Configure Shop Parameters Meta post-process before processing the Seo Options form', 1, 1),
(548, 'actionAdminAdminShopParametersMetaControllerPostProcessBefore', 'On post-process in Admin Configure Shop Parameters Meta Controller', 'This hook is called on Admin Configure Shop Parameters Meta post-process before processing any form', 1, 1),
(549, 'actionAdminShopParametersOrderPreferencesControllerPostProcessGeneralBefore', 'On post-process in Admin Configure Shop Parameters Order Preferences Controller', 'This hook is called on Admin Configure Shop Parameters Order Preferences post-process before processing the General form', 1, 1),
(550, 'actionAdminShopParametersOrderPreferencesControllerPostProcessGiftOptionsBefore', 'On post-process in Admin Configure Shop Parameters Order Preferences Controller', 'This hook is called on Admin Configure Shop Parameters Order Preferences post-process before processing the Gift Options form', 1, 1),
(551, 'actionAdminShopParametersOrderPreferencesControllerPostProcessBefore', 'On post-process in Admin Configure Shop Parameters Order Preferences Controller', 'This hook is called on Admin Configure Shop Parameters Order Preferences post-process before processing any form', 1, 1),
(552, 'actionAdminInternationalGeolocationControllerPostProcessByIpAddressBefore', 'On post-process in Admin Improve International Geolocation Controller', 'This hook is called on Admin Improve International Geolocation post-process before processing the By Ip Address form', 1, 1),
(553, 'actionAdminInternationalGeolocationControllerPostProcessWhitelistBefore', 'On post-process in Admin Improve International Geolocation Controller', 'This hook is called on Admin Improve International Geolocation post-process before processing the Whitelist form', 1, 1),
(554, 'actionAdminInternationalGeolocationControllerPostProcessOptionsBefore', 'On post-process in Admin Improve International Geolocation Controller', 'This hook is called on Admin Improve International Geolocation post-process before processing the Options form', 1, 1),
(555, 'actionAdminInternationalGeolocationControllerPostProcessBefore', 'On post-process in Admin Improve International Geolocation Controller', 'This hook is called on Admin Improve International Geolocation post-process before processing any form', 1, 1),
(556, 'actionAdminInternationalLocalizationControllerPostProcessConfigurationBefore', 'On post-process in Admin Improve International Localization Controller', 'This hook is called on Admin Improve International Localization post-process before processing the Configuration form', 1, 1),
(557, 'actionAdminInternationalLocalizationControllerPostProcessLocalUnitsBefore', 'On post-process in Admin Improve International Localization Controller', 'This hook is called on Admin Improve International Localization post-process before processing the Local Units form', 1, 1),
(558, 'actionAdminInternationalLocalizationControllerPostProcessAdvancedBefore', 'On post-process in Admin Improve International Localization Controller', 'This hook is called on Admin Improve International Localization post-process before processing the Advanced form', 1, 1),
(559, 'actionAdminInternationalLocalizationControllerPostProcessBefore', 'On post-process in Admin Improve International Localization Controller', 'This hook is called on Admin Improve International Localization post-process before processing any form', 1, 1),
(560, 'actionAdminShippingPreferencesControllerPostProcessHandlingBefore', 'On post-process in Admin Improve Shipping Preferences Controller', 'This hook is called on Admin Improve Shipping Preferences post-process before processing the Handling form', 1, 1),
(561, 'actionAdminShippingPreferencesControllerPostProcessCarrierOptionsBefore', 'On post-process in Admin Improve Shipping Preferences Controller', 'This hook is called on Admin Improve Shipping Preferences post-process before processing the Carrier Options form', 1, 1),
(562, 'actionAdminShippingPreferencesControllerPostProcessBefore', 'On post-process in Admin Improve Shipping Preferences Controller', 'This hook is called on Admin Improve Shipping Preferences post-process before processing any form', 1, 1),
(563, 'actionCheckoutRender', 'Modify checkout process', 'This hook is called when constructing the checkout process', 1, 1),
(564, 'actionPresentProductListing', 'Product Listing Presenter', 'This hook is called before a product listing is presented', 1, 1),
(565, 'actionGetProductPropertiesAfterUnitPrice', 'Product Properties', 'This hook is called after defining the properties of a product', 1, 1),
(566, 'actionOverrideEmployeeImage', 'Get Employee Image', 'This hook is used to get the employee image', 1, 1),
(567, 'actionProductSearchProviderRunQueryBefore', 'Runs an action before ProductSearchProviderInterface::RunQuery()', 'Required to modify an SQL query before executing it', 1, 1),
(568, 'actionProductSearchProviderRunQueryAfter', 'Runs an action after ProductSearchProviderInterface::RunQuery()', 'Required to return a previous state of an SQL query or/and to change a result of the SQL query after executing it', 1, 1),
(569, 'actionFrontControllerSetVariables', 'Add variables in JavaScript object and Smarty templates', 'Add variables to javascript object that is available in Front Office. These are also available in smarty templates in modules.your_module_name.', 1, 1),
(570, 'displayAdminOrderCreateExtraButtons', 'Add buttons on the create order page dropdown', 'Add buttons on the create order page dropdown', 1, 1),
(573, 'actionProductFormBuilderModifier', 'Modify product identifiable object form', 'This hook allows to modify product identifiable object form content by modifying form builder data or FormBuilder itself', 1, 1),
(574, 'actionBeforeCreateProductFormHandler', 'Modify product identifiable object data before creating it', 'This hook allows to modify product identifiable object form data before it was created', 1, 1),
(576, 'actionBeforeUpdateProductFormHandler', 'Modify product identifiable object data before updating it', 'This hook allows to modify product identifiable object form data before it was updated', 1, 1),
(577, 'actionAfterUpdateProductFormHandler', 'Modify product identifiable object data after updating it', 'This hook allows to modify product identifiable object form data after it was updated', 1, 1),
(578, 'actionCustomerDiscountGridDefinitionModifier', 'Modify customer discount grid definition', 'This hook allows to alter customer discount grid columns, actions and filters', 1, 1),
(579, 'actionCustomerAddressGridDefinitionModifier', 'Modify customer address grid definition', 'This hook allows to alter customer address grid columns, actions and filters', 1, 1);
INSERT INTO `ps_hook` (`id_hook`, `name`, `title`, `description`, `active`, `position`) VALUES
(580, 'actionCartRuleGridDefinitionModifier', 'Modify cart rule grid definition', 'This hook allows to alter cart rule grid columns, actions and filters', 1, 1),
(581, 'actionOrderStatesGridDefinitionModifier', 'Modify order states grid definition', 'This hook allows to alter order states grid columns, actions and filters', 1, 1),
(582, 'actionOrderReturnStatesGridDefinitionModifier', 'Modify order return states grid definition', 'This hook allows to alter order return states grid columns, actions and filters', 1, 1),
(583, 'actionOutstandingGridDefinitionModifier', 'Modify outstanding grid definition', 'This hook allows to alter outstanding grid columns, actions and filters', 1, 1),
(584, 'actionCarrierGridDefinitionModifier', 'Modify carrier grid definition', 'This hook allows to alter carrier grid columns, actions and filters', 1, 1),
(585, 'actionZoneGridDefinitionModifier', 'Modify zone grid definition', 'This hook allows to alter zone grid columns, actions and filters', 1, 1),
(586, 'actionCustomerDiscountGridQueryBuilderModifier', 'Modify customer discount grid query builder', 'This hook allows to alter Doctrine query builder for customer discount grid', 1, 1),
(587, 'actionCustomerAddressGridQueryBuilderModifier', 'Modify customer address grid query builder', 'This hook allows to alter Doctrine query builder for customer address grid', 1, 1),
(588, 'actionCartRuleGridQueryBuilderModifier', 'Modify cart rule grid query builder', 'This hook allows to alter Doctrine query builder for cart rule grid', 1, 1),
(589, 'actionOrderStatesGridQueryBuilderModifier', 'Modify order states grid query builder', 'This hook allows to alter Doctrine query builder for order states grid', 1, 1),
(590, 'actionOrderReturnStatesGridQueryBuilderModifier', 'Modify order return states grid query builder', 'This hook allows to alter Doctrine query builder for order return states grid', 1, 1),
(591, 'actionOutstandingGridQueryBuilderModifier', 'Modify outstanding grid query builder', 'This hook allows to alter Doctrine query builder for outstanding grid', 1, 1),
(592, 'actionCarrierGridQueryBuilderModifier', 'Modify carrier grid query builder', 'This hook allows to alter Doctrine query builder for carrier grid', 1, 1),
(593, 'actionZoneGridQueryBuilderModifier', 'Modify zone grid query builder', 'This hook allows to alter Doctrine query builder for zone grid', 1, 1),
(594, 'actionCustomerDiscountGridDataModifier', 'Modify customer discount grid data', 'This hook allows to modify customer discount grid data', 1, 1),
(595, 'actionCustomerAddressGridDataModifier', 'Modify customer address grid data', 'This hook allows to modify customer address grid data', 1, 1),
(596, 'actionCartRuleGridDataModifier', 'Modify cart rule grid data', 'This hook allows to modify cart rule grid data', 1, 1),
(597, 'actionOrderStatesGridDataModifier', 'Modify order states grid data', 'This hook allows to modify order states grid data', 1, 1),
(598, 'actionOrderReturnStatesGridDataModifier', 'Modify order return states grid data', 'This hook allows to modify order return states grid data', 1, 1),
(599, 'actionOutstandingGridDataModifier', 'Modify outstanding grid data', 'This hook allows to modify outstanding grid data', 1, 1),
(600, 'actionCarrierGridDataModifier', 'Modify carrier grid data', 'This hook allows to modify carrier grid data', 1, 1),
(601, 'actionZoneGridDataModifier', 'Modify zone grid data', 'This hook allows to modify zone grid data', 1, 1),
(602, 'actionCustomerDiscountGridFilterFormModifier', 'Modify customer discount grid filters', 'This hook allows to modify filters for customer discount grid', 1, 1),
(603, 'actionCustomerAddressGridFilterFormModifier', 'Modify customer address grid filters', 'This hook allows to modify filters for customer address grid', 1, 1),
(604, 'actionCartRuleGridFilterFormModifier', 'Modify cart rule grid filters', 'This hook allows to modify filters for cart rule grid', 1, 1),
(605, 'actionOrderStatesGridFilterFormModifier', 'Modify order states grid filters', 'This hook allows to modify filters for order states grid', 1, 1),
(606, 'actionOrderReturnStatesGridFilterFormModifier', 'Modify order return states grid filters', 'This hook allows to modify filters for order return states grid', 1, 1),
(607, 'actionOutstandingGridFilterFormModifier', 'Modify outstanding grid filters', 'This hook allows to modify filters for outstanding grid', 1, 1),
(608, 'actionCarrierGridFilterFormModifier', 'Modify carrier grid filters', 'This hook allows to modify filters for carrier grid', 1, 1),
(609, 'actionZoneGridFilterFormModifier', 'Modify zone grid filters', 'This hook allows to modify filters for zone grid', 1, 1),
(610, 'actionCustomerDiscountGridPresenterModifier', 'Modify customer discount grid template data', 'This hook allows to modify data which is about to be used in template for customer discount grid\n      ', 1, 1),
(611, 'actionCustomerAddressGridPresenterModifier', 'Modify customer address grid template data', 'This hook allows to modify data which is about to be used in template for customer address grid\n      ', 1, 1),
(612, 'actionCartRuleGridPresenterModifier', 'Modify cart rule grid template data', 'This hook allows to modify data which is about to be used in template for cart rule grid\n      ', 1, 1),
(613, 'actionOrderStatesGridPresenterModifier', 'Modify order states grid template data', 'This hook allows to modify data which is about to be used in template for order states grid\n      ', 1, 1),
(614, 'actionOrderReturnStatesGridPresenterModifier', 'Modify order return states grid template data', 'This hook allows to modify data which is about to be used in template for order return states grid\n      ', 1, 1),
(615, 'actionOutstandingGridPresenterModifier', 'Modify outstanding grid template data', 'This hook allows to modify data which is about to be used in template for outstanding grid\n      ', 1, 1),
(616, 'actionCarrierGridPresenterModifier', 'Modify carrier grid template data', 'This hook allows to modify data which is about to be used in template for carrier grid', 1, 1),
(617, 'actionZoneGridPresenterModifier', 'Modify zone grid template data', 'This hook allows to modify data which is about to be used in template for zone grid', 1, 1),
(618, 'actionPerformancePageSmartyForm', 'Modify performance page smarty options form content', 'This hook allows to modify performance page smarty options form FormBuilder', 1, 1),
(619, 'actionPerformancePageDebugModeForm', 'Modify performance page debug mode options form content', 'This hook allows to modify performance page debug mode options form FormBuilder', 1, 1),
(620, 'actionPerformancePageOptionalFeaturesForm', 'Modify performance page optional features options form content', 'This hook allows to modify performance page optional features options form FormBuilder', 1, 1),
(621, 'actionPerformancePageCombineCompressCacheForm', 'Modify performance page combine compress cache options form content', 'This hook allows to modify performance page combine compress cache options form FormBuilder\n      ', 1, 1),
(622, 'actionPerformancePageMediaServersForm', 'Modify performance page media servers options form content', 'This hook allows to modify performance page media servers options form FormBuilder', 1, 1),
(623, 'actionPerformancePagecachingForm', 'Modify performance pagecaching options form content', 'This hook allows to modify performance pagecaching options form FormBuilder', 1, 1),
(624, 'actionAdministrationPageGeneralForm', 'Modify administration page general options form content', 'This hook allows to modify administration page general options form FormBuilder', 1, 1),
(625, 'actionAdministrationPageUploadQuotaForm', 'Modify administration page upload quota options form content', 'This hook allows to modify administration page upload quota options form FormBuilder', 1, 1),
(626, 'actionAdministrationPageNotificationsForm', 'Modify administration page notifications options form content', 'This hook allows to modify administration page notifications options form FormBuilder', 1, 1),
(627, 'actionShippingPreferencesPageHandlingForm', 'Modify shipping preferences page handling options form content', 'This hook allows to modify shipping preferences page handling options form FormBuilder', 1, 1),
(628, 'actionShippingPreferencesPageCarrierOptionsForm', 'Modify shipping preferences page carrier options options form content', 'This hook allows to modify shipping preferences page carrier options options form FormBuilder\n      ', 1, 1),
(629, 'actionOrderPreferencesPageGeneralForm', 'Modify order preferences page general options form content', 'This hook allows to modify order preferences page general options form FormBuilder', 1, 1),
(630, 'actionOrderPreferencesPageGiftOptionsForm', 'Modify order preferences page gift options options form content', 'This hook allows to modify order preferences page gift options options form FormBuilder', 1, 1),
(631, 'actionProductPreferencesPageGeneralForm', 'Modify product preferences page general options form content', 'This hook allows to modify product preferences page general options form FormBuilder', 1, 1),
(632, 'actionProductPreferencesPagePaginationForm', 'Modify product preferences page pagination options form content', 'This hook allows to modify product preferences page pagination options form FormBuilder', 1, 1),
(633, 'actionProductPreferencesPagePageForm', 'Modify product preferences page page options form content', 'This hook allows to modify product preferences page page options form FormBuilder', 1, 1),
(634, 'actionProductPreferencesPageStockForm', 'Modify product preferences page stock options form content', 'This hook allows to modify product preferences page stock options form FormBuilder', 1, 1),
(635, 'actionGeolocationPageByAddressForm', 'Modify geolocation page by address options form content', 'This hook allows to modify geolocation page by address options form FormBuilder', 1, 1),
(636, 'actionGeolocationPageWhitelistForm', 'Modify geolocation page whitelist options form content', 'This hook allows to modify geolocation page whitelist options form FormBuilder', 1, 1),
(637, 'actionGeolocationPageOptionsForm', 'Modify geolocation page options options form content', 'This hook allows to modify geolocation page options options form FormBuilder', 1, 1),
(638, 'actionLocalizationPageConfigurationForm', 'Modify localization page configuration options form content', 'This hook allows to modify localization page configuration options form FormBuilder', 1, 1),
(639, 'actionLocalizationPageLocalUnitsForm', 'Modify localization page local units options form content', 'This hook allows to modify localization page local units options form FormBuilder', 1, 1),
(640, 'actionLocalizationPageAdvancedForm', 'Modify localization page advanced options form content', 'This hook allows to modify localization page advanced options form FormBuilder', 1, 1),
(641, 'actionFeatureFlagForm', 'Modify feature flag page form content', 'This hook allows to modify the Feature Flag page form\'s FormBuilder', 1, 1),
(642, 'actionPerformancePageSmartySave', 'Modify performance page smarty options form saved data', 'This hook allows to modify data of performance page smarty options form after it was saved\n      ', 1, 1),
(643, 'actionPerformancePageDebugModeSave', 'Modify performance page debug mode options form saved data', 'This hook allows to modify data of performance page debug mode options form after it was saved\n      ', 1, 1),
(644, 'actionPerformancePageOptionalFeaturesSave', 'Modify performance page optional features options form saved data', 'This hook allows to modify data of performance page optional features options form after it was\n        saved\n      ', 1, 1),
(645, 'actionPerformancePageCombineCompressCacheSave', 'Modify performance page combine compress cache options form saved data', 'This hook allows to modify data of performance page combine compress cache options form after it was\n        saved\n      ', 1, 1),
(646, 'actionPerformancePageMediaServersSave', 'Modify performance page media servers options form saved data', 'This hook allows to modify data of performance page media servers options form after it was saved\n      ', 1, 1),
(647, 'actionPerformancePagecachingSave', 'Modify performance pagecaching options form saved data', 'This hook allows to modify data of performance pagecaching options form after it was saved\n      ', 1, 1),
(648, 'actionAdministrationPageGeneralSave', 'Modify administration page general options form saved data', 'This hook allows to modify data of administration page general options form after it was saved\n      ', 1, 1),
(649, 'actionAdministrationPageUploadQuotaSave', 'Modify administration page upload quota options form saved data', 'This hook allows to modify data of administration page upload quota options form after it was saved\n      ', 1, 1),
(650, 'actionAdministrationPageNotificationsSave', 'Modify administration page notifications options form saved data', 'This hook allows to modify data of administration page notifications options form after it was\n        saved\n      ', 1, 1),
(651, 'actionShippingPreferencesPageHandlingSave', 'Modify shipping preferences page handling options form saved data', 'This hook allows to modify data of shipping preferences page handling options form after it was\n        saved\n      ', 1, 1),
(652, 'actionShippingPreferencesPageCarrierOptionsSave', 'Modify shipping preferences page carrier options options form saved data', 'This hook allows to modify data of shipping preferences page carrier options options form after it\n        was saved\n      ', 1, 1),
(653, 'actionOrderPreferencesPageGeneralSave', 'Modify order preferences page general options form saved data', 'This hook allows to modify data of order preferences page general options form after it was saved\n      ', 1, 1),
(654, 'actionOrderPreferencesPageGiftOptionsSave', 'Modify order preferences page gift options options form saved data', 'This hook allows to modify data of order preferences page gift options options form after it was\n        saved\n      ', 1, 1),
(655, 'actionProductPreferencesPageGeneralSave', 'Modify product preferences page general options form saved data', 'This hook allows to modify data of product preferences page general options form after it was saved\n      ', 1, 1),
(656, 'actionProductPreferencesPagePaginationSave', 'Modify product preferences page pagination options form saved data', 'This hook allows to modify data of product preferences page pagination options form after it was\n        saved\n      ', 1, 1),
(657, 'actionProductPreferencesPagePageSave', 'Modify product preferences page page options form saved data', 'This hook allows to modify data of product preferences page page options form after it was saved\n      ', 1, 1),
(658, 'actionProductPreferencesPageStockSave', 'Modify product preferences page stock options form saved data', 'This hook allows to modify data of product preferences page stock options form after it was saved\n      ', 1, 1),
(659, 'actionGeolocationPageByAddressSave', 'Modify geolocation page by address options form saved data', 'This hook allows to modify data of geolocation page by address options form after it was saved\n      ', 1, 1),
(660, 'actionGeolocationPageWhitelistSave', 'Modify geolocation page whitelist options form saved data', 'This hook allows to modify data of geolocation page whitelist options form after it was saved\n      ', 1, 1),
(661, 'actionGeolocationPageOptionsSave', 'Modify geolocation page options options form saved data', 'This hook allows to modify data of geolocation page options options form after it was saved\n      ', 1, 1),
(662, 'actionLocalizationPageConfigurationSave', 'Modify localization page configuration options form saved data', 'This hook allows to modify data of localization page configuration options form after it was saved\n      ', 1, 1),
(663, 'actionLocalizationPageLocalUnitsSave', 'Modify localization page local units options form saved data', 'This hook allows to modify data of localization page local units options form after it was saved\n      ', 1, 1),
(664, 'actionLocalizationPageAdvancedSave', 'Modify localization page advanced options form saved data', 'This hook allows to modify data of localization page advanced options form after it was saved\n      ', 1, 1),
(665, 'actionFeatureFlagSave', 'Modify feature flag form submitted data', 'This hook allows to modify the Feature Flag data being submitted through the form after it was\n        saved\n      ', 1, 1),
(666, 'actionOrderStateFormBuilderModifier', 'Modify order state identifiable object form', 'This hook allows to modify order state identifiable object forms content by modifying form builder\n        data or FormBuilder itself\n      ', 1, 1),
(667, 'actionOrderReturnStateFormBuilderModifier', 'Modify order return state identifiable object form', 'This hook allows to modify order return state identifiable object forms content by modifying form\n        builder data or FormBuilder itself\n      ', 1, 1),
(668, 'actionZoneFormBuilderModifier', 'Modify zone identifiable object form', 'This hook allows to modify zone identifiable object forms content by modifying form builder data or\n        FormBuilder itself\n      ', 1, 1),
(669, 'actionBeforeUpdateOrderStateFormHandler', 'Modify order state identifiable object data before updating it', 'This hook allows to modify order state identifiable object forms data before it was updated\n      ', 1, 1),
(670, 'actionBeforeUpdateOrderReturnStateFormHandler', 'Modify order return state identifiable object data before updating it', 'This hook allows to modify order return state identifiable object forms data before it was updated\n      ', 1, 1),
(671, 'actionBeforeUpdateZoneFormHandler', 'Modify zone identifiable object data before updating it', 'This hook allows to modify zone identifiable object forms data before it was updated', 1, 1),
(672, 'actionAfterUpdateOrderStateFormHandler', 'Modify order state identifiable object data after updating it', 'This hook allows to modify order state identifiable object forms data after it was updated\n      ', 1, 1),
(673, 'actionAfterUpdateOrderReturnStateFormHandler', 'Modify order return state identifiable object data after updating it', 'This hook allows to modify order return state identifiable object forms data after it was updated\n      ', 1, 1),
(674, 'actionAfterUpdateProductImageFormHandler', 'Modify product image identifiable object data after updating it', 'This hook allows to modify product image identifiable object forms data after it was updated\n      ', 1, 1),
(675, 'actionAfterUpdateZoneFormHandler', 'Modify zone identifiable object data after updating it', 'This hook allows to modify zone identifiable object forms data after it was updated', 1, 1),
(676, 'actionBeforeCreateOrderStateFormHandler', 'Modify order state identifiable object data before creating it', 'This hook allows to modify order state identifiable object forms data before it was created\n      ', 1, 1),
(677, 'actionBeforeCreateOrderReturnStateFormHandler', 'Modify order return state identifiable object data before creating it', 'This hook allows to modify order return state identifiable object forms data before it was created\n      ', 1, 1),
(678, 'actionBeforeCreateZoneFormHandler', 'Modify zone identifiable object data before creating it', 'This hook allows to modify zone identifiable object forms data before it was created', 1, 1),
(679, 'actionAfterCreateOrderStateFormHandler', 'Modify order state identifiable object data after creating it', 'This hook allows to modify order state identifiable object forms data after it was created\n      ', 1, 1),
(680, 'actionAfterCreateOrderReturnStateFormHandler', 'Modify order return state identifiable object data after creating it', 'This hook allows to modify order return state identifiable object forms data after it was created\n      ', 1, 1),
(681, 'actionAfterCreateZoneFormHandler', 'Modify zone identifiable object data after creating it', 'This hook allows to modify zone identifiable object forms data after it was created', 1, 1),
(682, 'actionAdminControllerSetMedia', 'actionAdminControllerSetMedia', '', 1, 1),
(683, 'actionFrontControllerSetMedia', 'actionFrontControllerSetMedia', '', 1, 1),
(684, 'deleteProductAttribute', 'deleteProductAttribute', '', 1, 1),
(685, 'registerGDPRConsent', 'registerGDPRConsent', '', 1, 1),
(686, 'dashboardZoneOne', 'dashboardZoneOne', '', 1, 1),
(687, 'dashboardData', 'dashboardData', '', 1, 1),
(688, 'actionObjectOrderAddAfter', 'actionObjectOrderAddAfter', '', 1, 1),
(689, 'actionObjectCustomerAddAfter', 'actionObjectCustomerAddAfter', '', 1, 1),
(690, 'actionObjectCustomerMessageAddAfter', 'actionObjectCustomerMessageAddAfter', '', 1, 1),
(691, 'actionObjectCustomerThreadAddAfter', 'actionObjectCustomerThreadAddAfter', '', 1, 1),
(692, 'actionObjectOrderReturnAddAfter', 'actionObjectOrderReturnAddAfter', '', 1, 1),
(693, 'dashboardZoneTwo', 'dashboardZoneTwo', '', 1, 1),
(694, 'actionSearch', 'actionSearch', '', 1, 1),
(695, 'GraphEngine', 'GraphEngine', '', 1, 1),
(696, 'GridEngine', 'GridEngine', '', 1, 1),
(697, 'gSitemapAppendUrls', 'GSitemap Append URLs', 'This hook allows a module to add URLs to a generated sitemap', 1, 1),
(698, 'displayProductListReviews', 'displayProductListReviews', '', 1, 1),
(699, 'actionDeleteGDPRCustomer', 'actionDeleteGDPRCustomer', '', 1, 1),
(700, 'actionExportGDPRData', 'actionExportGDPRData', '', 1, 1),
(701, 'actionObjectLanguageAddAfter', 'actionObjectLanguageAddAfter', '', 1, 1),
(702, 'paymentOptions', 'paymentOptions', '', 1, 1),
(703, 'paymentReturn', 'paymentReturn', '', 1, 1),
(704, 'displayNav1', 'displayNav1', '', 1, 1),
(705, 'actionAdminStoresControllerUpdate_optionsAfter', 'actionAdminStoresControllerUpdate_optionsAfter', '', 1, 1),
(706, 'actionAdminCurrenciesControllerSaveAfter', 'actionAdminCurrenciesControllerSaveAfter', '', 1, 1),
(707, 'actionModuleRegisterHookAfter', 'actionModuleRegisterHookAfter', '', 1, 1),
(708, 'actionModuleUnRegisterHookAfter', 'actionModuleUnRegisterHookAfter', '', 1, 1),
(709, 'actionShopDataDuplication', 'actionShopDataDuplication', '', 1, 1),
(710, 'displayFooterBefore', 'displayFooterBefore', '', 1, 1),
(711, 'actionObjectCustomerUpdateBefore', 'actionObjectCustomerUpdateBefore', '', 1, 1),
(712, 'displayAdminCustomersForm', 'displayAdminCustomersForm', '', 1, 1),
(713, 'productSearchProvider', 'productSearchProvider', '', 1, 1),
(714, 'actionObjectSpecificPriceRuleUpdateBefore', 'actionObjectSpecificPriceRuleUpdateBefore', '', 1, 1),
(715, 'actionAdminSpecificPriceRuleControllerSaveAfter', 'actionAdminSpecificPriceRuleControllerSaveAfter', '', 1, 1),
(716, 'displayOrderConfirmation2', 'displayOrderConfirmation2', '', 1, 1),
(717, 'displayCrossSellingShoppingCart', 'displayCrossSellingShoppingCart', '', 1, 1),
(718, 'actionAdminGroupsControllerSaveAfter', 'actionAdminGroupsControllerSaveAfter', '', 1, 1),
(719, 'actionObjectCategoryUpdateAfter', 'actionObjectCategoryUpdateAfter', '', 1, 1),
(720, 'actionObjectCategoryDeleteAfter', 'actionObjectCategoryDeleteAfter', '', 1, 1),
(721, 'actionObjectCategoryAddAfter', 'actionObjectCategoryAddAfter', '', 1, 1),
(722, 'actionObjectCmsUpdateAfter', 'actionObjectCmsUpdateAfter', '', 1, 1),
(723, 'actionObjectCmsDeleteAfter', 'actionObjectCmsDeleteAfter', '', 1, 1),
(724, 'actionObjectCmsAddAfter', 'actionObjectCmsAddAfter', '', 1, 1),
(725, 'actionObjectSupplierUpdateAfter', 'actionObjectSupplierUpdateAfter', '', 1, 1),
(726, 'actionObjectSupplierDeleteAfter', 'actionObjectSupplierDeleteAfter', '', 1, 1),
(727, 'actionObjectSupplierAddAfter', 'actionObjectSupplierAddAfter', '', 1, 1),
(728, 'actionObjectManufacturerUpdateAfter', 'actionObjectManufacturerUpdateAfter', '', 1, 1),
(729, 'actionObjectManufacturerDeleteAfter', 'actionObjectManufacturerDeleteAfter', '', 1, 1),
(730, 'actionObjectManufacturerAddAfter', 'actionObjectManufacturerAddAfter', '', 1, 1),
(731, 'actionObjectProductUpdateAfter', 'actionObjectProductUpdateAfter', '', 1, 1),
(732, 'actionObjectProductDeleteAfter', 'actionObjectProductDeleteAfter', '', 1, 1),
(733, 'actionObjectProductAddAfter', 'actionObjectProductAddAfter', '', 1, 1),
(734, 'displaySearch', 'displaySearch', '', 1, 1),
(735, 'displayProductButtons', 'displayProductButtons', '', 1, 1),
(736, 'displayNav2', 'displayNav2', '', 1, 1),
(737, 'AdminStatsModules', 'AdminStatsModules', '', 1, 1),
(738, 'authentication', 'authentication', '', 1, 1),
(739, 'createAccount', 'createAccount', '', 1, 1),
(740, 'displayAdminNavBarBeforeEnd', 'displayAdminNavBarBeforeEnd', '', 1, 1),
(741, 'displayAdminAfterHeader', 'displayAdminAfterHeader', '', 1, 1),
(742, 'displayGDPRConsent', 'displayGDPRConsent', '', 1, 1),
(743, 'displayAdminOrderLeft', 'displayAdminOrderLeft', '', 1, 1),
(744, 'actionObjectShopAddAfter', 'actionObjectShopAddAfter', '', 1, 1),
(745, 'displayProductPriceBlock', 'displayProductPriceBlock', '', 1, 1),
(746, 'header', 'header', '', 1, 1),
(747, 'actionObjectOrderPaymentAddAfter', 'actionObjectOrderPaymentAddAfter', '', 1, 1),
(748, 'actionObjectOrderPaymentUpdateAfter', 'actionObjectOrderPaymentUpdateAfter', '', 1, 1),
(749, 'displayExpressCheckout', 'displayExpressCheckout', '', 1, 1),
(750, 'actionCartUpdateQuantityBefore', 'actionCartUpdateQuantityBefore', '', 1, 1),
(751, 'actionAjaxDieProductControllerDisplayAjaxQuickviewAfter', 'actionAjaxDieProductControllerDisplayAjaxQuickviewAfter', '', 1, 1),
(752, 'actionNewsletterRegistrationAfter', 'actionNewsletterRegistrationAfter', '', 1, 1),
(753, 'actionFacebookCallPixel', 'actionFacebookCallPixel', '', 1, 1),
(754, 'displayFooterAfter', 'displayFooterAfter', '', 1, 1),
(755, 'displayReassurance', 'displayReassurance', '', 1, 1),
(756, 'actionAdminMetaControllerUpdate_optionsAfter', 'actionAdminMetaControllerUpdate_optionsAfter', '', 1, 1),
(757, 'actionAdminPerformanceControllerSaveAfter', 'actionAdminPerformanceControllerSaveAfter', '', 1, 1),
(758, 'actionObjectCarrierAddAfter', 'actionObjectCarrierAddAfter', '', 1, 1),
(759, 'actionObjectContactAddAfter', 'actionObjectContactAddAfter', '', 1, 1),
(760, 'actionAdminThemesControllerUpdate_optionsAfter', 'actionAdminThemesControllerUpdate_optionsAfter', '', 1, 1),
(761, 'actionObjectShopUpdateAfter', 'actionObjectShopUpdateAfter', '', 1, 1),
(762, 'actionAdminPreferencesControllerUpdate_optionsAfter', 'actionAdminPreferencesControllerUpdate_optionsAfter', '', 1, 1),
(763, 'actionObjectShopGroupAddAfter', 'actionObjectShopGroupAddAfter', '', 1, 1),
(764, 'actionObjectCartAddAfter', 'actionObjectCartAddAfter', '', 1, 1),
(765, 'actionObjectEmployeeAddAfter', 'actionObjectEmployeeAddAfter', '', 1, 1),
(766, 'actionObjectImageAddAfter', 'actionObjectImageAddAfter', '', 1, 1),
(767, 'actionObjectCartRuleAddAfter', 'actionObjectCartRuleAddAfter', '', 1, 1),
(768, 'newOrder', 'newOrder', '', 1, 1),
(769, 'actionAdminStoresControllerSaveAfter', 'actionAdminStoresControllerSaveAfter', '', 1, 1),
(770, 'actionAdminWebserviceControllerSaveAfter', 'actionAdminWebserviceControllerSaveAfter', '', 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_hook_alias`
--

CREATE TABLE `ps_hook_alias` (
  `id_hook_alias` int(10) UNSIGNED NOT NULL,
  `alias` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_hook_alias`
--

INSERT INTO `ps_hook_alias` (`id_hook_alias`, `alias`, `name`) VALUES
(1, 'newOrder', 'actionValidateOrder'),
(2, 'paymentConfirm', 'actionPaymentConfirmation'),
(3, 'paymentReturn', 'displayPaymentReturn'),
(4, 'updateQuantity', 'actionUpdateQuantity'),
(5, 'rightColumn', 'displayRightColumn'),
(6, 'leftColumn', 'displayLeftColumn'),
(7, 'home', 'displayHome'),
(8, 'Header', 'displayHeader'),
(9, 'cart', 'actionCartSave'),
(10, 'authentication', 'actionAuthentication'),
(11, 'addproduct', 'actionProductAdd'),
(12, 'updateproduct', 'actionProductUpdate'),
(13, 'top', 'displayTop'),
(14, 'extraRight', 'displayRightColumnProduct'),
(15, 'deleteproduct', 'actionProductDelete'),
(16, 'productfooter', 'displayFooterProduct'),
(17, 'invoice', 'displayInvoice'),
(18, 'updateOrderStatus', 'actionOrderStatusUpdate'),
(19, 'adminOrder', 'displayAdminOrder'),
(20, 'footer', 'displayFooter'),
(21, 'PDFInvoice', 'displayPDFInvoice'),
(22, 'adminCustomers', 'displayAdminCustomers'),
(23, 'orderConfirmation', 'displayOrderConfirmation'),
(24, 'createAccount', 'actionCustomerAccountAdd'),
(25, 'customerAccount', 'displayCustomerAccount'),
(26, 'orderSlip', 'actionOrderSlipAdd'),
(27, 'shoppingCart', 'displayShoppingCartFooter'),
(28, 'createAccountForm', 'displayCustomerAccountForm'),
(29, 'AdminStatsModules', 'displayAdminStatsModules'),
(30, 'GraphEngine', 'displayAdminStatsGraphEngine'),
(31, 'orderReturn', 'actionOrderReturn'),
(32, 'productActions', 'displayProductAdditionalInfo'),
(33, 'displayProductButtons', 'displayProductAdditionalInfo'),
(34, 'backOfficeHome', 'displayBackOfficeHome'),
(35, 'GridEngine', 'displayAdminStatsGridEngine'),
(36, 'watermark', 'actionWatermark'),
(37, 'cancelProduct', 'actionProductCancel'),
(38, 'extraLeft', 'displayLeftColumnProduct'),
(39, 'productOutOfStock', 'actionProductOutOfStock'),
(40, 'updateProductAttribute', 'actionProductAttributeUpdate'),
(41, 'extraCarrier', 'displayCarrierList'),
(42, 'shoppingCartExtra', 'displayShoppingCart'),
(43, 'updateCarrier', 'actionCarrierUpdate'),
(44, 'postUpdateOrderStatus', 'actionOrderStatusPostUpdate'),
(45, 'createAccountTop', 'displayCustomerAccountFormTop'),
(46, 'backOfficeHeader', 'displayBackOfficeHeader'),
(47, 'backOfficeTop', 'displayBackOfficeTop'),
(48, 'backOfficeFooter', 'displayBackOfficeFooter'),
(49, 'deleteProductAttribute', 'actionProductAttributeDelete'),
(50, 'processCarrier', 'actionCarrierProcess'),
(51, 'beforeCarrier', 'displayBeforeCarrier'),
(52, 'orderDetailDisplayed', 'displayOrderDetail'),
(53, 'paymentCCAdded', 'actionPaymentCCAdd'),
(54, 'categoryAddition', 'actionCategoryAdd'),
(55, 'categoryUpdate', 'actionCategoryUpdate'),
(56, 'categoryDeletion', 'actionCategoryDelete'),
(57, 'paymentTop', 'displayPaymentTop'),
(58, 'afterCreateHtaccess', 'actionHtaccessCreate'),
(59, 'afterSaveAdminMeta', 'actionAdminMetaSave'),
(60, 'attributeGroupForm', 'displayAttributeGroupForm'),
(61, 'afterSaveAttributeGroup', 'actionAttributeGroupSave'),
(62, 'afterDeleteAttributeGroup', 'actionAttributeGroupDelete'),
(63, 'featureForm', 'displayFeatureForm'),
(64, 'afterSaveFeature', 'actionFeatureSave'),
(65, 'afterDeleteFeature', 'actionFeatureDelete'),
(66, 'afterSaveProduct', 'actionProductSave'),
(67, 'postProcessAttributeGroup', 'displayAttributeGroupPostProcess'),
(68, 'postProcessFeature', 'displayFeaturePostProcess'),
(69, 'featureValueForm', 'displayFeatureValueForm'),
(70, 'postProcessFeatureValue', 'displayFeatureValuePostProcess'),
(71, 'afterDeleteFeatureValue', 'actionFeatureValueDelete'),
(72, 'afterSaveFeatureValue', 'actionFeatureValueSave'),
(73, 'attributeForm', 'displayAttributeForm'),
(74, 'postProcessAttribute', 'actionAttributePostProcess'),
(75, 'afterDeleteAttribute', 'actionAttributeDelete'),
(76, 'afterSaveAttribute', 'actionAttributeSave'),
(77, 'taxManager', 'actionTaxManager'),
(78, 'myAccountBlock', 'displayMyAccountBlock'),
(79, 'actionBeforeCartUpdateQty', 'actionCartUpdateQuantityBefore'),
(80, 'actionBeforeAjaxDie', 'actionAjaxDieBefore'),
(81, 'actionBeforeAuthentication', 'actionAuthenticationBefore'),
(82, 'actionBeforeSubmitAccount', 'actionSubmitAccountBefore'),
(83, 'actionAfterDeleteProductInCart', 'actionDeleteProductInCartAfter'),
(84, 'displayInvoice', 'displayAdminOrderTop'),
(85, 'displayBackOfficeOrderActions', 'displayAdminOrderSide'),
(86, 'actionFrontControllerAfterInit', 'actionFrontControllerInitAfter'),
(87, 'displayAdminListBefore', 'displayAdminGridTableBefore'),
(88, 'displayAdminListAfter', 'displayAdminGridTableAfter');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_hook_module`
--

CREATE TABLE `ps_hook_module` (
  `id_module` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_hook` int(10) UNSIGNED NOT NULL,
  `position` tinyint(2) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_hook_module`
--

INSERT INTO `ps_hook_module` (`id_module`, `id_shop`, `id_hook`, `position`) VALUES
(60, 1, 693, 0),
(1, 1, 28, 1),
(1, 1, 44, 1),
(1, 1, 49, 1),
(1, 1, 75, 1),
(1, 1, 102, 1),
(1, 1, 105, 1),
(1, 1, 207, 1),
(1, 1, 682, 1),
(1, 1, 683, 1),
(1, 1, 684, 1),
(2, 1, 685, 1),
(3, 1, 687, 1),
(3, 1, 688, 1),
(3, 1, 689, 1),
(3, 1, 690, 1),
(3, 1, 691, 1),
(3, 1, 692, 1),
(4, 1, 69, 1),
(4, 1, 693, 1),
(6, 1, 694, 1),
(7, 1, 695, 1),
(8, 1, 696, 1),
(10, 1, 55, 1),
(11, 1, 16, 1),
(11, 1, 31, 1),
(11, 1, 135, 1),
(11, 1, 698, 1),
(11, 1, 699, 1),
(11, 1, 700, 1),
(12, 1, 701, 1),
(13, 1, 14, 1),
(15, 1, 704, 1),
(15, 1, 705, 1),
(17, 1, 706, 1),
(18, 1, 707, 1),
(18, 1, 708, 1),
(20, 1, 709, 1),
(21, 1, 122, 1),
(22, 1, 47, 1),
(22, 1, 48, 1),
(22, 1, 711, 1),
(24, 1, 71, 1),
(25, 1, 19, 1),
(25, 1, 20, 1),
(25, 1, 82, 1),
(25, 1, 716, 1),
(25, 1, 717, 1),
(25, 1, 718, 1),
(26, 1, 15, 1),
(27, 1, 736, 1),
(28, 1, 41, 1),
(28, 1, 141, 1),
(29, 1, 25, 1),
(29, 1, 719, 1),
(29, 1, 720, 1),
(29, 1, 721, 1),
(29, 1, 722, 1),
(29, 1, 723, 1),
(29, 1, 724, 1),
(29, 1, 725, 1),
(29, 1, 726, 1),
(29, 1, 727, 1),
(29, 1, 728, 1),
(29, 1, 729, 1),
(29, 1, 730, 1),
(29, 1, 731, 1),
(29, 1, 732, 1),
(29, 1, 733, 1),
(30, 1, 734, 1),
(31, 1, 58, 1),
(35, 1, 7, 1),
(37, 1, 737, 1),
(44, 1, 24, 1),
(44, 1, 738, 1),
(44, 1, 739, 1),
(53, 1, 740, 1),
(53, 1, 741, 1),
(54, 1, 33, 1),
(54, 1, 107, 1),
(54, 1, 756, 1),
(54, 1, 757, 1),
(54, 1, 758, 1),
(54, 1, 759, 1),
(54, 1, 760, 1),
(54, 1, 761, 1),
(54, 1, 762, 1),
(54, 1, 763, 1),
(54, 1, 764, 1),
(54, 1, 765, 1),
(54, 1, 766, 1),
(54, 1, 767, 1),
(54, 1, 768, 1),
(54, 1, 769, 1),
(54, 1, 770, 1),
(55, 1, 686, 1),
(56, 1, 742, 1),
(57, 1, 140, 1),
(59, 1, 30, 1),
(59, 1, 43, 1),
(59, 1, 46, 1),
(59, 1, 84, 1),
(59, 1, 121, 1),
(59, 1, 208, 1),
(59, 1, 417, 1),
(59, 1, 702, 1),
(59, 1, 743, 1),
(59, 1, 744, 1),
(59, 1, 745, 1),
(59, 1, 746, 1),
(59, 1, 747, 1),
(59, 1, 748, 1),
(59, 1, 749, 1),
(59, 1, 750, 1),
(61, 1, 17, 1),
(61, 1, 751, 1),
(61, 1, 752, 1),
(61, 1, 753, 1),
(63, 1, 22, 1),
(63, 1, 26, 1),
(63, 1, 710, 1),
(63, 1, 754, 1),
(63, 1, 755, 1),
(64, 1, 81, 1),
(64, 1, 83, 1),
(64, 1, 87, 1),
(64, 1, 88, 1),
(64, 1, 89, 1),
(64, 1, 90, 1),
(64, 1, 91, 1),
(64, 1, 92, 1),
(64, 1, 93, 1),
(64, 1, 94, 1),
(64, 1, 95, 1),
(64, 1, 96, 1),
(64, 1, 97, 1),
(64, 1, 98, 1),
(64, 1, 99, 1),
(64, 1, 100, 1),
(64, 1, 101, 1),
(64, 1, 103, 1),
(64, 1, 426, 1),
(64, 1, 434, 1),
(64, 1, 442, 1),
(64, 1, 658, 1),
(64, 1, 713, 1),
(64, 1, 714, 1),
(64, 1, 715, 1),
(65, 1, 36, 1),
(65, 1, 62, 1),
(65, 1, 76, 1),
(3, 1, 682, 2),
(3, 1, 686, 2),
(4, 1, 687, 2),
(5, 1, 693, 2),
(6, 1, 688, 2),
(11, 1, 685, 2),
(16, 1, 31, 2),
(16, 1, 69, 2),
(17, 1, 736, 2),
(18, 1, 41, 2),
(22, 1, 122, 2),
(22, 1, 683, 2),
(22, 1, 699, 2),
(22, 1, 700, 2),
(22, 1, 710, 2),
(25, 1, 15, 2),
(25, 1, 28, 2),
(26, 1, 16, 2),
(26, 1, 709, 2),
(29, 1, 82, 2),
(30, 1, 25, 2),
(35, 1, 702, 2),
(36, 1, 55, 2),
(39, 1, 737, 2),
(51, 1, 694, 2),
(53, 1, 71, 2),
(54, 1, 689, 2),
(54, 1, 691, 2),
(54, 1, 705, 2),
(54, 1, 724, 2),
(54, 1, 733, 2),
(54, 1, 741, 2),
(54, 1, 744, 2),
(56, 1, 47, 2),
(61, 1, 46, 2),
(61, 1, 690, 2),
(62, 1, 750, 2),
(64, 1, 14, 2),
(65, 1, 17, 2),
(4, 1, 682, 3),
(5, 1, 687, 3),
(6, 1, 693, 3),
(12, 1, 15, 3),
(15, 1, 41, 3),
(19, 1, 736, 3),
(22, 1, 685, 3),
(29, 1, 709, 3),
(30, 1, 16, 3),
(33, 1, 710, 3),
(38, 1, 55, 3),
(42, 1, 737, 3),
(54, 1, 71, 3),
(54, 1, 688, 3),
(56, 1, 122, 3),
(59, 1, 31, 3),
(59, 1, 683, 3),
(59, 1, 741, 3),
(61, 1, 47, 3),
(61, 1, 694, 3),
(62, 1, 46, 3),
(64, 1, 82, 3),
(65, 1, 69, 3),
(66, 1, 702, 3),
(1, 1, 41, 4),
(5, 1, 682, 4),
(6, 1, 687, 4),
(20, 1, 15, 4),
(32, 1, 16, 4),
(32, 1, 736, 4),
(40, 1, 55, 4),
(52, 1, 737, 4),
(60, 1, 741, 4),
(61, 1, 71, 4),
(61, 1, 683, 4),
(65, 1, 31, 4),
(65, 1, 46, 4),
(7, 1, 682, 5),
(41, 1, 55, 5),
(61, 1, 16, 5),
(62, 1, 71, 5),
(63, 1, 683, 5),
(65, 1, 15, 5),
(65, 1, 41, 5),
(66, 1, 46, 5),
(43, 1, 55, 6),
(54, 1, 682, 6),
(62, 1, 16, 6),
(65, 1, 71, 6),
(45, 1, 55, 7),
(56, 1, 682, 7),
(65, 1, 16, 7),
(46, 1, 55, 8),
(57, 1, 682, 8),
(47, 1, 55, 9),
(59, 1, 682, 9),
(48, 1, 55, 10),
(60, 1, 682, 10),
(49, 1, 55, 11),
(50, 1, 55, 12),
(51, 1, 55, 13);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_hook_module_exceptions`
--

CREATE TABLE `ps_hook_module_exceptions` (
  `id_hook_module_exceptions` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_module` int(10) UNSIGNED NOT NULL,
  `id_hook` int(10) UNSIGNED NOT NULL,
  `file_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_image`
--

CREATE TABLE `ps_image` (
  `id_image` int(10) UNSIGNED NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `position` smallint(2) UNSIGNED NOT NULL DEFAULT 0,
  `cover` tinyint(1) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_image`
--

INSERT INTO `ps_image` (`id_image`, `id_product`, `position`, `cover`) VALUES
(29, 25, 1, 1),
(30, 26, 1, 1),
(31, 27, 1, 1),
(32, 28, 1, 1),
(33, 29, 1, 1),
(34, 30, 1, 1),
(35, 31, 1, 1),
(36, 32, 1, 1),
(37, 33, 1, 1),
(38, 34, 1, 1),
(39, 35, 1, 1),
(40, 36, 1, 1),
(41, 37, 1, 1),
(42, 38, 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_image_lang`
--

CREATE TABLE `ps_image_lang` (
  `id_image` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `legend` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_image_lang`
--

INSERT INTO `ps_image_lang` (`id_image`, `id_lang`, `legend`) VALUES
(29, 1, ''),
(30, 1, ''),
(31, 1, ''),
(32, 1, ''),
(33, 1, ''),
(34, 1, ''),
(35, 1, ''),
(36, 1, ''),
(37, 1, ''),
(38, 1, ''),
(39, 1, ''),
(40, 1, ''),
(41, 1, ''),
(42, 1, '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_image_shop`
--

CREATE TABLE `ps_image_shop` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_image` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL,
  `cover` tinyint(1) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_image_shop`
--

INSERT INTO `ps_image_shop` (`id_product`, `id_image`, `id_shop`, `cover`) VALUES
(25, 29, 1, 1),
(26, 30, 1, 1),
(27, 31, 1, 1),
(28, 32, 1, 1),
(29, 33, 1, 1),
(30, 34, 1, 1),
(31, 35, 1, 1),
(32, 36, 1, 1),
(33, 37, 1, 1),
(34, 38, 1, 1),
(35, 39, 1, 1),
(36, 40, 1, 1),
(37, 41, 1, 1),
(38, 42, 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_image_type`
--

CREATE TABLE `ps_image_type` (
  `id_image_type` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL,
  `width` int(10) UNSIGNED NOT NULL,
  `height` int(10) UNSIGNED NOT NULL,
  `products` tinyint(1) NOT NULL DEFAULT 1,
  `categories` tinyint(1) NOT NULL DEFAULT 1,
  `manufacturers` tinyint(1) NOT NULL DEFAULT 1,
  `suppliers` tinyint(1) NOT NULL DEFAULT 1,
  `stores` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_image_type`
--

INSERT INTO `ps_image_type` (`id_image_type`, `name`, `width`, `height`, `products`, `categories`, `manufacturers`, `suppliers`, `stores`) VALUES
(1, 'cart_default', 125, 125, 1, 0, 0, 0, 0),
(2, 'small_default', 98, 98, 1, 1, 1, 1, 0),
(3, 'medium_default', 452, 452, 1, 0, 1, 1, 0),
(4, 'home_default', 250, 250, 1, 0, 0, 0, 0),
(5, 'large_default', 800, 800, 1, 0, 1, 1, 0),
(6, 'category_default', 141, 180, 0, 1, 0, 0, 0),
(7, 'stores_default', 170, 115, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_import_match`
--

CREATE TABLE `ps_import_match` (
  `id_import_match` int(10) NOT NULL,
  `name` varchar(32) NOT NULL,
  `match` text NOT NULL,
  `skip` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_info`
--

CREATE TABLE `ps_info` (
  `id_info` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_info`
--

INSERT INTO `ps_info` (`id_info`) VALUES
(1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_info_lang`
--

CREATE TABLE `ps_info_lang` (
  `id_info` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_info_lang`
--

INSERT INTO `ps_info_lang` (`id_info`, `id_shop`, `id_lang`, `text`) VALUES
(1, 1, 1, '<h2>Custom Text Block</h2>\n<p><strong class=\"dark\">Lorem ipsum dolor sit amet conse ctetu</strong></p>\n<p>Sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit.</p>');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_info_shop`
--

CREATE TABLE `ps_info_shop` (
  `id_info` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_info_shop`
--

INSERT INTO `ps_info_shop` (`id_info`, `id_shop`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_lang`
--

CREATE TABLE `ps_lang` (
  `id_lang` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `iso_code` varchar(2) NOT NULL,
  `language_code` varchar(5) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `date_format_lite` varchar(32) NOT NULL,
  `date_format_full` varchar(32) NOT NULL,
  `is_rtl` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_lang`
--

INSERT INTO `ps_lang` (`id_lang`, `name`, `active`, `iso_code`, `language_code`, `locale`, `date_format_lite`, `date_format_full`, `is_rtl`) VALUES
(1, 'Polski (Polish)', 1, 'pl', 'pl', 'pl-PL', 'Y-m-d', 'Y-m-d H:i:s', 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_lang_shop`
--

CREATE TABLE `ps_lang_shop` (
  `id_lang` int(11) NOT NULL,
  `id_shop` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_lang_shop`
--

INSERT INTO `ps_lang_shop` (`id_lang`, `id_shop`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_category`
--

CREATE TABLE `ps_layered_category` (
  `id_layered_category` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL,
  `id_category` int(10) UNSIGNED NOT NULL,
  `id_value` int(10) UNSIGNED DEFAULT 0,
  `type` enum('category','id_feature','id_attribute_group','quantity','condition','manufacturer','weight','price') NOT NULL,
  `position` int(10) UNSIGNED NOT NULL,
  `filter_type` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `filter_show_limit` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_layered_category`
--

INSERT INTO `ps_layered_category` (`id_layered_category`, `id_shop`, `id_category`, `id_value`, `type`, `position`, `filter_type`, `filter_show_limit`) VALUES
(1, 1, 2, NULL, 'category', 1, 0, 0),
(2, 1, 2, 1, 'id_attribute_group', 2, 0, 0),
(3, 1, 2, 2, 'id_attribute_group', 3, 0, 0),
(4, 1, 2, 1, 'id_feature', 4, 0, 0),
(5, 1, 2, 2, 'id_feature', 5, 0, 0),
(6, 1, 2, NULL, 'quantity', 6, 0, 0),
(7, 1, 2, NULL, 'manufacturer', 7, 0, 0),
(8, 1, 2, NULL, 'condition', 8, 0, 0),
(9, 1, 2, NULL, 'weight', 9, 0, 0),
(10, 1, 2, NULL, 'price', 10, 0, 0),
(11, 1, 2, 3, 'id_attribute_group', 11, 0, 0),
(12, 1, 2, 4, 'id_attribute_group', 12, 0, 0),
(13, 1, 4, NULL, 'category', 1, 0, 0),
(14, 1, 4, 1, 'id_attribute_group', 2, 0, 0),
(15, 1, 4, 2, 'id_attribute_group', 3, 0, 0),
(16, 1, 4, 1, 'id_feature', 4, 0, 0),
(17, 1, 4, 2, 'id_feature', 5, 0, 0),
(18, 1, 4, NULL, 'quantity', 6, 0, 0),
(19, 1, 4, NULL, 'manufacturer', 7, 0, 0),
(20, 1, 4, NULL, 'condition', 8, 0, 0),
(21, 1, 4, NULL, 'weight', 9, 0, 0),
(22, 1, 4, NULL, 'price', 10, 0, 0),
(23, 1, 4, 3, 'id_attribute_group', 11, 0, 0),
(24, 1, 4, 4, 'id_attribute_group', 12, 0, 0),
(25, 1, 5, NULL, 'category', 1, 0, 0),
(26, 1, 5, 1, 'id_attribute_group', 2, 0, 0),
(27, 1, 5, 2, 'id_attribute_group', 3, 0, 0),
(28, 1, 5, 1, 'id_feature', 4, 0, 0),
(29, 1, 5, 2, 'id_feature', 5, 0, 0),
(30, 1, 5, NULL, 'quantity', 6, 0, 0),
(31, 1, 5, NULL, 'manufacturer', 7, 0, 0),
(32, 1, 5, NULL, 'condition', 8, 0, 0),
(33, 1, 5, NULL, 'weight', 9, 0, 0),
(34, 1, 5, NULL, 'price', 10, 0, 0),
(35, 1, 5, 3, 'id_attribute_group', 11, 0, 0),
(36, 1, 5, 4, 'id_attribute_group', 12, 0, 0),
(37, 1, 8, NULL, 'category', 1, 0, 0),
(38, 1, 8, 1, 'id_attribute_group', 2, 0, 0),
(39, 1, 8, 2, 'id_attribute_group', 3, 0, 0),
(40, 1, 8, 1, 'id_feature', 4, 0, 0),
(41, 1, 8, 2, 'id_feature', 5, 0, 0),
(42, 1, 8, NULL, 'quantity', 6, 0, 0),
(43, 1, 8, NULL, 'manufacturer', 7, 0, 0),
(44, 1, 8, NULL, 'condition', 8, 0, 0),
(45, 1, 8, NULL, 'weight', 9, 0, 0),
(46, 1, 8, NULL, 'price', 10, 0, 0),
(47, 1, 8, 3, 'id_attribute_group', 11, 0, 0),
(48, 1, 8, 4, 'id_attribute_group', 12, 0, 0),
(49, 1, 7, NULL, 'category', 1, 0, 0),
(50, 1, 7, 1, 'id_attribute_group', 2, 0, 0),
(51, 1, 7, 2, 'id_attribute_group', 3, 0, 0),
(52, 1, 7, 1, 'id_feature', 4, 0, 0),
(53, 1, 7, 2, 'id_feature', 5, 0, 0),
(54, 1, 7, NULL, 'quantity', 6, 0, 0),
(55, 1, 7, NULL, 'manufacturer', 7, 0, 0),
(56, 1, 7, NULL, 'condition', 8, 0, 0),
(57, 1, 7, NULL, 'weight', 9, 0, 0),
(58, 1, 7, NULL, 'price', 10, 0, 0),
(59, 1, 7, 3, 'id_attribute_group', 11, 0, 0),
(60, 1, 7, 4, 'id_attribute_group', 12, 0, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_filter`
--

CREATE TABLE `ps_layered_filter` (
  `id_layered_filter` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL,
  `filters` longtext DEFAULT NULL,
  `n_categories` int(10) UNSIGNED NOT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_layered_filter`
--

INSERT INTO `ps_layered_filter` (`id_layered_filter`, `name`, `filters`, `n_categories`, `date_add`) VALUES
(1, 'Mój szablon 2022-12-08', 'a:14:{s:10:\"categories\";a:5:{i:0;i:2;i:2;i:4;i:3;i:5;i:6;i:8;i:7;i:7;}s:9:\"shop_list\";a:1:{i:1;i:1;}s:31:\"layered_selection_subcategories\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}s:22:\"layered_selection_ag_1\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}s:22:\"layered_selection_ag_2\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}s:24:\"layered_selection_feat_1\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}s:24:\"layered_selection_feat_2\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}s:23:\"layered_selection_stock\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}s:30:\"layered_selection_manufacturer\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}s:27:\"layered_selection_condition\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}s:31:\"layered_selection_weight_slider\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}s:30:\"layered_selection_price_slider\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}s:22:\"layered_selection_ag_3\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}s:22:\"layered_selection_ag_4\";a:2:{s:11:\"filter_type\";i:0;s:17:\"filter_show_limit\";i:0;}}', 8, '2022-12-08 16:57:59');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_filter_block`
--

CREATE TABLE `ps_layered_filter_block` (
  `hash` char(32) NOT NULL DEFAULT '',
  `data` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_filter_shop`
--

CREATE TABLE `ps_layered_filter_shop` (
  `id_layered_filter` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_layered_filter_shop`
--

INSERT INTO `ps_layered_filter_shop` (`id_layered_filter`, `id_shop`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_indexable_attribute_group`
--

CREATE TABLE `ps_layered_indexable_attribute_group` (
  `id_attribute_group` int(11) NOT NULL,
  `indexable` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_layered_indexable_attribute_group`
--

INSERT INTO `ps_layered_indexable_attribute_group` (`id_attribute_group`, `indexable`) VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_indexable_attribute_group_lang_value`
--

CREATE TABLE `ps_layered_indexable_attribute_group_lang_value` (
  `id_attribute_group` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `url_name` varchar(128) DEFAULT NULL,
  `meta_title` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_indexable_attribute_lang_value`
--

CREATE TABLE `ps_layered_indexable_attribute_lang_value` (
  `id_attribute` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `url_name` varchar(128) DEFAULT NULL,
  `meta_title` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_indexable_feature`
--

CREATE TABLE `ps_layered_indexable_feature` (
  `id_feature` int(11) NOT NULL,
  `indexable` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_indexable_feature_lang_value`
--

CREATE TABLE `ps_layered_indexable_feature_lang_value` (
  `id_feature` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `url_name` varchar(128) NOT NULL,
  `meta_title` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_indexable_feature_value_lang_value`
--

CREATE TABLE `ps_layered_indexable_feature_value_lang_value` (
  `id_feature_value` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `url_name` varchar(128) DEFAULT NULL,
  `meta_title` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_price_index`
--

CREATE TABLE `ps_layered_price_index` (
  `id_product` int(11) NOT NULL,
  `id_currency` int(11) NOT NULL,
  `id_shop` int(11) NOT NULL,
  `price_min` decimal(20,6) NOT NULL,
  `price_max` decimal(20,6) NOT NULL,
  `id_country` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_layered_price_index`
--

INSERT INTO `ps_layered_price_index` (`id_product`, `id_currency`, `id_shop`, `price_min`, `price_max`, `id_country`) VALUES
(1, 1, 1, '23.517600', '29.397000', 14),
(2, 1, 1, '35.325600', '44.157000', 14),
(3, 1, 1, '35.670000', '35.670000', 14),
(4, 1, 1, '35.670000', '35.670000', 14),
(5, 1, 1, '35.670000', '35.670000', 14),
(6, 1, 1, '14.637000', '14.637000', 14),
(7, 1, 1, '14.637000', '14.637000', 14),
(8, 1, 1, '14.637000', '14.637000', 14),
(9, 1, 1, '23.247000', '23.247000', 14),
(10, 1, 1, '23.247000', '23.247000', 14),
(11, 1, 1, '23.247000', '23.247000', 14),
(12, 1, 1, '11.070000', '11.070000', 14),
(13, 1, 1, '11.070000', '11.070000', 14),
(14, 1, 1, '11.070000', '11.070000', 14),
(15, 1, 1, '43.050000', '43.050000', 14),
(16, 1, 1, '15.867000', '15.867000', 14),
(17, 1, 1, '15.867000', '15.867000', 14),
(18, 1, 1, '15.867000', '15.867000', 14),
(19, 1, 1, '17.097000', '17.097000', 14),
(20, 1, 1, '549.994500', '549.994500', 14),
(21, 1, 1, '549.994500', '549.994500', 14),
(22, 1, 1, '54998.994900', '54998.994900', 14),
(23, 1, 1, '54998.994900', '54998.994900', 14),
(24, 1, 1, '549.994500', '549.994500', 14),
(25, 1, 1, '549.994500', '549.994500', 14),
(26, 1, 1, '49.987200', '49.987200', 14),
(27, 1, 1, '49.987200', '49.987200', 14),
(28, 1, 1, '49.987200', '49.987200', 14),
(29, 1, 1, '209.985600', '209.985600', 14),
(30, 1, 1, '49.987200', '49.987200', 14),
(31, 1, 1, '49.987200', '49.987200', 14),
(32, 1, 1, '49.987200', '49.987200', 14),
(33, 1, 1, '49.987200', '49.987200', 14),
(34, 1, 1, '69.987000', '69.987000', 14),
(35, 1, 1, '49.987200', '49.987200', 14),
(36, 1, 1, '49.987200', '49.987200', 14),
(37, 1, 1, '49.987200', '49.987200', 14),
(38, 1, 1, '59.987100', '59.987100', 14);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_layered_product_attribute`
--

CREATE TABLE `ps_layered_product_attribute` (
  `id_attribute` int(10) UNSIGNED NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_attribute_group` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_shop` int(10) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_layered_product_attribute`
--

INSERT INTO `ps_layered_product_attribute` (`id_attribute`, `id_product`, `id_attribute_group`, `id_shop`) VALUES
(1, 1, 1, 1),
(1, 2, 1, 1),
(2, 1, 1, 1),
(2, 2, 1, 1),
(3, 1, 1, 1),
(3, 2, 1, 1),
(4, 1, 1, 1),
(4, 2, 1, 1),
(8, 1, 2, 1),
(8, 9, 2, 1),
(8, 10, 2, 1),
(8, 11, 2, 1),
(11, 1, 2, 1),
(11, 9, 2, 1),
(11, 10, 2, 1),
(11, 11, 2, 1),
(19, 3, 3, 1),
(19, 4, 3, 1),
(19, 5, 3, 1),
(20, 3, 3, 1),
(20, 4, 3, 1),
(20, 5, 3, 1),
(21, 3, 3, 1),
(21, 4, 3, 1),
(21, 5, 3, 1),
(22, 16, 4, 1),
(22, 17, 4, 1),
(22, 18, 4, 1),
(23, 16, 4, 1),
(23, 17, 4, 1),
(23, 18, 4, 1),
(24, 16, 4, 1),
(24, 17, 4, 1),
(24, 18, 4, 1),
(25, 16, 4, 1),
(25, 17, 4, 1),
(25, 18, 4, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_linksmenutop`
--

CREATE TABLE `ps_linksmenutop` (
  `id_linksmenutop` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL,
  `new_window` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_linksmenutop_lang`
--

CREATE TABLE `ps_linksmenutop_lang` (
  `id_linksmenutop` int(11) UNSIGNED NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL,
  `label` varchar(128) NOT NULL,
  `link` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_link_block`
--

CREATE TABLE `ps_link_block` (
  `id_link_block` int(10) UNSIGNED NOT NULL,
  `id_hook` int(1) UNSIGNED DEFAULT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `content` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_link_block`
--

INSERT INTO `ps_link_block` (`id_link_block`, `id_hook`, `position`, `content`) VALUES
(1, 41, 0, '{\"cms\":[false],\"product\":[\"prices-drop\",\"new-products\",\"best-sales\"],\"static\":[false]}'),
(2, 41, 1, '{\"cms\":[\"1\",\"2\",\"3\",\"4\",\"5\"],\"product\":[false],\"static\":[\"contact\",\"sitemap\",\"stores\"]}');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_link_block_lang`
--

CREATE TABLE `ps_link_block_lang` (
  `id_link_block` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(40) NOT NULL DEFAULT '',
  `custom_content` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_link_block_lang`
--

INSERT INTO `ps_link_block_lang` (`id_link_block`, `id_lang`, `name`, `custom_content`) VALUES
(1, 1, 'Produkty', NULL),
(2, 1, 'Nasza firma', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_link_block_shop`
--

CREATE TABLE `ps_link_block_shop` (
  `id_link_block` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL,
  `position` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_link_block_shop`
--

INSERT INTO `ps_link_block_shop` (`id_link_block`, `id_shop`, `position`) VALUES
(1, 1, 0),
(2, 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_log`
--

CREATE TABLE `ps_log` (
  `id_log` int(10) UNSIGNED NOT NULL,
  `severity` tinyint(1) NOT NULL,
  `error_code` int(11) DEFAULT NULL,
  `message` text NOT NULL,
  `object_type` varchar(32) DEFAULT NULL,
  `object_id` int(10) UNSIGNED DEFAULT NULL,
  `id_shop` int(10) UNSIGNED DEFAULT NULL,
  `id_shop_group` int(10) UNSIGNED DEFAULT NULL,
  `id_lang` int(10) UNSIGNED DEFAULT NULL,
  `in_all_shops` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `id_employee` int(10) UNSIGNED DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_log`
--

INSERT INTO `ps_log` (`id_log`, `severity`, `error_code`, `message`, `object_type`, `object_id`, `id_shop`, `id_shop_group`, `id_lang`, `in_all_shops`, `id_employee`, `date_add`, `date_upd`) VALUES
(1, 1, 0, 'Exporting mail with theme modern for language Polski (Polish)', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:24', '2022-12-08 17:56:24'),
(2, 1, 0, 'Core output folder: /var/www/html/mails', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:24', '2022-12-08 17:56:24'),
(3, 1, 0, 'Modules output folder: /var/www/html/modules/', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:24', '2022-12-08 17:56:24'),
(4, 1, 0, 'Generate html template account at /var/www/html/mails/pl/account.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(5, 1, 0, 'Generate txt template account at /var/www/html/mails/pl/account.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(6, 1, 0, 'Generate html template backoffice_order at /var/www/html/mails/pl/backoffice_order.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(7, 1, 0, 'Generate txt template backoffice_order at /var/www/html/mails/pl/backoffice_order.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(8, 1, 0, 'Generate html template bankwire at /var/www/html/mails/pl/bankwire.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(9, 1, 0, 'Generate txt template bankwire at /var/www/html/mails/pl/bankwire.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(10, 1, 0, 'Generate html template cheque at /var/www/html/mails/pl/cheque.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(11, 1, 0, 'Generate txt template cheque at /var/www/html/mails/pl/cheque.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(12, 1, 0, 'Generate html template contact at /var/www/html/mails/pl/contact.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(13, 1, 0, 'Generate txt template contact at /var/www/html/mails/pl/contact.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(14, 1, 0, 'Generate html template contact_form at /var/www/html/mails/pl/contact_form.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(15, 1, 0, 'Generate txt template contact_form at /var/www/html/mails/pl/contact_form.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:25', '2022-12-08 17:56:25'),
(16, 1, 0, 'Generate html template credit_slip at /var/www/html/mails/pl/credit_slip.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(17, 1, 0, 'Generate txt template credit_slip at /var/www/html/mails/pl/credit_slip.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(18, 1, 0, 'Generate html template download_product at /var/www/html/mails/pl/download_product.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(19, 1, 0, 'Generate txt template download_product at /var/www/html/mails/pl/download_product.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(20, 1, 0, 'Generate html template employee_password at /var/www/html/mails/pl/employee_password.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(21, 1, 0, 'Generate txt template employee_password at /var/www/html/mails/pl/employee_password.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(22, 1, 0, 'Generate html template forward_msg at /var/www/html/mails/pl/forward_msg.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(23, 1, 0, 'Generate txt template forward_msg at /var/www/html/mails/pl/forward_msg.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(24, 1, 0, 'Generate html template guest_to_customer at /var/www/html/mails/pl/guest_to_customer.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(25, 1, 0, 'Generate txt template guest_to_customer at /var/www/html/mails/pl/guest_to_customer.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(26, 1, 0, 'Generate html template import at /var/www/html/mails/pl/import.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(27, 1, 0, 'Generate txt template import at /var/www/html/mails/pl/import.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(28, 1, 0, 'Generate html template in_transit at /var/www/html/mails/pl/in_transit.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(29, 1, 0, 'Generate txt template in_transit at /var/www/html/mails/pl/in_transit.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(30, 1, 0, 'Generate html template log_alert at /var/www/html/mails/pl/log_alert.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(31, 1, 0, 'Generate txt template log_alert at /var/www/html/mails/pl/log_alert.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(32, 1, 0, 'Generate html template newsletter at /var/www/html/mails/pl/newsletter.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(33, 1, 0, 'Generate txt template newsletter at /var/www/html/mails/pl/newsletter.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(34, 1, 0, 'Generate html template order_canceled at /var/www/html/mails/pl/order_canceled.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(35, 1, 0, 'Generate txt template order_canceled at /var/www/html/mails/pl/order_canceled.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(36, 1, 0, 'Generate html template order_changed at /var/www/html/mails/pl/order_changed.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(37, 1, 0, 'Generate txt template order_changed at /var/www/html/mails/pl/order_changed.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(38, 1, 0, 'Generate html template order_conf at /var/www/html/mails/pl/order_conf.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(39, 1, 0, 'Generate txt template order_conf at /var/www/html/mails/pl/order_conf.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(40, 1, 0, 'Generate html template order_customer_comment at /var/www/html/mails/pl/order_customer_comment.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(41, 1, 0, 'Generate txt template order_customer_comment at /var/www/html/mails/pl/order_customer_comment.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(42, 1, 0, 'Generate html template order_merchant_comment at /var/www/html/mails/pl/order_merchant_comment.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(43, 1, 0, 'Generate txt template order_merchant_comment at /var/www/html/mails/pl/order_merchant_comment.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(44, 1, 0, 'Generate html template order_return_state at /var/www/html/mails/pl/order_return_state.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(45, 1, 0, 'Generate txt template order_return_state at /var/www/html/mails/pl/order_return_state.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(46, 1, 0, 'Generate html template outofstock at /var/www/html/mails/pl/outofstock.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(47, 1, 0, 'Generate txt template outofstock at /var/www/html/mails/pl/outofstock.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(48, 1, 0, 'Generate html template password at /var/www/html/mails/pl/password.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(49, 1, 0, 'Generate txt template password at /var/www/html/mails/pl/password.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(50, 1, 0, 'Generate html template password_query at /var/www/html/mails/pl/password_query.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(51, 1, 0, 'Generate txt template password_query at /var/www/html/mails/pl/password_query.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(52, 1, 0, 'Generate html template payment at /var/www/html/mails/pl/payment.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(53, 1, 0, 'Generate txt template payment at /var/www/html/mails/pl/payment.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(54, 1, 0, 'Generate html template payment_error at /var/www/html/mails/pl/payment_error.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(55, 1, 0, 'Generate txt template payment_error at /var/www/html/mails/pl/payment_error.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(56, 1, 0, 'Generate html template preparation at /var/www/html/mails/pl/preparation.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(57, 1, 0, 'Generate txt template preparation at /var/www/html/mails/pl/preparation.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(58, 1, 0, 'Generate html template productoutofstock at /var/www/html/mails/pl/productoutofstock.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(59, 1, 0, 'Generate txt template productoutofstock at /var/www/html/mails/pl/productoutofstock.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(60, 1, 0, 'Generate html template refund at /var/www/html/mails/pl/refund.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(61, 1, 0, 'Generate txt template refund at /var/www/html/mails/pl/refund.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(62, 1, 0, 'Generate html template reply_msg at /var/www/html/mails/pl/reply_msg.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(63, 1, 0, 'Generate txt template reply_msg at /var/www/html/mails/pl/reply_msg.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(64, 1, 0, 'Generate html template shipped at /var/www/html/mails/pl/shipped.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(65, 1, 0, 'Generate txt template shipped at /var/www/html/mails/pl/shipped.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(66, 1, 0, 'Generate html template test at /var/www/html/mails/pl/test.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(67, 1, 0, 'Generate txt template test at /var/www/html/mails/pl/test.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(68, 1, 0, 'Generate html template voucher at /var/www/html/mails/pl/voucher.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(69, 1, 0, 'Generate txt template voucher at /var/www/html/mails/pl/voucher.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(70, 1, 0, 'Generate html template voucher_new at /var/www/html/mails/pl/voucher_new.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(71, 1, 0, 'Generate txt template voucher_new at /var/www/html/mails/pl/voucher_new.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(72, 1, 0, 'Generate html template followup_1 at /var/www/html/modules//followup/mails/pl/followup_1.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(73, 1, 0, 'Generate txt template followup_1 at /var/www/html/modules//followup/mails/pl/followup_1.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(74, 1, 0, 'Generate html template followup_2 at /var/www/html/modules//followup/mails/pl/followup_2.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(75, 1, 0, 'Generate txt template followup_2 at /var/www/html/modules//followup/mails/pl/followup_2.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(76, 1, 0, 'Generate html template followup_3 at /var/www/html/modules//followup/mails/pl/followup_3.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(77, 1, 0, 'Generate txt template followup_3 at /var/www/html/modules//followup/mails/pl/followup_3.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(78, 1, 0, 'Generate html template followup_4 at /var/www/html/modules//followup/mails/pl/followup_4.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(79, 1, 0, 'Generate txt template followup_4 at /var/www/html/modules//followup/mails/pl/followup_4.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(80, 1, 0, 'Generate html template followup_1 at /var/www/html/modules//ps_reminder/mails/pl/followup_1.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(81, 1, 0, 'Generate txt template followup_1 at /var/www/html/modules//ps_reminder/mails/pl/followup_1.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(82, 1, 0, 'Generate html template followup_2 at /var/www/html/modules//ps_reminder/mails/pl/followup_2.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(83, 1, 0, 'Generate txt template followup_2 at /var/www/html/modules//ps_reminder/mails/pl/followup_2.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(84, 1, 0, 'Generate html template followup_3 at /var/www/html/modules//ps_reminder/mails/pl/followup_3.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(85, 1, 0, 'Generate txt template followup_3 at /var/www/html/modules//ps_reminder/mails/pl/followup_3.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(86, 1, 0, 'Generate html template followup_4 at /var/www/html/modules//ps_reminder/mails/pl/followup_4.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(87, 1, 0, 'Generate txt template followup_4 at /var/www/html/modules//ps_reminder/mails/pl/followup_4.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(88, 1, 0, 'Generate html template customer_qty at /var/www/html/modules//ps_emailalerts/mails/pl/customer_qty.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(89, 1, 0, 'Generate txt template customer_qty at /var/www/html/modules//ps_emailalerts/mails/pl/customer_qty.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(90, 1, 0, 'Generate html template new_order at /var/www/html/modules//ps_emailalerts/mails/pl/new_order.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(91, 1, 0, 'Generate txt template new_order at /var/www/html/modules//ps_emailalerts/mails/pl/new_order.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(92, 1, 0, 'Generate html template order_changed at /var/www/html/modules//ps_emailalerts/mails/pl/order_changed.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(93, 1, 0, 'Generate txt template order_changed at /var/www/html/modules//ps_emailalerts/mails/pl/order_changed.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:26', '2022-12-08 17:56:26'),
(94, 1, 0, 'Generate html template productcoverage at /var/www/html/modules//ps_emailalerts/mails/pl/productcoverage.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(95, 1, 0, 'Generate txt template productcoverage at /var/www/html/modules//ps_emailalerts/mails/pl/productcoverage.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(96, 1, 0, 'Generate html template productoutofstock at /var/www/html/modules//ps_emailalerts/mails/pl/productoutofstock.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(97, 1, 0, 'Generate txt template productoutofstock at /var/www/html/modules//ps_emailalerts/mails/pl/productoutofstock.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(98, 1, 0, 'Generate html template return_slip at /var/www/html/modules//ps_emailalerts/mails/pl/return_slip.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(99, 1, 0, 'Generate txt template return_slip at /var/www/html/modules//ps_emailalerts/mails/pl/return_slip.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(100, 1, 0, 'Generate html template newsletter_conf at /var/www/html/modules//ps_emailsubscription/mails/pl/newsletter_conf.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(101, 1, 0, 'Generate txt template newsletter_conf at /var/www/html/modules//ps_emailsubscription/mails/pl/newsletter_conf.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(102, 1, 0, 'Generate html template newsletter_verif at /var/www/html/modules//ps_emailsubscription/mails/pl/newsletter_verif.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(103, 1, 0, 'Generate txt template newsletter_verif at /var/www/html/modules//ps_emailsubscription/mails/pl/newsletter_verif.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(104, 1, 0, 'Generate html template newsletter_voucher at /var/www/html/modules//ps_emailsubscription/mails/pl/newsletter_voucher.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(105, 1, 0, 'Generate txt template newsletter_voucher at /var/www/html/modules//ps_emailsubscription/mails/pl/newsletter_voucher.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(106, 1, 0, 'Generate html template referralprogram-congratulations at /var/www/html/modules//referralprogram/mails/pl/referralprogram-congratulations.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(107, 1, 0, 'Generate txt template referralprogram-congratulations at /var/www/html/modules//referralprogram/mails/pl/referralprogram-congratulations.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(108, 1, 0, 'Generate html template referralprogram-invitation at /var/www/html/modules//referralprogram/mails/pl/referralprogram-invitation.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(109, 1, 0, 'Generate txt template referralprogram-invitation at /var/www/html/modules//referralprogram/mails/pl/referralprogram-invitation.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(110, 1, 0, 'Generate html template referralprogram-voucher at /var/www/html/modules//referralprogram/mails/pl/referralprogram-voucher.html', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(111, 1, 0, 'Generate txt template referralprogram-voucher at /var/www/html/modules//referralprogram/mails/pl/referralprogram-voucher.txt', '', 0, NULL, NULL, 0, 0, 0, '2022-12-08 17:56:27', '2022-12-08 17:56:27'),
(112, 1, 0, 'Protect vendor folder in module blockwishlist', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(113, 1, 0, 'Module blockwishlist has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(114, 1, 0, 'Protect vendor folder in module contactform', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(115, 1, 0, 'Module contactform has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(116, 1, 0, 'Protect vendor folder in module dashactivity', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(117, 1, 0, 'Module dashactivity has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(118, 1, 0, 'Protect vendor folder in module dashtrends', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(119, 1, 0, 'Module dashtrends has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:34', '2022-12-08 17:56:34'),
(120, 1, 0, 'Protect vendor folder in module dashgoals', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(121, 1, 0, 'Module dashgoals has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(122, 1, 0, 'Protect vendor folder in module dashproducts', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(123, 1, 0, 'Module dashproducts has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(124, 1, 0, 'Protect vendor folder in module graphnvd3', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(125, 1, 0, 'Module graphnvd3 has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(126, 1, 0, 'Protect vendor folder in module gridhtml', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(127, 1, 0, 'Module gridhtml has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(128, 1, 0, 'Protect vendor folder in module gsitemap', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(129, 1, 0, 'Module gsitemap has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(130, 1, 0, 'Protect vendor folder in module pagesnotfound', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(131, 1, 0, 'Module pagesnotfound has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:35', '2022-12-08 17:56:35'),
(132, 1, 0, 'Protect vendor folder in module productcomments', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(133, 1, 0, 'Module productcomments has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(134, 1, 0, 'Protect vendor folder in module ps_banner', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(135, 1, 0, 'Module ps_banner has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(136, 1, 0, 'Protect vendor folder in module ps_categorytree', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(137, 1, 0, 'Module ps_categorytree has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(138, 1, 0, 'Protect vendor folder in module ps_checkpayment', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(139, 1, 0, 'Module ps_checkpayment has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(140, 1, 0, 'Protect vendor folder in module ps_contactinfo', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(141, 1, 0, 'Module ps_contactinfo has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(142, 1, 0, 'Protect vendor folder in module ps_crossselling', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(143, 1, 0, 'Module ps_crossselling has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:36', '2022-12-08 17:56:36'),
(144, 1, 0, 'Protect vendor folder in module ps_currencyselector', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(145, 1, 0, 'Module ps_currencyselector has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(146, 1, 0, 'Protect vendor folder in module ps_customeraccountlinks', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(147, 1, 0, 'Module ps_customeraccountlinks has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(148, 1, 0, 'Protect vendor folder in module ps_customersignin', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(149, 1, 0, 'Module ps_customersignin has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(150, 1, 0, 'Protect vendor folder in module ps_customtext', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(151, 1, 0, 'Module ps_customtext has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(152, 1, 0, 'Protect vendor folder in module ps_dataprivacy', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(153, 1, 0, 'Module ps_dataprivacy has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(154, 1, 0, 'Protect vendor folder in module ps_emailsubscription', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(155, 1, 0, 'Module ps_emailsubscription has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:37', '2022-12-08 17:56:37'),
(156, 1, 0, 'Protect vendor folder in module ps_facetedsearch', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:38', '2022-12-08 17:56:38'),
(157, 1, 0, 'Module ps_facetedsearch has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:38', '2022-12-08 17:56:38'),
(158, 1, 0, 'Protect vendor folder in module ps_faviconnotificationbo', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(159, 1, 0, 'Module ps_faviconnotificationbo has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(160, 1, 0, 'Protect vendor folder in module ps_featuredproducts', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(161, 1, 0, 'Module ps_featuredproducts has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(162, 1, 0, 'Protect vendor folder in module ps_imageslider', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(163, 1, 0, 'Module ps_imageslider has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(164, 1, 0, 'Protect vendor folder in module ps_languageselector', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(165, 1, 0, 'Module ps_languageselector has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(166, 1, 0, 'Protect vendor folder in module ps_linklist', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(167, 1, 0, 'Module ps_linklist has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:39', '2022-12-08 17:56:39'),
(168, 1, 0, 'Protect vendor folder in module ps_mainmenu', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(169, 1, 0, 'Module ps_mainmenu has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(170, 1, 0, 'Protect vendor folder in module ps_searchbar', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(171, 1, 0, 'Module ps_searchbar has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(172, 1, 0, 'Protect vendor folder in module ps_sharebuttons', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(173, 1, 0, 'Module ps_sharebuttons has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(174, 1, 0, 'Protect vendor folder in module ps_shoppingcart', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(175, 1, 0, 'Module ps_shoppingcart has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(176, 1, 0, 'Protect vendor folder in module ps_socialfollow', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(177, 1, 0, 'Module ps_socialfollow has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:40', '2022-12-08 17:56:40'),
(178, 1, 0, 'Protect vendor folder in module ps_themecusto', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(179, 1, 0, 'Module ps_themecusto has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(180, 1, 0, 'Protect vendor folder in module ps_wirepayment', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(181, 1, 0, 'Module ps_wirepayment has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(182, 1, 0, 'Protect vendor folder in module statsbestcategories', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(183, 1, 0, 'Module statsbestcategories has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(184, 1, 0, 'Protect vendor folder in module statsbestcustomers', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(185, 1, 0, 'Module statsbestcustomers has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(186, 1, 0, 'Protect vendor folder in module statsbestproducts', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(187, 1, 0, 'Module statsbestproducts has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(188, 1, 0, 'Protect vendor folder in module statsbestsuppliers', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(189, 1, 0, 'Module statsbestsuppliers has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(190, 1, 0, 'Protect vendor folder in module statsbestvouchers', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(191, 1, 0, 'Module statsbestvouchers has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(192, 1, 0, 'Protect vendor folder in module statscarrier', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(193, 1, 0, 'Module statscarrier has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:41', '2022-12-08 17:56:41'),
(194, 1, 0, 'Protect vendor folder in module statscatalog', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(195, 1, 0, 'Module statscatalog has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(196, 1, 0, 'Protect vendor folder in module statscheckup', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(197, 1, 0, 'Module statscheckup has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(198, 1, 0, 'Protect vendor folder in module statsdata', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(199, 1, 0, 'Module statsdata has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(200, 1, 0, 'Protect vendor folder in module statsforecast', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(201, 1, 0, 'Module statsforecast has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(202, 1, 0, 'Protect vendor folder in module statsnewsletter', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(203, 1, 0, 'Module statsnewsletter has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(204, 1, 0, 'Protect vendor folder in module statspersonalinfos', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(205, 1, 0, 'Module statspersonalinfos has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(206, 1, 0, 'Protect vendor folder in module statsproduct', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(207, 1, 0, 'Module statsproduct has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(208, 1, 0, 'Protect vendor folder in module statsregistrations', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(209, 1, 0, 'Module statsregistrations has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(210, 1, 0, 'Protect vendor folder in module statssales', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(211, 1, 0, 'Module statssales has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(212, 1, 0, 'Protect vendor folder in module statssearch', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(213, 1, 0, 'Module statssearch has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:42', '2022-12-08 17:56:42'),
(214, 1, 0, 'Protect vendor folder in module statsstock', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:43', '2022-12-08 17:56:43'),
(215, 1, 0, 'Module statsstock has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:43', '2022-12-08 17:56:43'),
(216, 1, 0, 'Protect vendor folder in module welcome', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:43', '2022-12-08 17:56:43'),
(217, 1, 0, 'Module welcome has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:56:43', '2022-12-08 17:56:43'),
(218, 1, 0, 'Protect vendor folder in module gamification', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:57:24', '2022-12-08 17:57:24'),
(219, 1, 0, 'Protect vendor folder in module psaddonsconnect', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:57:24', '2022-12-08 17:57:24'),
(220, 1, 0, 'Protect vendor folder in module psgdpr', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(221, 1, 0, 'Protect vendor folder in module ps_mbo', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(222, 1, 0, 'Protect vendor folder in module ps_buybuttonlite', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:57:25', '2022-12-08 17:57:25'),
(223, 1, 0, 'Protect vendor folder in module ps_checkout', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:57:26', '2022-12-08 17:57:26'),
(224, 1, 0, 'Protect vendor folder in module ps_metrics', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(225, 1, 0, 'Protect vendor folder in module ps_facebook', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:57:28', '2022-12-08 17:57:28'),
(226, 1, 0, 'Protect vendor folder in module psxmarketingwithgoogle', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:57:30', '2022-12-08 17:57:30'),
(227, 1, 0, 'Protect vendor folder in module blockreassurance', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:57:38', '2022-12-08 17:57:38'),
(228, 1, 0, 'Module blockreassurance has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:57:38', '2022-12-08 17:57:38'),
(229, 1, 0, 'Protect vendor folder in module ps_facetedsearch', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:58:00', '2022-12-08 17:58:00'),
(230, 1, 0, 'Module ps_facetedsearch has no vendor folder', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 17:58:00', '2022-12-08 17:58:00'),
(231, 1, 0, 'Połączenie z panelem administracyjnym z 172.19.0.1', '', 0, NULL, NULL, 1, 1, 1, '2022-12-08 18:28:21', '2022-12-08 18:28:21'),
(232, 1, 0, 'Połączenie z panelem administracyjnym z 172.19.0.1', '', 0, NULL, NULL, 1, 1, 1, '2022-12-08 18:42:55', '2022-12-08 18:42:55'),
(233, 1, 0, 'Protect vendor folder in module ps_googleanalytics', '', 0, 1, NULL, 1, 0, 1, '2022-12-08 18:44:29', '2022-12-08 18:44:29'),
(234, 1, 0, 'Połączenie z panelem administracyjnym z 192.168.48.1', '', 0, NULL, NULL, 1, 1, 1, '2022-12-09 16:15:42', '2022-12-09 16:15:42'),
(235, 1, 0, 'Połączenie z panelem administracyjnym z 172.19.0.1', '', 0, NULL, NULL, 1, 1, 1, '2022-12-11 22:08:59', '2022-12-11 22:08:59'),
(236, 1, 0, 'Frontcontroller::init - Cart cannot be loaded or an order has already been placed using this cart', 'Cart', 6, 1, NULL, 1, 0, 0, '2022-12-11 22:13:02', '2022-12-11 22:13:02'),
(237, 1, 0, 'Protect vendor folder in module ps_cashondelivery', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:15:27', '2022-12-11 22:15:27'),
(238, 3, 0, 'No result was found for query although at least one row was expected.', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:18:25', '2022-12-11 22:18:25'),
(239, 3, 0, 'No result was found for query although at least one row was expected.', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:18:25', '2022-12-11 22:18:25'),
(240, 3, 0, 'No result was found for query although at least one row was expected.', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:18:25', '2022-12-11 22:18:25'),
(241, 3, 0, 'No result was found for query although at least one row was expected.', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:18:25', '2022-12-11 22:18:25'),
(242, 3, 0, 'No result was found for query although at least one row was expected.', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:18:50', '2022-12-11 22:18:50'),
(243, 3, 0, 'No result was found for query although at least one row was expected.', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:19:24', '2022-12-11 22:19:24'),
(244, 3, 0, 'No result was found for query although at least one row was expected.', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:19:24', '2022-12-11 22:19:24'),
(245, 1, 0, 'Klucz API został stworzony: VLNJ6H7Y4LURQUY2CUFH6M1NBFLKIMRH', 'WebserviceKey', 1, 1, NULL, 1, 0, 1, '2022-12-11 22:46:23', '2022-12-11 22:46:23'),
(246, 1, 0, 'Products deleted: (24).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:15', '2022-12-11 22:53:15'),
(247, 1, 0, 'Products deleted: (23).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:15', '2022-12-11 22:53:15'),
(248, 1, 0, 'Products deleted: (22).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:15', '2022-12-11 22:53:15'),
(249, 1, 0, 'Products deleted: (21).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:15', '2022-12-11 22:53:15'),
(250, 1, 0, 'Products deleted: (20).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:15', '2022-12-11 22:53:15'),
(251, 1, 0, 'Products deleted: (19).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:15', '2022-12-11 22:53:15'),
(252, 1, 0, 'Products deleted: (18).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:16', '2022-12-11 22:53:16'),
(253, 1, 0, 'Products deleted: (17).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:16', '2022-12-11 22:53:16'),
(254, 1, 0, 'Products deleted: (16).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:16', '2022-12-11 22:53:16'),
(255, 1, 0, 'Products deleted: (15).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:16', '2022-12-11 22:53:16'),
(256, 1, 0, 'Products deleted: (14).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:16', '2022-12-11 22:53:16'),
(257, 1, 0, 'Products deleted: (13).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:16', '2022-12-11 22:53:16'),
(258, 1, 0, 'Products deleted: (12).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:17', '2022-12-11 22:53:17'),
(259, 1, 0, 'Products deleted: (11).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:17', '2022-12-11 22:53:17'),
(260, 1, 0, 'Products deleted: (10).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:17', '2022-12-11 22:53:17'),
(261, 1, 0, 'Products deleted: (9).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:17', '2022-12-11 22:53:17'),
(262, 1, 0, 'Products deleted: (8).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:17', '2022-12-11 22:53:17'),
(263, 1, 0, 'Products deleted: (7).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:17', '2022-12-11 22:53:17'),
(264, 1, 0, 'Products deleted: (6).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:18', '2022-12-11 22:53:18'),
(265, 1, 0, 'Products deleted: (5).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:18', '2022-12-11 22:53:18'),
(266, 1, 0, 'Products deleted: (4).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:24', '2022-12-11 22:53:24'),
(267, 1, 0, 'Products deleted: (3).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:24', '2022-12-11 22:53:24'),
(268, 1, 0, 'Products deleted: (2).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:24', '2022-12-11 22:53:24'),
(269, 1, 0, 'Products deleted: (1).', '', 0, 1, NULL, 1, 0, 1, '2022-12-11 22:53:24', '2022-12-11 22:53:24'),
(270, 1, 0, 'usunięcie Feature', 'Feature', 1, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(271, 1, 0, 'usunięcie Feature', 'Feature', 2, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(272, 1, 0, 'usunięcie Feature', 'Feature', 3, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(273, 1, 0, 'usunięcie Feature', 'Feature', 4, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(274, 1, 0, 'usunięcie Feature', 'Feature', 5, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(275, 1, 0, 'usunięcie Feature', 'Feature', 6, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(276, 1, 0, 'usunięcie Feature', 'Feature', 7, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(277, 1, 0, 'usunięcie Feature', 'Feature', 8, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(278, 1, 0, 'usunięcie Feature', 'Feature', 9, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(279, 1, 0, 'usunięcie Feature', 'Feature', 10, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(280, 1, 0, 'usunięcie Feature', 'Feature', 11, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(281, 1, 0, 'usunięcie Feature', 'Feature', 12, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(282, 1, 0, 'usunięcie Feature', 'Feature', 13, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(283, 1, 0, 'usunięcie Feature', 'Feature', 14, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(284, 1, 0, 'usunięcie Feature', 'Feature', 15, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(285, 1, 0, 'usunięcie Feature', 'Feature', 16, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(286, 1, 0, 'usunięcie Feature', 'Feature', 17, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(287, 1, 0, 'usunięcie Feature', 'Feature', 18, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(288, 1, 0, 'usunięcie Feature', 'Feature', 19, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(289, 1, 0, 'usunięcie Feature', 'Feature', 20, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(290, 1, 0, 'usunięcie Feature', 'Feature', 21, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48'),
(291, 1, 0, 'usunięcie Feature', 'Feature', 22, 1, NULL, 1, 0, 1, '2022-12-11 22:53:48', '2022-12-11 22:53:48');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_mail`
--

CREATE TABLE `ps_mail` (
  `id_mail` int(11) UNSIGNED NOT NULL,
  `recipient` varchar(126) NOT NULL,
  `template` varchar(62) NOT NULL,
  `subject` varchar(254) NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `date_add` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_mail`
--

INSERT INTO `ps_mail` (`id_mail`, `recipient`, `template`, `subject`, `id_lang`, `date_add`) VALUES
(1, 'michazieli@gmail.com', 'bankwire', '[be] Oczekiwanie na płatność przelewem', 1, '2022-12-11 22:13:01'),
(2, 'michazieli@gmail.com', 'order_conf', '[be] Potwierdzenie zamówienia', 1, '2022-12-11 22:13:02'),
(3, 'admin@admin.pl', 'account', '[be] Witaj !', 1, '2022-12-11 22:15:57');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_manufacturer`
--

CREATE TABLE `ps_manufacturer` (
  `id_manufacturer` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_manufacturer`
--

INSERT INTO `ps_manufacturer` (`id_manufacturer`, `name`, `date_add`, `date_upd`, `active`) VALUES
(1, 'Studio Design', '2022-12-08 17:57:52', '2022-12-08 17:57:52', 1),
(2, 'Graphic Corner', '2022-12-08 17:57:52', '2022-12-08 17:57:52', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_manufacturer_lang`
--

CREATE TABLE `ps_manufacturer_lang` (
  `id_manufacturer` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `description` text DEFAULT NULL,
  `short_description` text DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_manufacturer_lang`
--

INSERT INTO `ps_manufacturer_lang` (`id_manufacturer`, `id_lang`, `description`, `short_description`, `meta_title`, `meta_keywords`, `meta_description`) VALUES
(1, 1, '<p>Studio Design offers a range of items from ready-to-wear collections to contemporary objects. The brand has been presenting new ideas and trends since its creation in 2012.</p>', '', '', '', ''),
(2, 1, '<p>Since 2010, Graphic Corner offers a large choice of quality posters, available on paper and many other formats. </p>', '', '', '', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_manufacturer_shop`
--

CREATE TABLE `ps_manufacturer_shop` (
  `id_manufacturer` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_manufacturer_shop`
--

INSERT INTO `ps_manufacturer_shop` (`id_manufacturer`, `id_shop`) VALUES
(1, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_memcached_servers`
--

CREATE TABLE `ps_memcached_servers` (
  `id_memcached_server` int(11) UNSIGNED NOT NULL,
  `ip` varchar(254) NOT NULL,
  `port` int(11) UNSIGNED NOT NULL,
  `weight` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_message`
--

CREATE TABLE `ps_message` (
  `id_message` int(10) UNSIGNED NOT NULL,
  `id_cart` int(10) UNSIGNED DEFAULT NULL,
  `id_customer` int(10) UNSIGNED NOT NULL,
  `id_employee` int(10) UNSIGNED DEFAULT NULL,
  `id_order` int(10) UNSIGNED NOT NULL,
  `message` text NOT NULL,
  `private` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_message_readed`
--

CREATE TABLE `ps_message_readed` (
  `id_message` int(10) UNSIGNED NOT NULL,
  `id_employee` int(10) UNSIGNED NOT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_meta`
--

CREATE TABLE `ps_meta` (
  `id_meta` int(10) UNSIGNED NOT NULL,
  `page` varchar(64) NOT NULL,
  `configurable` tinyint(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_meta`
--

INSERT INTO `ps_meta` (`id_meta`, `page`, `configurable`) VALUES
(1, 'pagenotfound', 1),
(2, 'best-sales', 1),
(3, 'contact', 1),
(4, 'index', 1),
(5, 'manufacturer', 1),
(6, 'new-products', 1),
(7, 'password', 1),
(8, 'prices-drop', 1),
(9, 'sitemap', 1),
(10, 'supplier', 1),
(11, 'address', 1),
(12, 'addresses', 1),
(13, 'authentication', 1),
(14, 'cart', 1),
(15, 'discount', 1),
(16, 'history', 1),
(17, 'identity', 1),
(18, 'my-account', 1),
(19, 'order-follow', 1),
(20, 'order-slip', 1),
(21, 'order', 1),
(22, 'search', 1),
(23, 'stores', 1),
(24, 'guest-tracking', 1),
(25, 'order-confirmation', 1),
(26, 'product', 0),
(27, 'category', 0),
(28, 'cms', 0),
(29, 'module-cheque-payment', 0),
(30, 'module-cheque-validation', 0),
(31, 'module-bankwire-validation', 0),
(32, 'module-bankwire-payment', 0),
(33, 'module-cashondelivery-validation', 0),
(36, 'module-ps_emailsubscription-verification', 1),
(37, 'module-ps_emailsubscription-subscription', 1),
(38, 'module-ps_shoppingcart-ajax', 1),
(39, 'module-ps_wirepayment-payment', 1),
(40, 'module-ps_wirepayment-validation', 1),
(41, 'module-ps_cashondelivery-validation', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_meta_lang`
--

CREATE TABLE `ps_meta_lang` (
  `id_meta` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `title` varchar(128) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `url_rewrite` varchar(254) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_meta_lang`
--

INSERT INTO `ps_meta_lang` (`id_meta`, `id_shop`, `id_lang`, `title`, `description`, `keywords`, `url_rewrite`) VALUES
(1, 1, 1, 'Błąd 404', 'Nie można odnaleźć strony', '', 'nie-znaleziono-strony'),
(2, 1, 1, 'Najczęściej kupowane', 'Nasze najlepiej sprzedające się produkty', '', 'najczesciej-kupowane'),
(3, 1, 1, 'Kontakt z nami', 'Skorzystaj z formularza kontaktowego', '', 'kontakt'),
(4, 1, 1, '', 'Sklep na oprogramowaniu PrestaShop', '', ''),
(5, 1, 1, 'Brands', 'Brands list', '', 'brands'),
(6, 1, 1, 'Nowe produkty', 'Nasze nowe produkty', '', 'nowe-produkty'),
(7, 1, 1, 'Zapomniałeś hasła', 'Wpisz swój adres e-mail w celu uzyskania nowego hasła', '', 'odzyskiwanie-hasla'),
(8, 1, 1, 'Promocje', 'Our special products', '', 'promocje'),
(9, 1, 1, 'Mapa strony', 'Zagubiłeś się? Znajdź to, czego szukasz!', '', 'Mapa strony'),
(10, 1, 1, 'Dostawcy', 'Lista dostawców', '', 'dostawcy'),
(11, 1, 1, 'Adres', '', '', 'adres'),
(12, 1, 1, 'Adresy', '', '', 'adresy'),
(13, 1, 1, 'Nazwa użytkowika', '', '', 'logowanie'),
(14, 1, 1, 'Koszyk', '', '', 'koszyk'),
(15, 1, 1, 'Rabat', '', '', 'rabaty'),
(16, 1, 1, 'Historia zamówień', '', '', 'historia-zamowien'),
(17, 1, 1, 'Dane osobiste', '', '', 'dane-osobiste'),
(18, 1, 1, 'Moje konto', '', '', 'moje-konto'),
(19, 1, 1, 'Śledzenie zamówienia', '', '', 'sledzenie-zamowienia'),
(20, 1, 1, 'Pokwitowanie - korekta kredytowa', '', '', 'potwierdzenie-zwrotu'),
(21, 1, 1, 'Zamówienie', '', '', 'zamówienie'),
(22, 1, 1, 'Szukaj', '', '', 'szukaj'),
(23, 1, 1, 'Sklepy', '', '', 'nasze-sklepy'),
(24, 1, 1, 'Śledzenie zamówień gości', '', '', 'sledzenie-zamowien-gosci'),
(25, 1, 1, 'Potwierdzenie zamówienia', '', '', 'potwierdzenie-zamowienia'),
(36, 1, 1, '', '', '', ''),
(37, 1, 1, '', '', '', ''),
(38, 1, 1, '', '', '', ''),
(39, 1, 1, '', '', '', ''),
(40, 1, 1, '', '', '', ''),
(41, 1, 1, '', '', '', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_module`
--

CREATE TABLE `ps_module` (
  `id_module` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `version` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_module`
--

INSERT INTO `ps_module` (`id_module`, `name`, `active`, `version`) VALUES
(1, 'blockwishlist', 1, '2.1.0'),
(2, 'contactform', 1, '4.3.0'),
(3, 'dashactivity', 1, '2.0.2'),
(4, 'dashtrends', 1, '2.0.3'),
(5, 'dashgoals', 1, '2.0.2'),
(6, 'dashproducts', 1, '2.1.1'),
(7, 'graphnvd3', 1, '2.0.2'),
(8, 'gridhtml', 1, '2.0.2'),
(9, 'gsitemap', 1, '4.2.0'),
(10, 'pagesnotfound', 1, '2.0.2'),
(11, 'productcomments', 1, '5.0.1'),
(12, 'ps_banner', 1, '2.1.1'),
(13, 'ps_categorytree', 1, '2.0.2'),
(15, 'ps_contactinfo', 1, '3.3.0'),
(16, 'ps_crossselling', 1, '2.0.1'),
(17, 'ps_currencyselector', 1, '2.0.1'),
(18, 'ps_customeraccountlinks', 1, '3.1.1'),
(19, 'ps_customersignin', 1, '2.0.4'),
(20, 'ps_customtext', 1, '4.2.0'),
(21, 'ps_dataprivacy', 1, '2.1.0'),
(22, 'ps_emailsubscription', 1, '2.7.0'),
(24, 'ps_faviconnotificationbo', 1, '2.1.1'),
(25, 'ps_featuredproducts', 1, '2.1.2'),
(26, 'ps_imageslider', 1, '3.1.1'),
(27, 'ps_languageselector', 1, '2.1.0'),
(28, 'ps_linklist', 1, '5.0.4'),
(29, 'ps_mainmenu', 1, '2.3.1'),
(30, 'ps_searchbar', 1, '2.1.3'),
(31, 'ps_sharebuttons', 1, '2.1.1'),
(32, 'ps_shoppingcart', 1, '2.0.5'),
(33, 'ps_socialfollow', 1, '2.2.0'),
(34, 'ps_themecusto', 1, '1.2.1'),
(35, 'ps_wirepayment', 1, '2.1.1'),
(36, 'statsbestcategories', 1, '2.0.1'),
(37, 'statsbestcustomers', 1, '2.0.3'),
(38, 'statsbestproducts', 1, '2.0.1'),
(39, 'statsbestsuppliers', 1, '2.0.0'),
(40, 'statsbestvouchers', 1, '2.0.1'),
(41, 'statscarrier', 1, '2.0.1'),
(42, 'statscatalog', 1, '2.0.2'),
(43, 'statscheckup', 1, '2.0.2'),
(44, 'statsdata', 1, '2.1.0'),
(45, 'statsforecast', 1, '2.0.4'),
(46, 'statsnewsletter', 1, '2.0.3'),
(47, 'statspersonalinfos', 1, '2.0.4'),
(48, 'statsproduct', 1, '2.1.1'),
(49, 'statsregistrations', 1, '2.0.1'),
(50, 'statssales', 1, '2.1.0'),
(51, 'statssearch', 1, '2.0.2'),
(52, 'statsstock', 1, '2.0.0'),
(53, 'welcome', 1, '6.0.7'),
(54, 'gamification', 1, '2.5.0'),
(55, 'psaddonsconnect', 1, '2.1.0'),
(56, 'psgdpr', 1, '1.4.2'),
(57, 'ps_mbo', 1, '2.0.1'),
(58, 'ps_buybuttonlite', 1, '1.0.1'),
(59, 'ps_checkout', 1, '2.20.2'),
(60, 'ps_metrics', 1, '3.5.4'),
(61, 'ps_facebook', 1, '1.20.0'),
(62, 'psxmarketingwithgoogle', 1, '1.31.0'),
(63, 'blockreassurance', 1, '5.1.0'),
(64, 'ps_facetedsearch', 1, '3.8.0'),
(65, 'ps_googleanalytics', 1, '4.1.2'),
(66, 'ps_cashondelivery', 1, '2.0.1');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_module_access`
--

CREATE TABLE `ps_module_access` (
  `id_profile` int(10) UNSIGNED NOT NULL,
  `id_authorization_role` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_module_access`
--

INSERT INTO `ps_module_access` (`id_profile`, `id_authorization_role`) VALUES
(1, 497),
(1, 498),
(1, 499),
(1, 500),
(1, 501),
(1, 502),
(1, 503),
(1, 504),
(1, 505),
(1, 506),
(1, 507),
(1, 508),
(1, 509),
(1, 510),
(1, 511),
(1, 512),
(1, 517),
(1, 518),
(1, 519),
(1, 520),
(1, 521),
(1, 522),
(1, 523),
(1, 524),
(1, 525),
(1, 526),
(1, 527),
(1, 528),
(1, 529),
(1, 530),
(1, 531),
(1, 532),
(1, 533),
(1, 534),
(1, 535),
(1, 536),
(1, 537),
(1, 538),
(1, 539),
(1, 540),
(1, 541),
(1, 542),
(1, 543),
(1, 544),
(1, 545),
(1, 546),
(1, 547),
(1, 548),
(1, 549),
(1, 550),
(1, 551),
(1, 552),
(1, 557),
(1, 558),
(1, 559),
(1, 560),
(1, 561),
(1, 562),
(1, 563),
(1, 564),
(1, 565),
(1, 566),
(1, 567),
(1, 568),
(1, 569),
(1, 570),
(1, 571),
(1, 572),
(1, 573),
(1, 574),
(1, 575),
(1, 576),
(1, 577),
(1, 578),
(1, 579),
(1, 580),
(1, 581),
(1, 582),
(1, 583),
(1, 584),
(1, 585),
(1, 586),
(1, 587),
(1, 588),
(1, 593),
(1, 594),
(1, 595),
(1, 596),
(1, 601),
(1, 602),
(1, 603),
(1, 604),
(1, 605),
(1, 606),
(1, 607),
(1, 608),
(1, 609),
(1, 610),
(1, 611),
(1, 612),
(1, 613),
(1, 614),
(1, 615),
(1, 616),
(1, 617),
(1, 618),
(1, 619),
(1, 620),
(1, 621),
(1, 622),
(1, 623),
(1, 624),
(1, 625),
(1, 626),
(1, 627),
(1, 628),
(1, 629),
(1, 630),
(1, 631),
(1, 632),
(1, 633),
(1, 634),
(1, 635),
(1, 636),
(1, 637),
(1, 638),
(1, 639),
(1, 640),
(1, 653),
(1, 654),
(1, 655),
(1, 656),
(1, 657),
(1, 658),
(1, 659),
(1, 660),
(1, 661),
(1, 662),
(1, 663),
(1, 664),
(1, 665),
(1, 666),
(1, 667),
(1, 668),
(1, 669),
(1, 670),
(1, 671),
(1, 672),
(1, 673),
(1, 674),
(1, 675),
(1, 676),
(1, 677),
(1, 678),
(1, 679),
(1, 680),
(1, 681),
(1, 682),
(1, 683),
(1, 684),
(1, 685),
(1, 686),
(1, 687),
(1, 688),
(1, 689),
(1, 690),
(1, 691),
(1, 692),
(1, 693),
(1, 694),
(1, 695),
(1, 696),
(1, 697),
(1, 698),
(1, 699),
(1, 700),
(1, 701),
(1, 702),
(1, 703),
(1, 704),
(1, 705),
(1, 706),
(1, 707),
(1, 708),
(1, 709),
(1, 710),
(1, 711),
(1, 712),
(1, 713),
(1, 714),
(1, 715),
(1, 716),
(1, 717),
(1, 718),
(1, 719),
(1, 720),
(1, 721),
(1, 722),
(1, 723),
(1, 724),
(1, 725),
(1, 726),
(1, 727),
(1, 728),
(1, 737),
(1, 738),
(1, 739),
(1, 740),
(1, 741),
(1, 742),
(1, 743),
(1, 744),
(1, 745),
(1, 746),
(1, 747),
(1, 748),
(1, 757),
(1, 758),
(1, 759),
(1, 760),
(1, 777),
(1, 778),
(1, 779),
(1, 780),
(1, 785),
(1, 786),
(1, 787),
(1, 788),
(1, 797),
(1, 798),
(1, 799),
(1, 800),
(1, 821),
(1, 822),
(1, 823),
(1, 824),
(1, 833),
(1, 834),
(1, 835),
(1, 836),
(1, 837),
(1, 838),
(1, 839),
(1, 840),
(1, 845),
(1, 846),
(1, 847),
(1, 848),
(1, 849),
(1, 850),
(1, 851),
(1, 852),
(1, 853),
(1, 854),
(1, 855),
(1, 856);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_module_carrier`
--

CREATE TABLE `ps_module_carrier` (
  `id_module` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_reference` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_module_carrier`
--

INSERT INTO `ps_module_carrier` (`id_module`, `id_shop`, `id_reference`) VALUES
(35, 1, 1),
(35, 1, 2),
(35, 1, 3),
(35, 1, 4),
(59, 1, 1),
(59, 1, 2),
(59, 1, 3),
(59, 1, 4),
(66, 1, 1),
(66, 1, 2),
(66, 1, 3),
(66, 1, 4);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_module_country`
--

CREATE TABLE `ps_module_country` (
  `id_module` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_country` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_module_country`
--

INSERT INTO `ps_module_country` (`id_module`, `id_shop`, `id_country`) VALUES
(35, 1, 14),
(59, 1, 1),
(59, 1, 2),
(59, 1, 3),
(59, 1, 4),
(59, 1, 5),
(59, 1, 6),
(59, 1, 7),
(59, 1, 8),
(59, 1, 9),
(59, 1, 10),
(59, 1, 11),
(59, 1, 12),
(59, 1, 13),
(59, 1, 14),
(59, 1, 15),
(59, 1, 16),
(59, 1, 17),
(59, 1, 18),
(59, 1, 19),
(59, 1, 20),
(59, 1, 21),
(59, 1, 22),
(59, 1, 23),
(59, 1, 24),
(59, 1, 25),
(59, 1, 26),
(59, 1, 27),
(59, 1, 28),
(59, 1, 29),
(59, 1, 30),
(59, 1, 31),
(59, 1, 32),
(59, 1, 33),
(59, 1, 34),
(59, 1, 35),
(59, 1, 36),
(59, 1, 37),
(59, 1, 38),
(59, 1, 40),
(59, 1, 41),
(59, 1, 42),
(59, 1, 43),
(59, 1, 44),
(59, 1, 45),
(59, 1, 46),
(59, 1, 47),
(59, 1, 48),
(59, 1, 49),
(59, 1, 51),
(59, 1, 52),
(59, 1, 53),
(59, 1, 54),
(59, 1, 55),
(59, 1, 56),
(59, 1, 57),
(59, 1, 58),
(59, 1, 59),
(59, 1, 60),
(59, 1, 62),
(59, 1, 63),
(59, 1, 64),
(59, 1, 65),
(59, 1, 67),
(59, 1, 68),
(59, 1, 69),
(59, 1, 70),
(59, 1, 71),
(59, 1, 72),
(59, 1, 73),
(59, 1, 74),
(59, 1, 76),
(59, 1, 77),
(59, 1, 78),
(59, 1, 79),
(59, 1, 81),
(59, 1, 82),
(59, 1, 83),
(59, 1, 85),
(59, 1, 86),
(59, 1, 87),
(59, 1, 88),
(59, 1, 89),
(59, 1, 90),
(59, 1, 91),
(59, 1, 92),
(59, 1, 93),
(59, 1, 95),
(59, 1, 96),
(59, 1, 97),
(59, 1, 98),
(59, 1, 100),
(59, 1, 102),
(59, 1, 103),
(59, 1, 104),
(59, 1, 106),
(59, 1, 107),
(59, 1, 108),
(59, 1, 109),
(59, 1, 110),
(59, 1, 114),
(59, 1, 116),
(59, 1, 117),
(59, 1, 118),
(59, 1, 119),
(59, 1, 121),
(59, 1, 122),
(59, 1, 123),
(59, 1, 124),
(59, 1, 126),
(59, 1, 129),
(59, 1, 130),
(59, 1, 132),
(59, 1, 133),
(59, 1, 134),
(59, 1, 135),
(59, 1, 136),
(59, 1, 137),
(59, 1, 138),
(59, 1, 139),
(59, 1, 140),
(59, 1, 141),
(59, 1, 142),
(59, 1, 143),
(59, 1, 144),
(59, 1, 145),
(59, 1, 146),
(59, 1, 147),
(59, 1, 148),
(59, 1, 149),
(59, 1, 150),
(59, 1, 151),
(59, 1, 152),
(59, 1, 153),
(59, 1, 154),
(59, 1, 155),
(59, 1, 156),
(59, 1, 157),
(59, 1, 158),
(59, 1, 159),
(59, 1, 160),
(59, 1, 162),
(59, 1, 164),
(59, 1, 166),
(59, 1, 167),
(59, 1, 168),
(59, 1, 169),
(59, 1, 170),
(59, 1, 171),
(59, 1, 173),
(59, 1, 174),
(59, 1, 175),
(59, 1, 176),
(59, 1, 178),
(59, 1, 179),
(59, 1, 181),
(59, 1, 182),
(59, 1, 183),
(59, 1, 184),
(59, 1, 185),
(59, 1, 186),
(59, 1, 187),
(59, 1, 188),
(59, 1, 189),
(59, 1, 190),
(59, 1, 191),
(59, 1, 192),
(59, 1, 193),
(59, 1, 195),
(59, 1, 197),
(59, 1, 198),
(59, 1, 199),
(59, 1, 201),
(59, 1, 202),
(59, 1, 203),
(59, 1, 204),
(59, 1, 206),
(59, 1, 207),
(59, 1, 208),
(59, 1, 210),
(59, 1, 211),
(59, 1, 212),
(59, 1, 213),
(59, 1, 214),
(59, 1, 215),
(59, 1, 216),
(59, 1, 218),
(59, 1, 219),
(59, 1, 220),
(59, 1, 221),
(59, 1, 223),
(59, 1, 225),
(59, 1, 226),
(59, 1, 227),
(59, 1, 228),
(59, 1, 231),
(59, 1, 233),
(59, 1, 234),
(59, 1, 237),
(59, 1, 238),
(59, 1, 239),
(66, 1, 14);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_module_currency`
--

CREATE TABLE `ps_module_currency` (
  `id_module` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_currency` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_module_currency`
--

INSERT INTO `ps_module_currency` (`id_module`, `id_shop`, `id_currency`) VALUES
(35, 1, 1),
(59, 1, 1),
(66, 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_module_group`
--

CREATE TABLE `ps_module_group` (
  `id_module` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_group` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_module_group`
--

INSERT INTO `ps_module_group` (`id_module`, `id_shop`, `id_group`) VALUES
(1, 1, 1),
(1, 1, 2),
(1, 1, 3),
(2, 1, 1),
(2, 1, 2),
(2, 1, 3),
(3, 1, 1),
(3, 1, 2),
(3, 1, 3),
(4, 1, 1),
(4, 1, 2),
(4, 1, 3),
(5, 1, 1),
(5, 1, 2),
(5, 1, 3),
(6, 1, 1),
(6, 1, 2),
(6, 1, 3),
(7, 1, 1),
(7, 1, 2),
(7, 1, 3),
(8, 1, 1),
(8, 1, 2),
(8, 1, 3),
(9, 1, 1),
(9, 1, 2),
(9, 1, 3),
(10, 1, 1),
(10, 1, 2),
(10, 1, 3),
(11, 1, 1),
(11, 1, 2),
(11, 1, 3),
(12, 1, 1),
(12, 1, 2),
(12, 1, 3),
(13, 1, 1),
(13, 1, 2),
(13, 1, 3),
(15, 1, 1),
(15, 1, 2),
(15, 1, 3),
(16, 1, 1),
(16, 1, 2),
(16, 1, 3),
(17, 1, 1),
(17, 1, 2),
(17, 1, 3),
(18, 1, 1),
(18, 1, 2),
(18, 1, 3),
(19, 1, 1),
(19, 1, 2),
(19, 1, 3),
(20, 1, 1),
(20, 1, 2),
(20, 1, 3),
(21, 1, 1),
(21, 1, 2),
(21, 1, 3),
(22, 1, 1),
(22, 1, 2),
(22, 1, 3),
(24, 1, 1),
(24, 1, 2),
(24, 1, 3),
(25, 1, 1),
(25, 1, 2),
(25, 1, 3),
(26, 1, 1),
(26, 1, 2),
(26, 1, 3),
(27, 1, 1),
(27, 1, 2),
(27, 1, 3),
(28, 1, 1),
(28, 1, 2),
(28, 1, 3),
(29, 1, 1),
(29, 1, 2),
(29, 1, 3),
(30, 1, 1),
(30, 1, 2),
(30, 1, 3),
(31, 1, 1),
(31, 1, 2),
(31, 1, 3),
(32, 1, 1),
(32, 1, 2),
(32, 1, 3),
(33, 1, 1),
(33, 1, 2),
(33, 1, 3),
(34, 1, 1),
(34, 1, 2),
(34, 1, 3),
(35, 1, 1),
(35, 1, 2),
(35, 1, 3),
(36, 1, 1),
(36, 1, 2),
(36, 1, 3),
(37, 1, 1),
(37, 1, 2),
(37, 1, 3),
(38, 1, 1),
(38, 1, 2),
(38, 1, 3),
(39, 1, 1),
(39, 1, 2),
(39, 1, 3),
(40, 1, 1),
(40, 1, 2),
(40, 1, 3),
(41, 1, 1),
(41, 1, 2),
(41, 1, 3),
(42, 1, 1),
(42, 1, 2),
(42, 1, 3),
(43, 1, 1),
(43, 1, 2),
(43, 1, 3),
(44, 1, 1),
(44, 1, 2),
(44, 1, 3),
(45, 1, 1),
(45, 1, 2),
(45, 1, 3),
(46, 1, 1),
(46, 1, 2),
(46, 1, 3),
(47, 1, 1),
(47, 1, 2),
(47, 1, 3),
(48, 1, 1),
(48, 1, 2),
(48, 1, 3),
(49, 1, 1),
(49, 1, 2),
(49, 1, 3),
(50, 1, 1),
(50, 1, 2),
(50, 1, 3),
(51, 1, 1),
(51, 1, 2),
(51, 1, 3),
(52, 1, 1),
(52, 1, 2),
(52, 1, 3),
(53, 1, 1),
(53, 1, 2),
(53, 1, 3),
(54, 1, 1),
(54, 1, 2),
(54, 1, 3),
(55, 1, 1),
(55, 1, 2),
(55, 1, 3),
(56, 1, 1),
(56, 1, 2),
(56, 1, 3),
(57, 1, 1),
(57, 1, 2),
(57, 1, 3),
(58, 1, 1),
(58, 1, 2),
(58, 1, 3),
(59, 1, 1),
(59, 1, 2),
(59, 1, 3),
(60, 1, 1),
(60, 1, 2),
(60, 1, 3),
(61, 1, 1),
(61, 1, 2),
(61, 1, 3),
(62, 1, 1),
(62, 1, 2),
(62, 1, 3),
(63, 1, 1),
(63, 1, 2),
(63, 1, 3),
(64, 1, 1),
(64, 1, 2),
(64, 1, 3),
(65, 1, 1),
(65, 1, 2),
(65, 1, 3),
(66, 1, 1),
(66, 1, 2),
(66, 1, 3);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_module_history`
--

CREATE TABLE `ps_module_history` (
  `id` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `id_module` int(11) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_module_history`
--

INSERT INTO `ps_module_history` (`id`, `id_employee`, `id_module`, `date_add`, `date_upd`) VALUES
(1, 1, 14, '2022-12-08 18:33:15', '2022-12-08 18:33:15'),
(2, 1, 65, '2022-12-08 18:44:44', '2022-12-08 18:48:24'),
(3, 1, 12, '2022-12-11 22:14:21', '2022-12-11 22:14:21');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_module_preference`
--

CREATE TABLE `ps_module_preference` (
  `id_module_preference` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `module` varchar(191) NOT NULL,
  `interest` tinyint(1) DEFAULT NULL,
  `favorite` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_module_shop`
--

CREATE TABLE `ps_module_shop` (
  `id_module` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL,
  `enable_device` tinyint(1) NOT NULL DEFAULT 7
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_module_shop`
--

INSERT INTO `ps_module_shop` (`id_module`, `id_shop`, `enable_device`) VALUES
(1, 1, 7),
(2, 1, 7),
(3, 1, 7),
(4, 1, 7),
(5, 1, 7),
(6, 1, 7),
(7, 1, 7),
(8, 1, 7),
(9, 1, 7),
(10, 1, 7),
(11, 1, 7),
(12, 1, 3),
(13, 1, 7),
(15, 1, 7),
(16, 1, 7),
(17, 1, 7),
(18, 1, 7),
(19, 1, 7),
(20, 1, 7),
(21, 1, 7),
(22, 1, 7),
(24, 1, 7),
(25, 1, 7),
(26, 1, 3),
(27, 1, 7),
(28, 1, 7),
(29, 1, 7),
(30, 1, 7),
(31, 1, 7),
(32, 1, 7),
(33, 1, 7),
(34, 1, 7),
(35, 1, 7),
(36, 1, 7),
(37, 1, 7),
(38, 1, 7),
(39, 1, 7),
(40, 1, 7),
(41, 1, 7),
(42, 1, 7),
(43, 1, 7),
(44, 1, 7),
(45, 1, 7),
(46, 1, 7),
(47, 1, 7),
(48, 1, 7),
(49, 1, 7),
(50, 1, 7),
(51, 1, 7),
(52, 1, 7),
(53, 1, 7),
(54, 1, 7),
(55, 1, 7),
(56, 1, 7),
(57, 1, 7),
(58, 1, 7),
(59, 1, 7),
(60, 1, 7),
(61, 1, 7),
(62, 1, 7),
(63, 1, 7),
(64, 1, 7),
(65, 1, 7),
(66, 1, 7);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_operating_system`
--

CREATE TABLE `ps_operating_system` (
  `id_operating_system` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_operating_system`
--

INSERT INTO `ps_operating_system` (`id_operating_system`, `name`) VALUES
(1, 'Windows XP'),
(2, 'Windows Vista'),
(3, 'Windows 7'),
(4, 'Windows 8'),
(5, 'Windows 8.1'),
(6, 'Windows 10'),
(7, 'MacOsX'),
(8, 'Linux'),
(9, 'Android');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_orders`
--

CREATE TABLE `ps_orders` (
  `id_order` int(10) UNSIGNED NOT NULL,
  `reference` varchar(9) DEFAULT NULL,
  `id_shop_group` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_carrier` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED NOT NULL,
  `id_cart` int(10) UNSIGNED NOT NULL,
  `id_currency` int(10) UNSIGNED NOT NULL,
  `id_address_delivery` int(10) UNSIGNED NOT NULL,
  `id_address_invoice` int(10) UNSIGNED NOT NULL,
  `current_state` int(10) UNSIGNED NOT NULL,
  `secure_key` varchar(32) NOT NULL DEFAULT '-1',
  `payment` varchar(255) NOT NULL,
  `conversion_rate` decimal(13,6) NOT NULL DEFAULT 1.000000,
  `module` varchar(255) DEFAULT NULL,
  `recyclable` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `gift` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `gift_message` text DEFAULT NULL,
  `mobile_theme` tinyint(1) NOT NULL DEFAULT 0,
  `shipping_number` varchar(64) DEFAULT NULL,
  `total_discounts` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_discounts_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_discounts_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_paid` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_paid_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_paid_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_paid_real` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_products` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_products_wt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_shipping` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_shipping_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_shipping_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `carrier_tax_rate` decimal(10,3) NOT NULL DEFAULT 0.000,
  `total_wrapping` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_wrapping_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_wrapping_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `round_mode` tinyint(1) NOT NULL DEFAULT 2,
  `round_type` tinyint(1) NOT NULL DEFAULT 1,
  `invoice_number` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `delivery_number` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `invoice_date` datetime NOT NULL,
  `delivery_date` datetime NOT NULL,
  `valid` int(1) UNSIGNED NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `note` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_orders`
--

INSERT INTO `ps_orders` (`id_order`, `reference`, `id_shop_group`, `id_shop`, `id_carrier`, `id_lang`, `id_customer`, `id_cart`, `id_currency`, `id_address_delivery`, `id_address_invoice`, `current_state`, `secure_key`, `payment`, `conversion_rate`, `module`, `recyclable`, `gift`, `gift_message`, `mobile_theme`, `shipping_number`, `total_discounts`, `total_discounts_tax_incl`, `total_discounts_tax_excl`, `total_paid`, `total_paid_tax_incl`, `total_paid_tax_excl`, `total_paid_real`, `total_products`, `total_products_wt`, `total_shipping`, `total_shipping_tax_incl`, `total_shipping_tax_excl`, `carrier_tax_rate`, `total_wrapping`, `total_wrapping_tax_incl`, `total_wrapping_tax_excl`, `round_mode`, `round_type`, `invoice_number`, `delivery_number`, `invoice_date`, `delivery_date`, `valid`, `date_add`, `date_upd`, `note`) VALUES
(1, 'XKBKNABJK', 1, 1, 2, 1, 2, 1, 1, 5, 5, 6, 'b44a6d9efd7a0076a0fbce6b15eaf3b1', 'Payment by check', '1.000000', 'ps_checkpayment', 0, 0, '', 0, '', '0.000000', '0.000000', '0.000000', '61.800000', '68.200000', '66.800000', '0.000000', '59.800000', '59.800000', '7.000000', '8.400000', '7.000000', '0.000', '0.000000', '0.000000', '0.000000', 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2022-12-08 17:57:55', '2022-12-08 17:57:55', 'Test'),
(2, 'OHSATSERP', 1, 1, 2, 1, 2, 2, 1, 5, 5, 1, 'b44a6d9efd7a0076a0fbce6b15eaf3b1', 'Payment by check', '1.000000', 'ps_checkpayment', 0, 0, '', 0, '', '0.000000', '0.000000', '0.000000', '169.900000', '169.900000', '169.900000', '0.000000', '169.900000', '169.900000', '0.000000', '0.000000', '0.000000', '0.000', '0.000000', '0.000000', '0.000000', 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2022-12-08 17:57:55', '2022-12-08 17:57:55', ''),
(3, 'UOYEVOLI', 1, 1, 2, 1, 2, 3, 1, 5, 5, 8, 'b44a6d9efd7a0076a0fbce6b15eaf3b1', 'Payment by check', '1.000000', 'ps_checkpayment', 0, 0, '', 0, '', '0.000000', '0.000000', '0.000000', '14.900000', '21.300000', '19.900000', '0.000000', '12.900000', '12.900000', '7.000000', '8.400000', '7.000000', '0.000', '0.000000', '0.000000', '0.000000', 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2022-12-08 17:57:55', '2022-12-08 17:57:55', ''),
(4, 'FFATNOMMJ', 1, 1, 2, 1, 2, 4, 1, 5, 5, 1, 'b44a6d9efd7a0076a0fbce6b15eaf3b1', 'Payment by check', '1.000000', 'ps_checkpayment', 0, 0, '', 0, '', '0.000000', '0.000000', '0.000000', '14.900000', '21.300000', '19.900000', '0.000000', '12.900000', '12.900000', '7.000000', '8.400000', '7.000000', '0.000', '0.000000', '0.000000', '0.000000', 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2022-12-08 17:57:55', '2022-12-08 17:57:55', ''),
(5, 'KHWLILZLL', 1, 1, 2, 1, 2, 5, 1, 5, 5, 10, 'b44a6d9efd7a0076a0fbce6b15eaf3b1', 'Bank wire', '1.000000', 'ps_wirepayment', 0, 0, '', 0, '', '0.000000', '0.000000', '0.000000', '20.900000', '27.300000', '25.900000', '0.000000', '18.900000', '18.900000', '7.000000', '8.400000', '7.000000', '0.000', '0.000000', '0.000000', '0.000000', 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2022-12-08 17:57:55', '2022-12-08 17:57:55', ''),
(6, 'NNYYFWQQV', 1, 1, 1, 1, 3, 6, 1, 7, 7, 10, 'b885af361da62e482e0e364032815c50', 'Płatności elektroniczne', '1.000000', 'ps_wirepayment', 0, 0, '', 0, '', '0.000000', '0.000000', '0.000000', '35.330000', '35.330000', '28.720000', '0.000000', '28.720000', '35.330000', '0.000000', '0.000000', '0.000000', '23.000', '0.000000', '0.000000', '0.000000', 2, 2, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2022-12-11 22:12:59', '2022-12-11 22:12:59', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_carrier`
--

CREATE TABLE `ps_order_carrier` (
  `id_order_carrier` int(11) NOT NULL,
  `id_order` int(11) UNSIGNED NOT NULL,
  `id_carrier` int(11) UNSIGNED NOT NULL,
  `id_order_invoice` int(11) UNSIGNED DEFAULT NULL,
  `weight` decimal(20,6) DEFAULT NULL,
  `shipping_cost_tax_excl` decimal(20,6) DEFAULT NULL,
  `shipping_cost_tax_incl` decimal(20,6) DEFAULT NULL,
  `tracking_number` varchar(64) DEFAULT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_order_carrier`
--

INSERT INTO `ps_order_carrier` (`id_order_carrier`, `id_order`, `id_carrier`, `id_order_invoice`, `weight`, `shipping_cost_tax_excl`, `shipping_cost_tax_incl`, `tracking_number`, `date_add`) VALUES
(1, 1, 2, 0, '0.000000', '7.000000', '8.400000', '', '2022-12-08 17:57:55'),
(2, 2, 2, 0, '0.000000', '7.000000', '8.400000', '', '2022-12-08 17:57:55'),
(3, 3, 2, 0, '0.000000', '7.000000', '8.400000', '', '2022-12-08 17:57:55'),
(4, 4, 2, 0, '0.000000', '7.000000', '8.400000', '', '2022-12-08 17:57:55'),
(5, 5, 2, 0, '0.000000', '7.000000', '8.400000', '', '2022-12-08 17:57:55'),
(6, 6, 1, 0, '0.300000', '0.000000', '0.000000', '', '2022-12-11 22:12:59');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_cart_rule`
--

CREATE TABLE `ps_order_cart_rule` (
  `id_order_cart_rule` int(10) UNSIGNED NOT NULL,
  `id_order` int(10) UNSIGNED NOT NULL,
  `id_cart_rule` int(10) UNSIGNED NOT NULL,
  `id_order_invoice` int(10) UNSIGNED DEFAULT 0,
  `name` varchar(254) NOT NULL,
  `value` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `value_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `free_shipping` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_detail`
--

CREATE TABLE `ps_order_detail` (
  `id_order_detail` int(10) UNSIGNED NOT NULL,
  `id_order` int(10) UNSIGNED NOT NULL,
  `id_order_invoice` int(11) DEFAULT NULL,
  `id_warehouse` int(10) UNSIGNED DEFAULT 0,
  `id_shop` int(11) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `product_attribute_id` int(10) UNSIGNED DEFAULT NULL,
  `id_customization` int(10) UNSIGNED DEFAULT 0,
  `product_name` varchar(255) NOT NULL,
  `product_quantity` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `product_quantity_in_stock` int(10) NOT NULL DEFAULT 0,
  `product_quantity_refunded` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `product_quantity_return` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `product_quantity_reinjected` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `product_price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `reduction_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `reduction_amount` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `reduction_amount_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `reduction_amount_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `group_reduction` decimal(5,2) NOT NULL DEFAULT 0.00,
  `product_quantity_discount` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `product_ean13` varchar(13) DEFAULT NULL,
  `product_isbn` varchar(32) DEFAULT NULL,
  `product_upc` varchar(12) DEFAULT NULL,
  `product_mpn` varchar(40) DEFAULT NULL,
  `product_reference` varchar(64) DEFAULT NULL,
  `product_supplier_reference` varchar(64) DEFAULT NULL,
  `product_weight` decimal(20,6) NOT NULL,
  `id_tax_rules_group` int(11) UNSIGNED DEFAULT 0,
  `tax_computation_method` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `tax_name` varchar(16) NOT NULL,
  `tax_rate` decimal(10,3) NOT NULL DEFAULT 0.000,
  `ecotax` decimal(17,6) NOT NULL DEFAULT 0.000000,
  `ecotax_tax_rate` decimal(5,3) NOT NULL DEFAULT 0.000,
  `discount_quantity_applied` tinyint(1) NOT NULL DEFAULT 0,
  `download_hash` varchar(255) DEFAULT NULL,
  `download_nb` int(10) UNSIGNED DEFAULT 0,
  `download_deadline` datetime DEFAULT NULL,
  `total_price_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_price_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `unit_price_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `unit_price_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_shipping_price_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_shipping_price_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `purchase_supplier_price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `original_product_price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `original_wholesale_price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_refunded_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_refunded_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_order_detail`
--

INSERT INTO `ps_order_detail` (`id_order_detail`, `id_order`, `id_order_invoice`, `id_warehouse`, `id_shop`, `product_id`, `product_attribute_id`, `id_customization`, `product_name`, `product_quantity`, `product_quantity_in_stock`, `product_quantity_refunded`, `product_quantity_return`, `product_quantity_reinjected`, `product_price`, `reduction_percent`, `reduction_amount`, `reduction_amount_tax_incl`, `reduction_amount_tax_excl`, `group_reduction`, `product_quantity_discount`, `product_ean13`, `product_isbn`, `product_upc`, `product_mpn`, `product_reference`, `product_supplier_reference`, `product_weight`, `id_tax_rules_group`, `tax_computation_method`, `tax_name`, `tax_rate`, `ecotax`, `ecotax_tax_rate`, `discount_quantity_applied`, `download_hash`, `download_nb`, `download_deadline`, `total_price_tax_incl`, `total_price_tax_excl`, `unit_price_tax_incl`, `unit_price_tax_excl`, `total_shipping_price_tax_incl`, `total_shipping_price_tax_excl`, `purchase_supplier_price`, `original_product_price`, `original_wholesale_price`, `total_refunded_tax_excl`, `total_refunded_tax_incl`) VALUES
(1, 1, 0, 0, 1, 1, 1, 0, 'Hummingbird printed t-shirt - Color : White, Size : S', 1, 1, 0, 0, 0, '23.900000', '0.00', '0.000000', '0.000000', '0.000000', '0.00', '0.000000', '', '', '', '', 'demo_1', '', '0.000000', 0, 0, '', '0.000', '0.000000', '0.000', 0, '', 0, '0000-00-00 00:00:00', '23.900000', '23.900000', '23.900000', '23.900000', '0.000000', '0.000000', '0.000000', '23.900000', '0.000000', '0.000000', '0.000000'),
(2, 1, 0, 0, 1, 2, 9, 0, 'Hummingbird printed sweater - Color : White, Size : S', 1, 1, 0, 0, 0, '35.900000', '0.00', '0.000000', '0.000000', '0.000000', '0.00', '0.000000', '', '', '', '', 'demo_3', '', '0.000000', 0, 0, '', '0.000', '0.000000', '0.000', 0, '', 0, '0000-00-00 00:00:00', '35.900000', '35.900000', '35.900000', '35.900000', '0.000000', '0.000000', '0.000000', '35.900000', '0.000000', '0.000000', '0.000000'),
(3, 2, 0, 0, 1, 4, 18, 0, 'The adventure begins Framed poster - Size : 80x120cm', 2, 3, 0, 0, 0, '79.000000', '0.00', '0.000000', '0.000000', '0.000000', '0.00', '0.000000', '', '', '', '', 'demo_5', '', '0.000000', 0, 0, '', '0.000', '0.000000', '0.000', 0, '', 0, '0000-00-00 00:00:00', '158.000000', '79.000000', '79.000000', '79.000000', '0.000000', '0.000000', '0.000000', '79.000000', '0.000000', '0.000000', '0.000000'),
(4, 2, 0, 0, 1, 8, 0, 0, 'Mug Today is a good day', 1, 1, 0, 0, 0, '11.900000', '0.00', '0.000000', '0.000000', '0.000000', '0.00', '0.000000', '', '', '', '', 'demo_13', '', '0.000000', 0, 0, '', '0.000', '0.000000', '0.000', 0, '', 0, '0000-00-00 00:00:00', '11.900000', '11.900000', '11.900000', '11.900000', '0.000000', '0.000000', '0.000000', '11.900000', '0.000000', '0.000000', '0.000000'),
(5, 3, 0, 0, 1, 16, 28, 0, 'Mountain fox notebook Style : Ruled', 1, 1, 0, 0, 0, '12.900000', '0.00', '0.000000', '0.000000', '0.000000', '0.00', '0.000000', '', '', '', '', 'demo_8', '', '0.000000', 0, 0, '', '0.000', '0.000000', '0.000', 0, '', 0, '0000-00-00 00:00:00', '12.900000', '12.900000', '12.900000', '12.900000', '0.000000', '0.000000', '0.000000', '12.900000', '0.000000', '0.000000', '0.000000'),
(6, 4, 0, 0, 1, 16, 29, 0, 'Mountain fox notebook Style : Plain', 1, 1, 0, 0, 0, '12.900000', '0.00', '0.000000', '0.000000', '0.000000', '0.00', '0.000000', '', '', '', '', 'demo_8', '', '0.000000', 0, 0, '', '0.000', '0.000000', '0.000', 0, '', 0, '0000-00-00 00:00:00', '12.900000', '12.900000', '12.900000', '12.900000', '0.000000', '0.000000', '0.000000', '12.900000', '0.000000', '0.000000', '0.000000'),
(7, 5, 0, 0, 1, 10, 25, 0, 'Brown bear cushion Color : Black', 1, 1, 0, 0, 0, '18.900000', '0.00', '0.000000', '0.000000', '0.000000', '0.00', '0.000000', '', '', '', '', 'demo_16', '', '0.000000', 0, 0, '', '0.000', '0.000000', '0.000', 0, '', 0, '0000-00-00 00:00:00', '18.900000', '18.900000', '18.900000', '18.900000', '0.000000', '0.000000', '0.000000', '18.900000', '0.000000', '0.000000', '0.000000'),
(8, 6, 0, 0, 1, 2, 9, 0, 'Hummingbird printed sweater (Rozmiar:S)', 1, 1, 0, 0, 0, '28.720000', '20.00', '0.000000', '0.000000', '0.000000', '0.00', '36.560000', '', '', '', '', 'demo_3', 'demo_3_62', '0.300000', 1, 0, 'PTU PL 23%', '23.000', '0.000000', '0.000', 0, '', 0, '0000-00-00 00:00:00', '35.330000', '28.720000', '35.325600', '28.720000', '0.000000', '0.000000', '5.490000', '35.900000', '0.000000', '0.000000', '0.000000');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_detail_tax`
--

CREATE TABLE `ps_order_detail_tax` (
  `id_order_detail` int(11) NOT NULL,
  `id_tax` int(11) NOT NULL,
  `unit_amount` decimal(16,6) NOT NULL DEFAULT 0.000000,
  `total_amount` decimal(16,6) NOT NULL DEFAULT 0.000000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_order_detail_tax`
--

INSERT INTO `ps_order_detail_tax` (`id_order_detail`, `id_tax`, `unit_amount`, `total_amount`) VALUES
(8, 1, '6.605600', '6.610000');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_history`
--

CREATE TABLE `ps_order_history` (
  `id_order_history` int(10) UNSIGNED NOT NULL,
  `id_employee` int(10) UNSIGNED NOT NULL,
  `id_order` int(10) UNSIGNED NOT NULL,
  `id_order_state` int(10) UNSIGNED NOT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_order_history`
--

INSERT INTO `ps_order_history` (`id_order_history`, `id_employee`, `id_order`, `id_order_state`, `date_add`) VALUES
(1, 0, 1, 1, '2022-12-08 17:57:55'),
(2, 0, 2, 1, '2022-12-08 17:57:55'),
(3, 0, 3, 1, '2022-12-08 17:57:55'),
(4, 0, 4, 1, '2022-12-08 17:57:55'),
(5, 0, 5, 10, '2022-12-08 17:57:55'),
(6, 1, 1, 6, '2022-12-08 17:57:55'),
(7, 1, 3, 8, '2022-12-08 17:57:55'),
(8, 0, 6, 10, '2022-12-11 22:12:59');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_invoice`
--

CREATE TABLE `ps_order_invoice` (
  `id_order_invoice` int(11) UNSIGNED NOT NULL,
  `id_order` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `delivery_number` int(11) NOT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `total_discount_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_discount_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_paid_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_paid_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_products` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_products_wt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_shipping_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_shipping_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `shipping_tax_computation_method` int(10) UNSIGNED NOT NULL,
  `total_wrapping_tax_excl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `total_wrapping_tax_incl` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `shop_address` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_invoice_payment`
--

CREATE TABLE `ps_order_invoice_payment` (
  `id_order_invoice` int(11) UNSIGNED NOT NULL,
  `id_order_payment` int(11) UNSIGNED NOT NULL,
  `id_order` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_invoice_tax`
--

CREATE TABLE `ps_order_invoice_tax` (
  `id_order_invoice` int(11) NOT NULL,
  `type` varchar(15) NOT NULL,
  `id_tax` int(11) NOT NULL,
  `amount` decimal(10,6) NOT NULL DEFAULT 0.000000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_message`
--

CREATE TABLE `ps_order_message` (
  `id_order_message` int(10) UNSIGNED NOT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_order_message`
--

INSERT INTO `ps_order_message` (`id_order_message`, `date_add`) VALUES
(1, '2022-12-08 17:57:55');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_message_lang`
--

CREATE TABLE `ps_order_message_lang` (
  `id_order_message` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(128) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_order_message_lang`
--

INSERT INTO `ps_order_message_lang` (`id_order_message`, `id_lang`, `name`, `message`) VALUES
(1, 1, 'Czas przesyłki', 'Witaj,\n\nNiestety, artykuł na twoim zamówieniu jest obecnie niedostępny. Może to spowodować delikatne opóźnienie w dostawie.\nPrzepraszamy za powstałe utrudnienia, zapewniamy że pracujemy by to skorygować.\n\nZ poważaniem,');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_payment`
--

CREATE TABLE `ps_order_payment` (
  `id_order_payment` int(11) NOT NULL,
  `order_reference` varchar(9) DEFAULT NULL,
  `id_currency` int(10) UNSIGNED NOT NULL,
  `amount` decimal(20,6) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `conversion_rate` decimal(13,6) NOT NULL DEFAULT 1.000000,
  `transaction_id` varchar(254) DEFAULT NULL,
  `card_number` varchar(254) DEFAULT NULL,
  `card_brand` varchar(254) DEFAULT NULL,
  `card_expiration` char(7) DEFAULT NULL,
  `card_holder` varchar(254) DEFAULT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_return`
--

CREATE TABLE `ps_order_return` (
  `id_order_return` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED NOT NULL,
  `id_order` int(10) UNSIGNED NOT NULL,
  `state` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `question` text NOT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_return_detail`
--

CREATE TABLE `ps_order_return_detail` (
  `id_order_return` int(10) UNSIGNED NOT NULL,
  `id_order_detail` int(10) UNSIGNED NOT NULL,
  `id_customization` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `product_quantity` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_return_state`
--

CREATE TABLE `ps_order_return_state` (
  `id_order_return_state` int(10) UNSIGNED NOT NULL,
  `color` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_order_return_state`
--

INSERT INTO `ps_order_return_state` (`id_order_return_state`, `color`) VALUES
(1, '#4169E1'),
(2, '#8A2BE2'),
(3, '#32CD32'),
(4, '#DC143C'),
(5, '#108510');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_return_state_lang`
--

CREATE TABLE `ps_order_return_state_lang` (
  `id_order_return_state` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_order_return_state_lang`
--

INSERT INTO `ps_order_return_state_lang` (`id_order_return_state`, `id_lang`, `name`) VALUES
(1, 1, 'Oczekiwanie na potwierdzenie'),
(2, 1, 'Oczekiwanie na paczkę'),
(3, 1, 'Paczka została odebrana'),
(4, 1, 'Brak akceptacji zwrotu'),
(5, 1, 'Dokonanie zwrotu');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_slip`
--

CREATE TABLE `ps_order_slip` (
  `id_order_slip` int(10) UNSIGNED NOT NULL,
  `conversion_rate` decimal(13,6) NOT NULL DEFAULT 1.000000,
  `id_customer` int(10) UNSIGNED NOT NULL,
  `id_order` int(10) UNSIGNED NOT NULL,
  `total_products_tax_excl` decimal(20,6) DEFAULT NULL,
  `total_products_tax_incl` decimal(20,6) DEFAULT NULL,
  `total_shipping_tax_excl` decimal(20,6) DEFAULT NULL,
  `total_shipping_tax_incl` decimal(20,6) DEFAULT NULL,
  `shipping_cost` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `amount` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `shipping_cost_amount` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `partial` tinyint(1) NOT NULL,
  `order_slip_type` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_slip_detail`
--

CREATE TABLE `ps_order_slip_detail` (
  `id_order_slip` int(10) UNSIGNED NOT NULL,
  `id_order_detail` int(10) UNSIGNED NOT NULL,
  `product_quantity` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `unit_price_tax_excl` decimal(20,6) DEFAULT NULL,
  `unit_price_tax_incl` decimal(20,6) DEFAULT NULL,
  `total_price_tax_excl` decimal(20,6) DEFAULT NULL,
  `total_price_tax_incl` decimal(20,6) DEFAULT NULL,
  `amount_tax_excl` decimal(20,6) DEFAULT NULL,
  `amount_tax_incl` decimal(20,6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_state`
--

CREATE TABLE `ps_order_state` (
  `id_order_state` int(10) UNSIGNED NOT NULL,
  `invoice` tinyint(1) UNSIGNED DEFAULT 0,
  `send_email` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `module_name` varchar(255) DEFAULT NULL,
  `color` varchar(32) DEFAULT NULL,
  `unremovable` tinyint(1) UNSIGNED NOT NULL,
  `hidden` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `logable` tinyint(1) NOT NULL DEFAULT 0,
  `delivery` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `shipped` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `paid` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `pdf_invoice` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `pdf_delivery` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_order_state`
--

INSERT INTO `ps_order_state` (`id_order_state`, `invoice`, `send_email`, `module_name`, `color`, `unremovable`, `hidden`, `logable`, `delivery`, `shipped`, `paid`, `pdf_invoice`, `pdf_delivery`, `deleted`) VALUES
(1, 0, 1, 'ps_checkpayment', '#34209E', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 1, 1, '', '#3498D8', 1, 0, 1, 0, 0, 1, 1, 0, 0),
(3, 1, 1, '', '#3498D8', 1, 0, 1, 1, 0, 1, 0, 0, 0),
(4, 1, 1, '', '#01B887', 1, 0, 1, 1, 1, 1, 0, 0, 0),
(5, 1, 0, '', '#01B887', 1, 0, 1, 1, 1, 1, 0, 0, 0),
(6, 0, 1, '', '#2C3E50', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(7, 1, 1, '', '#01B887', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(8, 0, 1, '', '#E74C3C', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(9, 1, 1, '', '#3498D8', 1, 0, 0, 0, 0, 1, 0, 0, 0),
(10, 0, 1, 'ps_wirepayment', '#34209E', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(11, 1, 1, '', '#3498D8', 1, 0, 1, 0, 0, 1, 0, 0, 0),
(12, 0, 1, '', '#34209E', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(13, 0, 0, 'ps_cashondelivery', '#34209E', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(14, 0, 0, 'ps_checkout', '#34209E', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(15, 0, 0, 'ps_checkout', '#34209E', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(16, 0, 0, 'ps_checkout', '#34209E', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(17, 0, 0, 'ps_checkout', '#3498D8', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(18, 0, 0, 'ps_checkout', '#01B887', 1, 0, 0, 0, 0, 0, 0, 0, 0),
(19, 0, 0, 'ps_checkout', '#3498D8', 1, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_order_state_lang`
--

CREATE TABLE `ps_order_state_lang` (
  `id_order_state` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL,
  `template` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_order_state_lang`
--

INSERT INTO `ps_order_state_lang` (`id_order_state`, `id_lang`, `name`, `template`) VALUES
(1, 1, 'Oczekiwanie na płatność czekiem', 'cheque'),
(2, 1, 'Płatność zaakceptowana', 'payment'),
(3, 1, 'Przygotowanie w toku', 'preparation'),
(4, 1, 'Wysłane', 'shipped'),
(5, 1, 'Dostarczone', ''),
(6, 1, 'Anulowane', 'order_canceled'),
(7, 1, 'Zwróconych pieniędzy', 'refund'),
(8, 1, 'Błąd płatności', 'payment_error'),
(9, 1, 'Zamówienie oczekujące (opłacone)', 'outofstock'),
(10, 1, 'Oczekiwanie na płatność przelewem', 'bankwire'),
(11, 1, 'Płatność przyjęta', 'payment'),
(12, 1, 'Zamówienie oczekujące (nieopłacone)', 'outofstock'),
(13, 1, 'Oczekiwanie na płatność przy odbiorze', 'cashondelivery'),
(14, 1, 'Oczekiwanie na płatność PayPal', 'payment'),
(15, 1, 'Oczekiwanie na płatność kartą kredytową', 'payment'),
(16, 1, 'Oczekiwanie na płatność lokalnym środkiem płatności', 'payment'),
(17, 1, 'Pomyślna autoryzacja. Transfer do przeprowadzenia przez sklep', 'payment'),
(18, 1, 'Częściowy zwrot', 'payment'),
(19, 1, 'Oczekiwanie na transfer', 'payment');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_pack`
--

CREATE TABLE `ps_pack` (
  `id_product_pack` int(10) UNSIGNED NOT NULL,
  `id_product_item` int(10) UNSIGNED NOT NULL,
  `id_product_attribute_item` int(10) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_page`
--

CREATE TABLE `ps_page` (
  `id_page` int(10) UNSIGNED NOT NULL,
  `id_page_type` int(10) UNSIGNED NOT NULL,
  `id_object` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_page`
--

INSERT INTO `ps_page` (`id_page`, `id_page_type`, `id_object`) VALUES
(1, 1, NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_pagenotfound`
--

CREATE TABLE `ps_pagenotfound` (
  `id_pagenotfound` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `id_shop_group` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `request_uri` varchar(256) NOT NULL,
  `http_referer` varchar(256) NOT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_page_type`
--

CREATE TABLE `ps_page_type` (
  `id_page_type` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_page_type`
--

INSERT INTO `ps_page_type` (`id_page_type`, `name`) VALUES
(1, 'index');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_page_viewed`
--

CREATE TABLE `ps_page_viewed` (
  `id_page` int(10) UNSIGNED NOT NULL,
  `id_shop_group` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `id_shop` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `id_date_range` int(10) UNSIGNED NOT NULL,
  `counter` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product`
--

CREATE TABLE `ps_product` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_supplier` int(10) UNSIGNED DEFAULT NULL,
  `id_manufacturer` int(10) UNSIGNED DEFAULT NULL,
  `id_category_default` int(10) UNSIGNED DEFAULT NULL,
  `id_shop_default` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `id_tax_rules_group` int(11) UNSIGNED NOT NULL,
  `on_sale` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `online_only` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `ean13` varchar(13) DEFAULT NULL,
  `isbn` varchar(32) DEFAULT NULL,
  `upc` varchar(12) DEFAULT NULL,
  `mpn` varchar(40) DEFAULT NULL,
  `ecotax` decimal(17,6) NOT NULL DEFAULT 0.000000,
  `quantity` int(10) NOT NULL DEFAULT 0,
  `minimal_quantity` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `low_stock_threshold` int(10) DEFAULT NULL,
  `low_stock_alert` tinyint(1) NOT NULL DEFAULT 0,
  `price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `wholesale_price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `unity` varchar(255) DEFAULT NULL,
  `unit_price_ratio` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `additional_shipping_cost` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `reference` varchar(64) DEFAULT NULL,
  `supplier_reference` varchar(64) DEFAULT NULL,
  `location` varchar(255) NOT NULL DEFAULT '',
  `width` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `height` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `depth` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `weight` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `out_of_stock` int(10) UNSIGNED NOT NULL DEFAULT 2,
  `additional_delivery_times` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `quantity_discount` tinyint(1) DEFAULT 0,
  `customizable` tinyint(2) NOT NULL DEFAULT 0,
  `uploadable_files` tinyint(4) NOT NULL DEFAULT 0,
  `text_fields` tinyint(4) NOT NULL DEFAULT 0,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `redirect_type` enum('404','301-product','302-product','301-category','302-category') NOT NULL DEFAULT '404',
  `id_type_redirected` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `available_for_order` tinyint(1) NOT NULL DEFAULT 1,
  `available_date` date DEFAULT NULL,
  `show_condition` tinyint(1) NOT NULL DEFAULT 0,
  `condition` enum('new','used','refurbished') NOT NULL DEFAULT 'new',
  `show_price` tinyint(1) NOT NULL DEFAULT 1,
  `indexed` tinyint(1) NOT NULL DEFAULT 0,
  `visibility` enum('both','catalog','search','none') NOT NULL DEFAULT 'both',
  `cache_is_pack` tinyint(1) NOT NULL DEFAULT 0,
  `cache_has_attachments` tinyint(1) NOT NULL DEFAULT 0,
  `is_virtual` tinyint(1) NOT NULL DEFAULT 0,
  `cache_default_attribute` int(10) UNSIGNED DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `advanced_stock_management` tinyint(1) NOT NULL DEFAULT 0,
  `pack_stock_type` int(11) UNSIGNED NOT NULL DEFAULT 3,
  `state` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `product_type` enum('standard','pack','virtual','combinations','') NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_product`
--

INSERT INTO `ps_product` (`id_product`, `id_supplier`, `id_manufacturer`, `id_category_default`, `id_shop_default`, `id_tax_rules_group`, `on_sale`, `online_only`, `ean13`, `isbn`, `upc`, `mpn`, `ecotax`, `quantity`, `minimal_quantity`, `low_stock_threshold`, `low_stock_alert`, `price`, `wholesale_price`, `unity`, `unit_price_ratio`, `additional_shipping_cost`, `reference`, `supplier_reference`, `location`, `width`, `height`, `depth`, `weight`, `out_of_stock`, `additional_delivery_times`, `quantity_discount`, `customizable`, `uploadable_files`, `text_fields`, `active`, `redirect_type`, `id_type_redirected`, `available_for_order`, `available_date`, `show_condition`, `condition`, `show_price`, `indexed`, `visibility`, `cache_is_pack`, `cache_has_attachments`, `is_virtual`, `cache_default_attribute`, `date_add`, `date_upd`, `advanced_stock_management`, `pack_stock_type`, `state`, `product_type`) VALUES
(25, 0, 0, 35, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '447.150000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 60, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(26, 0, 0, 35, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 64, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(27, 0, 0, 36, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 68, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(28, 0, 0, 35, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 72, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(29, 0, 0, 37, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '170.720000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 76, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(30, 0, 0, 35, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 80, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(31, 0, 0, 38, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 84, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(32, 0, 0, 39, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 88, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(33, 0, 0, 35, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 92, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(34, 0, 0, 39, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '56.900000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 96, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(35, 0, 0, 37, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 100, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(36, 0, 0, 36, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 104, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0, 0, 1, ''),
(37, 0, 0, 36, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 108, '2022-12-11 22:54:34', '2022-12-11 22:54:34', 0, 0, 1, ''),
(38, 0, 0, 36, 1, 1, 0, 0, '', '', '', '', '0.000000', 0, 1, NULL, 0, '48.770000', '0.000000', '', '0.000000', '0.000000', '', '', '', '0.000000', '0.000000', '0.000000', '0.000000', 2, 0, 0, 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 0, 0, 0, 112, '2022-12-11 22:54:34', '2022-12-11 22:54:34', 0, 0, 1, '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_attachment`
--

CREATE TABLE `ps_product_attachment` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_attachment` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_attribute`
--

CREATE TABLE `ps_product_attribute` (
  `id_product_attribute` int(10) UNSIGNED NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `reference` varchar(64) DEFAULT NULL,
  `supplier_reference` varchar(64) DEFAULT NULL,
  `location` varchar(255) NOT NULL DEFAULT '',
  `ean13` varchar(13) DEFAULT NULL,
  `isbn` varchar(32) DEFAULT NULL,
  `upc` varchar(12) DEFAULT NULL,
  `mpn` varchar(40) DEFAULT NULL,
  `wholesale_price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ecotax` decimal(17,6) NOT NULL DEFAULT 0.000000,
  `quantity` int(10) NOT NULL DEFAULT 0,
  `weight` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `unit_price_impact` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `default_on` tinyint(1) UNSIGNED DEFAULT NULL,
  `minimal_quantity` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `low_stock_threshold` int(10) DEFAULT NULL,
  `low_stock_alert` tinyint(1) NOT NULL DEFAULT 0,
  `available_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_product_attribute`
--

INSERT INTO `ps_product_attribute` (`id_product_attribute`, `id_product`, `reference`, `supplier_reference`, `location`, `ean13`, `isbn`, `upc`, `mpn`, `wholesale_price`, `price`, `ecotax`, `quantity`, `weight`, `unit_price_impact`, `default_on`, `minimal_quantity`, `low_stock_threshold`, `low_stock_alert`, `available_date`) VALUES
(60, 25, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(61, 25, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(62, 25, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(63, 25, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(64, 26, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(65, 26, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(66, 26, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(67, 26, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(68, 27, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(69, 27, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(70, 27, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(71, 27, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(72, 28, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(73, 28, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(74, 28, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(75, 28, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(76, 29, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(77, 29, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(78, 29, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(79, 29, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(80, 30, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(81, 30, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(82, 30, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(83, 30, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(84, 31, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(85, 31, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(86, 31, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(87, 31, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(88, 32, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(89, 32, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(90, 32, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(91, 32, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(92, 33, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(93, 33, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(94, 33, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(95, 33, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(96, 34, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(97, 34, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(98, 34, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(99, 34, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(100, 35, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(101, 35, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(102, 35, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(103, 35, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(104, 36, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(105, 36, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(106, 36, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(107, 36, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(108, 37, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(109, 37, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(110, 37, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(111, 37, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(112, 38, '', '', '', '', '', '', '', '0.000000', '98.000000', '0.000000', 10, '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(113, 38, '', '', '', '', '', '', '', '0.000000', '0.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(114, 38, '', '', '', '', '', '', '', '0.000000', '81.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(115, 38, '', '', '', '', '', '', '', '0.000000', '16.000000', '0.000000', 10, '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_attribute_combination`
--

CREATE TABLE `ps_product_attribute_combination` (
  `id_attribute` int(10) UNSIGNED NOT NULL,
  `id_product_attribute` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_product_attribute_combination`
--

INSERT INTO `ps_product_attribute_combination` (`id_attribute`, `id_product_attribute`) VALUES
(46, 60),
(46, 63),
(46, 64),
(46, 67),
(46, 68),
(46, 71),
(46, 72),
(46, 75),
(46, 76),
(46, 79),
(46, 80),
(46, 83),
(46, 84),
(46, 87),
(46, 88),
(46, 91),
(46, 92),
(46, 95),
(46, 96),
(46, 99),
(46, 100),
(46, 103),
(46, 104),
(46, 107),
(46, 108),
(46, 111),
(46, 112),
(46, 115),
(47, 61),
(47, 62),
(47, 65),
(47, 66),
(47, 69),
(47, 70),
(47, 73),
(47, 74),
(47, 77),
(47, 78),
(47, 81),
(47, 82),
(47, 85),
(47, 86),
(47, 89),
(47, 90),
(47, 93),
(47, 94),
(47, 97),
(47, 98),
(47, 101),
(47, 102),
(47, 105),
(47, 106),
(47, 109),
(47, 110),
(47, 113),
(47, 114),
(48, 60),
(48, 62),
(48, 64),
(48, 66),
(48, 68),
(48, 70),
(48, 72),
(48, 74),
(48, 76),
(48, 78),
(48, 80),
(48, 82),
(48, 84),
(48, 86),
(48, 88),
(48, 90),
(48, 92),
(48, 94),
(48, 96),
(48, 98),
(48, 100),
(48, 102),
(48, 104),
(48, 106),
(48, 108),
(48, 110),
(48, 112),
(48, 114),
(49, 61),
(49, 63),
(49, 65),
(49, 67),
(49, 69),
(49, 71),
(49, 73),
(49, 75),
(49, 77),
(49, 79),
(49, 81),
(49, 83),
(49, 85),
(49, 87),
(49, 89),
(49, 91),
(49, 93),
(49, 95),
(49, 97),
(49, 99),
(49, 101),
(49, 103),
(49, 105),
(49, 107),
(49, 109),
(49, 111),
(49, 113),
(49, 115);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_attribute_image`
--

CREATE TABLE `ps_product_attribute_image` (
  `id_product_attribute` int(10) UNSIGNED NOT NULL,
  `id_image` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_attribute_shop`
--

CREATE TABLE `ps_product_attribute_shop` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_product_attribute` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL,
  `wholesale_price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ecotax` decimal(17,6) NOT NULL DEFAULT 0.000000,
  `weight` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `unit_price_impact` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `default_on` tinyint(1) UNSIGNED DEFAULT NULL,
  `minimal_quantity` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `low_stock_threshold` int(10) DEFAULT NULL,
  `low_stock_alert` tinyint(1) NOT NULL DEFAULT 0,
  `available_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_product_attribute_shop`
--

INSERT INTO `ps_product_attribute_shop` (`id_product`, `id_product_attribute`, `id_shop`, `wholesale_price`, `price`, `ecotax`, `weight`, `unit_price_impact`, `default_on`, `minimal_quantity`, `low_stock_threshold`, `low_stock_alert`, `available_date`) VALUES
(25, 60, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(25, 61, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(25, 62, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(25, 63, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(26, 64, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(26, 65, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(26, 66, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(26, 67, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(27, 68, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(27, 69, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(27, 70, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(27, 71, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(28, 72, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(28, 73, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(28, 74, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(28, 75, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(29, 76, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(29, 77, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(29, 78, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(29, 79, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(30, 80, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(30, 81, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(30, 82, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(30, 83, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(31, 84, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(31, 85, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(31, 86, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(31, 87, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(32, 88, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(32, 89, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(32, 90, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(32, 91, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(33, 92, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(33, 93, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(33, 94, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(33, 95, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(34, 96, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(34, 97, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(34, 98, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(34, 99, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(35, 100, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(35, 101, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(35, 102, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(35, 103, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(36, 104, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(36, 105, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(36, 106, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(36, 107, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(37, 108, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(37, 109, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(37, 110, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(37, 111, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(38, 112, 1, '0.000000', '98.000000', '0.000000', '0.000000', '0.000000', 1, 1, NULL, 0, '0000-00-00'),
(38, 113, 1, '0.000000', '0.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(38, 114, 1, '0.000000', '81.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00'),
(38, 115, 1, '0.000000', '16.000000', '0.000000', '0.000000', '0.000000', NULL, 1, NULL, 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_carrier`
--

CREATE TABLE `ps_product_carrier` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_carrier_reference` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_comment`
--

CREATE TABLE `ps_product_comment` (
  `id_product_comment` int(10) UNSIGNED NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED NOT NULL,
  `id_guest` int(10) UNSIGNED DEFAULT NULL,
  `title` varchar(64) DEFAULT NULL,
  `content` text NOT NULL,
  `customer_name` varchar(64) DEFAULT NULL,
  `grade` float UNSIGNED NOT NULL,
  `validate` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_comment_criterion`
--

CREATE TABLE `ps_product_comment_criterion` (
  `id_product_comment_criterion` int(10) UNSIGNED NOT NULL,
  `id_product_comment_criterion_type` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_product_comment_criterion`
--

INSERT INTO `ps_product_comment_criterion` (`id_product_comment_criterion`, `id_product_comment_criterion_type`, `active`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_comment_criterion_category`
--

CREATE TABLE `ps_product_comment_criterion_category` (
  `id_product_comment_criterion` int(10) UNSIGNED NOT NULL,
  `id_category` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_comment_criterion_lang`
--

CREATE TABLE `ps_product_comment_criterion_lang` (
  `id_product_comment_criterion` int(11) UNSIGNED NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_product_comment_criterion_lang`
--

INSERT INTO `ps_product_comment_criterion_lang` (`id_product_comment_criterion`, `id_lang`, `name`) VALUES
(1, 1, 'Quality');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_comment_criterion_product`
--

CREATE TABLE `ps_product_comment_criterion_product` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_product_comment_criterion` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_comment_grade`
--

CREATE TABLE `ps_product_comment_grade` (
  `id_product_comment` int(10) UNSIGNED NOT NULL,
  `id_product_comment_criterion` int(10) UNSIGNED NOT NULL,
  `grade` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_comment_report`
--

CREATE TABLE `ps_product_comment_report` (
  `id_product_comment` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_comment_usefulness`
--

CREATE TABLE `ps_product_comment_usefulness` (
  `id_product_comment` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED NOT NULL,
  `usefulness` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_country_tax`
--

CREATE TABLE `ps_product_country_tax` (
  `id_product` int(11) NOT NULL,
  `id_country` int(11) NOT NULL,
  `id_tax` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_download`
--

CREATE TABLE `ps_product_download` (
  `id_product_download` int(10) UNSIGNED NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `display_filename` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `date_expiration` datetime DEFAULT NULL,
  `nb_days_accessible` int(10) UNSIGNED DEFAULT NULL,
  `nb_downloadable` int(10) UNSIGNED DEFAULT 1,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `is_shareable` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_group_reduction_cache`
--

CREATE TABLE `ps_product_group_reduction_cache` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_group` int(10) UNSIGNED NOT NULL,
  `reduction` decimal(5,4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_lang`
--

CREATE TABLE `ps_product_lang` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `description` text DEFAULT NULL,
  `description_short` text DEFAULT NULL,
  `link_rewrite` varchar(255) NOT NULL,
  `meta_description` varchar(512) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_title` varchar(128) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `available_now` varchar(255) DEFAULT NULL,
  `available_later` varchar(255) DEFAULT NULL,
  `delivery_in_stock` varchar(255) DEFAULT NULL,
  `delivery_out_stock` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_product_lang`
--

INSERT INTO `ps_product_lang` (`id_product`, `id_shop`, `id_lang`, `description`, `description_short`, `link_rewrite`, `meta_description`, `meta_keywords`, `meta_title`, `name`, `available_now`, `available_later`, `delivery_in_stock`, `delivery_out_stock`) VALUES
(25, 1, 1, '<h2>Opis</h2><span></span><p>Witaj! Jestem Sebastian. Znam <strong>Photoshopa </strong>od roku 1994, więc to już ponad 25 lat (ćwierć wieku!). Zaczynałem jako grafik w studiu poligraficznym, następnie w roku 2000 przeskoczyłem na <strong>profesjonalną fotografię</strong>, a w 2014 dodałem do tego <strong>film</strong>. W każdym z tych obszarów <strong>Photoshop </strong>był nieocenionym narzędziem i dzięki jego znajomości z wielu perspektyw, możesz liczyć na <strong>solidne wsparcie</strong>.</p><p>W tym kursie nauczysz się <strong>praktycznego</strong> wykorzystania Photoshopa, poznasz wszystkie niezbędne narzędzia i techniki do tworzenia <strong>projektów graficznych, obróbki oraz retuszu zdjęć</strong>.</p><p>Podążając za moimi wskazówkami i tworząc własne projekty, będziesz w stanie stworzyć <strong>własne portfolio</strong>, dodać Photoshopa do swojego <strong>CV </strong>i <strong>zwiększyć swoje szanse na rynku pracy</strong>. Po przejściu całego kursu otrzymasz <strong>certyfikat ukończenia</strong>.</p><p>Ten kurs jest dla początkujących, co oznacza, że nie potrzebujesz żadnego wcześniejszego doświadczenia z <strong>Adobe Photoshop. </strong>Dzięki zwięzłym, praktycznym wskazówkom opanujesz wszystkie niezbędne narzędzia i ustawienia tak, żeby z poczuciem pewności stawić czoło najróżniejszym wyzwaniom.</p><p>Wewnątrz kursu znajdziesz <strong>wszystkie materiały i zdjęcia</strong> na których demonstruję poszczególne techniki pracy w Adobe Photoshop - możesz je <strong>pobrać</strong> na swój komputer i <strong>ćwiczyć na nich razem ze mną.</strong></p><p>Jeśli nigdy jeszcze nie otworzyłeś Photoshopa lub masz trudności z podstawami, podążaj za moimi instrukcjami, a na pewno staniesz się fachowcem!</p><p>W razie jakichkolwiek trudności - <strong>zawsze możesz mnie zapytać</strong> wewnątrz kursu - bardzo chętnie pomogę!</p><h2>Dla kogo jest ten kurs</h2><ul><li>Osoby, które jeszcze nigdy nie próbowały pracować w programie Photoshop oraz te, które już mają za sobą pierwsze próby</li><li>Osoby, które już znają Adobe Photoshop, ale chciałyby usystematyzować swoją wiedzę</li></ul>', 'Nauczysz się jak w Adobe Photoshop obrabiać i retuszować zdjęcia oraz tworzyć piękne grafiki - dzięki jasnym instrukcjom', 'adobe-photoshop-cc-kurs-od-poczatkujacego-do-zawodowca-nauczysz-sie-jak-w-adobe-photoshop-obrabiac-i-retuszowac-zdjecia-oraz-tworzyc-piekne-grafiki---dzieki-jasnym-instrukcjom', '', '', '', 'Adobe Photoshop CC: Kurs Od Początkującego Do Zawodowca\nNauczysz się jak w Adobe Photoshop obrabiać i retuszować zdjęcia oraz tworzyć piękne grafiki - dzięki jasnym instrukcjom', '', '', '', ''),
(26, 1, 1, '<h2>Opis</h2><span></span><p>Photoshop to prawdopodobnie najbardziej wszechstronny program z jakim kiedykolwiek się spotkałeś. Obok edycji zdjęć stworzysz w nim także interfejsy stron WWW i aplikacji, fantastyczne ilustracje, a nawet będziesz pracował z materialem wideo i 3D. Ogrom możliwości jak również ilość zasobów może przytłaczać - dlatego niezwykle starannie przygotowaliśmy dla Ciebie kurs, który jest esencja doświadczenia jego autora, wieloletniego trenera i praktyka Photoshop a także Certyfikowanego Eksperta Adobe. To nasz flagowy kurs Photoshop, który doceniły tysiące klientów - nagrany na nowo, tak abyś mógł wykorzystać pełen potencjał najnowszych wersji programu. Jeśli zaczynasz przygodę z Photoshopem i od początku chcesz nabyć poprawne nawyki - nie wahaj się ani chwili, to jest materiał dla Ciebie!</p>\n\n<p><strong>Fundament pracy z grafiką rastrową</strong></p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p>Wadą wielu tutoriali, które znajdziesz w sieci, jest nakierowanie na osiągnięcie konkretnego i tylko jednego efektu. W Kursie, który opracowaliśmy, znajdziesz odpowiedzi na pytania nie tylko jak to jest zrobione, ale przede wszystkim dlaczego. Poznając zagadnienia takie jak teoria kolorów, specyfika grafiki rastrowej czy interpolacji pikseli, zrozumiesz mechanizmy, które działają pod maską narzędzi Photoshopa, co pozwoli Ci wykorzystać je we właściwy sposób.</p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p><strong>Formaty plików oraz narzędzia Bridge i Camera Raw</strong></p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p>Poznasz także podstawy pracy z niezwykle przydatnymi aplikacjami, które dostępne są razem z Adobe Photoshop. Poznasz specyfikę formatów plików i szybką nawigację z Adobe Bridge, a także dowiesz się jak pracować z korektą fotografii w Camera RAW. Obrazowo wyjaśnimy zalety jednych formatów nad innymi, kompresję oraz zapisywanie plików na potrzeby sieci jak również przygotowanie ich do druku.</p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p><strong>Korekta i edycja fotografii</strong></p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p>Podczas całego kursu zaprezentujemy dziesiątki praktycznych przykładów i zastosowań związanych z korektą obrazu - począwszy od Camera RAW, w którym wykonamy korektę zdjęcia, przez kluczowe funkcje Photoshopa i warstwy korekcyjne, które pozwolą Ci dostosować jasność, nasycenie, kolory i sprawią, że Twoja fotografia będzie wyglądała naprawdę świetnie.</p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p><strong>Praktyczny projekt retuszu</strong></p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p>Na koniec Kursu, kiedy już sprawnie będziesz poruszał się w interfejsie i znał mechanizmy działania Photoshopa, wykonamy praktyczny projekt w ramach którego poznasz szereg ciekawych technik retuszu w Photoshopie. Poprawimy zdjęcie modelki z którego usuniemy niedoskonałości, dodamy makijaż, poprawimy kolory i wiele więcej, poznając przy tym dziesiątki skrótów i ciekawych technik, które pozwolą Ci wyciągnąć z fotografii jeszcze więcej!</p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p><strong>Techniki Ekspertów na wyciągnięcie ręki</strong></p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p>W Internecie znajdziesz masę materiałów na temat Photoshopa. Zaletą naszego kursu jest fakt, iż został on przemyślany tak aby stanowić kompleksowe Kompendium i oszczędzić Ci dziesiątek godzin poszukiwań oraz nakierować na prawidłowy tok myślenia i poprawne nawyki. Po przerobieniu materiału będziesz w pełni świadomy nabytych umiejętności, jak również poznasz dobre nawyki, które zaprocentują w przyszłości. W przeciwieństwie do wielu podstawowych kursów, w kolejnych lekcjach będziesz odkrywał coraz bardziej zaawansowane techniki, z którymi pracują eksperci, takie jak maski, złożone selekcje, kanały i wiele więcej!</p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p><strong>Narzędzia wektorowe i praca z interfejsami</strong></p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p>Na przestrzeni kursu zapoznasz się z narzędziami, które ułatwią pracę z projektowaniem layoutów stron WWW czy aplikacji mobilnych. Począwszy od podstawowych ustawień programu Photoshop, przez preferencje siatki i organizację pola pracy, aż do narzędzi wektorowych, własnych kształtów oraz stylów warstw, które pomogą Ci osiągnąć pożądane efekty. Dowiesz się także jak skutecznie eksportować grafikę na potrzeby sieci.</p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p><strong>Typografia w Adobe Photoshop</strong></p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p>Photoshop jest niezwykle zaawansowanym narzędziem także w kontekście edycji tekstu oraz typografii. Możliwości nowych narzędzi w Photoshop CC pozwolą Ci także emulować wygląd tekstu na Mac i Windows, a obszerne biblioteki Typekit pozwolą na wykorzystanie w projektach setek wysokiej jakości fontów. W jednym z praktycznych projektów, stworzymy także niezwykle ciekawy, stylizowany tekst przy okazji poznając szereg faktastycznych efektów warstw!</p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p><strong>Efekty graficzne i Style</strong></p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p>W Kursie dowiesz się jak wykorzystać cały potencjał Adobe Photoshop - odkryjesz niesamowite Filtry i ich niecodzienne zastosowania, przydatne Style Warstw, a także bardziej zaawansowane efekty jak Tryby Mieszania i wykorzystanie Warstw Korekcyjnych. Dopiero połączenie tych technik pozwoli Ci zrozumieć, jaki potencjał drzemie w Adobe Photoshop i wkrótce zrozumiesz, że jego możliwości ogranicza w zasadzie tylko Twoja wyobraźnia!</p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p><strong>Praktyczne zastosowania oraz automatyzacja w Photoshop</strong></p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p>Główny nacisk położony został na przedstawienie narzędzi oraz tricków i technik procesu edycji zdjęć na praktycznych przykładach. Chodzi np. o przekształcanie, wycinanie, kadrowanie, poprawa kolorów i kontrastu, usuwanie szumów. Poznasz także ciekawe dodatki związane z Photoshopem, jak również sposoby na automatyzację i usprawnienie procesów z pomocą akcji!<br /></p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p><strong>Dla kogo jest ten kurs?</strong></p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p>Moim zadaniem jest przedstawienie Ci Adobe Photoshop, tak abyś zaprzyjaźnił się z interfejsem i funkcjami aplikacji i w procesie twórczym nie musiał zastanawiać się nad tym, z jakiego narzędzia skorzystać. Kurs przeznaczony jest dla osób początkujących, które stawiają swoje pierwsze kroki w Adobe Photoshop, ale także dla tych z Was, którzy pracują bądź pracowali już z tym fantastycznym programem i chcą uzupełnić podstawy a także dobre praktyki, które stanowią fundament wiedzy ekspertów. Jestem przekonany, że po przerobieniu kursu będziesz pewnie poruszał się w interfejsie programu a także będziesz dokładnie wiedział, jaki kierunek wybrać aby uzupełnić swoje umiejętności - jest to kolejny doskonały powód aby wybrać ten kurs, ponieważ nasza ścieżka Photoshop dopiero się tutaj zaczyna, a jej kontynuacja jest starannie dobraną kontynuacją materiału, który masz przed sobą!</p>\n\n\n\n<p>Autorem kursu jest Grzegorz Róg.<br /></p><p>Do tego kursu nie udzielamy wsparcia w ramach serwisu Udemy. <br /></p><h2>Dla kogo jest ten kurs</h2><ul><li>Osoby początkujące, które stawiają pierwsze kroki w dziedzinie grafiki komputerowej</li><li>Wszyscy Ci, którzy chcą rozwinąć swoje umiejętności obsługi Photoshopa</li><li>Osoby zainteresowane obróbką zdjęć i fotografią</li></ul>', 'Poznaj aplikacje Adobe Photoshop i naucz się profesjonalnej obróbki zdjęć oraz poznaj podstawy grafiki komputerowej', 'kurs-photoshop-cc-od-podstaw-poznaj-aplikacje-adobe-photoshop-i-naucz-sie-profesjonalnej-obrobki-zdjec-oraz-poznaj-podstawy-grafiki-komputerowej', '', '', '', 'Kurs Photoshop CC od Podstaw\nPoznaj aplikacje Adobe Photoshop i naucz się profesjonalnej obróbki zdjęć oraz poznaj podstawy grafiki komputerowej', '', '', '', ''),
(27, 1, 1, '<h2>Opis</h2><span></span><p>Witaj w kursie Web Design - Szybki Start! Web design jest niezwykle dynamicznie rozwijającą się branżą. Rosnące zainteresowanie projektowaniem stron www idzie w parze z rozwojem technologii, ale i oczekiwań względem web designerów. Dla osób, które dopiero rozpoczynają swoją przygodę z web designem, przygotowaliśmy praktyczne i uporządkowane kompendium wiedzy, które otworzy przed nimi nowe możliwości i pozwoli na rozpoczęcie pracy w tej branży. \n\nNa początku zajmiemy się wprowadzeniem Cię w technologie webowe i omówimy pokrótce każdą z nich. Dowiesz się jak zbudowane są strony WWW oraz z jakich elementów się składają. Prowadzący opowie Ci o istotnych obecnie zagadnieniach, takich jak Responsive Web Design czy Mobile First, dzięki którym już na początku swojej pracy z web designem będziesz przygotowany do wyzwań, jakie stoją przed współczesnymi projektantami. \n\nOpowiemy Ci o wszystkim, co musisz wiedzieć, by tworzyć nowoczesne strony oraz aplikacje zgodne zarówno ze standardami, jak i pasujące do oczekiwań klientów i użytkowników strony. Przejdziemy płynnie do podstaw języków programowania HTML i CSS, dzięki czemu po poznaniu praktycznych przykładów i ich zastosowań będziesz gotowy do wprowadzenia podstaw kodowania do Twoich projektów. Następnie wspólnie pod okiem prowadzącego wykonamy praktyczny projekt funkcjonalnej strony WWW od A do Z. </p>\n\n<p>Na zakończenie kursu poznasz informacje na temat konfiguracji środowiska i edytora kodu, które znacznie usprawnią Twoją codzienną pracę, a także przedstawimy Ci wiele przydanych, dodatkowych narzędzi, dzięki którym znacznie łatwiej i bardziej intuicyjnie będziesz odnajdować się w nowej branży. To wszystko oraz o wiele więcej czeka na Ciebie w kursie Web Design - Szybki Start!</p>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<p>Kurs przygotowany został z myślą o osobach, które nigdy przedtem nie miały do czynienia z projektowaniem stron WWW i chcą zapoznać się z podstawami web designu na praktycznych przykładach. Ponieważ web design jest zagadnieniem niezwykle rozbudowanym, bardzo ważne jest to, by już od samego początku wyrobić w sobie prawidłowe nawyki, poznać najważniejsze narzędzia oraz nie ominąć żadnych podstawowych informacji, które następnie mogłyby zablokować nas na bardziej zaawansowanym poziomie nauki. Dlatego duży nacisk położony został na przejście przez każdy etap tworzenia strony www od A do Z - a praca nad tym projektem okaże się znacznie prostsza i przyjemniejsza, niż możesz się spodziewać! </p>\n\n\n\n\n\n<p>Autorem kursu jest Grzegorz Róg.</p><p>Do tego kursu nie udzielamy wsparcia w ramach serwisu Udemy. <br /></p><h2>Dla kogo jest ten kurs</h2><ul><li>Każdy, kto chciałby rozpocząć projektowanie stron internetowych</li></ul>', 'Stwórz od podstaw swoją pierwszą stronę internetową i poznaj najważniejsze zasady UX', 'kurs-web-design-i-ux---szybki-start-stworz-od-podstaw-swoja-pierwsza-strone-internetowa-i-poznaj-najwazniejsze-zasady-ux', '', '', '', 'Kurs Web Design i UX - Szybki Start\nStwórz od podstaw swoją pierwszą stronę internetową i poznaj najważniejsze zasady UX', '', '', '', ''),
(28, 1, 1, '<h2>Opis</h2><span></span><p>Kurs poświęcony jest podstawom programu Adobe Illustrator przedstawionym na wersji CC 2017. Na samym początku wyjaśnione zostaną fundamentalne kwestie które trzeba opanować przed przystąpieniem do pracy z programem. Cały kolejny dział poświęcony jest podstawowym narzędziom i funkcjom które są niezbędne podczas codziennej pracy. Po przerobieniu fundamentalnych zagadnień stworzymy najpierw prosty obiekt w stylu flat design.Następnie zajmiemy się nieco bardziej skomplikowaną ilustrację, aby utrwalić nowe wiadomości i poznać kolejne opcje już w praktyce. Dalej czekają na nas działy rozwijające konkretne zagadnienia. Najpierw zajmiemy się problemami z  jakimi możemy się spotkać podczas pracy nad niewielkimi ikonami, następnie przejdziemy do narzędzi do wprowadzania tekstu i na koniec poznamy tajniki obsługi plików rastrowych w Illustratorze.</p><p><br /></p><p>Z wiedzą wyniesioną z kursu będziesz w stanie sprawnie poruszać się po programie Illustrator i nabędziesz techniczne umiejętności pozwalające na wykonanie podstawowych prac graficznych</p><p><br /></p><p><strong>Dla kogo skierowany jest kurs?</strong></p><p>Kurs jest skierowany do osób, które chcą poznać Adobe Illustrator od podstaw i nie posiadają wiedzy z zakresu grafiki wektorowej. Jeśli wcześniej miałeś styczność z programami graficznymi jak na przykład Photoshop, zdecydowanie ułatwi Ci to naukę - nie jest to jednak koniecznością!</p><p><br /></p><p><strong>W kursie zostały poruszone takie tematy, jak</strong></p><ul><li><p>Teoria grafiki wektorowej</p></li><li><p>Różnica pomiędzy ppi a dpi</p></li><li><p>Interfejs Illustratora</p></li><li><p>Poruszanie się po dokumencie</p></li><li><p>Narzędzia selekcji</p></li><li><p>Tworzenie kształtów podstawowych</p></li><li><p>Pentool</p></li><li><p>Modyfikacje ścieżek</p></li><li><p>Panel warstw i podwarstw</p></li><li><p>Wypełnienia i obrysy</p></li><li><p>Align tool</p></li><li><p>Transformacje obiektów</p></li><li><p>Pathfinder</p></li><li><p>Isolation mode</p></li><li><p>Outline view</p></li><li><p>Linie pomocnicze i grid</p></li><li><p>Praca w Illustratorze z tabletem</p></li><li><p>Panel appearance</p></li><li><p>Tworzenie gradientów</p></li><li><p>Tworzenie styli graficznych</p></li><li><p>Biblioteki presetów</p></li><li><p>Wzorki</p></li><li><p>Panel swatchy</p></li><li><p>Efekty wektorowe i rastrowe</p></li><li><p>Panel character i paragraph</p></li><li><p>Tworzenie tekstu na ścieżce</p></li><li><p>Biblioteka typekit</p></li><li><p>Zamiana tekstu na krzywe</p></li></ul><h2>Dla kogo jest ten kurs</h2><ul><li>Kurs jest skierowany do osób, które chcą poznać Adobe Illustrator od podstaw i nie posiadają wiedzy z zakresu grafiki wektorowej. Jeśli wcześniej miałeś styczność z programami graficznymi jak na przykład Photoshop, zdecydowanie ułatwi Ci to naukę - nie jest to jednak koniecznością!</li></ul>', 'Chcesz tworzyć niesamowite grafiki 2d? Sprawdź koniecznie nasz kurs!', 'adobe-illustrator-od-podstaw-chcesz-tworzyc-niesamowite-grafiki-2d-sprawdz-koniecznie-nasz-kurs', '', '', '', 'Adobe Illustrator od podstaw\nChcesz tworzyć niesamowite grafiki 2d? Sprawdź koniecznie nasz kurs!', '', '', '', ''),
(29, 1, 1, '<h2>Opis</h2><span></span><p>Z kursu dowiesz się co to jest Canva i dlaczego jest najlepsza! Nauczymy się jak tworzyć piękne prace korzystając z szablonów Canvy, jak również pokażemy jak tworzyć materiały całkowicie od zera. Opowiemy o Canvie Pro oraz jak uzyskać darmowy do niej dostęp dzięki Canvie dla edukacji. Jeśli zatem jesteś nauczycielem, będziesz miał dostęp do pełnej funkcjonalności Canvy całkowicie za darmo.</p><p>Dowiesz się także jak udostępniać stworzone prace innych oraz jak je prezentować na żywo. Na sam koniec poruszymy mocno temat pracy w zespołach i grupach, dowiesz się jak udostępnić konkretne prace konkretnym osobom/grupom aby mogli na nich pracować razem. Duża dawka wiedzy podana w odpowiedni sposób, sprawdź sam!</p><p>Oto materiały jakie przygotowujemy w ramach kursu</p><ul><li><p>Dyplom / certyfikat</p></li><li><p>Podziękowania dla rodziców</p></li><li><p>Zakładka do książki</p></li><li><p>Wirtualna klasa</p></li><li><p>Test / arkusz</p></li><li><p>Infografika</p></li><li><p>Wideo</p></li><li><p>E-booki</p></li><li><p>Avatarki Bitmoji</p></li></ul><p>Kurs prowadzony jest przez doświadczonego prowadzącego, który przeprowadził już ponad 100 szkoleń online pod marką \"Akademia Genialnego Nauczyciela\" oraz \"Nauczyciel w Necie\". Koniecznie znajdź nas na Facebooku i dołącz do naszej grupy, gdzie skupiamy fanów Genially, Canvy, Wordwalla, Wakeleta, LearningApps i innych narzędzi dedykowanych nauczaniu zdalnemu.</p><p>No i najważniejsze, gdy już przejdziesz przez kurs, daj nam znać jak się podobał i koniecznie zostaw opinię na serwisie Udemy. Jeśli kurs przypadł Ci do gustu, będziemy wdzięczni za polecenie go znajomym i/lub udostępnienie go na mediach społecznościowych!</p><p>Niech moc będzie z Tobą Kursancie!</p><p><br /></p><h2>Dla kogo jest ten kurs</h2><ul><li>Nauczyciele przygotowujący materiały online na lekcje</li><li>Osoby tworzące interaktywne materiały dydaktyczne</li><li>Każdy kto chce zgłębić wiedzę o Canvie</li></ul>', 'Poznaj Canvę i przenieś swoje interaktywne prace oraz nauczanie zdalne na wyższy poziom!', 'canva-bez-tajemnic---kurs-dla-poczatkujacych-poznaj-canve-i-przenies-swoje-interaktywne-prace-oraz-nauczanie-zdalne-na-wyzszy-poziom', '', '', '', 'Canva bez tajemnic - kurs dla początkujących\nPoznaj Canvę i przenieś swoje interaktywne prace oraz nauczanie zdalne na wyższy poziom!', '', '', '', ''),
(30, 1, 1, '<h2>Opis</h2><span></span><p>Witaj w Kursie Photoshop - Szybki Start! W naszym materiale zapoznasz się z podstawami pracy z tym uniwersalnym narzędziem wykorzystywanym przez grafików i designerów, a także rekreacyjnych użytkowników. To doskonały wybór dla wszystkich osób, które dopiero zaczynają swoją przygodę z grafiką komputerową i szukają kursu, który przeprowadzi ich przez tajniki Photoshopa od samych podstaw. \n\nNa początku dowiesz się, jakie są podstawowe różnice między grafiką wektorową a bitmapami oraz kiedy należy wykorzystywać te rodzaje grafik. Wraz z prowadzącym poznasz najpopularniejsze aplikacje do obróbki grafiki i sprytnego zarządzania plikami, tak, byś już od samego początku pracował z Photoshopem w sposób jak najbardziej efektywny. Zajmiemy się pracą ze zdjęciami o różnych rodzajach i rozdzielczości, dzięki czemu będziesz przygotowany do pracy nad każdego typu projektami. </p>\n\n<p>Następnym krokiem będzie przejście do takich zagadnień, jak kadrowanie, transformacje i selekcje. Po poznaniu podstawowych zagadnień i technik pracy przejdziemy do tematów, które pomogą Ci zoptymalizować stojące przed Tobą zadania. Omówimy najważniejsze ustawienia Photoshopa w celu zwiększenia wydajności, a na koniec zapoznasz się również z przydatnymi skrótami klawiszowymi. Wszystkie omawiane zagadnienia pokażemy Ci nie tylko w formie teoretycznej, lecz również na praktycznych przykładach, tak, by Twoja praca z Photoshopem była poparta działaniem na rzeczywistym projekcie. \n\nNa zakończenie kursu przejdziemy do sekcji poświeconej Photoshow - która w pełni odkryje przed Tobą całą magię kryjącą się w tym praktycznym narzędziu Adobe. </p>\n\n\n\n\n\n\n\n\n\n<p>Materiał przygotowany został z myślą o osobach, które dopiero rozpoczynają swoją przygodę z Adobe Photoshop i chcą znaleźć w Kursie wszystkie niezbędne informacje. To doskonałe kompendium podstawowej wiedzy, po opanowaniu którego będziesz przygotowany do zagłębienia się w bardziej rozbudowane zagadnienia. Kurs, który masz przed sobą, oparty został na praktycznych przykładach oraz wieloletnim doświadczeniu prowadzącego, co pozwoli Ci uniknąć częstych błędów osób początkujących i wypracuje u Ciebie poprawne odruchy podczas pracy z tym narzędziem. <br /></p>\n\n\n\n<p>Autorem kursu jest Grzegorz Róg. </p><p>Do tego kursu nie udzielamy wsparcia w ramach serwisu Udemy. <br /></p><h2>Dla kogo jest ten kurs</h2><ul><li>Osoby, które chcą w szybki sposób rozpocząć pracę z Adobe Photoshop</li></ul>', 'Zacznij przygodę z Adobe Photoshop i naucz się stawiać pierwsze kroki w obróbce zdjęć i grafice komputerowej', 'kurs-photoshop---szybki-start-zacznij-przygode-z-adobe-photoshop-i-naucz-sie-stawiac-pierwsze-kroki-w-obrobce-zdjec-i-grafice-komputerowej', '', '', '', 'Kurs Photoshop - Szybki Start\nZacznij przygodę z Adobe Photoshop i naucz się stawiać pierwsze kroki w obróbce zdjęć i grafice komputerowej', '', '', '', ''),
(31, 1, 1, '<h2>Opis</h2><span></span><p>Jako autor starałem się wyjaśnić poszczególne zagadnienia w taki sposób, aby były one <strong>zrozumiałe dla wszystkich</strong>. Jeżeli Twoja sytuacja zawodowa Cię nie zadowala, szukasz zmiany i masz chęci do nauki, to ten kurs jest właśnie dla Ciebie.<br /><br />Przed stworzeniem kursu starałem się przeszukać obecnie dostępne na rynku oferty i przeanalizować je pod kątem docelowego klienta. To, czego brakowało jednym kursom, to <strong>kompleksowość</strong>, czyli oparcia wszystkich tematów na przykładzie konkretnego produktu, w celu stworzenia spójnej całości. Minusem szkoleń i warsztatów, nawet jeśli są one w pełni kompleksowe, jest brak elastyczności. Zamiast być zobligowanym do pracy w trybie weekendowym i terminów oddania konkretnych zadań, każdy powinien sam decydować, kiedy jest dla niego<strong> najlepsza pora i czas na naukę</strong>.<br /><br />W moim kursie staram się posługiwać <strong>łatwym i przystępnym językiem</strong>, tak aby każdy, bez względu na wiek i doświadczenie zawodowe, mógł z łatwością przyswoić przekazywane przeze mnie treści. Dlatego jeśli jesteś osobą, która z jakichś powodów chce zmienić swoje zatrudnienie, przekwalifikować się lub która nadal szuka pomysłu na siebie, to zachęcam Cię do zapoznania się z tym kursem.<br /><br />Całość kursu to <strong>3 rozdziały</strong>, trwające łącznie <strong>9 godzin i 40 minut</strong>.<br /><br /><strong>01. ROZDZIAŁ BIZNES</strong><br /><strong>2 godziny i 12 minut</strong></p><ul><li><p>Wstęp do rozdziału biznes</p></li><li><p>Brief</p></li><li><p>Wprowadzenie do aplikacji miro</p></li><li><p>Mapa myśli</p></li><li><p>User Centered Design Canvas</p></li><li><p>Analiza SWOT</p></li><li><p>Technika MoSCoW</p></li></ul><p><br /></p><p><strong>02. ROZDZIAŁ UX</strong><br /><strong>4 godziny i 10 minut</strong></p><ul><li><p>Wstęp do rozdziału UX</p></li><li><p>Badania ilościowe i jakościowe</p></li><li><p>Przygotowanie ankiety i analiza wyników</p></li><li><p>Persony</p></li><li><p>Mapa empatii</p></li><li><p>Customer journey</p></li><li><p>Scenariusze</p></li><li><p>Flow map</p></li><li><p>Architektura informacji</p></li><li><p>Wireframe Lo-Fi vs Hi-Fi</p></li><li><p>Tworzenie wireframe\'ów UXPin</p></li><li><p>Prototypowanie</p></li><li><p>Testowanie</p></li></ul><p><br /></p><p><strong>03. ROZDZIAŁ UI</strong><br /><strong>3 godziny i 20 minut</strong></p><ul><li><p>Wstęp do rozdziału UI</p></li><li><p>Accessibility, czyli design dla wszystkich</p></li><li><p>Design system</p></li><li><p>O responsywności i czym jest grid</p></li><li><p>Tworzenie mockup\'ów w aplikacji Figma</p></li><li><p>Prototypowanie</p></li><li><p>Testowanie, heatmap\'a, testy A/B</p></li></ul><p>Do większości lekcji załączane są materiały, abyś mógł spokojnie się im przyjrzeć. Moim celem jest, abyś po ukończeniu tego kursu był/a w stanie samodzielnie podjąć swoje pierwsze kroki w zawodzie UX/UI Designera.</p><h2>Dla kogo jest ten kurs</h2><ul><li>Początkujący designerzy.</li><li>Osoby chcące rozpocząć pracę w IT.</li><li>Ludzie zainteresowani designem oraz UX/UI.</li><li>Każdy, kto chce się nauczyć projektować użyteczne produkty.</li></ul>', 'Kompleksowy kurs z obszarów research, user experience oraz user interface.', 'podstawowe-szkolenie-online-z-uxui-kompleksowy-kurs-z-obszarow-research-user-experience-oraz-user-interface', '', '', '', 'Podstawowe szkolenie online z UX/UI\nKompleksowy kurs z obszarów research, user experience oraz user interface.', '', '', '', ''),
(32, 1, 1, '<h2>Opis</h2><span></span><p>Kurs Grafika 3D MEGAPACK, to prawdziwe kompendium dla osób poszukujących lekcji z grafiki komputerowej. Kurs wprowadzi Cię w świat grafiki trójwymiarowej. Dzięki niemu nauczysz się, przygotowywać efektowne modele 3D i wizualizacje oraz poznasz tajniki pracy w aplikacjach AutoCAD, Inventor, 3ds max, Maya, Blender oraz w Rhino zobaczysz jak w praktyce twórzyć modele 3D pod druk 3D.</p><p><strong>** UWAGA UPDATE ** Kurs Grafika 3D MEGAPACK JUŻ JEST LIVE 2020 ! Poznaj możliwości UE4 wykorzystując wirtualną produkcję w praktyce!</strong></p><p><strong>Co możesz robić po obejrzeniu tego pakietu kursów?</strong></p><ul><li><p>Tworzyć assety do gier</p></li><li><p>Projektować unikalne przedmioty podarunkowe przy pomocy druku 3D</p></li><li><p>Zaprojektować swój wymarzony dom, samochód itd.</p></li><li><p>Nabędziesz umiejętność ekpresji poprzez grafike 3D</p></li><li><p>Renderować fotorealistyczne sceny przy pomocy darmowego oprogramowanie takiego jak <strong>Blender 2.8 czy UE 4.25 / 4.26</strong> !</p></li><li><p>Możesz rozpocząć karierę jako grafik 3D!</p></li></ul><p>To prawdziwe kompendium wiedzy o grafice 3D. Czego tak naprawdę dotyczy ten pakiet kursów?</p><p><br /></p><p><strong>Kurs Wprowadzenie do Wirtualnej Produkcji Unreal Engine 4 (*NOWOŚĆ 2020*)</strong></p><p>Silnik Unreal Engine jest używany przez największe studia produkcyjne tworzące filmy i gry. W tej serii filmów dowiesz się krok po kroku jaki hardware i software potrzebujesz żeby wykorzystywać potencją real-time renderingu. Seria jest kompendium wiedzy zebranej nt. bardzo rozwijającej się tematyki jaką jest Virtual Production. Wskakuj i dowiedz się więcej jak UE4 zmienia zasady gry i renderuje na żywo realtime rewolucjonizując pracę z grafika 3D. Ustawienie sceny, Tworzenie i importowanie postaci, Przechwytywanie motion capture przy pomocy zwykłego video z smartfona oraz wykorzystamy Kinect v2 +software do przechwytu ruchów postaci na żywo do silnika UE4 !</p><p><br /></p><p><strong>Kurs Inventor 2012 - 2016<br /></strong>Autodesk Inventor to bardzo rozbudowane narzędzie do projektowania części, które możemy poskładać w pełni działające maszyny. Bez tworzenia fizycznego modelu sprawdzisz co trzeba poprawić. Wszystko to dzięki rozbudowanemu interfejsowi, który w zależności od kontekstu zmienia wygląd i funkcje. Tu z pomocą przychodzi nasz kurs gdzie poznasz cały proces od rysowania i wymiarowania części aż po przymierzanie jej z resztą projektu.</p><p>Autorem tego kursu Inventor jest Mateusz Ertman. Mateusz pracuje w druku 3D i zajmuje się na co dzień grafika komputerowa 3D. Pracował w znanych Polskich startupach zajmując się projektowaniem drukarek 3D oraz innych rozwiązań wykorzystujących druk 3D w praktyce. <br /></p><p><strong>Czego się nauczę w tym kursie?</strong></p><ul><li><p>Jak narysować szkic</p></li><li><p>Jak określić wymiar</p></li><li><p>Co to zależności automatyczne</p></li><li><p>Jak powielać cechy</p></li><li><p>Jak tworzyć dokumentacje, przekroje oraz liste części</p></li><li><p>Zrobić praktyczny uchwyt na telefon, który możemy wydrukować np. na Drukarce 3D</p></li></ul><p><strong>\n</strong></p><p>Kurs przeznaczony jest dla osób, które nigdy nie korzystały z Inventora, lub posiadają podstawową wiedzę o tym programie.<br /></p><p><strong>Kurs AutoCAD 2011 - 2016 <br /></strong>Kreślenie, modelowanie i planowanie projektów</p><p>Naucz się w praktyce rysunku technicznego w 2,5 godziny. Przed Tobą pakiet filmów, które pozwolą Ci na szybkie i efektywne opanowanie programu AutoCAD. AutoCAD jest wykorzystywany w praktycznie każdej branży a umiejętność posługiwania się tym programem będzie wspomagać Twój proces projektowy. Wszystkie lekcje nagrane są w formie video, które krok po kroku demonstrują proces pracy z programem. Do Twojej dyspozycji oddajemy praktyczne filmy instruktażowych prowadzonych przez konstruktorów – praktyków z dziedziny projektowania CAD! <br /></p><p>Lekcje są opracowane tak, aby skorzystać z niego mogły zarówno osoby początkujące jak i te, które znają program. Do nauki wymagana jest dowolna wersja AutoCAD 2006-2016. Jeśli nigdy nie pracowałeś w CADzie, logiczny układ lekcji pozwoli Ci szybko utrwalić sobie poznawane funkcjonalności. Ponieważ w wersji 2009 AutoCAD zmienił wygląd ekranu, kurs zawiera omówienie zarówno starego jak i nowego widoku az do wersje AutoCAD 2016.<br /></p><p>Po omówieniu możliwości programu AutoCAD, zajmiemy się praktycznym zastosowaniem poznanych funkcji. Wykonamy rzut budynku, zaczynając od ścian, poprzez stolarkę i całe wyposażenie aż do końcowych opisów i rendering 3D.<br /></p><p>Autorem kursu jest Piotr Antecki w AutoCADzie pracuję od ponad 10 lat. Pierwsze kroki stawiał na studiach, aktualnie wykorzystuję go na co dzień pracując w Pracowni Projektowej Konstrukcji Budowlanych. Zdaję sobie sprawę, że dla nie wtajemniczonych AutoCAD może wyglądać groźnie i skomplikowanie. Zapewniam Was że tak nie jest. Niektóre rzeczy będą łatwe i proste w zrozumieniu, niektóre będą trudniejsze. W takim przypadku zachęcam do ponownego obejrzenia lekcji. Zachęcam również do samodzielnego przećwiczenia zagadnień z danej lekcji, na pewno prowadzić to będzie do lepszego opanowania zdobytej wiedzy.</p><p><strong>Kurs 3D Studio Max 2011 - 2016 </strong><br /></p><p>Projektowanie stoiska targowego rendering studyjny<br /></p><p>To prawdziwa gratka dla osób, które chcą rozpocząć swoją przygodę z grafiką 3D, ponieważ nie wymaga żadnej uprzedniej wiedzy o modelowaniu. Kurs jest adresowany również do osób zainteresowanych projektowaniem wnętrz i wizualizacjami. Jego twórcą jest doświadczony projektant, który chętnie dzieli się praktycznymi wskazówkami, co czyni proces nauki przyjemnym i inspirującym doświadczeniem.</p><p>Zagadnienia omówione w kursie</p><ul><li><p>Poznasz podstawy pracy w Studio 3D Max</p></li><li><p>Nauczysz się nawigacji po programie i przełączania się między widokami</p></li><li><p>Nauczysz się tworzyć obiekty i zmieniać ich właściwości</p></li><li><p>Nauczysz się dodawać, odejmować i edytować bryły, wykorzystując funkcje Boolean i opcje typu Slice On</p></li><li><p>Dowiesz się, jak wytłaczać bryły z dowolnego kształtu</p></li><li><p>Poznasz opcje kopiowania i skalowania elementów w 3D Studio Max</p></li><li><p>Dowiesz się jak edytować obiekty za pomocą Editable Mesh</p></li><li><p>Dowiesz się jak pracować z teksturami i mapować obiekty w programie</p></li><li><p>Nauczysz się ustawiać światła i poznasz ich rodzaje</p></li><li><p>Stworzysz kamery dla projektu, dowiesz się jak z nimi pracować i jak renderować widoki z kamer</p></li><li><p>Dowiesz się, jak importować i eksportować pliki w 3ds Max oraz z programów typu Photoshop czy Illustrator</p></li><li><p>Zobaczysz jak wykończyć projekt 3D w Picasa i przygotować wizualizację dla klienta</p></li></ul><p>Autorzy kursu to wieloletni grafik praktyktant Paweł Uniejewski zajmujący się renderingiem na potrzeby wizualizacji stoisk targowych.</p><p><strong>Kurs Maya 2011 - 2016<br /></strong> Kreatywne Projektowanie Postaci od zera<br /></p><p>Maya Kurs nauczy Cię, jak budować modele o czystej topologii bez zbytniego uszczerbku na ich wyglądzie. Zdobędziesz solidne podstawy z zakresu <strong>modelowania postaci</strong> i nakładania tekstur, dzięki którym unikniesz najczęściej popełnianych błędów przez początkujących.</p><p>Zagadnienia omówione w kursie</p><ul><li><p>Poznasz interfejs Maya i nauczysz się dostosowywać go do swoich potrzeb</p></li><li><p>Nauczysz się płynnej nawigacji po programie i przełączania się pomiędzy widokami</p></li><li><p>Nauczysz się tworzyć i modyfikować obiekty w Maya</p></li><li><p>Dowiesz się jak odejmować, ciąć i łączyć bryły i jak modelować obiekty symetryczne</p></li><li><p>Poznasz funkcję Extrude i jej opcje</p></li><li><p>Poznasz Slide Edge Tool i jego opcje</p></li><li><p>Nauczysz się modelować na poziomie poligonów, vertexów i krawędzi (edges)</p></li><li><p>Dowiesz się, na co zwracać szczególną uwagę i jak uniknąć błędów przy modelowaniu postaci pod animację</p></li><li><p>Nauczysz się pracować ze Sculp Geometry Tool i zobaczysz, jak ładnie wygładzić model</p></li><li><p>Dowiesz się jak pracować z teksturami i mapować obiekty w programie</p></li><li><p>Nauczysz się ustawiać opcje renderu</p></li><li><p>Zobaczysz, jak zbudować prosty szkielet postaci</p></li><li><p>Poznasz metody rigging\'u i skinning\'u w Maya. </p></li></ul><p>Autor kursu Arkadiusz Szplit jest Absolwentem Informatyki na Uniwersytecie im. Adama Mickiewicza, następnie Ilustracji i Designu na Uniwersytecie w Sunderland (UK). Grafiką 3D zajmuje się już ponad 10 lat. Pracuje na programach Maya, Zbrush 3, Photoshop CS5. Jego projekt zwyciężył w konkursie na maskotkę portalu mepi o czym zrealizował powyższy kurs.</p><p><strong>Kurs Blender 2.5 - 2.8 (nowość!)<br /></strong>Od Podstaw do mastera </p><p>Blender jest dla każdego i kązdy <strong>szanujący sie grafik 3D powinien go przynajmniej poznać</strong>. Dlaczego? To darmowy program do modelowania oraz animowania 3D. Jest to kompletne środowisko do pracy z obiektami trójwymiarowymi. Blender ma równie duże możliwości co komercyjne programy tego typu. Z całą pewnością jest to najpotężniejszy darmowy program do grafiki. Zobacz ten legendarny kurs, który przedstawia podstawowe aspekty pracy jak i bardziej zaawansowane techniki. Poradnik ten, krok po kroku pokaże w jaki sposób poruszać się po wszystkich funkcjach oraz przedstawi techniki modelowania, teksturowania oraz animacji.</p><p>Kurs Blender jest prowadzony przez Bartosz\'a Barłowskiego i Mateusza Ertmana. Bartosz wprowadzi cię w podstawy zajmuje się scenariuszem i produkcją filmów instruktażowych od ponad 10 lat. Pasją Mateusza jest druk 3D, grafika komputerowa 3D, IT oraz nowe technologie. Oboje pracowali w znanych Polskich startupach takich jak Omni 3D zajmując się projektowaniem drukarek 3D oraz innych rozwiązań wykorzystująych druk 3D. </p><p><strong>Kurs Rhinoceros 3D / Rhino 3D<br /></strong>Projektowanie parametryczne dla druku 3D</p><p>Oprogramowanie jest połączeniem CAD/CAM/CAE oraz Mesha. Program ten może być stosowany przy projektowaniu form przemysłowych, wspomaganiu procesów produkcji jak i podczas tworzenia interaktywnych animacji i gier.Wielkim plusem programu Rhino jest mnogość wtyczek, które pozwalają wzbogacić jego i tak spore możliwości projektowania poznasz jak <strong>projektowac parametrycznie w Grasshopper</strong>.</p><p> Kurs prowadzony przez Basia Pyper - specjalność Industrial Design ukończyła z wyróżnieniem na School of Form w Poznaniu. Basia pracując nad rozwiązaniami dla obecnych i przyszłych wyzwań w designie pokazuje jak parametrycznie można tworzyć modele 3D. Na uczelni zrealizowała projekt \"Polską Sztuką Ludową w języku Nowych technologii\" obecnie pracuje jako projektant w UK.</p><p><strong>Czy ten kurs jest dla mnie?</strong></p><p>Kompedium Grafik 3D to gratka dla każdej osoby, która chce zgłebiać tajniki grafiki 3D na wielu płaszczyznach nie ograniczając się do umiejętności obsługi tylko jednego programu. Przed Tobą swoi Twój świat. Zapisz się na ten unikalny kurs z grafiki i animacji komputerowej już dziś!</p><h2>Dla kogo jest ten kurs</h2><ul><li>Studenci kierunków artystycznych i inżynierii</li><li>Osoby chcące poszerzyć swoje umiejętności i znajomość programów takich jak AutoCAD, 3D Studio MAX, Inventor Blender, Rhino 3D,</li><li>Każda osoba, która interesuje się grafiką 3D</li><li>Twórcy kursów video, YouTuberzy, małe studia produkcyjne, Twórcy gier</li></ul>', 'Blender 2.8-2.9, UE4, AutoCAD, 3ds max, Maya, Inventor, oraz Rhino 3D. Praktyczne modelowanie i animacje 3D dla każdego.', 'kurs-grafika-3d-dla-poczatkujacych-7-szkolen-online-megapack-blender-28-29-ue4-autocad-3ds-max-maya-inventor-oraz-rhino-3d-praktyczne-modelowanie-i-animacje-3d-dla-kazdego', '', '', '', 'Kurs Grafika 3D dla początkujących 7 szkoleń online MEGAPACK\nBlender 2.8-2.9, UE4, AutoCAD, 3ds max, Maya, Inventor, oraz Rhino 3D. Praktyczne modelowanie i animacje 3D dla każdego.', '', '', '', ''),
(33, 1, 1, '<h2>Opis</h2><span></span><p>Witaj w kursie poświęconym grafice wektorowej. W trakcie tego materiału zapoznasz się z tajnikami tego zagadnienia, które jest nieodłącznym i podstawowym elementem pracy grafika. Z roku na rok zapotrzebowanie na graphic designerów poruszających się biegle w środowisku pracy z grafiką wektorową rośnie, a dzięki praktycznym przykładom, przygotowanym przez profesjonalistę z wieloletnim doświadczeniem, wprowadzimy Cię w techniki pracy od samych podstaw! Podczas kilkugodzinnego kursu zapoznasz się z niezwykle popularnym i praktycznym narzędziem od Adobe - Illustratorem. Zaczniemy od budowania prostych obiektów wektorowych, dzięki czemu zbudujesz solidne podstawy, które pozwolą Ci przejść do bardziej rozbudowanych projektów. Zapoznasz się z wachlarzem możliwości oferowanych przez różnorodne narzędzia zawarte w aplikacji Illustratora. Następnie przejdziemy do tworzenia na praktycznych przykładach pod okiem prowadzącego ilustracji flat oraz różnych technik tworzenia wektorów. Opowiemy Ci również nieco o cechach i właściwościach plików SVG, dzięki czemu praca z nimi będzie dla Ciebie wygodna i intuicyjna. </p>\n\n<p>Kurs przygotowany został z myślą o osobach, które nie miały uprzednio do czynienia z grafiką wektorową i chcą postawić pierwsze kroki w tej ciekawej i dynamicznie rozwijającej się dziedzinie grafiki. Od prostych kształtów, przez coraz bardziej rozbudowane, aż do dość zaawansowanych kompozycji graficznych - krok po kroku przeprowadzimy Cię przez wszystkie techniki, omawiając przydatne narzędzia oraz dzieląc się wskazówkami, które znacznie usprawnią Twoją codzienną pracę. Podczas kursu przygotujesz praktyczny projekt, dzięki czemu poczujesz się pewniej i będziesz mógł samodzielnie sprawdzić działanie omawianych funkcji.</p>\n\n<p>Do tego kursu nie udzielamy wsparcia w ramach serwisu Udemy. </p><h2>Dla kogo jest ten kurs</h2><ul><li>Każdy, kto chciałby tworzyć grafiki wektorowe</li><li>Osoby zainteresowane nauką Adobe Illustrator lub Affinity Designer</li></ul>', 'Pierwsze kroki z Grafiką Wektorową, Adobe Illustrator oraz Affinity Designer', 'kurs-grafika-wektorowa---szybki-start-pierwsze-kroki-z-grafika-wektorowa-adobe-illustrator-oraz-affinity-designer', '', '', '', 'Kurs Grafika Wektorowa - Szybki Start\nPierwsze kroki z Grafiką Wektorową, Adobe Illustrator oraz Affinity Designer', '', '', '', ''),
(34, 1, 1, '<h2>Opis</h2><span></span><p>Grafika 3D to kurs, w którym nauczymy się niezbędnych narzędzi do pracy z obiektami 3D w programie Blender.</p><p><br /></p><p>Stworzymy razem wiele praktycznych projektów, np Postacie z minecrafta, meble domowe i ogrodowe, podstawowe kopie rysunków technicznych oraz rzeczy, których używamy na co dzień. Dzięki różnorodności projektów, każdy znajdzie coś dla siebie. Wiadomo, że każdy ma swoje preferencje i upodobania dlatego rózna tematyka projektów sprawi, że będziecie mieli wiedzę w jaki sposób wykonać elementy z różnych kategorii.</p><p>Na początku będziemy uczyć się podstaw wielu aspektów związanych z grafiką 3D takich jak modelowanie, przygotowanie materiałów i tekstur, kompozycji, oświetlenia, animacji. Z czasem warto będzie zastanowić się co podoba Wam się najbardziej i rozwijać się głównie w wybranej dziedzinie, ponieważ nie można zostać ekspertem we wszystkim.</p><p><br /></p><p>Na początku kursu omówimy sobie podstawowe informacje związane z grafiką 3D i programem Blender. Następnie poznamy najczęsciej używane narzędzia i funkcje z kilkoma mniejszymi projektami po drodze. Przejdziemy do modyfikatorów i bardziej skomplikowanych projektów. Następnie poznamy podstawy animacji, a skończymy na podstawowych symulacjach fizycznych i systemach cząsteczek, abyście mogli zobaczyć jakie sa możliwości programu Blender. Choć w podstawowym kursie nie będziemy w stanie dojrzeć oceanu możliwości i niesamowitych funkcji jakie czekają na nas w programie.</p><p><br /></p><p>W kursie stworzymy postać Steva i Creepera z minecrafta, dodamy do nich materiały i ustawimy je w odpowiedniej pozycji do renderu. Stworzymy bloki z teksturami ziemi i lawy. Poza tym wymodelujemy buteleczkę kropli do nosa, mebel pod telewizor i latarkę. Nauczymy się dodawać materiał z efektem półprzezroczystości. Poznamy podstawy animacji i symulacji fizycznych. Na koniec zobaczymy jak może nam pomóc system cząsteczek w budowaniu obiektów z powtarzającymi elementami.</p><h2>Dla kogo jest ten kurs</h2><ul><li>Początkujący fascynaci tworzenia obiektów 3D</li></ul>', 'Nauka podstawowych narzędzi najnowszej wersji programu Blender 3.1 oraz różnorodnych aspektów pracy z modelami 3D', 'kurs-blendera-31---modelowanie-1-nauka-podstawowych-narzedzi-najnowszej-wersji-programu-blender-31-oraz-roznorodnych-aspektow-pracy-z-modelami-3d', '', '', '', 'Kurs Blendera 3.1 - Modelowanie sharp1\nNauka podstawowych narzędzi najnowszej wersji programu Blender 3.1 oraz różnorodnych aspektów pracy z modelami 3D', '', '', '', ''),
(35, 1, 1, '<h2>Opis</h2><span></span><p>Wiem, jak to jest, kiedy uruchamia się Illustratora i z przerażeniem i zniechęceniem patrzy na puste okno programu. Człowiek wtedy myśli <em>No i co teraz?</em></p><p>Pamiętam ile czasu spędziłem na szukaniu najlepszych sposobów na stworzenie projektów w Illustratorze.</p><p>Filmy, książki i poradniki, które znalazłem zawsze pozostawiały we mnie poczucie niemocy. Mysłałem <em>Musi być jakiś prostszy sposób, żeby to wszystko jakoś ogarnąć.</em></p><p>I na szczęście go znalazłem, a teraz chcę się nim z Tobą podzielić w tym kursie.</p><p>Ponieważ ten kurs to   </p><ul><li><p>Esencja najpotrzebniejszych i najprzydatniejszych funkcji programu, które w naprawdę krótkim czasie pozwolą Ci zacząć używać go samodzielnie.    </p></li><li><p>10 praktycznych projektów, pełnych tehnik i sztuczek używanych przez profesjonalistów z branży kreatywnej.   </p></li><li><p>Zwięzłe, proste w zrozumieniu lekcje, pozwalające na natychmiastwe zastosowanie zdobywanej wiedzy w praktyce   </p></li><li><p>Filmy w pełnej rozdzielczości HD, i o wysokiej jakości dźwięku.   </p></li><li><p>Do każdego projektu dodane materiały źródłowe, dzięki którym możesz łatwiej wykonywać polecenia w kursie.   </p></li></ul><p>To <strong>skondensowana i łatwa do przyswojenia bomba praktycznej wiedzy</strong> na temat najważniejszego programu do tworzenia grafiki wektorowej, jaki obecnie istnieje.</p><p>Koniec z poczuciem frustracji, bo nic Ci w illustratorze nie wychodzi.   </p><p>Koniec ze straconym czasem, który mógłbyś przeznaczyć na tworzenie projektów, zamiast zastanawiania się jak osiągnąć dany efekt.   </p><p>Ten kurs pomoże ci   </p><ul><li><p>Samodzielnie pracować  z Illustratorem   </p></li><li><p>Stosować zaawansowane techniki w prosty i łatwy do zapamiętania sposób   </p></li><li><p>Tworzyć projekty w stylu flat design</p></li></ul><p>Bez dłużyzn.   </p><p>Bez zbędnych ozdobników.   </p><p>Bez poczucia marnowanego czasu i pieniędzy</p><p>Przystępując do tego kursu, dobrze by było jakbyś miał jakieś doświadczenie w pracy z Illustratorem. Jeśli kiedykolwiek uruchomiłeś program, próbowałeś coś zrobić ale się zniechęciłeś, ten kurs przywróci ci wiarę w Illustratora.</p><p>Jeśli natomiast jesteś kompletnym nowicjuszem, to z początku możesz się czuć, że kurs toczy się nieco za szybko, ale już po 2-3 pierwszych projektach, powinieneś poczuć się dużo swobodniej.</p><p>Poza tym, jeśli coś będzie niejasne, zawsze możesz śmiało zapytać. </p><p>Chętnie pomogę!</p><p>Ten kurs nie jest jednak dla Ciebie, jeśli czujesz się ekspertem z Illustratora. (Choć przyznam, że często jestem zadziwiony (i ucieszony), jak osoby z wieloletnim stażem w pracy z Illustratorem mówią mi, ile nauczyły się dzięki moim kursom).</p><p>Ponadto, jeśli z jakiegokolwiek powodu kurs nie spełni Twoich oczekiwań, zawsze możesz w ciągu 30-dni poprosić o zwrot pieniędzy.</p><p>Nikt nie spyta dlaczego, a pieniądze wrócą na Twoje konto bez zbędnej zwłoki.   </p><p>Zatem, jeśli chcesz   </p><ul><li><p>Zdobyć praktyczne umiejętości obsugi Illustratora   </p></li><li><p>Nie chcesz na nauce spędzać zbyt wiele czasu   </p></li><li><p>Ucząc się od razu tworzyć interesujące projekty   </p></li></ul><p>Zapisz się na kurs teraz.   </p><p>Kliknij zielony przycisk Kup teraz i wierzę, że spotkamy się niedługo.   </p><p>Dawid </p><h2>Dla kogo jest ten kurs</h2><ul><li>Chcesz nauczyć się szybko i sprawnie używać programu Adobe Illustrator.</li><li>Chcesz zacząć przygodę z grafiką komputerową i chcesz nauczyć się obsługi programu do grafiki wektorowej.</li><li>Do tej pory używałeś Photoshopa (lub Corela) i chciałbyś nauczyć się Illustratora, ale z jakiegoś powodu ten program cie odstrasza i przytłacza.</li></ul>', 'Nauka Illustratora w mniej niż 15 minut podczas tworzenia ikon w stylu flat design. Illustrator w praktyce', 'illustrator-w-praktyce-dla-poczatkujacych-i-nie-tylko-nauka-illustratora-w-mniej-niz-15-minut-podczas-tworzenia-ikon-w-stylu-flat-design-illustrator-w-praktyce', '', '', '', 'Illustrator w praktyce dla początkujących i nie tylko\nNauka Illustratora w mniej niż 15 minut podczas tworzenia ikon w stylu flat design. Illustrator w praktyce', '', '', '', ''),
(36, 1, 1, '<h2>Opis</h2><span></span><p>English captions are now available!</p><p>W tym kursie przybliżę Ci podstawy tworzenia prototypów interfejsów użytkownika w programie Axure RP 9. Przejdziemy od minimalistycznych projektów, do projektu, który wygląda jak aplikacja webowa. Jeżeli chcesz rozpocząć karierę jak UXowiec albo projektant interfejsów, ten kurs jest właśnie dla Ciebie.</p><ul><li><p>Kurs to doskonały wstęp do Axure 9 - wszystkie podstawy i sporo ćwiczeń</p></li><li><p>Twórz już od pierwszej lekcji - od razu po niej zaczynają się ćwiczenia</p></li><li><p>Więcej ćwiczeń, niż teorii - każde ćwiczenie jest wyjaśniane, a następnie omawiane</p></li></ul><p>Zachęcam do obejrzenia filmu promocyjnego i zobaczenia kilku darmowych lekcji</p><h2>Dla kogo jest ten kurs</h2><ul><li>Analitycy, którzy chcą tworzyć lepsze ekrany aplikacji</li><li>UXowcy, którzy chcą przelać swoje pomysły w interaktywną makietę</li><li>Graficy, którzy płynnie chcą przejść do branży IT</li><li>Programiści, którzy chcą wcześniej zwizualizować to co robią</li><li>Wszyscy, którzy chcą nauczyć się projektowania interaktywnych makiet</li></ul>', 'Naucz się od podstaw projektowania interaktywnych makiet', 'axure-9-od-zera-naucz-sie-od-podstaw-projektowania-interaktywnych-makiet', '', '', '', 'Axure 9 od zera\nNaucz się od podstaw projektowania interaktywnych makiet', '', '', '', '');
INSERT INTO `ps_product_lang` (`id_product`, `id_shop`, `id_lang`, `description`, `description_short`, `link_rewrite`, `meta_description`, `meta_keywords`, `meta_title`, `name`, `available_now`, `available_later`, `delivery_in_stock`, `delivery_out_stock`) VALUES
(37, 1, 1, '<h2>Opis</h2><span></span><p><strong><em>UI/UX design </em></strong><em>to zagadnienie, które z roku na rok zdobywa coraz większą popularność i należy do wachlarza najbardziej poszukiwanych umiejętności webdesignera. </em></p><p>W kursie omówimy zagadnienia związane między innymi z <strong>użytecznością oraz pracą koncepcyjną, </strong>a także z pomocą narzędzi takich jak <strong>Photoshop, Illustrator, UX Pin czy Invision</strong> - stworzymy funkcjonalny prototyp i layout strony WWW. </p><p><strong>Jeśli zajmujesz się projektowaniem stron i chcesz poznać nowoczesne techniki tworzenia layoutów - nie mogłeś lepiej trafić!</strong></p><p><em>Kurs, który masz przed soba jest uzupełnieniem i praktycznym rozwinieciem kursu Nowoczesny Webdesign - zdecydowanie zalecamy obejrzenie go w pierwszej kolejności. </em></p><p><br /></p><p><strong>CO JEST ZAWARTE W KURSIE?</strong></p><p><br /></p><ul><li><p>poznasz <strong>najważniejsze narzędzia wykorzystywane w procesie koncepcyjnym</strong></p></li><li><p>dowiesz się na czym polega profesjonalne projektowanie grafiki w Photoshop i Illustrator</p></li><li><p>wspólnie przejdziemy przez<strong> prototypowanie oraz tworzenie interakcji</strong></p></li><li><p>stworzymy<strong> rozbudowany projekt layoutu strony WWW </strong>krok po kroku</p></li><li><p>poznasz rolę <strong>zastosowania typografii </strong>i przydatne narzędzia</p></li><li><p>przekonasz się jak powinna przebiegać <strong>praca w oparciu o urządzenia i testowanie</strong></p></li><li><p>przeprowadzimy <strong>eksport i optymalizację grafik</strong></p></li><li><p>I wiele więcej!</p></li></ul><p><br /></p><p><strong>PROJEKTOWANIE W PRAKTYCE</strong></p><p><br /></p><p><strong>Projektowanie nowoczesnych interfejsów stron WWW </strong>staje się zarazem coraz prostsze... i coraz bardziej skomplikowane. </p><p>Jak to możliwe? Po pierwsze, mamy do dyspozycji genialne narzędzia, takie jak <strong>Photoshop, Sketch, narzędzia do prototypowania oraz setki gotowych, świetnej jakości zasobów. </strong></p><p>Z drugiej strony jednak fragmentacja ekranów, zagadnienia związane z wyświetlaczami HiDPI i optymalizacją na nie grafik może przyprawić o ból głowy największego graficznego \"wyjadacza\". </p><p>Ten Kurs stanowi praktyczne rozwinięcie zagadnień omawianych w kursie Nowoczesny Webdesign o projekt, który wykonamy <strong>krok po kroku od procesu koncepcyjnego, aż do cięcia gotowej grafiki</strong>.</p><p><br /></p><p><strong>NARZĘDZIA ORAZ ZASOBY </strong></p><p><br /></p><p>Kurs, który masz przed sobą, jest nakierowany na <strong>przedstawienie etapów procesu z wykorzystaniem jak największej ilości narzędzi oraz zasobów</strong>, które na co dzień profesjonaliści wykorzystują w projektowaniu. </p><p>Dowiesz się jak uwolnić potencjał nowych funkcji oprogramowania, które zastosowane w odpowiedni sposób potrafią zaoszczędzić mnóstwo czasu. </p><p>Przekonasz się<strong> jak optymalnie pracować z</strong></p><ul><li><p><strong>Creative Sync</strong> </p></li><li><p><strong>fontami</strong></p></li><li><p>zasobami w postaci <strong>grafik</strong></p></li><li><p><strong>ikonami </strong></p></li><li><p>gotowymi zestawami <strong>UI Kits</strong></p></li></ul><p><br /></p><p><strong>TWORZENIE LAYOUTÓW KROK PO KROKU </strong></p><p><br /></p><p>W kursie<strong> nastawimy się na praktykę. </strong></p><p>Skoncentrujemy się na wykorzystaniu dobrych praktyk </p><ul><li><p>począwszy od <strong>zebrania pomysłów</strong></p></li><li><p>przez <strong>wireframe</strong> na papierze</p></li><li><p><strong>prototypowanie</strong> na urządzeniu mobilnym</p></li><li><p>aż do <strong>projektowania w Photoshop i Illustrator</strong>...</p></li><li><p>...oraz tworzenia <strong>interakcji z UX Pin</strong></p></li></ul><p><br /></p><p><strong>PŁYNNY PROCES TWORZENIA</strong></p><p>Dzięki wykorzystaniu nowych technologii w projektowaniu dowiesz się jak</p><ul><li><p><strong>zautomatyzować większość procesów projektowych </strong></p></li><li><p>ustawić odpowiedni <strong>grid</strong></p></li><li><p><strong>pracować w skali</strong></p></li><li><p>przenosić zasoby między projektami czy<strong> aktualizować je w jednym miejscu</strong> tak, aby zmiany widoczne były w całym projekcie</p></li></ul><p><br /></p><p><strong>NOWE EKRANY HiDPI I EKSPORT GRAFIK </strong></p><p><br /></p><p>W kursie poznasz także narzędzia oraz techniki pracy zorientowane na dostarczenie jak najlepszych grafik także dla <strong>nowoczesnych wyświetlaczy, takich jak Retina</strong>. </p><p>Dowiesz się jak łatwo wykorzystać <strong>potencjał nowych narzędzi eksportu w Photoshop oraz Adobe Extract,</strong> dzięki któremu zapomnisz o wycinaniu z pomocą przestarzałych metod takich jak plasterki.</p><p><br /></p><p><strong>INTERAKCJE I FUNKCJONALNE PROTOTYPY </strong></p><p><br /></p><p>W kursie zajmiemy się także tworzeniem <strong>interaktywnego prototypu witryny </strong>z wykorzystaniem narzędzi <strong>UX Pin</strong>.</p><p>Dowiesz się jak łatwo<strong> zaimportować do UX Pin stworzony w Photoshop prototyp</strong>, a następnie dorobisz do niego interakcje oraz przejścia tak, aby można było przetestować jego funkcjonalność i użyteczność dla użytkowników.</p><p><br /></p><p><strong>MOBILE FIRST, RWD I TESTOWANIE </strong></p><p>Projekt naszej witryny zorientujemy na podejście <strong>Mobile First,</strong> dzięki czemu uzyskamy w krótkim czasie szereg koncepcji, które postaramy się następnie<strong> zeskalować na większe ekrany - tablet i desktop</strong>. </p><p>Postaramy się pracować tak, aby <strong>coraz większe ekrany oferowały więcej funkcjonalności dla użytkownika</strong>, a te mniejsze były zoptymalizowane pod pracę z ekranami dotykowymi.</p><p><br /></p><p><strong>DLA KOGO JEST TEN KURS?</strong></p><p><br /></p><p>Kurs jest przeznaczony dla wszystkich osób, które chcą dowiedzieć się <strong>jak w praktyce wygląda projektowanie nowoczesnych interfejsów stron WWW</strong>. </p><h2>Dla kogo jest ten kurs</h2><ul><li>Kurs jest przeznaczony dla wszystkich osób, które chcą dowiedzieć się jak w praktyce wygląda projektowanie nowoczesnych interfejsów stron WWW.</li></ul>', 'Poznaj najważniejsze wytyczne dotyczące UX/UI designu, by zacząć tworzyć jeszcze lepsze, profesjonalne projekty!', 'uiux-w-praktyce---projektuj-jeszcze-lepsze-strony-www-poznaj-najwazniejsze-wytyczne-dotyczace-uxui-designu-by-zaczac-tworzyc-jeszcze-lepsze-profesjonalne-projekty', '', '', '', 'UI/UX w praktyce - projektuj jeszcze lepsze strony WWW!\nPoznaj najważniejsze wytyczne dotyczące UX/UI designu, by zacząć tworzyć jeszcze lepsze, profesjonalne projekty!', '', '', '', ''),
(38, 1, 1, '<h2>Opis</h2><span></span><p><em>WordPress to najpopularniejszy system CMS - zobacz, dlaczego tyle osób go wybiera i zacznij tworzyć dynamiczne strony WWW! </em></p><p><strong>Dzięki lekcjom z kursu od podstaw opanujesz obsługę WordPress, jak również zmodyfikujesz grafikę swojej strony i rozszerzysz jej funkcjonalności!</strong></p><p><br /></p><p><strong>CO JEST ZAWARTE W KURSIE? </strong></p><p><br /></p><ul><li><p>poznasz <strong>podstawy obsługi i zarządzania systemem CMS WordPress</strong></p></li><li><p>przejdziemy przez<strong> instalację i konfigurację WordPress\'a</strong></p></li><li><p>przekonasz się czym jest <strong>praca z mediami</strong> - obrazki, wideo, linki i inne</p></li><li><p>przejdziemy przez <strong>rozszerzanie strony z pomocą Wtyczek </strong>i zmianę wyglądu dzięki Motywom</p></li><li><p>wykonamy<strong> edycję kodu HTML i CSS Motywów</strong></p></li><li><p>przygotujemy <strong>aktualizacje strony w WordPress</strong></p></li></ul><p><br /></p><p><strong>INSTALACJA I KONFIGURACJA WORDPRESS </strong></p><p><br /></p><p>Pierwsze lekcje kursu dotyczą <strong>ekosystemu WordPress </strong>oraz tego, co można osiągnąć z wykorzystaniem tego systemu CMS. </p><p>Następnie zajmiemy się <strong>pobraniem aktualnej, polskiej wersji WordPress</strong> oraz jego instalacją na serwerze. </p><p>Kolejno skonfigurujemy naszą stronę tak, aby praca z nią była komfortowa a także aby <strong>publikowane treści były przyjazne dla wyszukiwarek.</strong></p><p><br /></p><p><strong>ADMINISTRACJA SYSTEMEM CMS WORDPRESS</strong></p><p>Na przestrzeni kursu poznasz <strong>wszystkie narzędzia, które służą do zarządzania Twoją stroną w WordPress</strong>. </p><p>Dowiesz się </p><ul><li><p>jakie są <strong>podstawowe typy treści</strong></p></li><li><p>czym są <strong>taksonomie</strong>, w ramach których możemy organizować strukturę naszej strony</p></li><li><p>poznasz także <strong>metody na dodawanie mediów do WordPress</strong>, takich jak obrazki, wideo czy linki</p></li><li><p>stworzymy też <strong>swoje własne galerie </strong>oraz wygenerujemy miniaturki na potrzeby Wpisów</p></li><li><p>zajmiemy się także<strong> administracją użytkownikami oraz ich uprawnieniami w ramach naszej strony.</strong></p><p><br /></p><p><br /></p></li></ul><p><strong>ZARZĄDZANIE MOTYWAMI </strong></p><p>Dowiesz się czym są <strong>darmowe oraz płatne Motywy do WordPress</strong>, które następnie będziemy instalować aby zmienić wygląd naszego serwisu. </p><p>Zajmiemy się także d<strong>ostosowywaniem gotowych Motywów </strong>do naszych potrzeb. </p><p>Skorzystamy z domyślnego Motywu WordPress oraz jego panelu, z pomocą którego <strong>podmienimy grafiki, kolory czy tła.</strong> Dowiesz się także</p><ul><li><p>jak można <strong>edytować styl Motywu</strong> dokonując zmiany bezpośrednio w plikach CSS oraz PHP</p></li><li><p>czym są i dlaczego warto korzystać z <strong>Motywów Potomnych w WordPress.</strong></p><p><br /></p></li></ul><p><strong>WTYCZKI DO WORDPRESS</strong></p><p><br /></p><p>W kursie dowiesz się również <strong>czym są Pluginy</strong>, czyli tak zwane wtyczki do CMS WordPress. </p><p>Z ich pomocą będziemy rozszerzać możliwości naszej witryny i dodawać do niej funkcjonalności, które pozwolą nam na przykład stworzyć <strong>działający formularz kontaktowy czy uruchomić automatyczne backupy </strong>zarówno bazy danych jak i plików z FTP tak, aby Twoja strona była zawsze bezpieczna. </p><p>Poznamy<strong> szereg najciekawszych Pluginów</strong>, jak również prowadzący pokaże Ci metody z których można skorzystać aby przywrócić działanie naszego systemu po awarii wynikającej np. z instalacji wadliwej wtyczki.</p><p><br /></p><p><strong>DODATKI I PROJEKT STRONY </strong></p><p>Na przestrzeni kursu będziemy <strong>rozszerzać możliwości naszej strony WWW</strong>, zarówno z pomocą wtyczek, mediów, jak również przez dodanie do strony mapki Google. Dodamy też skrót najnowszych informacji z profilu witryny na Facebook\'u. </p><p>Stworzymy <strong>prostą strukturę działającej strony Bloga Kulinarnego</strong>, którą dostosujemy do naszych potrzeb. </p><p>Pomówimy także o <strong>aktualizacjach WordPress </strong>oraz jego komponentów.</p><p><br /></p><p><strong>KOMPENDIUM WORDPRESS </strong></p><p>Kurs, który masz przed sobą, jest pierwszą częścią i fundamentem Kompendium WordPress - składa się na nie szereg kursów, dzięki którym będziesz mógł systematycznie rozwijać swoje umiejętności. </p><p>Kolejny kurs, który proponujemy przerobić to kurs Photoshop do HTML i CSS, w którym stworzymy grafikę i zakodujemy kompletny layout witryny WWW, którą w kursie WordPress - Własne Motywy wdrożymy do systemu CMS. </p><p>Kolejny kurs nauczy Cię tworzyć własne Pluginy do WordPress.</p><p><br /></p><p><strong>Dla kogo jest ten kurs?</strong></p><p>Kurs przeznaczony jest dla osób, które <strong>rozpoczynają swoją przygodę z systemem CMS WordPress </strong>i chcą od podstaw poznać jego możliwości.</p><p>Jeśli jeszcze nie pracowałeś z WordPress, posiadasz stronę WWW postawioną na tym systemie lub projektujesz witryny, ale chciałbyś uporządkować swoją wiedzę - <strong>ten kurs jest właśnie dla Ciebie! </strong></p><p>Pomoże Ci on szybko poznać wszystkie<strong> funkcje i narzędzia oraz techniki prowadzenia strony WWW</strong> opartej na WordPress. </p><h2>Dla kogo jest ten kurs</h2><ul><li>Kurs przeznaczony jest dla osób, które rozpoczynają swoją przygodę z systemem CMS WordPress i chcą od podstaw poznać jego możliwości. Jeśli jeszcze nie pracowałeś z WordPress, posiadasz stronę WWW postawioną na tym systemie lub projektujesz witryny, ale chciałbyś uporządkować swoją wiedzę - ten kurs jest właśnie dla Ciebie! Pomoże Ci on szybko poznać wszystkie funkcje i narzędzia oraz techniki prowadzenia strony WWW opartej na WordPress.</li></ul>', 'Poznaj od podstaw popularny system CMS WordPress i zacznij tworzyć dynamiczne strony WWW!', 'wordpress---zacznij-tworzyc-dynamiczne-strony-www-poznaj-od-podstaw-popularny-system-cms-wordpress-i-zacznij-tworzyc-dynamiczne-strony-www', '', '', '', 'WordPress - zacznij tworzyć dynamiczne strony WWW\nPoznaj od podstaw popularny system CMS WordPress i zacznij tworzyć dynamiczne strony WWW!', '', '', '', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_sale`
--

CREATE TABLE `ps_product_sale` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sale_nbr` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `date_upd` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_shop`
--

CREATE TABLE `ps_product_shop` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL,
  `id_category_default` int(10) UNSIGNED DEFAULT NULL,
  `id_tax_rules_group` int(11) UNSIGNED NOT NULL,
  `on_sale` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `online_only` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `ecotax` decimal(17,6) NOT NULL DEFAULT 0.000000,
  `minimal_quantity` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `low_stock_threshold` int(10) DEFAULT NULL,
  `low_stock_alert` tinyint(1) NOT NULL DEFAULT 0,
  `price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `wholesale_price` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `unity` varchar(255) DEFAULT NULL,
  `unit_price_ratio` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `additional_shipping_cost` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `customizable` tinyint(2) NOT NULL DEFAULT 0,
  `uploadable_files` tinyint(4) NOT NULL DEFAULT 0,
  `text_fields` tinyint(4) NOT NULL DEFAULT 0,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `redirect_type` enum('','404','301-product','302-product','301-category','302-category') NOT NULL DEFAULT '',
  `id_type_redirected` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `available_for_order` tinyint(1) NOT NULL DEFAULT 1,
  `available_date` date DEFAULT NULL,
  `show_condition` tinyint(1) NOT NULL DEFAULT 1,
  `condition` enum('new','used','refurbished') NOT NULL DEFAULT 'new',
  `show_price` tinyint(1) NOT NULL DEFAULT 1,
  `indexed` tinyint(1) NOT NULL DEFAULT 0,
  `visibility` enum('both','catalog','search','none') NOT NULL DEFAULT 'both',
  `cache_default_attribute` int(10) UNSIGNED DEFAULT NULL,
  `advanced_stock_management` tinyint(1) NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `pack_stock_type` int(11) UNSIGNED NOT NULL DEFAULT 3
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_product_shop`
--

INSERT INTO `ps_product_shop` (`id_product`, `id_shop`, `id_category_default`, `id_tax_rules_group`, `on_sale`, `online_only`, `ecotax`, `minimal_quantity`, `low_stock_threshold`, `low_stock_alert`, `price`, `wholesale_price`, `unity`, `unit_price_ratio`, `additional_shipping_cost`, `customizable`, `uploadable_files`, `text_fields`, `active`, `redirect_type`, `id_type_redirected`, `available_for_order`, `available_date`, `show_condition`, `condition`, `show_price`, `indexed`, `visibility`, `cache_default_attribute`, `advanced_stock_management`, `date_add`, `date_upd`, `pack_stock_type`) VALUES
(25, 1, 35, 1, 0, 0, '0.000000', 1, NULL, 0, '447.150000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 60, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(26, 1, 35, 1, 0, 0, '0.000000', 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 64, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(27, 1, 36, 1, 0, 0, '0.000000', 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 68, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(28, 1, 35, 1, 0, 0, '0.000000', 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 72, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(29, 1, 37, 1, 0, 0, '0.000000', 1, NULL, 0, '170.720000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 76, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(30, 1, 35, 1, 0, 0, '0.000000', 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 80, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(31, 1, 38, 1, 0, 0, '0.000000', 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 84, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(32, 1, 39, 1, 0, 0, '0.000000', 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 88, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(33, 1, 35, 1, 0, 0, '0.000000', 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 92, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(34, 1, 39, 1, 0, 0, '0.000000', 1, NULL, 0, '56.900000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 96, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(35, 1, 37, 1, 0, 0, '0.000000', 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 100, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(36, 1, 36, 1, 0, 0, '0.000000', 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 104, 0, '2022-12-11 22:54:33', '2022-12-11 22:54:33', 0),
(37, 1, 36, 1, 0, 0, '0.000000', 1, NULL, 0, '40.640000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 108, 0, '2022-12-11 22:54:34', '2022-12-11 22:54:34', 0),
(38, 1, 36, 1, 0, 0, '0.000000', 1, NULL, 0, '48.770000', '0.000000', '', '0.000000', '0.000000', 0, 0, 0, 1, '', 0, 1, '0000-00-00', 0, 'new', 1, 1, 'both', 112, 0, '2022-12-11 22:54:34', '2022-12-11 22:54:34', 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_supplier`
--

CREATE TABLE `ps_product_supplier` (
  `id_product_supplier` int(11) UNSIGNED NOT NULL,
  `id_product` int(11) UNSIGNED NOT NULL,
  `id_product_attribute` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `id_supplier` int(11) UNSIGNED NOT NULL,
  `product_supplier_reference` varchar(64) DEFAULT NULL,
  `product_supplier_price_te` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `id_currency` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_product_tag`
--

CREATE TABLE `ps_product_tag` (
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_tag` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_profile`
--

CREATE TABLE `ps_profile` (
  `id_profile` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_profile`
--

INSERT INTO `ps_profile` (`id_profile`) VALUES
(1),
(2),
(3),
(4);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_profile_lang`
--

CREATE TABLE `ps_profile_lang` (
  `id_lang` int(10) UNSIGNED NOT NULL,
  `id_profile` int(10) UNSIGNED NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_profile_lang`
--

INSERT INTO `ps_profile_lang` (`id_lang`, `id_profile`, `name`) VALUES
(1, 1, 'Administrator'),
(1, 2, 'Logistyk'),
(1, 3, 'Tłumacz'),
(1, 4, 'Sprzedawca');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_pscheckout_cart`
--

CREATE TABLE `ps_pscheckout_cart` (
  `id_pscheckout_cart` int(10) UNSIGNED NOT NULL,
  `id_cart` int(10) UNSIGNED NOT NULL,
  `paypal_intent` varchar(20) DEFAULT 'CAPTURE',
  `paypal_order` varchar(20) DEFAULT NULL,
  `paypal_status` varchar(20) DEFAULT NULL,
  `paypal_funding` varchar(20) DEFAULT NULL,
  `paypal_token` text DEFAULT NULL,
  `paypal_token_expire` datetime DEFAULT NULL,
  `paypal_authorization_expire` datetime DEFAULT NULL,
  `isExpressCheckout` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `isHostedFields` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_pscheckout_funding_source`
--

CREATE TABLE `ps_pscheckout_funding_source` (
  `name` varchar(20) NOT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `position` tinyint(2) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_pscheckout_order_matrice`
--

CREATE TABLE `ps_pscheckout_order_matrice` (
  `id_order_matrice` int(10) UNSIGNED NOT NULL,
  `id_order_prestashop` int(10) UNSIGNED NOT NULL,
  `id_order_paypal` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_psgdpr_consent`
--

CREATE TABLE `ps_psgdpr_consent` (
  `id_gdpr_consent` int(10) UNSIGNED NOT NULL,
  `id_module` int(10) UNSIGNED NOT NULL,
  `active` int(10) NOT NULL,
  `error` int(10) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_psgdpr_consent_lang`
--

CREATE TABLE `ps_psgdpr_consent_lang` (
  `id_gdpr_consent` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `message` text DEFAULT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_psgdpr_log`
--

CREATE TABLE `ps_psgdpr_log` (
  `id_gdpr_log` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED DEFAULT NULL,
  `id_guest` int(10) UNSIGNED DEFAULT NULL,
  `client_name` varchar(250) DEFAULT NULL,
  `id_module` int(10) UNSIGNED NOT NULL,
  `request_type` int(10) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_psgdpr_log`
--

INSERT INTO `ps_psgdpr_log` (`id_gdpr_log`, `id_customer`, `id_guest`, `client_name`, `id_module`, `request_type`, `date_add`, `date_upd`) VALUES
(1, 3, 0, 'Michał Zieliński', 0, 1, '2022-12-11 22:12:40', '2022-12-11 22:12:40'),
(2, 4, 0, 'Michał a', 0, 1, '2022-12-11 22:15:57', '2022-12-11 22:15:57');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_psreassurance`
--

CREATE TABLE `ps_psreassurance` (
  `id_psreassurance` int(10) UNSIGNED NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `custom_icon` varchar(255) DEFAULT NULL,
  `status` int(10) UNSIGNED NOT NULL,
  `position` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL,
  `type_link` int(10) UNSIGNED DEFAULT NULL,
  `id_cms` int(10) UNSIGNED DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_psreassurance`
--

INSERT INTO `ps_psreassurance` (`id_psreassurance`, `icon`, `custom_icon`, `status`, `position`, `id_shop`, `type_link`, `id_cms`, `date_add`, `date_upd`) VALUES
(1, '/modules/blockreassurance/views/img/reassurance/pack2/security.svg', NULL, 1, 1, 1, NULL, NULL, '2022-12-08 16:57:38', NULL),
(2, '/modules/blockreassurance/views/img/reassurance/pack2/carrier.svg', NULL, 1, 2, 1, NULL, NULL, '2022-12-08 16:57:38', NULL),
(3, '/modules/blockreassurance/views/img/reassurance/pack2/parcel.svg', NULL, 1, 3, 1, NULL, NULL, '2022-12-08 16:57:38', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_psreassurance_lang`
--

CREATE TABLE `ps_psreassurance_lang` (
  `id_psreassurance` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_psreassurance_lang`
--

INSERT INTO `ps_psreassurance_lang` (`id_psreassurance`, `id_lang`, `id_shop`, `title`, `description`, `link`) VALUES
(1, 1, 1, 'Polityka bezpieczeństwa', '(edytuj w module Customer Reassurance)', ''),
(2, 1, 1, 'Zasady dostawy', '(edytuj w module Customer Reassurance)', ''),
(3, 1, 1, 'Zasady zwrotu', '(edytuj w module Customer Reassurance)', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_quick_access`
--

CREATE TABLE `ps_quick_access` (
  `id_quick_access` int(10) UNSIGNED NOT NULL,
  `new_window` tinyint(1) NOT NULL DEFAULT 0,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_quick_access`
--

INSERT INTO `ps_quick_access` (`id_quick_access`, `new_window`, `link`) VALUES
(1, 0, 'index.php?controller=AdminOrders'),
(2, 0, 'index.php?controller=AdminCartRules&addcart_rule'),
(3, 0, 'index.php/sell/catalog/products/new'),
(4, 0, 'index.php/sell/catalog/categories/new'),
(5, 0, 'index.php/improve/modules/manage'),
(6, 0, 'index.php?controller=AdminStats&module=statscheckup');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_quick_access_lang`
--

CREATE TABLE `ps_quick_access_lang` (
  `id_quick_access` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_quick_access_lang`
--

INSERT INTO `ps_quick_access_lang` (`id_quick_access`, `id_lang`, `name`) VALUES
(1, 1, 'Zamówienia'),
(2, 1, 'Nowy kupon'),
(3, 1, 'Nowy produkt'),
(4, 1, 'Nowa kategoria'),
(5, 1, 'Zainstalowane moduły'),
(6, 1, 'Ocena katalogu');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_range_price`
--

CREATE TABLE `ps_range_price` (
  `id_range_price` int(10) UNSIGNED NOT NULL,
  `id_carrier` int(10) UNSIGNED NOT NULL,
  `delimiter1` decimal(20,6) NOT NULL,
  `delimiter2` decimal(20,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_range_price`
--

INSERT INTO `ps_range_price` (`id_range_price`, `id_carrier`, `delimiter1`, `delimiter2`) VALUES
(1, 2, '0.000000', '10000.000000'),
(2, 3, '0.000000', '50.000000'),
(3, 3, '50.000000', '100.000000'),
(4, 3, '100.000000', '200.000000');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_range_weight`
--

CREATE TABLE `ps_range_weight` (
  `id_range_weight` int(10) UNSIGNED NOT NULL,
  `id_carrier` int(10) UNSIGNED NOT NULL,
  `delimiter1` decimal(20,6) NOT NULL,
  `delimiter2` decimal(20,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_range_weight`
--

INSERT INTO `ps_range_weight` (`id_range_weight`, `id_carrier`, `delimiter1`, `delimiter2`) VALUES
(1, 2, '0.000000', '10000.000000'),
(2, 4, '0.000000', '1.000000'),
(3, 4, '1.000000', '3.000000'),
(4, 4, '3.000000', '10000.000000');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_referrer`
--

CREATE TABLE `ps_referrer` (
  `id_referrer` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL,
  `passwd` varchar(255) DEFAULT NULL,
  `http_referer_regexp` varchar(64) DEFAULT NULL,
  `http_referer_like` varchar(64) DEFAULT NULL,
  `request_uri_regexp` varchar(64) DEFAULT NULL,
  `request_uri_like` varchar(64) DEFAULT NULL,
  `http_referer_regexp_not` varchar(64) DEFAULT NULL,
  `http_referer_like_not` varchar(64) DEFAULT NULL,
  `request_uri_regexp_not` varchar(64) DEFAULT NULL,
  `request_uri_like_not` varchar(64) DEFAULT NULL,
  `base_fee` decimal(5,2) NOT NULL DEFAULT 0.00,
  `percent_fee` decimal(5,2) NOT NULL DEFAULT 0.00,
  `click_fee` decimal(5,2) NOT NULL DEFAULT 0.00,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_referrer_cache`
--

CREATE TABLE `ps_referrer_cache` (
  `id_connections_source` int(11) UNSIGNED NOT NULL,
  `id_referrer` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_referrer_shop`
--

CREATE TABLE `ps_referrer_shop` (
  `id_referrer` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `cache_visitors` int(11) DEFAULT NULL,
  `cache_visits` int(11) DEFAULT NULL,
  `cache_pages` int(11) DEFAULT NULL,
  `cache_registrations` int(11) DEFAULT NULL,
  `cache_orders` int(11) DEFAULT NULL,
  `cache_sales` decimal(17,2) DEFAULT NULL,
  `cache_reg_rate` decimal(5,4) DEFAULT NULL,
  `cache_order_rate` decimal(5,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_request_sql`
--

CREATE TABLE `ps_request_sql` (
  `id_request_sql` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `sql` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_required_field`
--

CREATE TABLE `ps_required_field` (
  `id_required_field` int(11) NOT NULL,
  `object_name` varchar(32) NOT NULL,
  `field_name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_risk`
--

CREATE TABLE `ps_risk` (
  `id_risk` int(11) UNSIGNED NOT NULL,
  `percent` tinyint(3) NOT NULL,
  `color` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_risk`
--

INSERT INTO `ps_risk` (`id_risk`, `percent`, `color`) VALUES
(1, 0, '#32CD32'),
(2, 35, '#FF8C00'),
(3, 75, '#DC143C'),
(4, 100, '#ec2e15');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_risk_lang`
--

CREATE TABLE `ps_risk_lang` (
  `id_risk` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_risk_lang`
--

INSERT INTO `ps_risk_lang` (`id_risk`, `id_lang`, `name`) VALUES
(1, 1, 'Żaden'),
(2, 1, 'Niski'),
(3, 1, 'Średnia'),
(4, 1, 'Wysoka');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_search_engine`
--

CREATE TABLE `ps_search_engine` (
  `id_search_engine` int(10) UNSIGNED NOT NULL,
  `server` varchar(64) NOT NULL,
  `getvar` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_search_engine`
--

INSERT INTO `ps_search_engine` (`id_search_engine`, `server`, `getvar`) VALUES
(1, 'google', 'q'),
(2, 'aol', 'q'),
(3, 'yandex', 'text'),
(4, 'ask.com', 'q'),
(5, 'nhl.com', 'q'),
(6, 'yahoo', 'p'),
(7, 'baidu', 'wd'),
(8, 'lycos', 'query'),
(9, 'exalead', 'q'),
(10, 'search.live', 'q'),
(11, 'voila', 'rdata'),
(12, 'altavista', 'q'),
(13, 'bing', 'q'),
(14, 'daum', 'q'),
(15, 'eniro', 'search_word'),
(16, 'naver', 'query'),
(17, 'msn', 'q'),
(18, 'netscape', 'query'),
(19, 'cnn', 'query'),
(20, 'about', 'terms'),
(21, 'mamma', 'query'),
(22, 'alltheweb', 'q'),
(23, 'virgilio', 'qs'),
(24, 'alice', 'qs'),
(25, 'najdi', 'q'),
(26, 'mama', 'query'),
(27, 'seznam', 'q'),
(28, 'onet', 'qt'),
(29, 'szukacz', 'q'),
(30, 'yam', 'k'),
(31, 'pchome', 'q'),
(32, 'kvasir', 'q'),
(33, 'sesam', 'q'),
(34, 'ozu', 'q'),
(35, 'terra', 'query'),
(36, 'mynet', 'q'),
(37, 'ekolay', 'q'),
(38, 'rambler', 'words');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_search_index`
--

CREATE TABLE `ps_search_index` (
  `id_product` int(11) UNSIGNED NOT NULL,
  `id_word` int(11) UNSIGNED NOT NULL,
  `weight` smallint(4) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_search_index`
--

INSERT INTO `ps_search_index` (`id_product`, `id_word`, `weight`) VALUES
(25, 4082, 1),
(25, 4084, 1),
(25, 4085, 1),
(25, 4086, 1),
(25, 4087, 1),
(25, 4088, 1),
(25, 4089, 1),
(25, 4090, 1),
(25, 4091, 1),
(25, 4092, 1),
(25, 4093, 1),
(25, 4094, 1),
(25, 4095, 1),
(25, 4096, 1),
(25, 4097, 1),
(25, 4098, 1),
(25, 4099, 1),
(25, 4100, 1),
(25, 4101, 1),
(25, 4102, 1),
(25, 4103, 1),
(25, 4104, 1),
(25, 4105, 1),
(25, 4106, 1),
(25, 4107, 1),
(25, 4108, 1),
(25, 4109, 1),
(25, 4110, 1),
(25, 4111, 1),
(25, 4112, 1),
(25, 4113, 1),
(25, 4114, 1),
(25, 4115, 1),
(25, 4116, 1),
(25, 4117, 1),
(25, 4118, 1),
(25, 4120, 1),
(25, 4121, 1),
(25, 4122, 1),
(25, 4123, 1),
(25, 4124, 1),
(25, 4125, 1),
(25, 4126, 1),
(25, 4127, 1),
(25, 4128, 1),
(25, 4129, 1),
(25, 4130, 1),
(25, 4131, 1),
(25, 4132, 1),
(25, 4133, 1),
(25, 4134, 1),
(25, 4135, 1),
(25, 4136, 1),
(25, 4137, 1),
(25, 4138, 1),
(25, 4139, 1),
(25, 4140, 1),
(25, 4141, 1),
(25, 4142, 1),
(25, 4143, 1),
(25, 4144, 1),
(25, 4145, 1),
(25, 4146, 1),
(25, 4147, 1),
(25, 4148, 1),
(25, 4149, 1),
(25, 4150, 1),
(25, 4151, 1),
(25, 4152, 1),
(25, 4153, 1),
(25, 4154, 1),
(25, 4155, 1),
(25, 4156, 1),
(25, 4157, 1),
(25, 4158, 1),
(25, 4159, 1),
(25, 4160, 1),
(25, 4161, 1),
(25, 4162, 1),
(25, 4163, 1),
(25, 4164, 1),
(25, 4165, 1),
(25, 4166, 1),
(25, 4167, 1),
(25, 4168, 1),
(25, 4169, 1),
(25, 4170, 1),
(25, 4171, 1),
(25, 4172, 1),
(25, 4173, 1),
(25, 4174, 1),
(25, 4175, 1),
(25, 4176, 1),
(25, 4177, 1),
(25, 4178, 1),
(25, 4179, 1),
(25, 4180, 1),
(25, 4181, 1),
(25, 4182, 1),
(25, 4183, 1),
(25, 4184, 1),
(25, 4185, 1),
(25, 4186, 1),
(25, 4187, 1),
(25, 4188, 1),
(25, 4189, 1),
(25, 4190, 1),
(25, 4191, 1),
(25, 4192, 1),
(25, 4193, 1),
(25, 4194, 1),
(25, 4195, 1),
(25, 4196, 1),
(25, 4197, 1),
(25, 4198, 1),
(25, 4199, 1),
(25, 4200, 1),
(25, 4201, 1),
(25, 4202, 1),
(25, 4203, 1),
(25, 4204, 1),
(25, 4205, 1),
(25, 4206, 1),
(25, 4207, 1),
(25, 4208, 1),
(25, 4209, 1),
(25, 4210, 1),
(25, 4211, 1),
(25, 4212, 1),
(25, 4213, 1),
(25, 4214, 1),
(25, 4215, 1),
(25, 4381, 1),
(25, 4219, 2),
(25, 4220, 2),
(25, 4221, 2),
(25, 4222, 2),
(25, 4223, 2),
(25, 4224, 2),
(25, 4225, 2),
(25, 4226, 2),
(25, 4227, 2),
(25, 4083, 3),
(25, 4216, 3),
(25, 4217, 3),
(25, 4218, 3),
(25, 4069, 6),
(25, 4070, 6),
(25, 4068, 7),
(25, 4072, 7),
(25, 4073, 7),
(25, 4076, 7),
(25, 4077, 7),
(25, 4078, 7),
(25, 4080, 7),
(25, 4081, 7),
(25, 4066, 8),
(25, 4067, 8),
(25, 4071, 8),
(25, 4074, 8),
(25, 4075, 8),
(25, 4079, 8),
(26, 4074, 1),
(26, 4085, 1),
(26, 4104, 1),
(26, 4107, 1),
(26, 4111, 1),
(26, 4113, 1),
(26, 4120, 1),
(26, 4123, 1),
(26, 4126, 1),
(26, 4127, 1),
(26, 4129, 1),
(26, 4132, 1),
(26, 4140, 1),
(26, 4147, 1),
(26, 4150, 1),
(26, 4152, 1),
(26, 4153, 1),
(26, 4157, 1),
(26, 4162, 1),
(26, 4176, 1),
(26, 4185, 1),
(26, 4186, 1),
(26, 4188, 1),
(26, 4201, 1),
(26, 4202, 1),
(26, 4203, 1),
(26, 4205, 1),
(26, 4207, 1),
(26, 4208, 1),
(26, 4211, 1),
(26, 4381, 1),
(26, 4550, 1),
(26, 4551, 1),
(26, 4552, 1),
(26, 4553, 1),
(26, 4554, 1),
(26, 4555, 1),
(26, 4556, 1),
(26, 4558, 1),
(26, 4560, 1),
(26, 4561, 1),
(26, 4562, 1),
(26, 4563, 1),
(26, 4564, 1),
(26, 4565, 1),
(26, 4566, 1),
(26, 4567, 1),
(26, 4568, 1),
(26, 4570, 1),
(26, 4572, 1),
(26, 4573, 1),
(26, 4574, 1),
(26, 4576, 1),
(26, 4577, 1),
(26, 4578, 1),
(26, 4579, 1),
(26, 4580, 1),
(26, 4581, 1),
(26, 4582, 1),
(26, 4583, 1),
(26, 4584, 1),
(26, 4585, 1),
(26, 4586, 1),
(26, 4587, 1),
(26, 4588, 1),
(26, 4589, 1),
(26, 4590, 1),
(26, 4591, 1),
(26, 4592, 1),
(26, 4593, 1),
(26, 4594, 1),
(26, 4595, 1),
(26, 4599, 1),
(26, 4600, 1),
(26, 4601, 1),
(26, 4602, 1),
(26, 4603, 1),
(26, 4604, 1),
(26, 4605, 1),
(26, 4606, 1),
(26, 4607, 1),
(26, 4608, 1),
(26, 4609, 1),
(26, 4610, 1),
(26, 4611, 1),
(26, 4613, 1),
(26, 4614, 1),
(26, 4616, 1),
(26, 4617, 1),
(26, 4618, 1),
(26, 4619, 1),
(26, 4620, 1),
(26, 4621, 1),
(26, 4622, 1),
(26, 4623, 1),
(26, 4624, 1),
(26, 4625, 1),
(26, 4626, 1),
(26, 4627, 1),
(26, 4628, 1),
(26, 4629, 1),
(26, 4630, 1),
(26, 4631, 1),
(26, 4632, 1),
(26, 4633, 1),
(26, 4634, 1),
(26, 4635, 1),
(26, 4636, 1),
(26, 4637, 1),
(26, 4638, 1),
(26, 4639, 1),
(26, 4640, 1),
(26, 4641, 1),
(26, 4642, 1),
(26, 4643, 1),
(26, 4644, 1),
(26, 4645, 1),
(26, 4646, 1),
(26, 4647, 1),
(26, 4648, 1),
(26, 4649, 1),
(26, 4650, 1),
(26, 4651, 1),
(26, 4652, 1),
(26, 4653, 1),
(26, 4654, 1),
(26, 4655, 1),
(26, 4656, 1),
(26, 4657, 1),
(26, 4658, 1),
(26, 4659, 1),
(26, 4660, 1),
(26, 4661, 1),
(26, 4662, 1),
(26, 4663, 1),
(26, 4664, 1),
(26, 4665, 1),
(26, 4666, 1),
(26, 4667, 1),
(26, 4668, 1),
(26, 4669, 1),
(26, 4670, 1),
(26, 4671, 1),
(26, 4672, 1),
(26, 4673, 1),
(26, 4674, 1),
(26, 4675, 1),
(26, 4676, 1),
(26, 4677, 1),
(26, 4678, 1),
(26, 4679, 1),
(26, 4680, 1),
(26, 4681, 1),
(26, 4682, 1),
(26, 4683, 1),
(26, 4684, 1),
(26, 4685, 1),
(26, 4686, 1),
(26, 4687, 1),
(26, 4688, 1),
(26, 4689, 1),
(26, 4690, 1),
(26, 4691, 1),
(26, 4692, 1),
(26, 4693, 1),
(26, 4694, 1),
(26, 4695, 1),
(26, 4696, 1),
(26, 4697, 1),
(26, 4698, 1),
(26, 4699, 1),
(26, 4700, 1),
(26, 4701, 1),
(26, 4702, 1),
(26, 4703, 1),
(26, 4704, 1),
(26, 4705, 1),
(26, 4706, 1),
(26, 4707, 1),
(26, 4708, 1),
(26, 4709, 1),
(26, 4710, 1),
(26, 4711, 1),
(26, 4712, 1),
(26, 4713, 1),
(26, 4714, 1),
(26, 4715, 1),
(26, 4716, 1),
(26, 4717, 1),
(26, 4718, 1),
(26, 4719, 1),
(26, 4720, 1),
(26, 4721, 1),
(26, 4722, 1),
(26, 4723, 1),
(26, 4724, 1),
(26, 4725, 1),
(26, 4726, 1),
(26, 4727, 1),
(26, 4728, 1),
(26, 4729, 1),
(26, 4730, 1),
(26, 4731, 1),
(26, 4732, 1),
(26, 4733, 1),
(26, 4734, 1),
(26, 4735, 1),
(26, 4736, 1),
(26, 4737, 1),
(26, 4738, 1),
(26, 4739, 1),
(26, 4740, 1),
(26, 4741, 1),
(26, 4742, 1),
(26, 4743, 1),
(26, 4744, 1),
(26, 4745, 1),
(26, 4746, 1),
(26, 4747, 1),
(26, 4748, 1),
(26, 4749, 1),
(26, 4751, 1),
(26, 4752, 1),
(26, 4753, 1),
(26, 4754, 1),
(26, 4755, 1),
(26, 4756, 1),
(26, 4757, 1),
(26, 4758, 1),
(26, 4759, 1),
(26, 4760, 1),
(26, 4761, 1),
(26, 4762, 1),
(26, 4763, 1),
(26, 4764, 1),
(26, 4765, 1),
(26, 4766, 1),
(26, 4767, 1),
(26, 4768, 1),
(26, 4769, 1),
(26, 4770, 1),
(26, 4771, 1),
(26, 4772, 1),
(26, 4773, 1),
(26, 4774, 1),
(26, 4775, 1),
(26, 4776, 1),
(26, 4777, 1),
(26, 4778, 1),
(26, 4779, 1),
(26, 4780, 1),
(26, 4781, 1),
(26, 4782, 1),
(26, 4783, 1),
(26, 4784, 1),
(26, 4785, 1),
(26, 4786, 1),
(26, 4787, 1),
(26, 4788, 1),
(26, 4789, 1),
(26, 4790, 1),
(26, 4791, 1),
(26, 4792, 1),
(26, 4793, 1),
(26, 4794, 1),
(26, 4795, 1),
(26, 4796, 1),
(26, 4797, 1),
(26, 4798, 1),
(26, 4799, 1),
(26, 4800, 1),
(26, 4801, 1),
(26, 4802, 1),
(26, 4803, 1),
(26, 4804, 1),
(26, 4805, 1),
(26, 4806, 1),
(26, 4807, 1),
(26, 4808, 1),
(26, 4809, 1),
(26, 4810, 1),
(26, 4811, 1),
(26, 4812, 1),
(26, 4813, 1),
(26, 4814, 1),
(26, 4815, 1),
(26, 4816, 1),
(26, 4817, 1),
(26, 4818, 1),
(26, 4819, 1),
(26, 4820, 1),
(26, 4821, 1),
(26, 4822, 1),
(26, 4823, 1),
(26, 4824, 1),
(26, 4825, 1),
(26, 4826, 1),
(26, 4827, 1),
(26, 4828, 1),
(26, 4829, 1),
(26, 4830, 1),
(26, 4831, 1),
(26, 4832, 1),
(26, 4833, 1),
(26, 4834, 1),
(26, 4835, 1),
(26, 4836, 1),
(26, 4837, 1),
(26, 4838, 1),
(26, 4839, 1),
(26, 4840, 1),
(26, 4841, 1),
(26, 4842, 1),
(26, 4843, 1),
(26, 4844, 1),
(26, 4845, 1),
(26, 4846, 1),
(26, 4847, 1),
(26, 4848, 1),
(26, 4849, 1),
(26, 4850, 1),
(26, 4851, 1),
(26, 4852, 1),
(26, 4853, 1),
(26, 4854, 1),
(26, 4855, 1),
(26, 4856, 1),
(26, 4857, 1),
(26, 4858, 1),
(26, 4859, 1),
(26, 4860, 1),
(26, 4861, 1),
(26, 4862, 1),
(26, 4863, 1),
(26, 4864, 1),
(26, 4865, 1),
(26, 4866, 1),
(26, 4867, 1),
(26, 4868, 1),
(26, 4869, 1),
(26, 4870, 1),
(26, 4871, 1),
(26, 4872, 1),
(26, 4873, 1),
(26, 4874, 1),
(26, 4875, 1),
(26, 4876, 1),
(26, 4877, 1),
(26, 4878, 1),
(26, 4879, 1),
(26, 4880, 1),
(26, 4881, 1),
(26, 4882, 1),
(26, 4883, 1),
(26, 4884, 1),
(26, 4885, 1),
(26, 4886, 1),
(26, 4887, 1),
(26, 4888, 1),
(26, 4889, 1),
(26, 4890, 1),
(26, 4891, 1),
(26, 4892, 1),
(26, 4893, 1),
(26, 4894, 1),
(26, 4895, 1),
(26, 4896, 1),
(26, 4897, 1),
(26, 4898, 1),
(26, 4899, 1),
(26, 4900, 1),
(26, 4901, 1),
(26, 4902, 1),
(26, 4903, 1),
(26, 4904, 1),
(26, 4905, 1),
(26, 4906, 1),
(26, 4907, 1),
(26, 4908, 1),
(26, 4909, 1),
(26, 4910, 1),
(26, 4911, 1),
(26, 4912, 1),
(26, 4913, 1),
(26, 4914, 1),
(26, 4916, 1),
(26, 4917, 1),
(26, 4918, 1),
(26, 4919, 1),
(26, 4920, 1),
(26, 4921, 1),
(26, 4922, 1),
(26, 4923, 1),
(26, 4924, 1),
(26, 4925, 1),
(26, 4926, 1),
(26, 4927, 1),
(26, 4928, 1),
(26, 4929, 1),
(26, 4930, 1),
(26, 4931, 1),
(26, 4932, 1),
(26, 4933, 1),
(26, 4934, 1),
(26, 5580, 1),
(26, 5581, 1),
(26, 5582, 1),
(26, 5583, 1),
(26, 5584, 1),
(26, 5585, 1),
(26, 4219, 2),
(26, 4221, 2),
(26, 4222, 2),
(26, 4223, 2),
(26, 4225, 2),
(26, 5139, 2),
(26, 5140, 2),
(26, 4216, 3),
(26, 4218, 3),
(26, 4220, 3),
(26, 4571, 3),
(26, 4750, 3),
(26, 4217, 4),
(26, 4543, 6),
(26, 4068, 7),
(26, 4131, 7),
(26, 4544, 7),
(26, 4545, 7),
(26, 4546, 7),
(26, 4547, 7),
(26, 4549, 7),
(26, 4066, 8),
(26, 4067, 8),
(26, 4075, 8),
(26, 4078, 8),
(26, 4133, 8),
(26, 4548, 8),
(27, 4075, 1),
(27, 4076, 1),
(27, 4079, 1),
(27, 4082, 1),
(27, 4097, 1),
(27, 4104, 1),
(27, 4115, 1),
(27, 4120, 1),
(27, 4123, 1),
(27, 4126, 1),
(27, 4128, 1),
(27, 4129, 1),
(27, 4140, 1),
(27, 4150, 1),
(27, 4153, 1),
(27, 4190, 1),
(27, 4201, 1),
(27, 4203, 1),
(27, 4211, 1),
(27, 4381, 1),
(27, 4545, 1),
(27, 4560, 1),
(27, 4563, 1),
(27, 4573, 1),
(27, 4578, 1),
(27, 4580, 1),
(27, 4592, 1),
(27, 4604, 1),
(27, 4606, 1),
(27, 4610, 1),
(27, 4633, 1),
(27, 4647, 1),
(27, 4648, 1),
(27, 4664, 1),
(27, 4671, 1),
(27, 4682, 1),
(27, 4683, 1),
(27, 4684, 1),
(27, 4688, 1),
(27, 4689, 1),
(27, 4691, 1),
(27, 4707, 1),
(27, 4708, 1),
(27, 4715, 1),
(27, 4728, 1),
(27, 4729, 1),
(27, 4738, 1),
(27, 4742, 1),
(27, 4747, 1),
(27, 4766, 1),
(27, 4772, 1),
(27, 4782, 1),
(27, 4788, 1),
(27, 4789, 1),
(27, 4810, 1),
(27, 4847, 1),
(27, 4855, 1),
(27, 4858, 1),
(27, 4859, 1),
(27, 4863, 1),
(27, 4893, 1),
(27, 4901, 1),
(27, 4905, 1),
(27, 4920, 1),
(27, 4921, 1),
(27, 4922, 1),
(27, 4923, 1),
(27, 4924, 1),
(27, 4925, 1),
(27, 4926, 1),
(27, 6027, 1),
(27, 6028, 1),
(27, 6029, 1),
(27, 6030, 1),
(27, 6031, 1),
(27, 6032, 1),
(27, 6033, 1),
(27, 6034, 1),
(27, 6035, 1),
(27, 6036, 1),
(27, 6037, 1),
(27, 6038, 1),
(27, 6039, 1),
(27, 6040, 1),
(27, 6041, 1),
(27, 6042, 1),
(27, 6043, 1),
(27, 6044, 1),
(27, 6045, 1),
(27, 6046, 1),
(27, 6047, 1),
(27, 6048, 1),
(27, 6049, 1),
(27, 6050, 1),
(27, 6051, 1),
(27, 6052, 1),
(27, 6053, 1),
(27, 6054, 1),
(27, 6055, 1),
(27, 6056, 1),
(27, 6057, 1),
(27, 6058, 1),
(27, 6059, 1),
(27, 6060, 1),
(27, 6061, 1),
(27, 6062, 1),
(27, 6063, 1),
(27, 6064, 1),
(27, 6065, 1),
(27, 6066, 1),
(27, 6067, 1),
(27, 6068, 1),
(27, 6069, 1),
(27, 6070, 1),
(27, 6071, 1),
(27, 6072, 1),
(27, 6073, 1),
(27, 6074, 1),
(27, 6075, 1),
(27, 6076, 1),
(27, 6077, 1),
(27, 6078, 1),
(27, 6079, 1),
(27, 6080, 1),
(27, 6081, 1),
(27, 6082, 1),
(27, 6083, 1),
(27, 6084, 1),
(27, 6085, 1),
(27, 6086, 1),
(27, 6087, 1),
(27, 6088, 1),
(27, 6089, 1),
(27, 6090, 1),
(27, 6091, 1),
(27, 6092, 1),
(27, 6093, 1),
(27, 6094, 1),
(27, 6095, 1),
(27, 6096, 1),
(27, 6097, 1),
(27, 6098, 1),
(27, 6099, 1),
(27, 6101, 1),
(27, 6102, 1),
(27, 6103, 1),
(27, 6104, 1),
(27, 6105, 1),
(27, 6106, 1),
(27, 6107, 1),
(27, 6108, 1),
(27, 6109, 1),
(27, 6110, 1),
(27, 6111, 1),
(27, 6112, 1),
(27, 6113, 1),
(27, 6114, 1),
(27, 6115, 1),
(27, 6116, 1),
(27, 6117, 1),
(27, 6118, 1),
(27, 6119, 1),
(27, 6120, 1),
(27, 6121, 1),
(27, 6122, 1),
(27, 6123, 1),
(27, 6124, 1),
(27, 6125, 1),
(27, 6126, 1),
(27, 6127, 1),
(27, 6128, 1),
(27, 6129, 1),
(27, 6130, 1),
(27, 6131, 1),
(27, 6132, 1),
(27, 6133, 1),
(27, 6134, 1),
(27, 6135, 1),
(27, 6136, 1),
(27, 6137, 1),
(27, 6138, 1),
(27, 6139, 1),
(27, 6140, 1),
(27, 6141, 1),
(27, 6142, 1),
(27, 6143, 1),
(27, 6144, 1),
(27, 6145, 1),
(27, 6146, 1),
(27, 6147, 1),
(27, 6148, 1),
(27, 6149, 1),
(27, 6150, 1),
(27, 4219, 2),
(27, 4220, 2),
(27, 4221, 2),
(27, 4222, 2),
(27, 4223, 2),
(27, 4225, 2),
(27, 4571, 2),
(27, 4750, 2),
(27, 5139, 2),
(27, 4216, 4),
(27, 4562, 4),
(27, 6151, 4),
(27, 4068, 7),
(27, 4544, 7),
(27, 6017, 7),
(27, 6018, 7),
(27, 6019, 7),
(27, 6020, 7),
(27, 6021, 7),
(27, 6022, 7),
(27, 6023, 7),
(27, 6024, 7),
(27, 6026, 7),
(27, 4214, 8),
(27, 4543, 8),
(27, 6025, 8),
(28, 4067, 1),
(28, 4097, 1),
(28, 4120, 1),
(28, 4125, 1),
(28, 4140, 1),
(28, 4141, 1),
(28, 4150, 1),
(28, 4153, 1),
(28, 4201, 1),
(28, 4203, 1),
(28, 4206, 1),
(28, 4566, 1),
(28, 4601, 1),
(28, 4602, 1),
(28, 4606, 1),
(28, 4635, 1),
(28, 4636, 1),
(28, 4647, 1),
(28, 4653, 1),
(28, 4671, 1),
(28, 4679, 1),
(28, 4709, 1),
(28, 4710, 1),
(28, 4744, 1),
(28, 4756, 1),
(28, 4761, 1),
(28, 4766, 1),
(28, 4772, 1),
(28, 4781, 1),
(28, 4799, 1),
(28, 4801, 1),
(28, 4812, 1),
(28, 4829, 1),
(28, 4837, 1),
(28, 4893, 1),
(28, 4900, 1),
(28, 4901, 1),
(28, 4905, 1),
(28, 4912, 1),
(28, 4931, 1),
(28, 6018, 1),
(28, 6043, 1),
(28, 6047, 1),
(28, 6084, 1),
(28, 6132, 1),
(28, 7273, 1),
(28, 7274, 1),
(28, 7275, 1),
(28, 7276, 1),
(28, 7277, 1),
(28, 7278, 1),
(28, 7279, 1),
(28, 7280, 1),
(28, 7281, 1),
(28, 7282, 1),
(28, 7283, 1),
(28, 7284, 1),
(28, 7285, 1),
(28, 7287, 1),
(28, 7288, 1),
(28, 7289, 1),
(28, 7291, 1),
(28, 7292, 1),
(28, 7293, 1),
(28, 7294, 1),
(28, 7295, 1),
(28, 7296, 1),
(28, 7298, 1),
(28, 7299, 1),
(28, 7300, 1),
(28, 7301, 1),
(28, 7302, 1),
(28, 7304, 1),
(28, 7305, 1),
(28, 7307, 1),
(28, 7308, 1),
(28, 7309, 1),
(28, 7310, 1),
(28, 7311, 1),
(28, 7312, 1),
(28, 7313, 1),
(28, 7314, 1),
(28, 7315, 1),
(28, 7316, 1),
(28, 7317, 1),
(28, 7318, 1),
(28, 7320, 1),
(28, 7321, 1),
(28, 7322, 1),
(28, 7324, 1),
(28, 7325, 1),
(28, 7328, 1),
(28, 7330, 1),
(28, 7331, 1),
(28, 7332, 1),
(28, 7333, 1),
(28, 7334, 1),
(28, 7335, 1),
(28, 7336, 1),
(28, 7337, 1),
(28, 7338, 1),
(28, 7339, 1),
(28, 7340, 1),
(28, 7341, 1),
(28, 7342, 1),
(28, 7343, 1),
(28, 7344, 1),
(28, 7345, 1),
(28, 7346, 1),
(28, 7347, 1),
(28, 7348, 1),
(28, 7349, 1),
(28, 7350, 1),
(28, 7351, 1),
(28, 7352, 1),
(28, 7353, 1),
(28, 7354, 1),
(28, 7355, 1),
(28, 7356, 1),
(28, 7357, 1),
(28, 7358, 1),
(28, 7359, 1),
(28, 7360, 1),
(28, 7361, 1),
(28, 7362, 1),
(28, 7363, 1),
(28, 7364, 1),
(28, 7365, 1),
(28, 7366, 1),
(28, 7367, 1),
(28, 7368, 1),
(28, 7369, 1),
(28, 7370, 1),
(28, 7371, 1),
(28, 7372, 1),
(28, 7373, 1),
(28, 7374, 1),
(28, 7375, 1),
(28, 7376, 1),
(28, 7377, 1),
(28, 7378, 1),
(28, 7379, 1),
(28, 7380, 1),
(28, 7381, 1),
(28, 7382, 1),
(28, 7383, 1),
(28, 7384, 1),
(28, 7385, 1),
(28, 8437, 1),
(28, 8438, 1),
(28, 8439, 1),
(28, 8440, 1),
(28, 4219, 2),
(28, 4220, 2),
(28, 4221, 2),
(28, 4222, 2),
(28, 4223, 2),
(28, 4225, 2),
(28, 4226, 2),
(28, 4227, 2),
(28, 5139, 2),
(28, 8257, 2),
(28, 8258, 2),
(28, 4216, 3),
(28, 4217, 3),
(28, 4218, 3),
(28, 4066, 7),
(28, 4076, 7),
(28, 4543, 7),
(28, 4607, 7),
(28, 4839, 7),
(28, 7270, 7),
(28, 7271, 7),
(28, 7272, 7),
(28, 4068, 8),
(28, 4078, 8),
(29, 4076, 1),
(29, 4077, 1),
(29, 4079, 1),
(29, 4088, 1),
(29, 4140, 1),
(29, 4150, 1),
(29, 4153, 1),
(29, 4177, 1),
(29, 4185, 1),
(29, 4201, 1),
(29, 4205, 1),
(29, 4215, 1),
(29, 4560, 1),
(29, 4574, 1),
(29, 4581, 1),
(29, 4647, 1),
(29, 4651, 1),
(29, 4664, 1),
(29, 4691, 1),
(29, 4703, 1),
(29, 4709, 1),
(29, 4715, 1),
(29, 4738, 1),
(29, 4744, 1),
(29, 4905, 1),
(29, 4926, 1),
(29, 6025, 1),
(29, 6071, 1),
(29, 6075, 1),
(29, 6098, 1),
(29, 7271, 1),
(29, 7272, 1),
(29, 7311, 1),
(29, 8258, 1),
(29, 8622, 1),
(29, 8623, 1),
(29, 8624, 1),
(29, 8625, 1),
(29, 8626, 1),
(29, 8627, 1),
(29, 8628, 1),
(29, 8629, 1),
(29, 8630, 1),
(29, 8631, 1),
(29, 8632, 1),
(29, 8633, 1),
(29, 8634, 1),
(29, 8635, 1),
(29, 8636, 1),
(29, 8637, 1),
(29, 8638, 1),
(29, 8639, 1),
(29, 8640, 1),
(29, 8641, 1),
(29, 8642, 1),
(29, 8643, 1),
(29, 8644, 1),
(29, 8645, 1),
(29, 8646, 1),
(29, 8647, 1),
(29, 8648, 1),
(29, 8649, 1),
(29, 8650, 1),
(29, 8651, 1),
(29, 8652, 1),
(29, 8653, 1),
(29, 8654, 1),
(29, 8655, 1),
(29, 8656, 1),
(29, 8657, 1),
(29, 8658, 1),
(29, 8659, 1),
(29, 8660, 1),
(29, 8661, 1),
(29, 8662, 1),
(29, 8663, 1),
(29, 8664, 1),
(29, 8665, 1),
(29, 8666, 1),
(29, 8667, 1),
(29, 8668, 1),
(29, 8670, 1),
(29, 8671, 1),
(29, 8672, 1),
(29, 8673, 1),
(29, 8674, 1),
(29, 8675, 1),
(29, 8676, 1),
(29, 8677, 1),
(29, 8678, 1),
(29, 8679, 1),
(29, 8680, 1),
(29, 8681, 1),
(29, 8682, 1),
(29, 8683, 1),
(29, 8684, 1),
(29, 8685, 1),
(29, 8686, 1),
(29, 8687, 1),
(29, 8688, 1),
(29, 8689, 1),
(29, 8690, 1),
(29, 8691, 1),
(29, 8692, 1),
(29, 8693, 1),
(29, 8694, 1),
(29, 8695, 1),
(29, 8696, 1),
(29, 8697, 1),
(29, 8698, 1),
(29, 8699, 1),
(29, 8700, 1),
(29, 8701, 1),
(29, 8702, 1),
(29, 8703, 1),
(29, 8704, 1),
(29, 8705, 1),
(29, 8706, 1),
(29, 8707, 1),
(29, 8708, 1),
(29, 8709, 1),
(29, 8710, 1),
(29, 8711, 1),
(29, 8712, 1),
(29, 8713, 1),
(29, 8714, 1),
(29, 8715, 1),
(29, 8716, 1),
(29, 8717, 1),
(29, 8718, 1),
(29, 8719, 1),
(29, 8720, 1),
(29, 8721, 1),
(29, 8722, 1),
(29, 8723, 1),
(29, 4219, 2),
(29, 4220, 2),
(29, 4221, 2),
(29, 4222, 2),
(29, 4223, 2),
(29, 4225, 2),
(29, 4226, 2),
(29, 4227, 2),
(29, 9760, 2),
(29, 9761, 2),
(29, 4126, 3),
(29, 8669, 3),
(29, 8724, 3),
(29, 4157, 6),
(29, 8614, 6),
(29, 4068, 7),
(29, 4147, 7),
(29, 4544, 7),
(29, 8613, 7),
(29, 8615, 7),
(29, 8616, 7),
(29, 8618, 7),
(29, 8619, 7),
(29, 8620, 7),
(29, 8621, 7),
(29, 4075, 8),
(29, 4788, 8),
(29, 8617, 8),
(30, 4075, 1),
(30, 4078, 1),
(30, 4079, 1),
(30, 4082, 1),
(30, 4085, 1),
(30, 4094, 1),
(30, 4104, 1),
(30, 4111, 1),
(30, 4120, 1),
(30, 4123, 1),
(30, 4124, 1),
(30, 4125, 1),
(30, 4131, 1),
(30, 4140, 1),
(30, 4150, 1),
(30, 4153, 1),
(30, 4157, 1),
(30, 4164, 1),
(30, 4167, 1),
(30, 4188, 1),
(30, 4190, 1),
(30, 4201, 1),
(30, 4202, 1),
(30, 4203, 1),
(30, 4207, 1),
(30, 4214, 1),
(30, 4381, 1),
(30, 4543, 1),
(30, 4545, 1),
(30, 4552, 1),
(30, 4560, 1),
(30, 4568, 1),
(30, 4574, 1),
(30, 4581, 1),
(30, 4605, 1),
(30, 4606, 1),
(30, 4609, 1),
(30, 4614, 1),
(30, 4617, 1),
(30, 4625, 1),
(30, 4635, 1),
(30, 4648, 1),
(30, 4651, 1),
(30, 4657, 1),
(30, 4664, 1),
(30, 4671, 1),
(30, 4679, 1),
(30, 4682, 1),
(30, 4691, 1),
(30, 4703, 1),
(30, 4709, 1),
(30, 4715, 1),
(30, 4716, 1),
(30, 4719, 1),
(30, 4742, 1),
(30, 4747, 1),
(30, 4758, 1),
(30, 4766, 1),
(30, 4772, 1),
(30, 4779, 1),
(30, 4782, 1),
(30, 4785, 1),
(30, 4788, 1),
(30, 4802, 1),
(30, 4847, 1),
(30, 4863, 1),
(30, 4867, 1),
(30, 4893, 1),
(30, 4901, 1),
(30, 4905, 1),
(30, 4913, 1),
(30, 4920, 1),
(30, 4921, 1),
(30, 4922, 1),
(30, 4923, 1),
(30, 4924, 1),
(30, 4925, 1),
(30, 4926, 1),
(30, 6025, 1),
(30, 6038, 1),
(30, 6039, 1),
(30, 6047, 1),
(30, 6051, 1),
(30, 6064, 1),
(30, 6069, 1),
(30, 6071, 1),
(30, 6083, 1),
(30, 6084, 1),
(30, 6090, 1),
(30, 6091, 1),
(30, 6098, 1),
(30, 6101, 1),
(30, 6102, 1),
(30, 6119, 1),
(30, 6120, 1),
(30, 6128, 1),
(30, 6141, 1),
(30, 6150, 1),
(30, 7293, 1),
(30, 7321, 1),
(30, 8628, 1),
(30, 9927, 1),
(30, 9928, 1),
(30, 9929, 1),
(30, 9930, 1),
(30, 9931, 1),
(30, 9932, 1),
(30, 9933, 1),
(30, 9934, 1),
(30, 9935, 1),
(30, 9936, 1),
(30, 9937, 1),
(30, 9938, 1),
(30, 9939, 1),
(30, 9940, 1),
(30, 9941, 1),
(30, 9942, 1),
(30, 9943, 1),
(30, 9944, 1),
(30, 9945, 1),
(30, 9946, 1),
(30, 9947, 1),
(30, 9948, 1),
(30, 9949, 1),
(30, 9950, 1),
(30, 9951, 1),
(30, 9952, 1),
(30, 9953, 1),
(30, 9954, 1),
(30, 9955, 1),
(30, 9956, 1),
(30, 9957, 1),
(30, 9958, 1),
(30, 9959, 1),
(30, 9960, 1),
(30, 9961, 1),
(30, 9962, 1),
(30, 9963, 1),
(30, 9964, 1),
(30, 9965, 1),
(30, 9966, 1),
(30, 9967, 1),
(30, 9968, 1),
(30, 9969, 1),
(30, 9970, 1),
(30, 9971, 1),
(30, 9972, 1),
(30, 9973, 1),
(30, 9974, 1),
(30, 9975, 1),
(30, 9976, 1),
(30, 9977, 1),
(30, 9978, 1),
(30, 9979, 1),
(30, 9980, 1),
(30, 9981, 1),
(30, 9982, 1),
(30, 9983, 1),
(30, 9984, 1),
(30, 9985, 1),
(30, 9986, 1),
(30, 9987, 1),
(30, 9988, 1),
(30, 9989, 1),
(30, 9990, 1),
(30, 9991, 1),
(30, 9992, 1),
(30, 9993, 1),
(30, 9994, 1),
(30, 9995, 1),
(30, 9996, 1),
(30, 9997, 1),
(30, 9998, 1),
(30, 9999, 1),
(30, 10000, 1),
(30, 10001, 1),
(30, 10002, 1),
(30, 10003, 1),
(30, 10004, 1),
(30, 10005, 1),
(30, 10006, 1),
(30, 4219, 2),
(30, 4220, 2),
(30, 4221, 2),
(30, 4222, 2),
(30, 4223, 2),
(30, 4225, 2),
(30, 4571, 2),
(30, 4750, 2),
(30, 5139, 2),
(30, 4216, 3),
(30, 4217, 3),
(30, 4218, 3),
(30, 4068, 7),
(30, 4133, 7),
(30, 4208, 7),
(30, 4546, 7),
(30, 4549, 7),
(30, 4895, 7),
(30, 6019, 7),
(30, 6020, 7),
(30, 9923, 7),
(30, 9924, 7),
(30, 9925, 7),
(30, 9926, 7),
(30, 4066, 8),
(30, 4067, 8),
(30, 4604, 8),
(31, 4104, 1),
(31, 4109, 1),
(31, 4120, 1),
(31, 4141, 1),
(31, 4147, 1),
(31, 4149, 1),
(31, 4150, 1),
(31, 4153, 1),
(31, 4177, 1),
(31, 4180, 1),
(31, 4188, 1),
(31, 4201, 1),
(31, 4208, 1),
(31, 4227, 1),
(31, 4381, 1),
(31, 4564, 1),
(31, 4567, 1),
(31, 4595, 1),
(31, 4624, 1),
(31, 4635, 1),
(31, 4651, 1),
(31, 4659, 1),
(31, 4744, 1),
(31, 4746, 1),
(31, 4758, 1),
(31, 4788, 1),
(31, 4828, 1),
(31, 4881, 1),
(31, 4895, 1),
(31, 5583, 1),
(31, 6018, 1),
(31, 6040, 1),
(31, 6062, 1),
(31, 6139, 1),
(31, 6150, 1),
(31, 7347, 1),
(31, 8623, 1),
(31, 8638, 1),
(31, 8676, 1),
(31, 8722, 1),
(31, 9934, 1),
(31, 9966, 1),
(31, 9970, 1),
(31, 9987, 1),
(31, 11711, 1),
(31, 11712, 1),
(31, 11713, 1),
(31, 11714, 1),
(31, 11715, 1),
(31, 11716, 1),
(31, 11717, 1),
(31, 11718, 1),
(31, 11719, 1),
(31, 11720, 1),
(31, 11721, 1),
(31, 11722, 1),
(31, 11723, 1),
(31, 11724, 1),
(31, 11725, 1),
(31, 11726, 1),
(31, 11727, 1),
(31, 11728, 1),
(31, 11729, 1),
(31, 11730, 1),
(31, 11731, 1),
(31, 11732, 1),
(31, 11733, 1),
(31, 11734, 1),
(31, 11735, 1),
(31, 11736, 1),
(31, 11737, 1),
(31, 11738, 1),
(31, 11739, 1),
(31, 11740, 1),
(31, 11741, 1),
(31, 11742, 1),
(31, 11743, 1),
(31, 11744, 1),
(31, 11745, 1),
(31, 11746, 1),
(31, 11747, 1),
(31, 11748, 1),
(31, 11749, 1),
(31, 11750, 1),
(31, 11751, 1),
(31, 11752, 1),
(31, 11753, 1),
(31, 11754, 1),
(31, 11755, 1),
(31, 11756, 1),
(31, 11757, 1),
(31, 11758, 1),
(31, 11759, 1),
(31, 11760, 1),
(31, 11761, 1),
(31, 11762, 1),
(31, 11763, 1),
(31, 11764, 1),
(31, 11765, 1),
(31, 11766, 1),
(31, 11767, 1),
(31, 11768, 1),
(31, 11769, 1),
(31, 11770, 1),
(31, 11771, 1),
(31, 11772, 1),
(31, 11773, 1),
(31, 11774, 1),
(31, 11775, 1),
(31, 11776, 1),
(31, 11777, 1),
(31, 11778, 1),
(31, 11779, 1),
(31, 11780, 1),
(31, 11781, 1),
(31, 11782, 1),
(31, 11783, 1),
(31, 11784, 1),
(31, 11785, 1),
(31, 11786, 1),
(31, 11787, 1),
(31, 11788, 1),
(31, 11789, 1),
(31, 11790, 1),
(31, 11791, 1),
(31, 11792, 1),
(31, 11793, 1),
(31, 11794, 1),
(31, 11795, 1),
(31, 11796, 1),
(31, 11797, 1),
(31, 11798, 1),
(31, 11799, 1),
(31, 11800, 1),
(31, 11801, 1),
(31, 11802, 1),
(31, 11803, 1),
(31, 11804, 1),
(31, 11805, 1),
(31, 11806, 1),
(31, 11807, 1),
(31, 11808, 1),
(31, 11809, 1),
(31, 11810, 1),
(31, 11811, 1),
(31, 11812, 1),
(31, 11813, 1),
(31, 11814, 1),
(31, 11815, 1),
(31, 11816, 1),
(31, 11817, 1),
(31, 11818, 1),
(31, 11819, 1),
(31, 11820, 1),
(31, 11821, 1),
(31, 11822, 1),
(31, 11823, 1),
(31, 11824, 1),
(31, 11825, 1),
(31, 11826, 1),
(31, 11827, 1),
(31, 11828, 1),
(31, 11829, 1),
(31, 11830, 1),
(31, 11831, 1),
(31, 11832, 1),
(31, 11833, 1),
(31, 11834, 1),
(31, 11835, 1),
(31, 11836, 1),
(31, 11837, 1),
(31, 11838, 1),
(31, 11839, 1),
(31, 11840, 1),
(31, 11841, 1),
(31, 11844, 1),
(31, 11845, 1),
(31, 11846, 1),
(31, 11847, 1),
(31, 11849, 1),
(31, 11850, 1),
(31, 11851, 1),
(31, 11852, 1),
(31, 11853, 1),
(31, 13480, 1),
(31, 4219, 2),
(31, 4220, 2),
(31, 4221, 2),
(31, 4222, 2),
(31, 4223, 2),
(31, 4225, 2),
(31, 13271, 2),
(31, 13272, 2),
(31, 4216, 3),
(31, 4750, 3),
(31, 11854, 3),
(31, 11855, 3),
(31, 8258, 6),
(31, 9940, 6),
(31, 11705, 6),
(31, 4108, 7),
(31, 11706, 7),
(31, 11707, 7),
(31, 11708, 7),
(31, 11709, 7),
(31, 11710, 7),
(31, 4068, 8),
(31, 4075, 8),
(32, 4067, 1),
(32, 4071, 1),
(32, 4076, 1),
(32, 4078, 1),
(32, 4079, 1),
(32, 4088, 1),
(32, 4089, 1),
(32, 4093, 1),
(32, 4094, 1),
(32, 4097, 1),
(32, 4104, 1),
(32, 4113, 1),
(32, 4115, 1),
(32, 4117, 1),
(32, 4120, 1),
(32, 4123, 1),
(32, 4124, 1),
(32, 4127, 1),
(32, 4128, 1),
(32, 4136, 1),
(32, 4147, 1),
(32, 4150, 1),
(32, 4153, 1),
(32, 4159, 1),
(32, 4164, 1),
(32, 4168, 1),
(32, 4182, 1),
(32, 4193, 1),
(32, 4199, 1),
(32, 4201, 1),
(32, 4203, 1),
(32, 4205, 1),
(32, 4206, 1),
(32, 4208, 1),
(32, 4210, 1),
(32, 4214, 1),
(32, 4215, 1),
(32, 4216, 1),
(32, 4381, 1),
(32, 4543, 1),
(32, 4544, 1),
(32, 4548, 1),
(32, 4549, 1),
(32, 4554, 1),
(32, 4568, 1),
(32, 4573, 1),
(32, 4574, 1),
(32, 4581, 1),
(32, 4601, 1),
(32, 4602, 1),
(32, 4604, 1),
(32, 4625, 1),
(32, 4626, 1),
(32, 4635, 1),
(32, 4648, 1),
(32, 4651, 1),
(32, 4664, 1),
(32, 4671, 1),
(32, 4675, 1),
(32, 4677, 1),
(32, 4679, 1),
(32, 4688, 1),
(32, 4689, 1),
(32, 4691, 1),
(32, 4693, 1),
(32, 4696, 1),
(32, 4703, 1),
(32, 4705, 1),
(32, 4707, 1),
(32, 4708, 1),
(32, 4729, 1),
(32, 4730, 1),
(32, 4744, 1),
(32, 4747, 1),
(32, 4758, 1),
(32, 4761, 1),
(32, 4767, 1),
(32, 4772, 1),
(32, 4773, 1),
(32, 4788, 1),
(32, 4789, 1),
(32, 4807, 1),
(32, 4808, 1),
(32, 4814, 1),
(32, 4816, 1),
(32, 4837, 1),
(32, 4878, 1),
(32, 4879, 1),
(32, 4891, 1),
(32, 4892, 1),
(32, 4893, 1),
(32, 4895, 1),
(32, 4898, 1),
(32, 4900, 1),
(32, 4901, 1),
(32, 4905, 1),
(32, 4920, 1),
(32, 4927, 1),
(32, 4931, 1),
(32, 6018, 1),
(32, 6026, 1),
(32, 6035, 1),
(32, 6043, 1),
(32, 6045, 1),
(32, 6046, 1),
(32, 6047, 1),
(32, 6049, 1),
(32, 6053, 1),
(32, 6057, 1),
(32, 6062, 1),
(32, 6064, 1),
(32, 6070, 1),
(32, 6080, 1),
(32, 6091, 1),
(32, 6124, 1),
(32, 6130, 1),
(32, 6132, 1),
(32, 6138, 1),
(32, 6139, 1),
(32, 6150, 1),
(32, 7273, 1),
(32, 7283, 1),
(32, 7293, 1),
(32, 7295, 1),
(32, 7301, 1),
(32, 7305, 1),
(32, 7314, 1),
(32, 7321, 1),
(32, 7328, 1),
(32, 7336, 1),
(32, 7337, 1),
(32, 7355, 1),
(32, 8439, 1),
(32, 8440, 1),
(32, 8634, 1),
(32, 8642, 1),
(32, 8646, 1),
(32, 8648, 1),
(32, 8672, 1),
(32, 8720, 1),
(32, 8722, 1),
(32, 9760, 1),
(32, 9926, 1),
(32, 9934, 1),
(32, 9936, 1),
(32, 9940, 1),
(32, 9942, 1),
(32, 9946, 1),
(32, 9961, 1),
(32, 9976, 1),
(32, 9987, 1),
(32, 9989, 1),
(32, 9998, 1),
(32, 10002, 1),
(32, 10004, 1),
(32, 11712, 1),
(32, 11731, 1),
(32, 11754, 1),
(32, 11772, 1),
(32, 11782, 1),
(32, 11791, 1),
(32, 11820, 1),
(32, 11828, 1),
(32, 11840, 1),
(32, 11841, 1),
(32, 11847, 1),
(32, 13700, 1),
(32, 13701, 1),
(32, 13702, 1),
(32, 13703, 1),
(32, 13704, 1),
(32, 13706, 1),
(32, 13707, 1),
(32, 13708, 1),
(32, 13709, 1),
(32, 13712, 1),
(32, 13713, 1),
(32, 13714, 1),
(32, 13715, 1),
(32, 13718, 1),
(32, 13720, 1),
(32, 13721, 1),
(32, 13722, 1),
(32, 13723, 1),
(32, 13724, 1),
(32, 13725, 1),
(32, 13726, 1),
(32, 13727, 1),
(32, 13728, 1),
(32, 13729, 1),
(32, 13730, 1),
(32, 13731, 1),
(32, 13732, 1),
(32, 13733, 1),
(32, 13734, 1),
(32, 13735, 1),
(32, 13736, 1),
(32, 13737, 1),
(32, 13738, 1),
(32, 13739, 1),
(32, 13740, 1),
(32, 13741, 1),
(32, 13742, 1),
(32, 13743, 1),
(32, 13744, 1),
(32, 13745, 1),
(32, 13746, 1),
(32, 13747, 1),
(32, 13748, 1),
(32, 13749, 1),
(32, 13750, 1),
(32, 13751, 1),
(32, 13752, 1),
(32, 13753, 1),
(32, 13754, 1),
(32, 13755, 1),
(32, 13756, 1),
(32, 13757, 1),
(32, 13758, 1),
(32, 13759, 1),
(32, 13760, 1),
(32, 13761, 1),
(32, 13762, 1),
(32, 13763, 1),
(32, 13764, 1),
(32, 13765, 1),
(32, 13766, 1),
(32, 13767, 1),
(32, 13768, 1),
(32, 13769, 1),
(32, 13770, 1),
(32, 13771, 1),
(32, 13772, 1),
(32, 13773, 1),
(32, 13774, 1),
(32, 13775, 1),
(32, 13776, 1),
(32, 13777, 1),
(32, 13778, 1),
(32, 13779, 1),
(32, 13780, 1),
(32, 13781, 1),
(32, 13782, 1),
(32, 13783, 1),
(32, 13784, 1),
(32, 13785, 1),
(32, 13786, 1),
(32, 13787, 1),
(32, 13788, 1),
(32, 13789, 1),
(32, 13790, 1),
(32, 13791, 1),
(32, 13792, 1),
(32, 13793, 1),
(32, 13794, 1),
(32, 13796, 1),
(32, 13797, 1),
(32, 13798, 1),
(32, 13799, 1),
(32, 13800, 1),
(32, 13801, 1),
(32, 13802, 1),
(32, 13803, 1),
(32, 13804, 1),
(32, 13805, 1),
(32, 13806, 1),
(32, 13807, 1),
(32, 13808, 1),
(32, 13809, 1),
(32, 13811, 1),
(32, 13812, 1),
(32, 13813, 1),
(32, 13814, 1),
(32, 13815, 1),
(32, 13816, 1),
(32, 13817, 1),
(32, 13818, 1),
(32, 13819, 1),
(32, 13821, 1),
(32, 13822, 1),
(32, 13823, 1),
(32, 13824, 1),
(32, 13825, 1),
(32, 13826, 1),
(32, 13829, 1),
(32, 13832, 1),
(32, 13833, 1),
(32, 13836, 1),
(32, 13837, 1),
(32, 13838, 1),
(32, 13839, 1),
(32, 13840, 1),
(32, 13841, 1),
(32, 13842, 1),
(32, 13844, 1),
(32, 13845, 1),
(32, 13846, 1),
(32, 13847, 1),
(32, 13848, 1),
(32, 13849, 1),
(32, 13850, 1),
(32, 13851, 1),
(32, 13852, 1),
(32, 13853, 1),
(32, 13854, 1),
(32, 13855, 1),
(32, 13856, 1),
(32, 13857, 1),
(32, 13858, 1),
(32, 13859, 1),
(32, 13860, 1),
(32, 13861, 1),
(32, 13862, 1),
(32, 13863, 1),
(32, 13864, 1),
(32, 13866, 1),
(32, 13867, 1),
(32, 13868, 1),
(32, 13869, 1),
(32, 13872, 1),
(32, 13873, 1),
(32, 13874, 1),
(32, 13875, 1),
(32, 13876, 1),
(32, 13877, 1),
(32, 13878, 1),
(32, 13879, 1),
(32, 13880, 1),
(32, 13882, 1),
(32, 13883, 1),
(32, 13884, 1),
(32, 13885, 1),
(32, 13886, 1),
(32, 13887, 1),
(32, 13891, 1),
(32, 13892, 1),
(32, 13893, 1),
(32, 13894, 1),
(32, 13895, 1),
(32, 13899, 1),
(32, 13900, 1),
(32, 13901, 1),
(32, 13902, 1),
(32, 13903, 1),
(32, 13904, 1),
(32, 13905, 1),
(32, 13906, 1),
(32, 13907, 1),
(32, 13908, 1),
(32, 13909, 1),
(32, 13910, 1),
(32, 13911, 1),
(32, 13912, 1),
(32, 13913, 1),
(32, 13914, 1),
(32, 13915, 1),
(32, 13916, 1),
(32, 13917, 1),
(32, 13918, 1),
(32, 13919, 1),
(32, 13920, 1),
(32, 13921, 1),
(32, 13922, 1),
(32, 13923, 1),
(32, 13924, 1),
(32, 13925, 1),
(32, 13926, 1),
(32, 13927, 1),
(32, 13928, 1),
(32, 13929, 1),
(32, 13930, 1),
(32, 13931, 1),
(32, 13932, 1),
(32, 13934, 1),
(32, 13936, 1),
(32, 13939, 1),
(32, 13940, 1),
(32, 13941, 1),
(32, 13942, 1),
(32, 13943, 1),
(32, 13944, 1),
(32, 13945, 1),
(32, 13946, 1),
(32, 13947, 1),
(32, 13948, 1),
(32, 13949, 1),
(32, 13950, 1),
(32, 13951, 1),
(32, 13952, 1),
(32, 13953, 1),
(32, 13954, 1),
(32, 13955, 1),
(32, 13956, 1),
(32, 13957, 1),
(32, 13958, 1),
(32, 13959, 1),
(32, 13960, 1),
(32, 13961, 1),
(32, 13962, 1),
(32, 13963, 1),
(32, 13964, 1),
(32, 13965, 1),
(32, 13966, 1),
(32, 13967, 1),
(32, 13968, 1),
(32, 13969, 1),
(32, 13970, 1),
(32, 13971, 1),
(32, 13972, 1),
(32, 13973, 1),
(32, 13975, 1),
(32, 13976, 1),
(32, 13977, 1),
(32, 13978, 1),
(32, 13979, 1),
(32, 13980, 1),
(32, 13981, 1),
(32, 13982, 1),
(32, 13983, 1),
(32, 13984, 1),
(32, 13985, 1),
(32, 13986, 1),
(32, 13987, 1),
(32, 13988, 1),
(32, 13989, 1),
(32, 13990, 1),
(32, 13991, 1),
(32, 13992, 1),
(32, 13993, 1),
(32, 13994, 1),
(32, 13995, 1),
(32, 13996, 1),
(32, 13997, 1),
(32, 13998, 1),
(32, 13999, 1),
(32, 14000, 1),
(32, 14001, 1),
(32, 14002, 1),
(32, 14003, 1),
(32, 14004, 1),
(32, 14005, 1),
(32, 14006, 1),
(32, 14007, 1),
(32, 14008, 1),
(32, 14009, 1),
(32, 14010, 1),
(32, 14011, 1),
(32, 14012, 1),
(32, 14013, 1),
(32, 14014, 1),
(32, 14015, 1),
(32, 14016, 1),
(32, 14017, 1),
(32, 14018, 1),
(32, 14019, 1),
(32, 14020, 1),
(32, 14021, 1),
(32, 14022, 1),
(32, 14023, 1),
(32, 14024, 1),
(32, 14025, 1),
(32, 14026, 1),
(32, 14027, 1),
(32, 14028, 1),
(32, 14029, 1),
(32, 14030, 1),
(32, 14031, 1),
(32, 14032, 1),
(32, 14033, 1),
(32, 14034, 1),
(32, 14035, 1),
(32, 14036, 1),
(32, 14037, 1),
(32, 14038, 1),
(32, 14039, 1),
(32, 14040, 1),
(32, 14043, 1),
(32, 14044, 1),
(32, 14045, 1),
(32, 14046, 1),
(32, 14047, 1),
(32, 14048, 1),
(32, 14049, 1),
(32, 14050, 1),
(32, 14051, 1),
(32, 14052, 1),
(32, 14053, 1),
(32, 14054, 1),
(32, 14055, 1),
(32, 14056, 1),
(32, 14057, 1),
(32, 14058, 1),
(32, 14059, 1),
(32, 14060, 1),
(32, 14061, 1),
(32, 14062, 1),
(32, 14063, 1),
(32, 14064, 1),
(32, 14065, 1),
(32, 14066, 1),
(32, 14067, 1),
(32, 14068, 1),
(32, 14069, 1),
(32, 14070, 1),
(32, 14071, 1),
(32, 14072, 1),
(32, 14073, 1),
(32, 14074, 1),
(32, 14075, 1),
(32, 14076, 1),
(32, 14077, 1),
(32, 14078, 1),
(32, 14079, 1),
(32, 14080, 1),
(32, 14081, 1),
(32, 14082, 1),
(32, 14083, 1),
(32, 14084, 1),
(32, 14085, 1),
(32, 14086, 1),
(32, 14087, 1),
(32, 14088, 1),
(32, 14089, 1),
(32, 14090, 1),
(32, 14091, 1),
(32, 14092, 1),
(32, 14093, 1),
(32, 14094, 1),
(32, 14095, 1),
(32, 14096, 1),
(32, 14097, 1),
(32, 14098, 1),
(32, 14099, 1),
(32, 14101, 1),
(32, 14102, 1),
(32, 14104, 1),
(32, 14105, 1),
(32, 14106, 1),
(32, 14107, 1),
(32, 14108, 1),
(32, 14109, 1),
(32, 14110, 1),
(32, 14111, 1),
(32, 14112, 1),
(32, 14113, 1),
(32, 14114, 1),
(32, 14115, 1),
(32, 14116, 1),
(32, 14119, 1),
(32, 14121, 1),
(32, 14123, 1),
(32, 14124, 1),
(32, 14125, 1),
(32, 14126, 1),
(32, 14127, 1),
(32, 14128, 1),
(32, 14129, 1),
(32, 14130, 1),
(32, 14131, 1),
(32, 14132, 1),
(32, 14133, 1),
(32, 14134, 1),
(32, 14135, 1),
(32, 14136, 1),
(32, 14137, 1),
(32, 14138, 1),
(32, 14139, 1),
(32, 14140, 1),
(32, 14141, 1),
(32, 14142, 1),
(32, 14143, 1),
(32, 14144, 1),
(32, 14145, 1),
(32, 14146, 1),
(32, 14147, 1),
(32, 14148, 1),
(32, 14149, 1),
(32, 14150, 1),
(32, 14151, 1),
(32, 14153, 1),
(32, 14154, 1),
(32, 14155, 1),
(32, 14156, 1),
(32, 14159, 1),
(32, 14161, 1),
(32, 14163, 1),
(32, 14164, 1),
(32, 14165, 1),
(32, 14166, 1),
(32, 14167, 1),
(32, 14168, 1),
(32, 14169, 1),
(32, 14170, 1),
(32, 14171, 1),
(32, 14172, 1),
(32, 14173, 1),
(32, 14174, 1),
(32, 14175, 1),
(32, 14177, 1),
(32, 14178, 1),
(32, 14179, 1),
(32, 14180, 1),
(32, 14181, 1),
(32, 14182, 1),
(32, 14183, 1),
(32, 14184, 1),
(32, 14185, 1),
(32, 14186, 1),
(32, 14188, 1),
(32, 14189, 1),
(32, 14190, 1),
(32, 14191, 1),
(32, 14192, 1),
(32, 14193, 1),
(32, 14197, 1),
(32, 14198, 1),
(32, 14199, 1),
(32, 14200, 1),
(32, 14201, 1),
(32, 14202, 1),
(32, 14203, 1),
(32, 14204, 1),
(32, 14205, 1),
(32, 14206, 1),
(32, 14207, 1),
(32, 14208, 1),
(32, 14210, 1),
(32, 14211, 1),
(32, 14212, 1),
(32, 14213, 1),
(32, 14214, 1),
(32, 14215, 1),
(32, 14216, 1),
(32, 14218, 1),
(32, 14219, 1),
(32, 14220, 1),
(32, 14221, 1),
(32, 14222, 1),
(32, 14223, 1),
(32, 14224, 1),
(32, 14225, 1),
(32, 14226, 1),
(32, 14227, 1),
(32, 14228, 1),
(32, 14229, 1),
(32, 16703, 1),
(32, 16704, 1),
(32, 16705, 1),
(32, 16706, 1),
(32, 16707, 1),
(32, 16708, 1),
(32, 16709, 1),
(32, 16710, 1),
(32, 16711, 1),
(32, 16712, 1),
(32, 16713, 1),
(32, 16714, 1),
(32, 16715, 1),
(32, 16716, 1),
(32, 4219, 2),
(32, 4220, 2),
(32, 4221, 2),
(32, 4222, 2),
(32, 4223, 2),
(32, 4225, 2),
(32, 4226, 2),
(32, 4227, 2),
(32, 15977, 2),
(32, 15978, 2),
(32, 13795, 3),
(32, 14117, 3),
(32, 14231, 3),
(32, 8258, 6),
(32, 8676, 6),
(32, 4068, 7),
(32, 4157, 7),
(32, 4617, 7),
(32, 13688, 7),
(32, 13690, 7),
(32, 13699, 7),
(32, 4075, 8),
(32, 4855, 8),
(32, 9960, 8),
(32, 13689, 8),
(32, 13691, 8),
(32, 13692, 8),
(32, 13693, 8),
(32, 13694, 8),
(32, 13695, 8),
(32, 13696, 8),
(32, 13697, 8),
(32, 13698, 8),
(33, 4076, 1),
(33, 4078, 1),
(33, 4079, 1),
(33, 4082, 1),
(33, 4086, 1),
(33, 4097, 1),
(33, 4104, 1),
(33, 4111, 1),
(33, 4117, 1),
(33, 4120, 1),
(33, 4124, 1),
(33, 4126, 1),
(33, 4127, 1),
(33, 4128, 1),
(33, 4129, 1),
(33, 4130, 1),
(33, 4136, 1),
(33, 4140, 1),
(33, 4150, 1),
(33, 4153, 1),
(33, 4164, 1),
(33, 4201, 1),
(33, 4203, 1),
(33, 4543, 1),
(33, 4548, 1),
(33, 4564, 1),
(33, 4573, 1),
(33, 4574, 1),
(33, 4578, 1),
(33, 4635, 1),
(33, 4653, 1),
(33, 4679, 1),
(33, 4682, 1),
(33, 4691, 1),
(33, 4696, 1),
(33, 4703, 1),
(33, 4707, 1),
(33, 4708, 1),
(33, 4715, 1),
(33, 4719, 1),
(33, 4742, 1),
(33, 4757, 1),
(33, 4771, 1),
(33, 4772, 1),
(33, 4782, 1),
(33, 4785, 1),
(33, 4788, 1),
(33, 4797, 1),
(33, 4799, 1),
(33, 4843, 1),
(33, 4863, 1),
(33, 4901, 1),
(33, 4923, 1),
(33, 4924, 1),
(33, 4925, 1),
(33, 4926, 1),
(33, 4928, 1),
(33, 4933, 1),
(33, 5583, 1),
(33, 6027, 1),
(33, 6038, 1),
(33, 6045, 1),
(33, 6069, 1),
(33, 6075, 1),
(33, 6084, 1),
(33, 6090, 1),
(33, 6097, 1),
(33, 6098, 1),
(33, 6107, 1),
(33, 6108, 1),
(33, 6109, 1),
(33, 6110, 1),
(33, 6119, 1),
(33, 6120, 1),
(33, 6121, 1),
(33, 6122, 1),
(33, 6148, 1),
(33, 6149, 1),
(33, 7288, 1),
(33, 7298, 1),
(33, 7299, 1),
(33, 7338, 1),
(33, 9926, 1),
(33, 9939, 1),
(33, 9957, 1),
(33, 9998, 1),
(33, 10000, 1),
(33, 11834, 1),
(33, 13766, 1),
(33, 13767, 1),
(33, 13776, 1),
(33, 13922, 1),
(33, 13996, 1),
(33, 14108, 1),
(33, 17398, 1),
(33, 17399, 1),
(33, 17400, 1),
(33, 17401, 1),
(33, 17402, 1),
(33, 17403, 1),
(33, 17404, 1),
(33, 17405, 1),
(33, 17406, 1),
(33, 17407, 1),
(33, 17408, 1),
(33, 17409, 1),
(33, 17410, 1),
(33, 17411, 1),
(33, 17412, 1),
(33, 17413, 1),
(33, 17415, 1),
(33, 17416, 1),
(33, 17417, 1),
(33, 17418, 1),
(33, 17419, 1),
(33, 17420, 1),
(33, 17421, 1),
(33, 17422, 1),
(33, 17423, 1),
(33, 17424, 1),
(33, 17425, 1),
(33, 17426, 1),
(33, 17427, 1),
(33, 17428, 1),
(33, 17429, 1),
(33, 17430, 1),
(33, 17432, 1),
(33, 17433, 1),
(33, 17434, 1),
(33, 17435, 1),
(33, 17436, 1),
(33, 17437, 1),
(33, 17438, 1),
(33, 17439, 1),
(33, 17440, 1),
(33, 17441, 1),
(33, 17442, 1),
(33, 17444, 1),
(33, 17445, 1),
(33, 17446, 1),
(33, 17447, 1),
(33, 17448, 1),
(33, 17449, 1),
(33, 17450, 1),
(33, 17451, 1),
(33, 17452, 1),
(33, 17453, 1),
(33, 4219, 2),
(33, 4220, 2),
(33, 4221, 2),
(33, 4222, 2),
(33, 4223, 2),
(33, 4225, 2),
(33, 4226, 2),
(33, 4227, 2),
(33, 4571, 2),
(33, 5139, 2),
(33, 4216, 3),
(33, 4217, 3),
(33, 4218, 3),
(33, 6019, 6),
(33, 6020, 6),
(33, 4068, 7),
(33, 4066, 8),
(33, 4075, 8),
(33, 4208, 8),
(33, 4617, 8),
(33, 4895, 8),
(33, 7270, 8),
(33, 9943, 8),
(33, 17395, 8),
(33, 17396, 8),
(34, 4079, 1),
(34, 4097, 1),
(34, 4113, 1),
(34, 4120, 1),
(34, 4126, 1),
(34, 4128, 1),
(34, 4129, 1),
(34, 4141, 1),
(34, 4147, 1),
(34, 4153, 1),
(34, 4177, 1),
(34, 4178, 1),
(34, 4185, 1),
(34, 4201, 1),
(34, 4206, 1),
(34, 4215, 1),
(34, 4381, 1),
(34, 4543, 1),
(34, 4548, 1),
(34, 4552, 1),
(34, 4573, 1),
(34, 4606, 1),
(34, 4614, 1),
(34, 4617, 1),
(34, 4633, 1),
(34, 4651, 1),
(34, 4676, 1),
(34, 4682, 1),
(34, 4685, 1),
(34, 4688, 1),
(34, 4693, 1),
(34, 4703, 1),
(34, 4709, 1),
(34, 4726, 1),
(34, 4728, 1),
(34, 4772, 1),
(34, 4793, 1),
(34, 4829, 1),
(34, 4874, 1),
(34, 4900, 1),
(34, 4928, 1),
(34, 6051, 1),
(34, 6064, 1),
(34, 6071, 1),
(34, 6084, 1),
(34, 6102, 1),
(34, 6130, 1),
(34, 7288, 1),
(34, 7308, 1),
(34, 7320, 1),
(34, 8624, 1),
(34, 8657, 1),
(34, 8707, 1),
(34, 9940, 1),
(34, 9957, 1),
(34, 9962, 1),
(34, 11781, 1),
(34, 11838, 1),
(34, 13833, 1),
(34, 13922, 1),
(34, 13956, 1),
(34, 14006, 1),
(34, 14021, 1),
(34, 14059, 1),
(34, 14061, 1),
(34, 14130, 1),
(34, 14147, 1),
(34, 14202, 1),
(34, 17421, 1),
(34, 17441, 1),
(34, 20182, 1),
(34, 20183, 1),
(34, 20184, 1),
(34, 20185, 1),
(34, 20186, 1),
(34, 20187, 1),
(34, 20188, 1),
(34, 20189, 1),
(34, 20190, 1),
(34, 20191, 1),
(34, 20192, 1),
(34, 20193, 1),
(34, 20194, 1),
(34, 20195, 1),
(34, 20196, 1),
(34, 20197, 1),
(34, 20198, 1),
(34, 20199, 1),
(34, 20200, 1),
(34, 20201, 1),
(34, 20202, 1),
(34, 20203, 1),
(34, 20204, 1),
(34, 20205, 1),
(34, 20206, 1),
(34, 20207, 1),
(34, 20208, 1),
(34, 20209, 1),
(34, 20210, 1),
(34, 20211, 1),
(34, 20212, 1),
(34, 20213, 1),
(34, 20214, 1),
(34, 20215, 1),
(34, 20216, 1),
(34, 20217, 1),
(34, 20218, 1),
(34, 20219, 1),
(34, 20220, 1),
(34, 20221, 1),
(34, 20222, 1),
(34, 20223, 1),
(34, 20224, 1),
(34, 20225, 1),
(34, 20226, 1),
(34, 20227, 1),
(34, 20228, 1),
(34, 20229, 1),
(34, 20230, 1),
(34, 20231, 1),
(34, 20232, 1),
(34, 20233, 1),
(34, 20234, 1),
(34, 20235, 1),
(34, 20236, 1),
(34, 20237, 1),
(34, 20238, 1),
(34, 20239, 1),
(34, 20240, 1),
(34, 20241, 1),
(34, 20242, 1),
(34, 20243, 1),
(34, 20244, 1),
(34, 20245, 1),
(34, 20246, 1),
(34, 20247, 1),
(34, 20248, 1),
(34, 20249, 1),
(34, 20250, 1),
(34, 20251, 1),
(34, 20252, 1),
(34, 20253, 1),
(34, 20254, 1),
(34, 20255, 1),
(34, 20256, 1),
(34, 20257, 1),
(34, 20258, 1),
(34, 20259, 1),
(34, 20260, 1),
(34, 20261, 1),
(34, 4219, 2),
(34, 4221, 2),
(34, 4222, 2),
(34, 4223, 2),
(34, 4225, 2),
(34, 4226, 2),
(34, 4227, 2),
(34, 22781, 2),
(34, 22782, 2),
(34, 22783, 2),
(34, 4220, 3),
(34, 14231, 3),
(34, 20176, 6),
(34, 20177, 6),
(34, 4068, 7),
(34, 4601, 7),
(34, 13698, 7),
(34, 17453, 7),
(34, 20178, 7),
(34, 20179, 7),
(34, 20181, 7),
(34, 4075, 8),
(34, 4150, 8),
(34, 4602, 8),
(34, 4647, 8),
(34, 4766, 8),
(34, 13689, 8),
(34, 20180, 8),
(35, 4066, 1),
(35, 4068, 1),
(35, 4076, 1),
(35, 4078, 1),
(35, 4079, 1),
(35, 4085, 1),
(35, 4104, 1),
(35, 4115, 1),
(35, 4120, 1),
(35, 4127, 1),
(35, 4129, 1),
(35, 4139, 1),
(35, 4150, 1),
(35, 4153, 1),
(35, 4168, 1),
(35, 4169, 1),
(35, 4177, 1),
(35, 4198, 1),
(35, 4199, 1),
(35, 4200, 1),
(35, 4201, 1),
(35, 4203, 1),
(35, 4205, 1),
(35, 4211, 1),
(35, 4381, 1),
(35, 4554, 1),
(35, 4556, 1),
(35, 4581, 1),
(35, 4582, 1),
(35, 4602, 1),
(35, 4604, 1),
(35, 4606, 1),
(35, 4607, 1),
(35, 4617, 1),
(35, 4651, 1),
(35, 4682, 1),
(35, 4688, 1),
(35, 4691, 1),
(35, 4696, 1),
(35, 4703, 1),
(35, 4705, 1),
(35, 4709, 1),
(35, 4710, 1),
(35, 4728, 1),
(35, 4738, 1),
(35, 4773, 1),
(35, 4803, 1),
(35, 4823, 1),
(35, 4825, 1),
(35, 4826, 1),
(35, 4855, 1),
(35, 4881, 1),
(35, 4905, 1),
(35, 4931, 1),
(35, 6036, 1),
(35, 6045, 1),
(35, 6046, 1),
(35, 6062, 1),
(35, 6095, 1),
(35, 6114, 1),
(35, 7295, 1),
(35, 7299, 1),
(35, 7331, 1),
(35, 7338, 1),
(35, 7348, 1),
(35, 7371, 1),
(35, 8637, 1),
(35, 8638, 1),
(35, 8640, 1),
(35, 8641, 1),
(35, 8722, 1),
(35, 9936, 1),
(35, 9959, 1),
(35, 9960, 1),
(35, 10000, 1),
(35, 11733, 1),
(35, 11746, 1),
(35, 11765, 1),
(35, 11834, 1),
(35, 11840, 1),
(35, 11846, 1),
(35, 13762, 1),
(35, 13788, 1),
(35, 13826, 1),
(35, 13882, 1),
(35, 13908, 1),
(35, 13922, 1),
(35, 13959, 1),
(35, 13960, 1),
(35, 14215, 1),
(35, 17417, 1),
(35, 20195, 1),
(35, 20208, 1),
(35, 20216, 1),
(35, 20230, 1),
(35, 20244, 1),
(35, 22961, 1),
(35, 22962, 1),
(35, 22963, 1),
(35, 22964, 1),
(35, 22965, 1),
(35, 22966, 1),
(35, 22967, 1),
(35, 22968, 1),
(35, 22969, 1),
(35, 22970, 1),
(35, 22971, 1),
(35, 22972, 1),
(35, 22973, 1),
(35, 22974, 1),
(35, 22975, 1),
(35, 22976, 1),
(35, 22977, 1),
(35, 22978, 1),
(35, 22979, 1),
(35, 22980, 1),
(35, 22981, 1),
(35, 22982, 1),
(35, 22983, 1),
(35, 22984, 1),
(35, 22985, 1),
(35, 22986, 1),
(35, 22987, 1),
(35, 22988, 1),
(35, 22989, 1),
(35, 22990, 1),
(35, 22991, 1),
(35, 22993, 1),
(35, 22994, 1),
(35, 22995, 1),
(35, 22996, 1),
(35, 22997, 1),
(35, 22998, 1),
(35, 22999, 1),
(35, 23000, 1),
(35, 23001, 1),
(35, 23002, 1),
(35, 23003, 1),
(35, 23004, 1),
(35, 23006, 1),
(35, 23007, 1),
(35, 23008, 1),
(35, 23009, 1),
(35, 23010, 1),
(35, 23011, 1),
(35, 23012, 1),
(35, 23013, 1),
(35, 23015, 1),
(35, 23016, 1),
(35, 23017, 1),
(35, 23018, 1),
(35, 23019, 1),
(35, 23020, 1),
(35, 23021, 1),
(35, 23022, 1),
(35, 23023, 1),
(35, 23025, 1),
(35, 23026, 1),
(35, 23027, 1),
(35, 23028, 1),
(35, 23029, 1),
(35, 23030, 1),
(35, 23032, 1),
(35, 23035, 1),
(35, 23036, 1),
(35, 23038, 1),
(35, 23039, 1),
(35, 23040, 1),
(35, 23041, 1),
(35, 23042, 1),
(35, 23043, 1),
(35, 23044, 1),
(35, 23045, 1),
(35, 23046, 1),
(35, 23047, 1),
(35, 23048, 1),
(35, 23049, 1),
(35, 23050, 1),
(35, 23051, 1),
(35, 23052, 1),
(35, 23053, 1),
(35, 23054, 1),
(35, 23055, 1),
(35, 23056, 1),
(35, 23057, 1),
(35, 23058, 1),
(35, 23060, 1),
(35, 23061, 1),
(35, 23062, 1),
(35, 23063, 1),
(35, 23064, 1),
(35, 23065, 1),
(35, 23066, 1),
(35, 23067, 1),
(35, 23068, 1),
(35, 23069, 1),
(35, 23070, 1),
(35, 23071, 1),
(35, 23072, 1),
(35, 23073, 1),
(35, 23074, 1),
(35, 23075, 1),
(35, 23076, 1),
(35, 23077, 1),
(35, 23078, 1),
(35, 23079, 1),
(35, 23080, 1),
(35, 23081, 1),
(35, 23082, 1),
(35, 23083, 1),
(35, 23084, 1),
(35, 23085, 1),
(35, 23086, 1),
(35, 23087, 1),
(35, 23088, 1),
(35, 23089, 1),
(35, 23092, 1),
(35, 23093, 1),
(35, 23095, 1),
(35, 23096, 1),
(35, 23097, 1),
(35, 23099, 1),
(35, 23100, 1),
(35, 23103, 1),
(35, 23104, 1),
(35, 23105, 1),
(35, 23106, 1),
(35, 23107, 1),
(35, 23108, 1),
(35, 23110, 1),
(35, 23111, 1),
(35, 23112, 1),
(35, 23113, 1),
(35, 23114, 1),
(35, 23115, 1),
(35, 23116, 1),
(35, 23117, 1),
(35, 23118, 1),
(35, 23119, 1),
(35, 23120, 1),
(35, 26130, 1),
(35, 26131, 1),
(35, 26132, 1),
(35, 26133, 1),
(35, 26134, 1),
(35, 4219, 2),
(35, 4220, 2),
(35, 4221, 2),
(35, 4222, 2),
(35, 4223, 2),
(35, 4225, 2),
(35, 4226, 2),
(35, 4227, 2),
(35, 25848, 2),
(35, 4126, 3),
(35, 8724, 3),
(35, 25847, 3),
(35, 4157, 6),
(35, 4625, 6),
(35, 4679, 7),
(35, 6018, 7),
(35, 11788, 7),
(35, 17453, 7),
(35, 22959, 7),
(35, 22960, 7),
(35, 4128, 8),
(35, 7270, 8),
(35, 7298, 8),
(35, 8438, 8),
(35, 8439, 8),
(35, 17429, 8),
(36, 4068, 1),
(36, 4076, 1),
(36, 4097, 1),
(36, 4120, 1),
(36, 4124, 1),
(36, 4128, 1),
(36, 4129, 1),
(36, 4147, 1),
(36, 4201, 1),
(36, 4206, 1),
(36, 4381, 1),
(36, 4548, 1),
(36, 4581, 1),
(36, 4607, 1),
(36, 4896, 1),
(36, 4901, 1),
(36, 4913, 1),
(36, 6046, 1),
(36, 6084, 1),
(36, 6085, 1),
(36, 6150, 1),
(36, 7339, 1),
(36, 9935, 1),
(36, 11723, 1),
(36, 11828, 1),
(36, 11846, 1),
(36, 11855, 1),
(36, 13748, 1),
(36, 13826, 1),
(36, 13965, 1),
(36, 13990, 1),
(36, 17423, 1),
(36, 23099, 1),
(36, 26403, 1),
(36, 26404, 1),
(36, 26405, 1),
(36, 26406, 1),
(36, 26407, 1),
(36, 26408, 1),
(36, 26409, 1),
(36, 26410, 1),
(36, 26411, 1),
(36, 26412, 1),
(36, 26413, 1),
(36, 26414, 1),
(36, 26415, 1),
(36, 26416, 1),
(36, 26417, 1),
(36, 26418, 1),
(36, 26419, 1),
(36, 26420, 1),
(36, 26421, 1),
(36, 26422, 1),
(36, 26423, 1),
(36, 26424, 1),
(36, 26425, 1),
(36, 26426, 1),
(36, 26427, 1),
(36, 26428, 1),
(36, 26429, 1),
(36, 26430, 1),
(36, 26431, 1),
(36, 26432, 1),
(36, 26433, 1),
(36, 26434, 1),
(36, 26435, 1),
(36, 26436, 1),
(36, 26437, 1),
(36, 26438, 1),
(36, 26439, 1),
(36, 26440, 1),
(36, 26441, 1),
(36, 26442, 1),
(36, 26443, 1),
(36, 4219, 2),
(36, 4220, 2),
(36, 4221, 2),
(36, 4222, 2),
(36, 4223, 2),
(36, 4225, 2),
(36, 4226, 2),
(36, 4227, 2),
(36, 29371, 2),
(36, 29372, 2),
(36, 4216, 3),
(36, 4562, 3),
(36, 6151, 3),
(36, 8630, 6),
(36, 4543, 7),
(36, 4546, 7),
(36, 26401, 7),
(36, 13805, 8),
(36, 14177, 8),
(36, 26402, 8),
(37, 4066, 1),
(37, 4067, 1),
(37, 4068, 1),
(37, 4075, 1),
(37, 4078, 1),
(37, 4079, 1),
(37, 4086, 1),
(37, 4094, 1),
(37, 4097, 1),
(37, 4120, 1),
(37, 4123, 1),
(37, 4126, 1),
(37, 4127, 1),
(37, 4128, 1),
(37, 4150, 1),
(37, 4153, 1),
(37, 4164, 1),
(37, 4188, 1),
(37, 4201, 1),
(37, 4203, 1),
(37, 4205, 1),
(37, 4207, 1),
(37, 4208, 1),
(37, 4552, 1),
(37, 4560, 1),
(37, 4576, 1),
(37, 4581, 1),
(37, 4599, 1),
(37, 4607, 1),
(37, 4635, 1),
(37, 4636, 1),
(37, 4647, 1),
(37, 4649, 1),
(37, 4651, 1),
(37, 4664, 1),
(37, 4672, 1),
(37, 4687, 1),
(37, 4689, 1),
(37, 4691, 1),
(37, 4708, 1),
(37, 4717, 1),
(37, 4728, 1),
(37, 4729, 1),
(37, 4744, 1),
(37, 4761, 1),
(37, 4771, 1),
(37, 4772, 1),
(37, 4782, 1),
(37, 4788, 1),
(37, 4789, 1),
(37, 4790, 1),
(37, 4813, 1),
(37, 4814, 1),
(37, 4826, 1),
(37, 4828, 1),
(37, 4829, 1),
(37, 4842, 1),
(37, 4843, 1),
(37, 4855, 1),
(37, 4860, 1),
(37, 4862, 1),
(37, 4874, 1),
(37, 4878, 1),
(37, 4879, 1),
(37, 4886, 1),
(37, 4892, 1),
(37, 4893, 1),
(37, 4901, 1),
(37, 6018, 1),
(37, 6035, 1),
(37, 6047, 1),
(37, 6051, 1),
(37, 6064, 1),
(37, 6066, 1),
(37, 6067, 1),
(37, 6078, 1),
(37, 6083, 1),
(37, 6084, 1),
(37, 6090, 1),
(37, 6132, 1),
(37, 7270, 1),
(37, 7293, 1),
(37, 7345, 1),
(37, 7348, 1),
(37, 7385, 1),
(37, 8642, 1),
(37, 8661, 1),
(37, 8686, 1),
(37, 9934, 1),
(37, 9942, 1),
(37, 9945, 1),
(37, 9962, 1),
(37, 11715, 1),
(37, 11721, 1),
(37, 11813, 1),
(37, 11820, 1),
(37, 11855, 1),
(37, 13766, 1),
(37, 13767, 1),
(37, 13788, 1),
(37, 13790, 1),
(37, 13805, 1),
(37, 13821, 1),
(37, 13833, 1),
(37, 13886, 1),
(37, 13922, 1),
(37, 14172, 1),
(37, 14202, 1),
(37, 17403, 1),
(37, 17428, 1),
(37, 17451, 1),
(37, 22972, 1),
(37, 22975, 1),
(37, 22995, 1),
(37, 22996, 1),
(37, 23045, 1),
(37, 26410, 1),
(37, 26412, 1),
(37, 26419, 1),
(37, 26435, 1),
(37, 29469, 1),
(37, 29470, 1),
(37, 29471, 1),
(37, 29472, 1),
(37, 29473, 1),
(37, 29474, 1),
(37, 29475, 1),
(37, 29476, 1),
(37, 29477, 1),
(37, 29478, 1),
(37, 29479, 1),
(37, 29480, 1),
(37, 29481, 1),
(37, 29482, 1),
(37, 29483, 1),
(37, 29484, 1),
(37, 29485, 1),
(37, 29486, 1),
(37, 29487, 1),
(37, 29488, 1),
(37, 29489, 1),
(37, 29491, 1),
(37, 29492, 1),
(37, 29493, 1),
(37, 29494, 1),
(37, 29496, 1),
(37, 29497, 1),
(37, 29498, 1),
(37, 29499, 1),
(37, 29500, 1),
(37, 29501, 1),
(37, 29502, 1),
(37, 29503, 1),
(37, 29504, 1),
(37, 29505, 1),
(37, 29506, 1),
(37, 29507, 1),
(37, 29508, 1),
(37, 29509, 1),
(37, 29510, 1),
(37, 29511, 1),
(37, 29512, 1),
(37, 29513, 1),
(37, 29515, 1),
(37, 29516, 1),
(37, 29517, 1),
(37, 29518, 1),
(37, 29519, 1),
(37, 29520, 1),
(37, 29522, 1),
(37, 29523, 1),
(37, 29524, 1),
(37, 29525, 1),
(37, 29526, 1),
(37, 29527, 1),
(37, 29528, 1),
(37, 29529, 1),
(37, 29530, 1),
(37, 29531, 1),
(37, 29532, 1),
(37, 29533, 1),
(37, 29534, 1),
(37, 29535, 1),
(37, 29536, 1),
(37, 29537, 1),
(37, 29538, 1),
(37, 29539, 1),
(37, 29540, 1),
(37, 29541, 1),
(37, 29542, 1),
(37, 29543, 1),
(37, 29544, 1),
(37, 29545, 1),
(37, 29546, 1),
(37, 29549, 1),
(37, 29550, 1),
(37, 29551, 1),
(37, 29552, 1),
(37, 29553, 1),
(37, 29554, 1),
(37, 29555, 1),
(37, 29556, 1),
(37, 29557, 1),
(37, 29558, 1),
(37, 29559, 1),
(37, 29560, 1),
(37, 29561, 1),
(37, 29562, 1),
(37, 29563, 1),
(37, 29564, 1),
(37, 29565, 1),
(37, 29566, 1),
(37, 29567, 1),
(37, 29568, 1),
(37, 29569, 1),
(37, 29570, 1),
(37, 29574, 1),
(37, 29575, 1),
(37, 29576, 1),
(37, 29577, 1),
(37, 29578, 1),
(37, 29579, 1),
(37, 29580, 1),
(37, 29581, 1),
(37, 29582, 1),
(37, 29583, 1),
(37, 29584, 1),
(37, 29585, 1),
(37, 29586, 1),
(37, 29589, 1),
(37, 29590, 1),
(37, 29591, 1),
(37, 29592, 1),
(37, 29593, 1),
(37, 29594, 1),
(37, 29595, 1),
(37, 29596, 1),
(37, 29597, 1),
(37, 29598, 1),
(37, 29599, 1),
(37, 29600, 1),
(37, 29606, 1),
(37, 29607, 1),
(37, 29608, 1),
(37, 29609, 1),
(37, 29610, 1),
(37, 29611, 1),
(37, 29612, 1),
(37, 29613, 1),
(37, 29614, 1),
(37, 29615, 1),
(37, 29616, 1),
(37, 29617, 1),
(37, 29618, 1),
(37, 29619, 1),
(37, 29622, 1),
(37, 29623, 1),
(37, 29624, 1),
(37, 29625, 1),
(37, 29626, 1),
(37, 29627, 1),
(37, 29628, 1),
(37, 29629, 1),
(37, 29630, 1),
(37, 29631, 1),
(37, 29632, 1),
(37, 29634, 1),
(37, 29637, 1),
(37, 29638, 1),
(37, 29639, 1),
(37, 29640, 1),
(37, 29641, 1),
(37, 29642, 1),
(37, 29643, 1),
(37, 29644, 1),
(37, 29645, 1),
(37, 29646, 1),
(37, 29647, 1),
(37, 29648, 1),
(37, 29649, 1),
(37, 29650, 1),
(37, 29652, 1),
(37, 33107, 1),
(37, 33108, 1),
(37, 33109, 1),
(37, 33110, 1),
(37, 33111, 1),
(37, 4219, 2),
(37, 4220, 2),
(37, 4221, 2),
(37, 4222, 2),
(37, 4223, 2),
(37, 4225, 2),
(37, 4226, 2),
(37, 4227, 2),
(37, 4571, 2),
(37, 5139, 2),
(37, 6151, 3),
(37, 4216, 4),
(37, 4562, 4),
(37, 29465, 6),
(37, 4076, 7),
(37, 4139, 7),
(37, 4186, 7),
(37, 4544, 7),
(37, 4563, 7),
(37, 6055, 7),
(37, 6124, 7),
(37, 8439, 7),
(37, 22997, 7),
(37, 26434, 7),
(37, 29466, 7),
(37, 29467, 7),
(37, 6025, 8),
(37, 29468, 8),
(38, 4067, 1),
(38, 4068, 1),
(38, 4075, 1),
(38, 4078, 1),
(38, 4079, 1),
(38, 4097, 1),
(38, 4104, 1),
(38, 4120, 1),
(38, 4123, 1),
(38, 4124, 1),
(38, 4126, 1),
(38, 4127, 1),
(38, 4138, 1),
(38, 4140, 1),
(38, 4142, 1),
(38, 4147, 1),
(38, 4153, 1),
(38, 4166, 1),
(38, 4178, 1),
(38, 4186, 1),
(38, 4188, 1),
(38, 4201, 1),
(38, 4203, 1),
(38, 4207, 1),
(38, 4208, 1),
(38, 4211, 1),
(38, 4214, 1),
(38, 4215, 1),
(38, 4381, 1),
(38, 4548, 1),
(38, 4560, 1),
(38, 4573, 1),
(38, 4574, 1),
(38, 4581, 1),
(38, 4600, 1),
(38, 4601, 1),
(38, 4604, 1),
(38, 4653, 1),
(38, 4664, 1),
(38, 4675, 1),
(38, 4688, 1),
(38, 4691, 1),
(38, 4693, 1),
(38, 4696, 1),
(38, 4700, 1),
(38, 4708, 1),
(38, 4715, 1),
(38, 4716, 1),
(38, 4717, 1),
(38, 4726, 1),
(38, 4740, 1),
(38, 4744, 1),
(38, 4747, 1),
(38, 4761, 1),
(38, 4767, 1),
(38, 4782, 1),
(38, 4784, 1),
(38, 4803, 1),
(38, 4808, 1),
(38, 4816, 1),
(38, 4829, 1),
(38, 4873, 1),
(38, 4879, 1),
(38, 4891, 1),
(38, 4892, 1),
(38, 4893, 1),
(38, 4901, 1),
(38, 4912, 1),
(38, 4925, 1),
(38, 4931, 1),
(38, 5583, 1),
(38, 6022, 1),
(38, 6023, 1),
(38, 6039, 1),
(38, 6047, 1),
(38, 6059, 1),
(38, 6064, 1),
(38, 6068, 1),
(38, 6071, 1),
(38, 6080, 1),
(38, 6088, 1),
(38, 6089, 1),
(38, 6106, 1),
(38, 6109, 1),
(38, 6132, 1),
(38, 6135, 1),
(38, 7314, 1),
(38, 7320, 1),
(38, 7344, 1),
(38, 7385, 1),
(38, 8642, 1),
(38, 8686, 1),
(38, 8707, 1),
(38, 9940, 1),
(38, 9950, 1),
(38, 9952, 1),
(38, 9979, 1),
(38, 9987, 1),
(38, 11715, 1),
(38, 11721, 1),
(38, 11723, 1),
(38, 11735, 1),
(38, 11771, 1),
(38, 11775, 1),
(38, 11820, 1),
(38, 13882, 1),
(38, 13904, 1),
(38, 13908, 1),
(38, 14006, 1),
(38, 14008, 1),
(38, 14049, 1),
(38, 14097, 1),
(38, 14138, 1),
(38, 14143, 1),
(38, 14182, 1),
(38, 14202, 1),
(38, 17428, 1),
(38, 17450, 1),
(38, 20209, 1),
(38, 20212, 1),
(38, 23032, 1),
(38, 23114, 1),
(38, 29483, 1),
(38, 29527, 1),
(38, 29551, 1),
(38, 29625, 1),
(38, 33426, 1),
(38, 33427, 1),
(38, 33428, 1),
(38, 33430, 1),
(38, 33431, 1),
(38, 33432, 1),
(38, 33433, 1),
(38, 33435, 1),
(38, 33436, 1),
(38, 33437, 1),
(38, 33438, 1),
(38, 33439, 1),
(38, 33440, 1),
(38, 33441, 1),
(38, 33442, 1),
(38, 33443, 1),
(38, 33444, 1),
(38, 33445, 1),
(38, 33446, 1),
(38, 33447, 1),
(38, 33448, 1),
(38, 33449, 1),
(38, 33450, 1),
(38, 33451, 1),
(38, 33454, 1),
(38, 33455, 1),
(38, 33456, 1),
(38, 33457, 1),
(38, 33458, 1),
(38, 33459, 1),
(38, 33460, 1),
(38, 33461, 1),
(38, 33462, 1),
(38, 33463, 1),
(38, 33464, 1),
(38, 33465, 1),
(38, 33466, 1),
(38, 33467, 1),
(38, 33468, 1),
(38, 33469, 1),
(38, 33473, 1),
(38, 33474, 1),
(38, 33475, 1),
(38, 33476, 1),
(38, 33477, 1),
(38, 33478, 1),
(38, 33479, 1),
(38, 33480, 1),
(38, 33481, 1),
(38, 33482, 1),
(38, 33483, 1),
(38, 33484, 1),
(38, 33485, 1),
(38, 33486, 1),
(38, 33487, 1),
(38, 33488, 1),
(38, 33489, 1),
(38, 33490, 1),
(38, 33491, 1),
(38, 33494, 1),
(38, 33495, 1),
(38, 33496, 1),
(38, 33497, 1),
(38, 33498, 1),
(38, 33499, 1),
(38, 33500, 1),
(38, 33501, 1),
(38, 33502, 1),
(38, 33503, 1),
(38, 33504, 1),
(38, 33505, 1),
(38, 33506, 1),
(38, 33507, 1),
(38, 33508, 1),
(38, 33509, 1),
(38, 33510, 1),
(38, 33511, 1),
(38, 33512, 1),
(38, 33513, 1),
(38, 33514, 1),
(38, 33515, 1),
(38, 33516, 1),
(38, 33518, 1),
(38, 33519, 1),
(38, 33520, 1),
(38, 33521, 1),
(38, 33522, 1),
(38, 33523, 1),
(38, 33524, 1),
(38, 33525, 1),
(38, 33526, 1),
(38, 33527, 1),
(38, 33528, 1),
(38, 33529, 1),
(38, 33530, 1),
(38, 33531, 1),
(38, 33532, 1),
(38, 33533, 1),
(38, 33534, 1),
(38, 33535, 1),
(38, 33536, 1),
(38, 33537, 1),
(38, 33539, 1),
(38, 33540, 1),
(38, 33541, 1),
(38, 33542, 1),
(38, 33543, 1),
(38, 33544, 1),
(38, 33545, 1),
(38, 33546, 1),
(38, 33547, 1),
(38, 33548, 1),
(38, 33549, 1),
(38, 33550, 1),
(38, 33551, 1),
(38, 33552, 1),
(38, 33553, 1),
(38, 33554, 1),
(38, 33555, 1),
(38, 33556, 1),
(38, 33557, 1),
(38, 33558, 1),
(38, 33559, 1),
(38, 33560, 1),
(38, 33561, 1),
(38, 33562, 1),
(38, 33563, 1),
(38, 33564, 1),
(38, 33565, 1),
(38, 33566, 1),
(38, 33567, 1),
(38, 33568, 1),
(38, 37308, 1),
(38, 37309, 1),
(38, 37310, 1),
(38, 37311, 1),
(38, 4219, 2),
(38, 4220, 2),
(38, 4221, 2),
(38, 4222, 2),
(38, 4223, 2),
(38, 4225, 2),
(38, 4226, 2),
(38, 4227, 2),
(38, 5139, 2),
(38, 4216, 3),
(38, 4562, 3),
(38, 4571, 3),
(38, 6151, 3),
(38, 4544, 7),
(38, 33424, 7),
(38, 4076, 8),
(38, 4543, 8),
(38, 4563, 8),
(38, 6055, 8),
(38, 9923, 8),
(38, 20257, 8),
(38, 33422, 8),
(38, 33423, 8),
(38, 33425, 8);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_search_word`
--

CREATE TABLE `ps_search_word` (
  `id_word` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `word` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_search_word`
--

INSERT INTO `ps_search_word` (`id_word`, `id_shop`, `id_lang`, `word`) VALUES
(8675, 1, 1, '100'),
(5140, 1, 1, '115'),
(4087, 1, 1, '1994'),
(4098, 1, 1, '2000'),
(13903, 1, 1, '20062016'),
(13910, 1, 1, '2009'),
(13863, 1, 1, '2011'),
(13802, 1, 1, '2012'),
(4102, 1, 1, '2014'),
(13864, 1, 1, '2016'),
(13803, 1, 1, '2016autodesk'),
(7277, 1, 1, '2017'),
(13718, 1, 1, '2020'),
(13690, 1, 1, '2829'),
(23120, 1, 1, '30-dni'),
(23119, 1, 1, '30dni'),
(15978, 1, 1, '385'),
(14166, 1, 1, '3doprogramowani'),
(14164, 1, 1, '3dprojektowanie'),
(13740, 1, 1, '3drenderowac'),
(13693, 1, 1, '3ds'),
(14225, 1, 1, '3dtworcy'),
(13732, 1, 1, '3dzaprojektowac'),
(13746, 1, 1, '425'),
(13747, 1, 1, '426'),
(16712, 1, 1, 'absolwentem'),
(4744, 1, 1, 'aby'),
(4595, 1, 1, 'abys'),
(20228, 1, 1, 'abyscie'),
(14106, 1, 1, 'adama'),
(33469, 1, 1, 'administracja'),
(4066, 1, 1, 'adobe'),
(13984, 1, 1, 'adresowany'),
(17395, 1, 1, 'affinity'),
(8678, 1, 1, 'akademia'),
(4880, 1, 1, 'akcji'),
(33551, 1, 1, 'aktualizacjach'),
(33450, 1, 1, 'aktualizacje'),
(29596, 1, 1, 'aktualizowac'),
(33458, 1, 1, 'aktualnej'),
(13941, 1, 1, 'aktualnie'),
(4211, 1, 1, 'ale'),
(11806, 1, 1, 'analiza'),
(5585, 1, 1, 'ani'),
(14231, 1, 1, 'animacja'),
(13699, 1, 1, 'animacje'),
(14087, 1, 1, 'animacjenauczys'),
(14147, 1, 1, 'animacji'),
(14127, 1, 1, 'animowania'),
(11805, 1, 1, 'ankiety'),
(13934, 1, 1, 'antecki'),
(26413, 1, 1, 'aplikacja'),
(13709, 1, 1, 'aplikacjach'),
(4658, 1, 1, 'aplikacjami'),
(4545, 1, 1, 'aplikacje'),
(4564, 1, 1, 'aplikacji'),
(26436, 1, 1, 'aplikacjiuxowcy'),
(7373, 1, 1, 'appearancetworz'),
(33439, 1, 1, 'aprzekonasz'),
(26405, 1, 1, 'are'),
(14101, 1, 1, 'arkadiusz'),
(8669, 1, 1, 'arkuszinfografi'),
(14220, 1, 1, 'artystycznych'),
(20180, 1, 1, 'aspektow'),
(14141, 1, 1, 'aspekty'),
(13726, 1, 1, 'assety'),
(13692, 1, 1, 'autocad'),
(16709, 1, 1, 'autocadzie'),
(33525, 1, 1, 'automatyczne'),
(13849, 1, 1, 'automatycznejak'),
(4856, 1, 1, 'automatyzacja'),
(4876, 1, 1, 'automatyzacje'),
(11712, 1, 1, 'autor'),
(4583, 1, 1, 'autora'),
(4920, 1, 1, 'autorem'),
(26407, 1, 1, 'available'),
(33534, 1, 1, 'awarii'),
(26401, 1, 1, 'axure'),
(33526, 1, 1, 'backupy'),
(4897, 1, 1, 'badz'),
(4772, 1, 1, 'bardziej'),
(14149, 1, 1, 'barlowskiego'),
(14148, 1, 1, 'bartosz'),
(14188, 1, 1, 'basia'),
(33527, 1, 1, 'bazy'),
(11826, 1, 1, 'bdo'),
(13957, 1, 1, 'beda'),
(4703, 1, 1, 'bedzie'),
(20201, 1, 1, 'bedziecie'),
(8707, 1, 1, 'bedziemy'),
(4140, 1, 1, 'bedziesz'),
(33530, 1, 1, 'bezpieczna'),
(33511, 1, 1, 'bezposrednio'),
(4820, 1, 1, 'biblioteki'),
(17407, 1, 1, 'biegle'),
(9944, 1, 1, 'bitmapami'),
(8671, 1, 1, 'bitmojikurs'),
(11790, 1, 1, 'biznes2'),
(11794, 1, 1, 'biznesbriefwpro'),
(10004, 1, 1, 'bledow'),
(13689, 1, 1, 'blender'),
(20176, 1, 1, 'blendera'),
(33547, 1, 1, 'bloga'),
(20241, 1, 1, 'bloki'),
(29536, 1, 1, 'bol'),
(23018, 1, 1, 'bomba'),
(8670, 1, 1, 'bookiavatarki'),
(14010, 1, 1, 'boolean'),
(11744, 1, 1, 'brak'),
(11732, 1, 1, 'brakowalo'),
(6029, 1, 1, 'branza'),
(6046, 1, 1, 'branzy'),
(4654, 1, 1, 'bridge'),
(14009, 1, 1, 'bryly'),
(14050, 1, 1, 'budowac'),
(17419, 1, 1, 'budowania'),
(20258, 1, 1, 'budowaniu'),
(13947, 1, 1, 'budowlanych'),
(13924, 1, 1, 'budynku'),
(20246, 1, 1, 'buteleczke'),
(4109, 1, 1, 'byl'),
(9979, 1, 1, 'byla'),
(23045, 1, 1, 'bylo'),
(11715, 1, 1, 'byly'),
(9954, 1, 1, 'bys'),
(13895, 1, 1, 'cad'),
(13905, 1, 1, 'cadzie'),
(14169, 1, 1, 'cae'),
(9989, 1, 1, 'cala'),
(13928, 1, 1, 'cale'),
(4152, 1, 1, 'calego'),
(8629, 1, 1, 'calkowicie'),
(11785, 1, 1, 'calosc'),
(11741, 1, 1, 'calosci'),
(4837, 1, 1, 'caly'),
(29599, 1, 1, 'calym'),
(14168, 1, 1, 'cam'),
(4655, 1, 1, 'camera'),
(8613, 1, 1, 'canva'),
(11798, 1, 1, 'canvasanaliza'),
(8615, 1, 1, 'canve'),
(8631, 1, 1, 'canvie'),
(8627, 1, 1, 'canvy'),
(26404, 1, 1, 'captions'),
(13793, 1, 1, 'capture'),
(17432, 1, 1, 'cechach'),
(13851, 1, 1, 'cechyjak'),
(11832, 1, 1, 'celem'),
(9970, 1, 1, 'celu'),
(11797, 1, 1, 'centered'),
(4155, 1, 1, 'certyfikat'),
(4221, 1, 1, 'certyfikatem'),
(8665, 1, 1, 'certyfikatpodzi'),
(4222, 1, 1, 'certyfikatu'),
(4587, 1, 1, 'certyfikowanego'),
(8257, 1, 1, 'cgwisdom'),
(7380, 1, 1, 'character'),
(4901, 1, 1, 'chca'),
(11841, 1, 1, 'chcace'),
(8722, 1, 1, 'chce'),
(4607, 1, 1, 'chcesz'),
(6149, 1, 1, 'chcialby'),
(23114, 1, 1, 'chcialbys'),
(4212, 1, 1, 'chcialyby'),
(11722, 1, 1, 'checi'),
(4199, 1, 1, 'chetnie'),
(20230, 1, 1, 'choc'),
(4864, 1, 1, 'chodzi'),
(4613, 1, 1, 'chwili'),
(14070, 1, 1, 'ciac'),
(23078, 1, 1, 'ciagu'),
(23116, 1, 1, 'cie'),
(29545, 1, 1, 'ciecia'),
(4872, 1, 1, 'ciekawe'),
(17439, 1, 1, 'ciekawej'),
(4830, 1, 1, 'ciekawy'),
(4718, 1, 1, 'ciekawych'),
(33425, 1, 1, 'cms'),
(6110, 1, 1, 'codzienna'),
(7291, 1, 1, 'codziennej'),
(4771, 1, 1, 'coraz'),
(23113, 1, 1, 'corela'),
(20195, 1, 1, 'cos'),
(20236, 1, 1, 'creepera'),
(14112, 1, 1, 'cs5'),
(6089, 1, 1, 'css'),
(26421, 1, 1, 'cwiczen'),
(26420, 1, 1, 'cwiczeniawiecej'),
(26424, 1, 1, 'cwiczenie'),
(26418, 1, 1, 'cwiczentworz'),
(4184, 1, 1, 'cwiczyc'),
(4090, 1, 1, 'cwierc'),
(11757, 1, 1, 'czas'),
(20208, 1, 1, 'czasem'),
(22996, 1, 1, 'czasie'),
(20227, 1, 1, 'czasteczek'),
(22972, 1, 1, 'czasu'),
(11731, 1, 1, 'czego'),
(6118, 1, 1, 'czeka'),
(7308, 1, 1, 'czekaja'),
(6090, 1, 1, 'czemu'),
(13806, 1, 1, 'czesci'),
(33553, 1, 1, 'czescia'),
(13855, 1, 1, 'czescizrobic'),
(23068, 1, 1, 'czesto'),
(10003, 1, 1, 'czestych'),
(22968, 1, 1, 'czlowiek'),
(4172, 1, 1, 'czolo'),
(23057, 1, 1, 'czuc'),
(23066, 1, 1, 'czujesz'),
(11735, 1, 1, 'czyli'),
(11820, 1, 1, 'czym'),
(13993, 1, 1, 'czyni'),
(6122, 1, 1, 'czynienia'),
(14051, 1, 1, 'czystej'),
(8699, 1, 1, 'daj'),
(7307, 1, 1, 'dalej'),
(13968, 1, 1, 'danej'),
(23029, 1, 1, 'dany'),
(33528, 1, 1, 'danych'),
(8643, 1, 1, 'darmo'),
(33494, 1, 1, 'darmowe'),
(13743, 1, 1, 'darmowego'),
(8634, 1, 1, 'darmowy'),
(26431, 1, 1, 'darmowych'),
(25847, 1, 1, 'dawid'),
(8659, 1, 1, 'dawka'),
(11755, 1, 1, 'decydowac'),
(8694, 1, 1, 'dedykowanych'),
(13884, 1, 1, 'demonstruja'),
(4179, 1, 1, 'demonstruje'),
(6018, 1, 1, 'design'),
(23038, 1, 1, 'designbez'),
(6040, 1, 1, 'designem'),
(17396, 1, 1, 'designer'),
(11837, 1, 1, 'designera'),
(6038, 1, 1, 'designerow'),
(11839, 1, 1, 'designerzy'),
(14200, 1, 1, 'designie'),
(6124, 1, 1, 'designu'),
(29645, 1, 1, 'desktop'),
(23039, 1, 1, 'dluzyzn'),
(23079, 1, 1, 'dni'),
(4919, 1, 1, 'dobrana'),
(4762, 1, 1, 'dobre'),
(29578, 1, 1, 'dobrych'),
(11729, 1, 1, 'docelowego'),
(4590, 1, 1, 'docenily'),
(4144, 1, 1, 'dodac'),
(4103, 1, 1, 'dodalem'),
(4726, 1, 1, 'dodamy'),
(23010, 1, 1, 'dodane'),
(33539, 1, 1, 'dodanie'),
(4873, 1, 1, 'dodatki'),
(6113, 1, 1, 'dodatkowych'),
(14006, 1, 1, 'dodawac'),
(33481, 1, 1, 'dodawanie'),
(20231, 1, 1, 'dojrzec'),
(4908, 1, 1, 'dokladnie'),
(33510, 1, 1, 'dokonujac'),
(7359, 1, 1, 'dokumencienarze'),
(13852, 1, 1, 'dokumentacje'),
(8685, 1, 1, 'dolacz'),
(13734, 1, 1, 'dom'),
(20187, 1, 1, 'domowe'),
(33503, 1, 1, 'domyslnego'),
(4847, 1, 1, 'dopiero'),
(29628, 1, 1, 'dorobisz'),
(9994, 1, 1, 'doskonale'),
(4913, 1, 1, 'doskonaly'),
(29607, 1, 1, 'dostarczenie'),
(8635, 1, 1, 'dostep'),
(4659, 1, 1, 'dostepne'),
(4697, 1, 1, 'dostosowac'),
(14064, 1, 1, 'dostosowywac'),
(33498, 1, 1, 'dostosowywaniem'),
(33549, 1, 1, 'dostosujemy'),
(11854, 1, 1, 'doswiadczen'),
(4162, 1, 1, 'doswiadczenia'),
(11765, 1, 1, 'doswiadczenie'),
(13996, 1, 1, 'doswiadczeniem'),
(10001, 1, 1, 'doswiadczeniu'),
(8673, 1, 1, 'doswiadczonego'),
(13989, 1, 1, 'doswiadczony'),
(33454, 1, 1, 'dotycza'),
(29467, 1, 1, 'dotyczace'),
(13749, 1, 1, 'dotyczy'),
(29650, 1, 1, 'dotykowymi'),
(13782, 1, 1, 'dowiedz'),
(29652, 1, 1, 'dowiedziec'),
(4664, 1, 1, 'dowiesz'),
(13901, 1, 1, 'dowolna'),
(14014, 1, 1, 'dowolnego'),
(7357, 1, 1, 'dpiinterfejs'),
(20220, 1, 1, 'drodze'),
(29529, 1, 1, 'drugiej'),
(13713, 1, 1, 'druk'),
(13859, 1, 1, 'drukarce'),
(13840, 1, 1, 'drukarek'),
(4677, 1, 1, 'druku'),
(4850, 1, 1, 'drzemie'),
(8658, 1, 1, 'duza'),
(14133, 1, 1, 'duze'),
(6140, 1, 1, 'duzy'),
(8721, 1, 1, 'dydaktycznekazd'),
(33423, 1, 1, 'dynamiczne'),
(6027, 1, 1, 'dynamicznie'),
(13886, 1, 1, 'dyspozycji'),
(7287, 1, 1, 'dzial'),
(4645, 1, 1, 'dzialaja'),
(13808, 1, 1, 'dzialajace'),
(33546, 1, 1, 'dzialajacej'),
(33521, 1, 1, 'dzialajacy'),
(4714, 1, 1, 'dzialania'),
(17450, 1, 1, 'dzialanie'),
(9981, 1, 1, 'dzialaniem'),
(7309, 1, 1, 'dzialy'),
(4928, 1, 1, 'dziedzinie'),
(13894, 1, 1, 'dziedziny'),
(4079, 1, 1, 'dzieki'),
(17445, 1, 1, 'dzielac'),
(13991, 1, 1, 'dzieli'),
(13833, 1, 1, 'dzien'),
(4749, 1, 1, 'dziesiatek'),
(4681, 1, 1, 'dziesiatki'),
(23009, 1, 1, 'dzwieku'),
(14077, 1, 1, 'edge'),
(14083, 1, 1, 'edges'),
(14019, 1, 1, 'editable'),
(22782, 1, 1, 'edukacja'),
(8636, 1, 1, 'edukacji'),
(4678, 1, 1, 'edycja'),
(33448, 1, 1, 'edycje'),
(4558, 1, 1, 'edycji'),
(6105, 1, 1, 'edytora'),
(14008, 1, 1, 'edytowac'),
(23030, 1, 1, 'efekt'),
(20252, 1, 1, 'efektem'),
(4835, 1, 1, 'efektow'),
(13706, 1, 1, 'efektowne'),
(4627, 1, 1, 'efektu'),
(4805, 1, 1, 'efekty'),
(13873, 1, 1, 'efektywne'),
(9955, 1, 1, 'efektywny'),
(33455, 1, 1, 'ekosystemu'),
(13738, 1, 1, 'ekpresji'),
(29649, 1, 1, 'ekranami'),
(29531, 1, 1, 'ekranow'),
(13912, 1, 1, 'ekranu'),
(26435, 1, 1, 'ekrany'),
(4776, 1, 1, 'eksperci'),
(4225, 1, 1, 'ekspert'),
(4588, 1, 1, 'eksperta'),
(20216, 1, 1, 'ekspertem'),
(4733, 1, 1, 'ekspertow'),
(29512, 1, 1, 'eksport'),
(4807, 1, 1, 'eksportowac'),
(29611, 1, 1, 'eksportu'),
(11745, 1, 1, 'elastycznosci'),
(20260, 1, 1, 'elementami'),
(17402, 1, 1, 'elementem'),
(6057, 1, 1, 'elementow'),
(20204, 1, 1, 'elementy'),
(11808, 1, 1, 'empatiicustomer'),
(4815, 1, 1, 'emulowac'),
(13755, 1, 1, 'engine'),
(16705, 1, 1, 'ertman'),
(14151, 1, 1, 'ertmana'),
(4582, 1, 1, 'esencja'),
(6142, 1, 1, 'etap'),
(29550, 1, 1, 'etapow'),
(11709, 1, 1, 'experience'),
(29612, 1, 1, 'extract'),
(14074, 1, 1, 'extrude'),
(33544, 1, 1, 'facebook'),
(8684, 1, 1, 'facebooku'),
(4195, 1, 1, 'fachowcem'),
(4741, 1, 1, 'fakt'),
(4834, 1, 1, 'faktastycznych'),
(8689, 1, 1, 'fanow'),
(4565, 1, 1, 'fantastyczne'),
(4899, 1, 1, 'fantastycznym'),
(20261, 1, 1, 'fascynaci'),
(11823, 1, 1, 'figmaprototypow'),
(4105, 1, 1, 'film'),
(13765, 1, 1, 'filmow'),
(26427, 1, 1, 'filmu'),
(13762, 1, 1, 'filmy'),
(4840, 1, 1, 'filtry'),
(6067, 1, 1, 'first'),
(11812, 1, 1, 'fitworzenie'),
(13811, 1, 1, 'fizycznego'),
(20225, 1, 1, 'fizycznych'),
(4589, 1, 1, 'flagowy'),
(7298, 1, 1, 'flat'),
(29566, 1, 1, 'fontamizasobami'),
(4827, 1, 1, 'fontow'),
(14173, 1, 1, 'form'),
(4661, 1, 1, 'formatow'),
(4652, 1, 1, 'formaty'),
(9976, 1, 1, 'formie'),
(33522, 1, 1, 'formularz'),
(4702, 1, 1, 'fotografia'),
(4101, 1, 1, 'fotografie'),
(4666, 1, 1, 'fotografii'),
(13741, 1, 1, 'fotorealistyczn'),
(29530, 1, 1, 'fragmentacja'),
(23022, 1, 1, 'frustracji'),
(33529, 1, 1, 'ftp'),
(4616, 1, 1, 'fundament'),
(7281, 1, 1, 'fundamentalne'),
(7292, 1, 1, 'fundamentalnych'),
(33554, 1, 1, 'fundamentem'),
(14144, 1, 1, 'funkcjach'),
(4885, 1, 1, 'funkcjami'),
(4693, 1, 1, 'funkcje'),
(13922, 1, 1, 'funkcji'),
(8437, 1, 1, 'funkcjom'),
(33109, 1, 1, 'funkcjonalne'),
(6099, 1, 1, 'funkcjonalnej'),
(29631, 1, 1, 'funkcjonalnosc'),
(8642, 1, 1, 'funkcjonalnosci'),
(29481, 1, 1, 'funkcjonalny'),
(33485, 1, 1, 'galerie'),
(8697, 1, 1, 'gdy'),
(8690, 1, 1, 'genially'),
(29523, 1, 1, 'genialne'),
(8679, 1, 1, 'genialnego'),
(14089, 1, 1, 'geometry'),
(14178, 1, 1, 'gier'),
(13727, 1, 1, 'gierprojektowac'),
(20213, 1, 1, 'glownie'),
(4857, 1, 1, 'glowny'),
(29537, 1, 1, 'glowy'),
(4226, 1, 1, 'godz'),
(4750, 1, 1, 'godzin'),
(11791, 1, 1, 'godziny'),
(33541, 1, 1, 'google'),
(29546, 1, 1, 'gotowej'),
(6092, 1, 1, 'gotowy'),
(29527, 1, 1, 'gotowych'),
(29568, 1, 1, 'gotowymi'),
(7374, 1, 1, 'gradientowtworz'),
(9926, 1, 1, 'grafice'),
(4217, 1, 1, 'graficzne'),
(29539, 1, 1, 'graficznego'),
(4130, 1, 1, 'graficznych'),
(7376, 1, 1, 'graficznychbibl'),
(7334, 1, 1, 'graficznychdla'),
(7343, 1, 1, 'graficznymi'),
(4094, 1, 1, 'grafik'),
(4617, 1, 1, 'grafika'),
(4808, 1, 1, 'grafike'),
(4078, 1, 1, 'grafiki'),
(29567, 1, 1, 'grafikikonami'),
(9931, 1, 1, 'grafikow'),
(17405, 1, 1, 'graphic'),
(16715, 1, 1, 'grasshopper'),
(13979, 1, 1, 'gratka'),
(7370, 1, 1, 'gridpraca'),
(29593, 1, 1, 'gridpracowac'),
(11821, 1, 1, 'gridtworzenie'),
(13952, 1, 1, 'groznie'),
(8652, 1, 1, 'grupach'),
(8656, 1, 1, 'grupom'),
(8687, 1, 1, 'grupy'),
(13763, 1, 1, 'gry'),
(4921, 1, 1, 'grzegorz'),
(8706, 1, 1, 'gustu'),
(13768, 1, 1, 'hardware'),
(11824, 1, 1, 'heatmap'),
(11853, 1, 1, 'hi-fitworzenie'),
(29533, 1, 1, 'hidpi'),
(11851, 1, 1, 'hifitworzenie'),
(6088, 1, 1, 'html'),
(6032, 1, 1, 'idzie'),
(22960, 1, 1, 'ikon'),
(7317, 1, 1, 'ikonami'),
(7270, 1, 1, 'illustrator'),
(17429, 1, 1, 'illustratora'),
(7358, 1, 1, 'illustratorapor'),
(17417, 1, 1, 'illustratorem'),
(29499, 1, 1, 'illustratorwspo'),
(7371, 1, 1, 'illustratorze'),
(14034, 1, 1, 'illustratorzoba'),
(5582, 1, 1, 'ilosc'),
(29553, 1, 1, 'ilosci'),
(11803, 1, 1, 'ilosciowe'),
(4566, 1, 1, 'ilustracje'),
(14108, 1, 1, 'ilustracji'),
(4218, 1, 1, 'ilustrowanie'),
(14031, 1, 1, 'importowac'),
(13789, 1, 1, 'importowanie'),
(14191, 1, 1, 'industrial'),
(6102, 1, 1, 'informacje'),
(6135, 1, 1, 'informacji'),
(11811, 1, 1, 'informacjiwiref'),
(14104, 1, 1, 'informatyki'),
(33443, 1, 1, 'inneprzejdziemy'),
(8646, 1, 1, 'innych'),
(4672, 1, 1, 'innymi'),
(13995, 1, 1, 'inspirujacym'),
(33460, 1, 1, 'instalacja'),
(33437, 1, 1, 'instalacje'),
(33536, 1, 1, 'instalacji'),
(33497, 1, 1, 'instalowac'),
(4192, 1, 1, 'instrukcjami'),
(4081, 1, 1, 'instrukcjom'),
(14155, 1, 1, 'instruktazowych'),
(4223, 1, 1, 'instruktor'),
(29619, 1, 1, 'interakcje'),
(29585, 1, 1, 'interakcji'),
(29501, 1, 1, 'interakcjistwor'),
(26439, 1, 1, 'interaktywna'),
(8617, 1, 1, 'interaktywne'),
(29623, 1, 1, 'interaktywnego'),
(14177, 1, 1, 'interaktywnych'),
(23100, 1, 1, 'interesujace'),
(14224, 1, 1, 'interesuje'),
(11710, 1, 1, 'interface'),
(14063, 1, 1, 'interfejs'),
(4783, 1, 1, 'interfejsami'),
(4884, 1, 1, 'interfejsem'),
(4712, 1, 1, 'interfejsie'),
(26410, 1, 1, 'interfejsow'),
(13816, 1, 1, 'interfejsowi'),
(4561, 1, 1, 'interfejsy'),
(4736, 1, 1, 'internecie'),
(6024, 1, 1, 'internetowa'),
(6151, 1, 1, 'internetowych'),
(4641, 1, 1, 'interpolacji'),
(17436, 1, 1, 'intuicyjna'),
(6115, 1, 1, 'intuicyjnie'),
(13696, 1, 1, 'inventor'),
(13861, 1, 1, 'inventora'),
(29480, 1, 1, 'invision'),
(14221, 1, 1, 'inzynieriiosoby'),
(23021, 1, 1, 'istnieje'),
(6061, 1, 1, 'istotnych'),
(13736, 1, 1, 'itd'),
(26441, 1, 1, 'itprogramisci'),
(13778, 1, 1, 'jaka'),
(23046, 1, 1, 'jakbys'),
(6056, 1, 1, 'jakich'),
(4197, 1, 1, 'jakichkolwiek'),
(11773, 1, 1, 'jakichs'),
(6071, 1, 1, 'jakie'),
(4890, 1, 1, 'jakiego'),
(23075, 1, 1, 'jakiegokolwiek'),
(23115, 1, 1, 'jakiegos'),
(23047, 1, 1, 'jakies'),
(4555, 1, 1, 'jakim'),
(7313, 1, 1, 'jakimi'),
(22986, 1, 1, 'jakis'),
(4093, 1, 1, 'jako'),
(22988, 1, 1, 'jakos'),
(4826, 1, 1, 'jakosci'),
(11804, 1, 1, 'jakoscioweprzyg'),
(7353, 1, 1, 'jakteoria'),
(29589, 1, 1, 'jakzautomatyzow'),
(4698, 1, 1, 'jasnosc'),
(4080, 1, 1, 'jasnym'),
(7348, 1, 1, 'jednak'),
(4626, 1, 1, 'jednego'),
(4670, 1, 1, 'jednych'),
(4828, 1, 1, 'jednym'),
(8638, 1, 1, 'jestes'),
(4186, 1, 1, 'jeszcze'),
(4224, 1, 1, 'jezierski'),
(11762, 1, 1, 'jezykiem'),
(6086, 1, 1, 'jezykow'),
(14208, 1, 1, 'jezyku'),
(11809, 1, 1, 'journeyscenariu'),
(4867, 1, 1, 'kadrowanie'),
(14030, 1, 1, 'kamerdowiesz'),
(14027, 1, 1, 'kamery'),
(29371, 1, 1, 'kamil'),
(4780, 1, 1, 'kanaly'),
(13748, 1, 1, 'kariere'),
(20205, 1, 1, 'kategorii'),
(11728, 1, 1, 'katem'),
(6053, 1, 1, 'kazda'),
(26423, 1, 1, 'kazde'),
(9960, 1, 1, 'kazdego'),
(13877, 1, 1, 'kazdej'),
(14123, 1, 1, 'kazdy'),
(4106, 1, 1, 'kazdym'),
(4556, 1, 1, 'kiedykolwiek'),
(4910, 1, 1, 'kierunek'),
(14219, 1, 1, 'kierunkow'),
(20218, 1, 1, 'kilkoma'),
(26430, 1, 1, 'kilku'),
(17415, 1, 1, 'kilkugodzinnego'),
(13798, 1, 1, 'kinect'),
(29570, 1, 1, 'kitstworzenie'),
(8668, 1, 1, 'klasatest'),
(9974, 1, 1, 'klawiszowymi'),
(11730, 1, 1, 'klienta'),
(14038, 1, 1, 'klientaautorzy'),
(4592, 1, 1, 'klientow'),
(26134, 1, 1, 'kliknij'),
(4692, 1, 1, 'kluczowe'),
(6094, 1, 1, 'kodowania'),
(6106, 1, 1, 'kodu'),
(4201, 1, 1, 'kogo'),
(7304, 1, 1, 'kolejne'),
(33462, 1, 1, 'kolejno'),
(29494, 1, 1, 'kolejnosci'),
(4912, 1, 1, 'kolejny'),
(4768, 1, 1, 'kolejnych'),
(4638, 1, 1, 'kolorow'),
(4700, 1, 1, 'kolory'),
(14134, 1, 1, 'komercyjne'),
(33465, 1, 1, 'komfortowa'),
(14210, 1, 1, 'kompedium'),
(4747, 1, 1, 'kompendium'),
(4746, 1, 1, 'kompleksowe'),
(11734, 1, 1, 'kompleksowosc'),
(11706, 1, 1, 'kompleksowy'),
(14128, 1, 1, 'kompletne'),
(33560, 1, 1, 'kompletny'),
(23055, 1, 1, 'kompletnym'),
(33552, 1, 1, 'komponentow'),
(17441, 1, 1, 'kompozycji'),
(4673, 1, 1, 'kompresje'),
(4183, 1, 1, 'komputer'),
(9936, 1, 1, 'komputerowa'),
(4549, 1, 1, 'komputerowej'),
(4929, 1, 1, 'komputerowejwsz'),
(29640, 1, 1, 'koncepcji'),
(29478, 1, 1, 'koncepcyjna'),
(29544, 1, 1, 'koncepcyjnego'),
(29497, 1, 1, 'koncepcyjnymdow'),
(13930, 1, 1, 'koncowych'),
(37308, 1, 1, 'konfiguracja'),
(33438, 1, 1, 'konfiguracje'),
(6103, 1, 1, 'konfiguracji'),
(4709, 1, 1, 'koniec'),
(7272, 1, 1, 'koniecznie'),
(7349, 1, 1, 'koniecznoscia'),
(7311, 1, 1, 'konkretne'),
(4624, 1, 1, 'konkretnego'),
(11752, 1, 1, 'konkretnych'),
(8654, 1, 1, 'konkretnym'),
(14114, 1, 1, 'konkursie'),
(13946, 1, 1, 'konstrukcji'),
(13892, 1, 1, 'konstruktorow'),
(33523, 1, 1, 'kontaktowy'),
(4811, 1, 1, 'kontekscie'),
(13818, 1, 1, 'kontekstu'),
(23087, 1, 1, 'konto'),
(4869, 1, 1, 'kontrastu'),
(4918, 1, 1, 'kontynuacja'),
(20189, 1, 1, 'kopie'),
(14016, 1, 1, 'kopiowania'),
(4695, 1, 1, 'korekcyjne'),
(4846, 1, 1, 'korekcyjnych'),
(4665, 1, 1, 'korekta'),
(4690, 1, 1, 'korekte'),
(33514, 1, 1, 'korzystac'),
(8625, 1, 1, 'korzystajac'),
(13860, 1, 1, 'korzystaly'),
(14082, 1, 1, 'krawedzi'),
(14047, 1, 1, 'kreatywne'),
(23004, 1, 1, 'kreatywnej'),
(16706, 1, 1, 'kreslenie'),
(13766, 1, 1, 'krok'),
(4895, 1, 1, 'kroki'),
(9964, 1, 1, 'krokiem'),
(13767, 1, 1, 'kroku'),
(29504, 1, 1, 'krokupoznasz'),
(20247, 1, 1, 'kropli'),
(22995, 1, 1, 'krotkim'),
(9991, 1, 1, 'kryjaca'),
(7384, 1, 1, 'krzywedla'),
(22978, 1, 1, 'ksiazki'),
(8667, 1, 1, 'ksiazkiwirtualn'),
(4799, 1, 1, 'ksztaltow'),
(14015, 1, 1, 'ksztaltupoznasz'),
(9987, 1, 1, 'ktora'),
(4203, 1, 1, 'ktore'),
(4716, 1, 1, 'ktorego'),
(29613, 1, 1, 'ktoremu'),
(4581, 1, 1, 'ktory'),
(4178, 1, 1, 'ktorych'),
(4688, 1, 1, 'ktorym'),
(4774, 1, 1, 'ktorymi'),
(4896, 1, 1, 'ktorzy'),
(33548, 1, 1, 'kulinarnego'),
(23105, 1, 1, 'kup'),
(4068, 1, 1, 'kurs'),
(26433, 1, 1, 'kursanalitycy'),
(8716, 1, 1, 'kursancie'),
(23110, 1, 1, 'kurschcesz'),
(11784, 1, 1, 'kursem'),
(4120, 1, 1, 'kursie'),
(13998, 1, 1, 'kursiepoznasz'),
(6148, 1, 1, 'kurskazdy'),
(7385, 1, 1, 'kurskurs'),
(8717, 1, 1, 'kursnauczyciele'),
(11733, 1, 1, 'kursom'),
(4202, 1, 1, 'kursosoby'),
(4767, 1, 1, 'kursow'),
(11838, 1, 1, 'kurspoczatkujac'),
(14218, 1, 1, 'kursstudenci'),
(4153, 1, 1, 'kursu'),
(8664, 1, 1, 'kursudyplom'),
(5139, 1, 1, 'kursy'),
(7282, 1, 1, 'kwestie'),
(4227, 1, 1, 'lacznie'),
(14071, 1, 1, 'laczyc'),
(14090, 1, 1, 'ladnie'),
(4089, 1, 1, 'lat'),
(20251, 1, 1, 'latarke'),
(23016, 1, 1, 'latwa'),
(13958, 1, 1, 'latwe'),
(6114, 1, 1, 'latwiej'),
(29610, 1, 1, 'latwo'),
(11767, 1, 1, 'latwoscia'),
(23035, 1, 1, 'latwy'),
(11760, 1, 1, 'latwym'),
(20243, 1, 1, 'lawy'),
(29483, 1, 1, 'layout'),
(4790, 1, 1, 'layoutow'),
(29503, 1, 1, 'layoutu'),
(8693, 1, 1, 'learningapps'),
(9978, 1, 1, 'lecz'),
(14139, 1, 1, 'legendarny'),
(4769, 1, 1, 'lekcjach'),
(13882, 1, 1, 'lekcje'),
(8719, 1, 1, 'lekcjeosoby'),
(11828, 1, 1, 'lekcji'),
(26432, 1, 1, 'lekcjidla'),
(33430, 1, 1, 'lekcjom'),
(29486, 1, 1, 'lepiej'),
(26434, 1, 1, 'lepsze'),
(13970, 1, 1, 'lepszego'),
(4116, 1, 1, 'liczyc'),
(33442, 1, 1, 'linki'),
(33483, 1, 1, 'linkistworzymy'),
(13854, 1, 1, 'liste'),
(16704, 1, 1, 'live'),
(11852, 1, 1, 'lo-fi'),
(11850, 1, 1, 'lofi'),
(13906, 1, 1, 'logiczny'),
(14207, 1, 1, 'ludowa'),
(11844, 1, 1, 'ludzie'),
(4817, 1, 1, 'mac'),
(9990, 1, 1, 'magie'),
(26402, 1, 1, 'makiet'),
(26440, 1, 1, 'makietegraficy'),
(4727, 1, 1, 'makijaz'),
(14227, 1, 1, 'male'),
(29522, 1, 1, 'mamy'),
(11810, 1, 1, 'maparchitektura'),
(33540, 1, 1, 'mapki'),
(14022, 1, 1, 'mapowac'),
(8677, 1, 1, 'marka'),
(23043, 1, 1, 'marnowanego'),
(4737, 1, 1, 'mase'),
(4646, 1, 1, 'maska'),
(4777, 1, 1, 'maski'),
(14115, 1, 1, 'maskotke'),
(14121, 1, 1, 'mastera'),
(4188, 1, 1, 'masz'),
(13809, 1, 1, 'maszyny'),
(4614, 1, 1, 'material'),
(4219, 1, 1, 'materialami'),
(9928, 1, 1, 'materiale'),
(4570, 1, 1, 'materialem'),
(4220, 1, 1, 'materialow'),
(4757, 1, 1, 'materialu'),
(4177, 1, 1, 'materialy'),
(13829, 1, 1, 'mateusz'),
(14150, 1, 1, 'mateusza'),
(13694, 1, 1, 'max'),
(14018, 1, 1, 'maxdowiesz'),
(13999, 1, 1, 'maxnauczysz'),
(13695, 1, 1, 'maya'),
(14069, 1, 1, 'mayadowiesz'),
(20249, 1, 1, 'mebel'),
(20186, 1, 1, 'meble'),
(4644, 1, 1, 'mechanizmy'),
(8712, 1, 1, 'mediach'),
(33440, 1, 1, 'mediami'),
(33482, 1, 1, 'mediow'),
(13688, 1, 1, 'megapack'),
(14117, 1, 1, 'mepi'),
(14170, 1, 1, 'mesha'),
(14020, 1, 1, 'meshdowiesz'),
(29617, 1, 1, 'metod'),
(14097, 1, 1, 'metody'),
(8640, 1, 1, 'mial'),
(7340, 1, 1, 'miales'),
(6121, 1, 1, 'mialy'),
(14107, 1, 1, 'mickiewicza'),
(9942, 1, 1, 'miedzy'),
(29597, 1, 1, 'miejscu'),
(20202, 1, 1, 'mieli'),
(4845, 1, 1, 'mieszania'),
(20185, 1, 1, 'minecrafta'),
(33487, 1, 1, 'miniaturki'),
(26411, 1, 1, 'minimalistyczny'),
(11742, 1, 1, 'minusem'),
(11788, 1, 1, 'minut'),
(11792, 1, 1, 'minutwstep'),
(11795, 1, 1, 'miromapa'),
(22959, 1, 1, 'mniej'),
(29647, 1, 1, 'mniejsze'),
(20219, 1, 1, 'mniejszymi'),
(14181, 1, 1, 'mnogosc'),
(29561, 1, 1, 'mnostwo'),
(6066, 1, 1, 'mobile'),
(4791, 1, 1, 'mobilnych'),
(29584, 1, 1, 'mobilnymaz'),
(8715, 1, 1, 'moc'),
(11822, 1, 1, 'mockup'),
(8650, 1, 1, 'mocno'),
(20181, 1, 1, 'modelami'),
(14092, 1, 1, 'modeldowiesz'),
(13707, 1, 1, 'modele'),
(4723, 1, 1, 'modelki'),
(14072, 1, 1, 'modelowac'),
(14057, 1, 1, 'modelowania'),
(13698, 1, 1, 'modelowanie'),
(13983, 1, 1, 'modelowaniu'),
(13812, 1, 1, 'modelu'),
(7367, 1, 1, 'modeoutline'),
(20221, 1, 1, 'modyfikatorow'),
(14068, 1, 1, 'modyfikowac'),
(5583, 1, 1, 'mogl'),
(23026, 1, 1, 'moglbys'),
(29485, 1, 1, 'mogles'),
(8657, 1, 1, 'mogli'),
(13899, 1, 1, 'mogly'),
(6136, 1, 1, 'moglyby'),
(4881, 1, 1, 'moim'),
(4135, 1, 1, 'moimi'),
(11800, 1, 1, 'moscow02'),
(13792, 1, 1, 'motion'),
(37310, 1, 1, 'motywami'),
(33447, 1, 1, 'motywomwykonamy'),
(33499, 1, 1, 'motywow'),
(33449, 1, 1, 'motywowprzygotu'),
(33504, 1, 1, 'motywu'),
(33496, 1, 1, 'motywy'),
(23072, 1, 1, 'mowia'),
(7314, 1, 1, 'mozemy'),
(4115, 1, 1, 'mozesz'),
(29520, 1, 1, 'mozliwe'),
(4573, 1, 1, 'mozliwosci'),
(14202, 1, 1, 'mozna'),
(22985, 1, 1, 'musi'),
(4888, 1, 1, 'musial'),
(6076, 1, 1, 'musisz'),
(6119, 1, 1, 'mysla'),
(22984, 1, 1, 'myslalem'),
(4755, 1, 1, 'myslenia'),
(22969, 1, 1, 'mysli'),
(11796, 1, 1, 'mysliuser'),
(8440, 1, 1, 'nabedziesz'),
(4608, 1, 1, 'nabyc'),
(4760, 1, 1, 'nabytych'),
(4858, 1, 1, 'nacisk'),
(4671, 1, 1, 'nad'),
(11778, 1, 1, 'nadal'),
(13883, 1, 1, 'nagrane'),
(4593, 1, 1, 'nagrany'),
(4552, 1, 1, 'najbardziej'),
(33531, 1, 1, 'najciekawszych'),
(14061, 1, 1, 'najczesciej'),
(8623, 1, 1, 'najlepsza'),
(22975, 1, 1, 'najlepszych'),
(20178, 1, 1, 'najnowszej'),
(4600, 1, 1, 'najnowszych'),
(7294, 1, 1, 'najpierw'),
(9950, 1, 1, 'najpopularniejs'),
(14137, 1, 1, 'najpotezniejszy'),
(22993, 1, 1, 'najpotrzebniejs'),
(22994, 1, 1, 'najprzydatniejs'),
(4173, 1, 1, 'najrozniejszym'),
(6025, 1, 1, 'najwazniejsze'),
(23020, 1, 1, 'najwazniejszego'),
(13759, 1, 1, 'najwieksze'),
(29538, 1, 1, 'najwiekszego'),
(29552, 1, 1, 'najwiekszej'),
(4752, 1, 1, 'nakierowac'),
(4622, 1, 1, 'nakierowanie'),
(29549, 1, 1, 'nakierowany'),
(14058, 1, 1, 'nakladania'),
(9945, 1, 1, 'nalezy'),
(4705, 1, 1, 'naprawde'),
(13845, 1, 1, 'narysowac'),
(4647, 1, 1, 'narzedzi'),
(4126, 1, 1, 'narzedzia'),
(4786, 1, 1, 'narzedziami'),
(29506, 1, 1, 'narzedziaprzeko'),
(13804, 1, 1, 'narzedzie'),
(4111, 1, 1, 'narzedziem'),
(7289, 1, 1, 'narzedziom'),
(9992, 1, 1, 'narzedziu'),
(29574, 1, 1, 'nastawimy'),
(4097, 1, 1, 'nastepnie'),
(9963, 1, 1, 'nastepnym'),
(4699, 1, 1, 'nasycenie'),
(33464, 1, 1, 'nasza'),
(4740, 1, 1, 'naszego'),
(8686, 1, 1, 'naszej'),
(33500, 1, 1, 'naszych'),
(9927, 1, 1, 'naszym'),
(23054, 1, 1, 'natomiast'),
(23006, 1, 1, 'natychmiastwe'),
(23095, 1, 1, 'nauce'),
(4546, 1, 1, 'naucz'),
(8618, 1, 1, 'nauczanie'),
(8695, 1, 1, 'nauczaniu'),
(13844, 1, 1, 'naucze'),
(14049, 1, 1, 'nauczy'),
(11846, 1, 1, 'nauczyc'),
(8681, 1, 1, 'nauczyciel'),
(8680, 1, 1, 'nauczyciela'),
(8639, 1, 1, 'nauczycielem'),
(23073, 1, 1, 'nauczyly'),
(8624, 1, 1, 'nauczymy'),
(4071, 1, 1, 'nauczysz'),
(17453, 1, 1, 'nauka'),
(7347, 1, 1, 'nauke'),
(6139, 1, 1, 'nauki'),
(4567, 1, 1, 'nawet'),
(4663, 1, 1, 'nawigacje'),
(14000, 1, 1, 'nawigacji'),
(4610, 1, 1, 'nawyki'),
(6100, 1, 1, 'nbsp'),
(14230, 1, 1, 'nbsp-'),
(13710, 1, 1, 'nbsp3ds'),
(14103, 1, 1, 'nbspabsolwentem'),
(4612, 1, 1, 'nbspani'),
(13935, 1, 1, 'nbspautocadzie'),
(14100, 1, 1, 'nbspautor'),
(14152, 1, 1, 'nbspbartosz'),
(14196, 1, 1, 'nbspbasia'),
(13810, 1, 1, 'nbspbez'),
(14122, 1, 1, 'nbspblender'),
(13820, 1, 1, 'nbspcaly'),
(13871, 1, 1, 'nbspci'),
(33471, 1, 1, 'nbspcms'),
(13843, 1, 1, 'nbspczego'),
(23109, 1, 1, 'nbspdawid'),
(4615, 1, 1, 'nbspdla'),
(10007, 1, 1, 'nbspdo'),
(33493, 1, 1, 'nbspdowiesz'),
(14158, 1, 1, 'nbspdruk'),
(13831, 1, 1, 'nbspdruku'),
(33429, 1, 1, 'nbspdzieki'),
(29601, 1, 1, 'nbspekrany'),
(29604, 1, 1, 'nbspeksport'),
(13828, 1, 1, 'nbspertman'),
(22992, 1, 1, 'nbspesencja'),
(13889, 1, 1, 'nbspfilmy'),
(29633, 1, 1, 'nbspfirst'),
(7290, 1, 1, 'nbspfunkcjom'),
(29620, 1, 1, 'nbspfunkcjonaln'),
(29605, 1, 1, 'nbspgrafik'),
(13834, 1, 1, 'nbspgrafika'),
(14187, 1, 1, 'nbspgrasshopper'),
(29602, 1, 1, 'nbsphidpi'),
(29603, 1, 1, 'nbspi'),
(7323, 1, 1, 'nbspillustrator'),
(4575, 1, 1, 'nbspilosc'),
(13890, 1, 1, 'nbspinstruktazo'),
(13716, 1, 1, 'nbspjest'),
(14217, 1, 1, 'nbspjuz'),
(23102, 1, 1, 'nbspkliknij'),
(29651, 1, 1, 'nbspkogo'),
(33452, 1, 1, 'nbspkonfiguracj'),
(23024, 1, 1, 'nbspkoniec'),
(13865, 1, 1, 'nbspkreslenie'),
(29572, 1, 1, 'nbspkrok'),
(29573, 1, 1, 'nbspkroku'),
(4915, 1, 1, 'nbspkurs'),
(17397, 1, 1, 'nbspkursie'),
(7326, 1, 1, 'nbspkursu'),
(13937, 1, 1, 'nbsplat'),
(29571, 1, 1, 'nbsplayoutow'),
(13896, 1, 1, 'nbsplekcje'),
(13717, 1, 1, 'nbsplive'),
(13827, 1, 1, 'nbspmateusz'),
(14157, 1, 1, 'nbspmateusza'),
(4596, 1, 1, 'nbspmogl'),
(33492, 1, 1, 'nbspmotywami'),
(7319, 1, 1, 'nbspna'),
(7329, 1, 1, 'nbspnabedziesz'),
(23094, 1, 1, 'nbspnie'),
(29490, 1, 1, 'nbspnowoczesny'),
(14118, 1, 1, 'nbspo'),
(17431, 1, 1, 'nbspopowiemy'),
(13897, 1, 1, 'nbspopracowane'),
(29547, 1, 1, 'nbsporaz'),
(4598, 1, 1, 'nbsppelen'),
(13938, 1, 1, 'nbsppierwsze'),
(13933, 1, 1, 'nbsppiotr'),
(29521, 1, 1, 'nbsppo'),
(14176, 1, 1, 'nbsppodczas'),
(14160, 1, 1, 'nbsppolskich'),
(14120, 1, 1, 'nbsppowyzszy'),
(7303, 1, 1, 'nbsppoznac'),
(13719, 1, 1, 'nbsppoznaj'),
(14195, 1, 1, 'nbsppoznaniu'),
(33434, 1, 1, 'nbsppoznasz'),
(13870, 1, 1, 'nbsppozwola'),
(11842, 1, 1, 'nbspprace'),
(13835, 1, 1, 'nbsppracowal'),
(13830, 1, 1, 'nbsppracuje'),
(7306, 1, 1, 'nbsppraktyce'),
(29514, 1, 1, 'nbsppraktycepro'),
(13888, 1, 1, 'nbsppraktyczne'),
(29587, 1, 1, 'nbspproces'),
(7286, 1, 1, 'nbspprogramem'),
(29636, 1, 1, 'nbspprojekt'),
(13974, 1, 1, 'nbspprojektowan'),
(29621, 1, 1, 'nbspprototypy'),
(17443, 1, 1, 'nbspprzez'),
(13705, 1, 1, 'nbspprzygotowyw'),
(13711, 1, 1, 'nbsprhino'),
(23033, 1, 1, 'nbspsamodzielni'),
(14194, 1, 1, 'nbspschool'),
(4557, 1, 1, 'nbspspotkales'),
(7327, 1, 1, 'nbspstanie'),
(23034, 1, 1, 'nbspstosowac'),
(33538, 1, 1, 'nbspstrony'),
(4559, 1, 1, 'nbspstworzysz'),
(7297, 1, 1, 'nbspstylu'),
(33470, 1, 1, 'nbspsystemem'),
(13898, 1, 1, 'nbsptak'),
(17414, 1, 1, 'nbsptechniki'),
(23031, 1, 1, 'nbspten'),
(29635, 1, 1, 'nbsptestowanie'),
(23014, 1, 1, 'nbspto'),
(29588, 1, 1, 'nbsptworzeniadz'),
(23037, 1, 1, 'nbsptworzyc'),
(4119, 1, 1, 'nbsptym'),
(23098, 1, 1, 'nbspuczac'),
(14209, 1, 1, 'nbspuk'),
(14041, 1, 1, 'nbspuniejewski'),
(11848, 1, 1, 'nbspuzyteczne'),
(11843, 1, 1, 'nbspw'),
(33453, 1, 1, 'nbspwordpress'),
(33472, 1, 1, 'nbspwordpressna'),
(33517, 1, 1, 'nbspwordpressw'),
(13881, 1, 1, 'nbspwszystkie'),
(4597, 1, 1, 'nbspwykorzystac'),
(14162, 1, 1, 'nbspwykorzystuj'),
(4569, 1, 1, 'nbspz'),
(23059, 1, 1, 'nbspza'),
(14042, 1, 1, 'nbspzajmujacy'),
(23101, 1, 1, 'nbspzapisz'),
(29548, 1, 1, 'nbspzasoby'),
(23090, 1, 1, 'nbspzatem'),
(29495, 1, 1, 'nbspzawarte'),
(23091, 1, 1, 'nbspzdobyc'),
(23005, 1, 1, 'nbspzwiezle'),
(8682, 1, 1, 'necie'),
(8714, 1, 1, 'niech'),
(7299, 1, 1, 'nieco'),
(4841, 1, 1, 'niecodzienne'),
(23108, 1, 1, 'niedlugo'),
(4725, 1, 1, 'niedoskonalosci'),
(23064, 1, 1, 'niejasne'),
(13955, 1, 1, 'niektore'),
(22983, 1, 1, 'niemocy'),
(4110, 1, 1, 'nieocenionym'),
(17401, 1, 1, 'nieodlacznym'),
(4839, 1, 1, 'niesamowite'),
(20233, 1, 1, 'niesamowitych'),
(7316, 1, 1, 'niewielkimi'),
(4125, 1, 1, 'niezbedne'),
(20183, 1, 1, 'niezbednych'),
(4578, 1, 1, 'niezwykle'),
(23083, 1, 1, 'nikt'),
(20248, 1, 1, 'nosa'),
(26406, 1, 1, 'now'),
(6043, 1, 1, 'nowe'),
(13916, 1, 1, 'nowego'),
(6117, 1, 1, 'nowej'),
(23056, 1, 1, 'nowicjuszem'),
(4594, 1, 1, 'nowo'),
(6078, 1, 1, 'nowoczesne'),
(29543, 1, 1, 'nowoczesny'),
(29515, 1, 1, 'nowoczesnych'),
(13756, 1, 1, 'nowosc'),
(4814, 1, 1, 'nowych'),
(6062, 1, 1, 'obecnie'),
(14198, 1, 1, 'obecnych'),
(13965, 1, 1, 'obejrzenia'),
(29493, 1, 1, 'obejrzenie'),
(13724, 1, 1, 'obejrzeniu'),
(7296, 1, 1, 'obiekt'),
(14130, 1, 1, 'obiektami'),
(17421, 1, 1, 'obiektow'),
(7366, 1, 1, 'obiektowpathfin'),
(14003, 1, 1, 'obiekty'),
(14159, 1, 1, 'oboje'),
(4072, 1, 1, 'obrabiac'),
(33441, 1, 1, 'obrazki'),
(4667, 1, 1, 'obrazowo'),
(4686, 1, 1, 'obrazu'),
(9925, 1, 1, 'obrobce'),
(4934, 1, 1, 'obrobka'),
(4131, 1, 1, 'obrobki'),
(7364, 1, 1, 'obrysyalign'),
(33431, 1, 1, 'obsluge'),
(4931, 1, 1, 'obslugi'),
(23093, 1, 1, 'obsugi'),
(4108, 1, 1, 'obszarow'),
(4819, 1, 1, 'obszerne'),
(20232, 1, 1, 'oceanu'),
(6036, 1, 1, 'oczekiwan'),
(13887, 1, 1, 'oddajemy'),
(11751, 1, 1, 'oddania'),
(14007, 1, 1, 'odejmowac'),
(9988, 1, 1, 'odkryje'),
(4838, 1, 1, 'odkryjesz'),
(4770, 1, 1, 'odkrywal'),
(6116, 1, 1, 'odnajdowac'),
(8661, 1, 1, 'odpowiedni'),
(20238, 1, 1, 'odpowiedniej'),
(4629, 1, 1, 'odpowiedzi'),
(10006, 1, 1, 'odruchy'),
(23117, 1, 1, 'odstrasza'),
(29646, 1, 1, 'oferowaly'),
(17426, 1, 1, 'oferowanych'),
(11726, 1, 1, 'oferty'),
(22989, 1, 1, 'ogarnac'),
(4852, 1, 1, 'ogranicza'),
(14213, 1, 1, 'ograniczajac'),
(20188, 1, 1, 'ogrodowe'),
(4572, 1, 1, 'ogrom'),
(6144, 1, 1, 'okaze'),
(4833, 1, 1, 'okazji'),
(6097, 1, 1, 'okiem'),
(22967, 1, 1, 'okno'),
(13847, 1, 1, 'okreslic'),
(17444, 1, 1, 'omawiajac'),
(9975, 1, 1, 'omawiane'),
(26426, 1, 1, 'omawianezacheca'),
(17451, 1, 1, 'omawianych'),
(6133, 1, 1, 'ominac'),
(14161, 1, 1, 'omni'),
(13914, 1, 1, 'omowienie'),
(13919, 1, 1, 'omowieniu'),
(6051, 1, 1, 'omowimy'),
(13997, 1, 1, 'omowione'),
(14012, 1, 1, 'ondowiesz'),
(8258, 1, 1, 'online'),
(7284, 1, 1, 'opanowac'),
(13971, 1, 1, 'opanowania'),
(13874, 1, 1, 'opanowanie'),
(9996, 1, 1, 'opanowaniu'),
(4166, 1, 1, 'opanujesz'),
(11736, 1, 1, 'oparcia'),
(29509, 1, 1, 'oparciu'),
(33568, 1, 1, 'opartej'),
(9999, 1, 1, 'oparty'),
(7305, 1, 1, 'opcje'),
(14079, 1, 1, 'opcjenauczysz'),
(14075, 1, 1, 'opcjepoznasz'),
(8703, 1, 1, 'opinie'),
(26403, 1, 1, 'opisenglish'),
(20182, 1, 1, 'opisgrafika'),
(11711, 1, 1, 'opisjako'),
(7273, 1, 1, 'opiskurs'),
(13931, 1, 1, 'opisow'),
(4550, 1, 1, 'opisphotoshop'),
(29469, 1, 1, 'opisui'),
(22961, 1, 1, 'opiswiem'),
(4082, 1, 1, 'opiswitaj'),
(33426, 1, 1, 'opiswordpress'),
(8622, 1, 1, 'opisz'),
(6060, 1, 1, 'opowie'),
(6075, 1, 1, 'opowiemy'),
(4628, 1, 1, 'opracowalismy'),
(16707, 1, 1, 'opracowane'),
(29557, 1, 1, 'oprogramowania'),
(13744, 1, 1, 'oprogramowanie'),
(29534, 1, 1, 'optymalizacja'),
(29513, 1, 1, 'optymalizacje'),
(29563, 1, 1, 'optymalnie'),
(4075, 1, 1, 'oraz'),
(4795, 1, 1, 'organizacje'),
(33478, 1, 1, 'organizowac'),
(4803, 1, 1, 'osiagnac'),
(4623, 1, 1, 'osiagniecie'),
(4893, 1, 1, 'osob'),
(11772, 1, 1, 'osoba'),
(6120, 1, 1, 'osobach'),
(8655, 1, 1, 'osobom'),
(11840, 1, 1, 'osoby'),
(20207, 1, 1, 'oswietlenia'),
(4748, 1, 1, 'oszczedzic'),
(8662, 1, 1, 'oto'),
(4154, 1, 1, 'otrzymasz'),
(6042, 1, 1, 'otworzy'),
(4187, 1, 1, 'otworzyles'),
(23041, 1, 1, 'ozdobnikow'),
(4158, 1, 1, 'oznacza'),
(13750, 1, 1, 'pakiet'),
(13725, 1, 1, 'pakietu'),
(22971, 1, 1, 'pamietam'),
(33505, 1, 1, 'panelu'),
(29582, 1, 1, 'papierzeprototy'),
(7381, 1, 1, 'paragraphtworze'),
(14165, 1, 1, 'parametryczne'),
(14186, 1, 1, 'parametrycznie'),
(6033, 1, 1, 'parze'),
(14156, 1, 1, 'pasja'),
(6082, 1, 1, 'pasujace'),
(22965, 1, 1, 'patrzy'),
(9760, 1, 1, 'pawel'),
(5584, 1, 1, 'pelen'),
(8641, 1, 1, 'pelnej'),
(4758, 1, 1, 'pelni'),
(22999, 1, 1, 'pelnych'),
(4114, 1, 1, 'perspektyw'),
(4907, 1, 1, 'pewnie'),
(17448, 1, 1, 'pewniej'),
(4193, 1, 1, 'pewno'),
(4170, 1, 1, 'pewnosci'),
(14136, 1, 1, 'pewnoscia'),
(4067, 1, 1, 'photoshop'),
(4085, 1, 1, 'photoshopa'),
(4932, 1, 1, 'photoshopaosoby'),
(4605, 1, 1, 'photoshopem'),
(4720, 1, 1, 'photoshopie'),
(9986, 1, 1, 'photoshow'),
(33513, 1, 1, 'phpczym'),
(14036, 1, 1, 'picasa'),
(4077, 1, 1, 'piekne'),
(23085, 1, 1, 'pieniadze'),
(23082, 1, 1, 'pieniedzy'),
(23044, 1, 1, 'pieniedzyprzyst'),
(6022, 1, 1, 'pierwsza'),
(4208, 1, 1, 'pierwsze'),
(26419, 1, 1, 'pierwszej'),
(23060, 1, 1, 'pierwszych'),
(22781, 1, 1, 'pikademia'),
(4642, 1, 1, 'pikseli'),
(29479, 1, 1, 'pin'),
(29586, 1, 1, 'pinplynny'),
(16708, 1, 1, 'piotr'),
(13866, 1, 1, 'planowanie'),
(29618, 1, 1, 'plasterki'),
(14212, 1, 1, 'plaszczyznach'),
(33495, 1, 1, 'platne'),
(33512, 1, 1, 'plikach'),
(9953, 1, 1, 'plikami'),
(14032, 1, 1, 'pliki'),
(4653, 1, 1, 'plikow'),
(33532, 1, 1, 'pluginow'),
(33518, 1, 1, 'pluginy'),
(14180, 1, 1, 'plusem'),
(14067, 1, 1, 'plynnej'),
(6085, 1, 1, 'plynnie'),
(4181, 1, 1, 'pobrac'),
(33457, 1, 1, 'pobraniem'),
(4606, 1, 1, 'poczatku'),
(4927, 1, 1, 'poczatkujace'),
(4069, 1, 1, 'poczatkujacego'),
(4157, 1, 1, 'poczatkujacych'),
(4687, 1, 1, 'poczawszy'),
(23062, 1, 1, 'poczuc'),
(23042, 1, 1, 'poczucia'),
(22982, 1, 1, 'poczucie'),
(4169, 1, 1, 'poczuciem'),
(17447, 1, 1, 'poczujesz'),
(8660, 1, 1, 'podana'),
(13730, 1, 1, 'podarunkowe'),
(4191, 1, 1, 'podazaj'),
(4134, 1, 1, 'podazajac'),
(4679, 1, 1, 'podczas'),
(29638, 1, 1, 'podejscie'),
(11835, 1, 1, 'podjac'),
(33506, 1, 1, 'podmienimy'),
(20211, 1, 1, 'podoba'),
(8701, 1, 1, 'podobal'),
(4543, 1, 1, 'podstaw'),
(4190, 1, 1, 'podstawami'),
(7275, 1, 1, 'podstawom'),
(13862, 1, 1, 'podstawowa'),
(9940, 1, 1, 'podstawowe'),
(9995, 1, 1, 'podstawowej'),
(4766, 1, 1, 'podstawowych'),
(7361, 1, 1, 'podstawowychpen'),
(7288, 1, 1, 'podstawowym'),
(4548, 1, 1, 'podstawy'),
(7363, 1, 1, 'podwarstwwypeln'),
(22991, 1, 1, 'podzielic'),
(14143, 1, 1, 'pokaze'),
(8628, 1, 1, 'pokazemy'),
(14201, 1, 1, 'pokazuje'),
(6052, 1, 1, 'pokrotce'),
(4796, 1, 1, 'pola'),
(4848, 1, 1, 'polaczenie'),
(14167, 1, 1, 'polaczeniem'),
(23013, 1, 1, 'polecenia'),
(8709, 1, 1, 'polecenie'),
(29498, 1, 1, 'polega'),
(14080, 1, 1, 'poligonow'),
(4096, 1, 1, 'poligraficznym'),
(4859, 1, 1, 'polozony'),
(20253, 1, 1, 'polprzezroczyst'),
(14205, 1, 1, 'polska'),
(13837, 1, 1, 'polskich'),
(33459, 1, 1, 'polskiej'),
(7355, 1, 1, 'pomiedzy'),
(20256, 1, 1, 'pomoc'),
(4879, 1, 1, 'pomoca'),
(7369, 1, 1, 'pomocnicze'),
(13731, 1, 1, 'pomocy'),
(4802, 1, 1, 'pomoga'),
(4200, 1, 1, 'pomoge'),
(33550, 1, 1, 'pomowimy'),
(23032, 1, 1, 'pomoze'),
(29581, 1, 1, 'pomyslowprzez'),
(11780, 1, 1, 'pomyslu'),
(26438, 1, 1, 'pomysly'),
(4088, 1, 1, 'ponad'),
(23074, 1, 1, 'ponadto'),
(13964, 1, 1, 'ponownego'),
(9980, 1, 1, 'poparta'),
(14062, 1, 1, 'popelnianych'),
(4868, 1, 1, 'poprawa'),
(13814, 1, 1, 'poprawic'),
(4721, 1, 1, 'poprawimy'),
(4609, 1, 1, 'poprawne'),
(23080, 1, 1, 'poprosic'),
(13739, 1, 1, 'poprzez'),
(29473, 1, 1, 'popularnosc'),
(33424, 1, 1, 'popularny'),
(17416, 1, 1, 'popularnym'),
(11756, 1, 1, 'pora'),
(14142, 1, 1, 'poradnik'),
(22979, 1, 1, 'poradniki'),
(14116, 1, 1, 'portalu'),
(4143, 1, 1, 'portfolio'),
(7328, 1, 1, 'poruszac'),
(17406, 1, 1, 'poruszajacych'),
(4711, 1, 1, 'poruszal'),
(7351, 1, 1, 'poruszone'),
(8649, 1, 1, 'poruszymy'),
(23111, 1, 1, 'pory'),
(7336, 1, 1, 'posiadaja'),
(33562, 1, 1, 'posiadasz'),
(13807, 1, 1, 'poskladac'),
(11759, 1, 1, 'poslugiwac'),
(13878, 1, 1, 'poslugiwania'),
(20234, 1, 1, 'postac'),
(13790, 1, 1, 'postaci'),
(20184, 1, 1, 'postacie'),
(14096, 1, 1, 'postacipoznasz'),
(29641, 1, 1, 'postaramy'),
(17438, 1, 1, 'postawic'),
(33563, 1, 1, 'postawiona'),
(9985, 1, 1, 'poswieconej'),
(7274, 1, 1, 'poswiecony'),
(17398, 1, 1, 'poswieconym'),
(4180, 1, 1, 'poszczegolne'),
(14222, 1, 1, 'poszerzyc'),
(4751, 1, 1, 'poszukiwan'),
(29475, 1, 1, 'poszukiwanych'),
(13701, 1, 1, 'poszukujacych'),
(13770, 1, 1, 'potencja'),
(4599, 1, 1, 'potencjal'),
(33515, 1, 1, 'potomnych'),
(29559, 1, 1, 'potrafia'),
(33501, 1, 1, 'potrzeb'),
(14066, 1, 1, 'potrzebnauczysz'),
(4159, 1, 1, 'potrzebujesz'),
(4675, 1, 1, 'potrzeby'),
(13850, 1, 1, 'powielac'),
(11754, 1, 1, 'powinien'),
(23061, 1, 1, 'powinienes'),
(29507, 1, 1, 'powinna'),
(4914, 1, 1, 'powod'),
(11774, 1, 1, 'powodow'),
(23076, 1, 1, 'powodu'),
(20259, 1, 1, 'powtarzajacymi'),
(16713, 1, 1, 'powyzszy'),
(20244, 1, 1, 'poza'),
(4804, 1, 1, 'pozadane'),
(8621, 1, 1, 'poziom'),
(6138, 1, 1, 'poziomie'),
(6132, 1, 1, 'poznac'),
(4544, 1, 1, 'poznaj'),
(4634, 1, 1, 'poznajac'),
(7320, 1, 1, 'poznamy'),
(6091, 1, 1, 'poznaniu'),
(13921, 1, 1, 'poznanych'),
(4123, 1, 1, 'poznasz'),
(13909, 1, 1, 'poznawane'),
(22981, 1, 1, 'pozostawialy'),
(14183, 1, 1, 'pozwalaja'),
(7331, 1, 1, 'pozwalajace'),
(4696, 1, 1, 'pozwola'),
(4648, 1, 1, 'pozwoli'),
(20239, 1, 1, 'pozycji'),
(7356, 1, 1, 'ppi'),
(7333, 1, 1, 'prac'),
(4782, 1, 1, 'praca'),
(4788, 1, 1, 'prace'),
(4205, 1, 1, 'pracowac'),
(4568, 1, 1, 'pracowal'),
(13904, 1, 1, 'pracowales'),
(4898, 1, 1, 'pracowali'),
(13944, 1, 1, 'pracowni'),
(4775, 1, 1, 'pracuja'),
(13943, 1, 1, 'pracujac'),
(13936, 1, 1, 'pracuje'),
(4150, 1, 1, 'pracy'),
(8439, 1, 1, 'praktyce'),
(33107, 1, 1, 'praktyceprojekt'),
(4855, 1, 1, 'praktyczne'),
(4121, 1, 1, 'praktycznego'),
(23019, 1, 1, 'praktycznej'),
(13876, 1, 1, 'praktycznie'),
(4707, 1, 1, 'praktyczny'),
(4682, 1, 1, 'praktycznych'),
(4164, 1, 1, 'praktycznym'),
(13992, 1, 1, 'praktycznymi'),
(29579, 1, 1, 'praktyk'),
(4586, 1, 1, 'praktyka'),
(29575, 1, 1, 'praktyke'),
(4903, 1, 1, 'praktyki'),
(13893, 1, 1, 'praktykow'),
(14040, 1, 1, 'praktyktant'),
(4551, 1, 1, 'prawdopodobnie'),
(13978, 1, 1, 'prawdziwa'),
(13700, 1, 1, 'prawdziwe'),
(6131, 1, 1, 'prawidlowe'),
(4753, 1, 1, 'prawidlowy'),
(4793, 1, 1, 'preferencje'),
(7377, 1, 1, 'presetowwzorkip'),
(8647, 1, 1, 'prezentowac'),
(8632, 1, 1, 'pro'),
(7312, 1, 1, 'problemami'),
(23049, 1, 1, 'probowales'),
(4204, 1, 1, 'probowaly'),
(4209, 1, 1, 'probyosoby'),
(13821, 1, 1, 'proces'),
(4886, 1, 1, 'procesie'),
(4878, 1, 1, 'procesow'),
(4862, 1, 1, 'procesu'),
(13780, 1, 1, 'production'),
(14154, 1, 1, 'produkcja'),
(13722, 1, 1, 'produkcje'),
(13753, 1, 1, 'produkcji'),
(13761, 1, 1, 'produkcyjne'),
(11738, 1, 1, 'produktu'),
(11849, 1, 1, 'produkty'),
(29554, 1, 1, 'profesjonalisci'),
(17412, 1, 1, 'profesjonaliste'),
(23003, 1, 1, 'profesjonalisto'),
(4100, 1, 1, 'profesjonalna'),
(29468, 1, 1, 'profesjonalne'),
(4547, 1, 1, 'profesjonalnej'),
(33543, 1, 1, 'profilu'),
(4554, 1, 1, 'program'),
(14110, 1, 1, 'programach'),
(7342, 1, 1, 'programami'),
(4900, 1, 1, 'programem'),
(4206, 1, 1, 'programie'),
(14023, 1, 1, 'programienauczy'),
(14033, 1, 1, 'programow'),
(6087, 1, 1, 'programowania'),
(4602, 1, 1, 'programu'),
(14135, 1, 1, 'programy'),
(9983, 1, 1, 'projekcie'),
(29600, 1, 1, 'projekcienowe'),
(4708, 1, 1, 'projekt'),
(4823, 1, 1, 'projektach'),
(9962, 1, 1, 'projektami'),
(13990, 1, 1, 'projektant'),
(6074, 1, 1, 'projektantami'),
(6143, 1, 1, 'projektem'),
(4129, 1, 1, 'projektow'),
(11847, 1, 1, 'projektowac'),
(13805, 1, 1, 'projektowania'),
(4216, 1, 1, 'projektowanie'),
(4789, 1, 1, 'projektowaniem'),
(14172, 1, 1, 'projektowaniu'),
(8724, 1, 1, 'projektowe'),
(13945, 1, 1, 'projektowej'),
(13867, 1, 1, 'projektownaucz'),
(13880, 1, 1, 'projektowy'),
(29591, 1, 1, 'projektowych'),
(13826, 1, 1, 'projektu'),
(29465, 1, 1, 'projektuj'),
(33565, 1, 1, 'projektujesz'),
(4139, 1, 1, 'projekty'),
(26428, 1, 1, 'promocyjnego'),
(33557, 1, 1, 'proponujemy'),
(33545, 1, 1, 'prosta'),
(13959, 1, 1, 'proste'),
(6145, 1, 1, 'prostsza'),
(29518, 1, 1, 'prostsze'),
(22987, 1, 1, 'prostszy'),
(7295, 1, 1, 'prosty'),
(17420, 1, 1, 'prostych'),
(29482, 1, 1, 'prototyp'),
(26409, 1, 1, 'prototypow'),
(29525, 1, 1, 'prototypowania'),
(29500, 1, 1, 'prototypowanie'),
(29624, 1, 1, 'prototypu'),
(33110, 1, 1, 'prototypy'),
(6098, 1, 1, 'prowadzacego'),
(6059, 1, 1, 'prowadzacy'),
(9949, 1, 1, 'prowadzacym'),
(33567, 1, 1, 'prowadzenia'),
(13969, 1, 1, 'prowadzic'),
(8672, 1, 1, 'prowadzony'),
(13891, 1, 1, 'prowadzonych'),
(11727, 1, 1, 'przeanalizowac'),
(29508, 1, 1, 'przebiegac'),
(13799, 1, 1, 'przechwytu'),
(13791, 1, 1, 'przechwytywanie'),
(4765, 1, 1, 'przeciwienstwie'),
(13967, 1, 1, 'przecwiczenia'),
(4632, 1, 1, 'przede'),
(13729, 1, 1, 'przedmioty'),
(14145, 1, 1, 'przedstawi'),
(14140, 1, 1, 'przedstawia'),
(4860, 1, 1, 'przedstawienie'),
(6111, 1, 1, 'przedstawimy'),
(7276, 1, 1, 'przedstawionym'),
(6084, 1, 1, 'przejdziemy'),
(8698, 1, 1, 'przejdziesz'),
(17423, 1, 1, 'przejsc'),
(29629, 1, 1, 'przejscia'),
(6141, 1, 1, 'przejscie'),
(4151, 1, 1, 'przejsciu'),
(11769, 1, 1, 'przekazywane'),
(4906, 1, 1, 'przekonany'),
(29562, 1, 1, 'przekonasz'),
(13853, 1, 1, 'przekroje'),
(4865, 1, 1, 'przeksztalcanie'),
(11777, 1, 1, 'przekwalifikowa'),
(26437, 1, 1, 'przelac'),
(14001, 1, 1, 'przelaczania'),
(4743, 1, 1, 'przemyslany'),
(14174, 1, 1, 'przemyslowych'),
(8616, 1, 1, 'przenies'),
(9938, 1, 1, 'przeprowadzi'),
(8674, 1, 1, 'przeprowadzil'),
(17442, 1, 1, 'przeprowadzimy'),
(22963, 1, 1, 'przerazeniem'),
(33558, 1, 1, 'przerobic'),
(4756, 1, 1, 'przerobieniu'),
(4099, 1, 1, 'przeskoczylem'),
(29616, 1, 1, 'przestarzalych'),
(4784, 1, 1, 'przestrzeni'),
(11725, 1, 1, 'przeszukac'),
(29630, 1, 1, 'przetestowac'),
(4691, 1, 1, 'przez'),
(11770, 1, 1, 'przeze'),
(4892, 1, 1, 'przeznaczony'),
(23027, 1, 1, 'przeznaczyc'),
(4730, 1, 1, 'przy'),
(26408, 1, 1, 'przyblize'),
(13819, 1, 1, 'przychodzi'),
(23104, 1, 1, 'przycisk'),
(6112, 1, 1, 'przydanych'),
(4843, 1, 1, 'przydatne'),
(4657, 1, 1, 'przydatnymi'),
(4604, 1, 1, 'przygode'),
(14037, 1, 1, 'przygotowac'),
(4580, 1, 1, 'przygotowalismy'),
(4676, 1, 1, 'przygotowanie'),
(6069, 1, 1, 'przygotowany'),
(17411, 1, 1, 'przygotowanym'),
(8718, 1, 1, 'przygotowujacy'),
(8663, 1, 1, 'przygotowujemy'),
(16703, 1, 1, 'przygotowywac'),
(17446, 1, 1, 'przygotujesz'),
(33467, 1, 1, 'przyjazne'),
(6146, 1, 1, 'przyjemniejsza'),
(13994, 1, 1, 'przyjemnym'),
(11831, 1, 1, 'przyjrzec'),
(7344, 1, 1, 'przyklad'),
(4863, 1, 1, 'przykladach'),
(17410, 1, 1, 'przykladom'),
(4683, 1, 1, 'przykladow'),
(11737, 1, 1, 'przykladzie'),
(13824, 1, 1, 'przymierzanie'),
(14126, 1, 1, 'przynajmniej'),
(13963, 1, 1, 'przypadku'),
(8705, 1, 1, 'przypadl'),
(29535, 1, 1, 'przyprawic'),
(7285, 1, 1, 'przystapieniem'),
(11761, 1, 1, 'przystepnym'),
(11768, 1, 1, 'przyswoic'),
(23017, 1, 1, 'przyswojenia'),
(4764, 1, 1, 'przyszlosci'),
(14199, 1, 1, 'przyszlych'),
(23118, 1, 1, 'przytlacza'),
(4577, 1, 1, 'przytlaczac'),
(23052, 1, 1, 'przywroci'),
(33533, 1, 1, 'przywrocic'),
(23067, 1, 1, 'przyznam'),
(33466, 1, 1, 'publikowane'),
(22966, 1, 1, 'puste'),
(14189, 1, 1, 'pyper'),
(4630, 1, 1, 'pytania'),
(4715, 1, 1, 'ramach'),
(4618, 1, 1, 'rastrowa'),
(4640, 1, 1, 'rastrowej'),
(7379, 1, 1, 'rastrowepanel'),
(7322, 1, 1, 'rastrowych'),
(4656, 1, 1, 'raw'),
(4185, 1, 1, 'razem'),
(4196, 1, 1, 'razie'),
(23099, 1, 1, 'razu'),
(13771, 1, 1, 'real'),
(14229, 1, 1, 'real-time'),
(13785, 1, 1, 'realtime'),
(4735, 1, 1, 'reki'),
(9932, 1, 1, 'rekreacyjnych'),
(13932, 1, 1, 'rendering'),
(14043, 1, 1, 'renderingiem'),
(13773, 1, 1, 'renderingu'),
(14028, 1, 1, 'renderowac'),
(20240, 1, 1, 'renderu'),
(13784, 1, 1, 'renderuje'),
(14093, 1, 1, 'renderuzobaczys'),
(11707, 1, 1, 'research'),
(6065, 1, 1, 'responsive'),
(11819, 1, 1, 'responsywnosci'),
(13825, 1, 1, 'reszta'),
(29609, 1, 1, 'retina'),
(4073, 1, 1, 'retuszowac'),
(4132, 1, 1, 'retuszu'),
(13786, 1, 1, 'rewolucjonizuja'),
(13697, 1, 1, 'rhino'),
(14163, 1, 1, 'rhinoceros'),
(14098, 1, 1, 'rigging'),
(13271, 1, 1, 'robert'),
(26443, 1, 1, 'robiawszyscy'),
(13723, 1, 1, 'robic'),
(9958, 1, 1, 'rodzajach'),
(9947, 1, 1, 'rodzaje'),
(14026, 1, 1, 'rodzajestworzys'),
(8666, 1, 1, 'rodzicowzakladk'),
(4922, 1, 1, 'rog'),
(17403, 1, 1, 'rok'),
(4086, 1, 1, 'roku'),
(29505, 1, 1, 'role'),
(6030, 1, 1, 'rosnace'),
(17409, 1, 1, 'rosnie'),
(14132, 1, 1, 'rownie'),
(4574, 1, 1, 'rowniez'),
(9998, 1, 1, 'rozbudowane'),
(13815, 1, 1, 'rozbudowanemu'),
(29502, 1, 1, 'rozbudowany'),
(17424, 1, 1, 'rozbudowanych'),
(6126, 1, 1, 'rozbudowanym'),
(11789, 1, 1, 'rozdzial'),
(11793, 1, 1, 'rozdzialu'),
(11786, 1, 1, 'rozdzialy'),
(9959, 1, 1, 'rozdzielczosci'),
(20198, 1, 1, 'rozna'),
(9941, 1, 1, 'roznice'),
(17427, 1, 1, 'roznorodne'),
(20193, 1, 1, 'roznorodnosci'),
(20179, 1, 1, 'roznorodnych'),
(9957, 1, 1, 'roznych'),
(6150, 1, 1, 'rozpoczac'),
(6044, 1, 1, 'rozpoczecie'),
(6039, 1, 1, 'rozpoczynaja'),
(33520, 1, 1, 'rozszerzac'),
(33444, 1, 1, 'rozszerzanie'),
(33433, 1, 1, 'rozszerzysz'),
(13841, 1, 1, 'rozwiazan'),
(14197, 1, 1, 'rozwiazaniami'),
(20212, 1, 1, 'rozwijac'),
(6028, 1, 1, 'rozwijajaca'),
(7310, 1, 1, 'rozwijajace'),
(13776, 1, 1, 'rozwijajacej'),
(4930, 1, 1, 'rozwinac'),
(29542, 1, 1, 'rozwiniecie'),
(29489, 1, 1, 'rozwinieciem'),
(6034, 1, 1, 'rozwojem'),
(13800, 1, 1, 'ruchow'),
(29634, 1, 1, 'rwd'),
(4149, 1, 1, 'rynku'),
(13822, 1, 1, 'rysowania'),
(20190, 1, 1, 'rysunkow'),
(13868, 1, 1, 'rysunku'),
(13956, 1, 1, 'rzeczy'),
(9982, 1, 1, 'rzeczywistym'),
(13923, 1, 1, 'rzut'),
(6128, 1, 1, 'samego'),
(13735, 1, 1, 'samochod'),
(13966, 1, 1, 'samodzielnego'),
(11834, 1, 1, 'samodzielnie'),
(9939, 1, 1, 'samych'),
(7278, 1, 1, 'samym'),
(14153, 1, 1, 'scenariuszem'),
(13742, 1, 1, 'sceny'),
(16716, 1, 1, 'school'),
(13926, 1, 1, 'scian'),
(7382, 1, 1, 'sciezcebibliote'),
(7362, 1, 1, 'sciezekpanel'),
(4916, 1, 1, 'sciezka'),
(14088, 1, 1, 'sculp'),
(4083, 1, 1, 'sebastian'),
(9984, 1, 1, 'sekcji'),
(4779, 1, 1, 'selekcje'),
(7360, 1, 1, 'selekcjitworzen'),
(13774, 1, 1, 'seria'),
(13764, 1, 1, 'serii'),
(33461, 1, 1, 'serwerze'),
(8704, 1, 1, 'serwisie'),
(4925, 1, 1, 'serwisu'),
(4824, 1, 1, 'setek'),
(29526, 1, 1, 'setki'),
(20177, 1, 1, 'sharp1'),
(4794, 1, 1, 'siatki'),
(14125, 1, 1, 'sie'),
(11781, 1, 1, 'siebie'),
(4621, 1, 1, 'sieci'),
(13757, 1, 1, 'silnik'),
(13801, 1, 1, 'silnika'),
(29594, 1, 1, 'skaliprzenosic'),
(14017, 1, 1, 'skalowania'),
(29524, 1, 1, 'sketch'),
(7335, 1, 1, 'skierowany'),
(14099, 1, 1, 'skinning'),
(33555, 1, 1, 'sklada'),
(6058, 1, 1, 'skladaja'),
(7300, 1, 1, 'skomplikowana'),
(29519, 1, 1, 'skomplikowane'),
(13953, 1, 1, 'skomplikowanie'),
(20222, 1, 1, 'skomplikowanych'),
(29576, 1, 1, 'skoncentrujemy'),
(20223, 1, 1, 'skonczymy'),
(23015, 1, 1, 'skondensowana'),
(33463, 1, 1, 'skonfigurujemy'),
(4891, 1, 1, 'skorzystac'),
(33502, 1, 1, 'skorzystamy'),
(33542, 1, 1, 'skrot'),
(9973, 1, 1, 'skrotami'),
(4731, 1, 1, 'skrotow'),
(8688, 1, 1, 'skupiamy'),
(4806, 1, 1, 'skutecznie'),
(14011, 1, 1, 'slice'),
(14076, 1, 1, 'slide'),
(33473, 1, 1, 'sluza'),
(13796, 1, 1, 'smartfona'),
(23065, 1, 1, 'smialo'),
(4207, 1, 1, 'soba'),
(6130, 1, 1, 'sobie'),
(13769, 1, 1, 'software'),
(4117, 1, 1, 'solidne'),
(14190, 1, 1, 'specjalnosc'),
(4639, 1, 1, 'specyfika'),
(4660, 1, 1, 'specyfike'),
(23096, 1, 1, 'spedzac'),
(22973, 1, 1, 'spedzilem'),
(23077, 1, 1, 'spelni'),
(6147, 1, 1, 'spodziewac'),
(11740, 1, 1, 'spojnej'),
(11830, 1, 1, 'spokojnie'),
(8713, 1, 1, 'spolecznosciowy'),
(14185, 1, 1, 'spore'),
(26417, 1, 1, 'sporo'),
(4651, 1, 1, 'sposob'),
(22976, 1, 1, 'sposobow'),
(4875, 1, 1, 'sposoby'),
(7315, 1, 1, 'spotkac'),
(5580, 1, 1, 'spotkales'),
(23107, 1, 1, 'spotkamy'),
(7271, 1, 1, 'sprawdz'),
(17449, 1, 1, 'sprawdzic'),
(13813, 1, 1, 'sprawdzisz'),
(13949, 1, 1, 'sprawe'),
(20200, 1, 1, 'sprawi'),
(4701, 1, 1, 'sprawia'),
(4710, 1, 1, 'sprawnie'),
(9951, 1, 1, 'sprytnego'),
(23084, 1, 1, 'spyta'),
(6104, 1, 1, 'srodowiska'),
(14129, 1, 1, 'srodowisko'),
(17408, 1, 1, 'srodowisku'),
(29516, 1, 1, 'staje'),
(6081, 1, 1, 'standardami'),
(4141, 1, 1, 'stanie'),
(4194, 1, 1, 'staniesz'),
(29541, 1, 1, 'stanowi'),
(4904, 1, 1, 'stanowia'),
(4745, 1, 1, 'stanowic'),
(11713, 1, 1, 'staralem'),
(11758, 1, 1, 'staram'),
(4579, 1, 1, 'starannie'),
(13915, 1, 1, 'starego'),
(6020, 1, 1, 'start'),
(13838, 1, 1, 'startupach'),
(9924, 1, 1, 'stawiac'),
(4894, 1, 1, 'stawiaja'),
(13939, 1, 1, 'stawial'),
(4171, 1, 1, 'stawic'),
(23071, 1, 1, 'stazem'),
(20235, 1, 1, 'steva'),
(14045, 1, 1, 'stoisk'),
(13975, 1, 1, 'stoiska'),
(6072, 1, 1, 'stoja'),
(9968, 1, 1, 'stojace'),
(13927, 1, 1, 'stolarke'),
(26131, 1, 1, 'stosowac'),
(14171, 1, 1, 'stosowany'),
(23025, 1, 1, 'straconym'),
(4562, 1, 1, 'stron'),
(33474, 1, 1, 'strona'),
(6023, 1, 1, 'strone'),
(6055, 1, 1, 'strony'),
(33480, 1, 1, 'stronypoznasz'),
(33479, 1, 1, 'strukture'),
(13760, 1, 1, 'studia'),
(13940, 1, 1, 'studiach'),
(13973, 1, 1, 'studio'),
(4095, 1, 1, 'studiu'),
(13977, 1, 1, 'studyjnyto'),
(6021, 1, 1, 'stworz'),
(11739, 1, 1, 'stworzenia'),
(22977, 1, 1, 'stworzenie'),
(11724, 1, 1, 'stworzeniem'),
(8645, 1, 1, 'stworzone'),
(29627, 1, 1, 'stworzony'),
(4142, 1, 1, 'stworzyc'),
(4829, 1, 1, 'stworzymy'),
(5581, 1, 1, 'stworzysz'),
(7341, 1, 1, 'stycznosc'),
(33509, 1, 1, 'styl'),
(4836, 1, 1, 'style'),
(7375, 1, 1, 'styli'),
(4831, 1, 1, 'stylizowany'),
(4800, 1, 1, 'stylow'),
(8438, 1, 1, 'stylu'),
(14109, 1, 1, 'sunderland'),
(17434, 1, 1, 'svg'),
(7378, 1, 1, 'swatchyefekty'),
(4759, 1, 1, 'swiadomy'),
(13703, 1, 1, 'swiat'),
(14025, 1, 1, 'swiatla'),
(29528, 1, 1, 'swietnej'),
(4706, 1, 1, 'swietnie'),
(23063, 1, 1, 'swobodniej'),
(14214, 1, 1, 'swoi'),
(14065, 1, 1, 'swoich'),
(4182, 1, 1, 'swoj'),
(4214, 1, 1, 'swoja'),
(4147, 1, 1, 'swoje'),
(4145, 1, 1, 'swojego'),
(6068, 1, 1, 'swojej'),
(11799, 1, 1, 'swottechnika'),
(14073, 1, 1, 'symetrycznepozn'),
(20224, 1, 1, 'symulacjach'),
(20254, 1, 1, 'symulacji'),
(29565, 1, 1, 'sync'),
(20257, 1, 1, 'system'),
(20226, 1, 1, 'systemach'),
(33556, 1, 1, 'systematycznie'),
(33435, 1, 1, 'systemem'),
(33564, 1, 1, 'systemie'),
(11818, 1, 1, 'systemo'),
(33456, 1, 1, 'systemu'),
(11717, 1, 1, 'sytuacja'),
(8626, 1, 1, 'szablonow'),
(4148, 1, 1, 'szanse'),
(14124, 1, 1, 'szanujacy'),
(14085, 1, 1, 'szczegolna'),
(22990, 1, 1, 'szczescie'),
(4717, 1, 1, 'szereg'),
(13846, 1, 1, 'szkicjak'),
(14095, 1, 1, 'szkielet'),
(8676, 1, 1, 'szkolen'),
(11705, 1, 1, 'szkolenie'),
(14102, 1, 1, 'szplit'),
(23001, 1, 1, 'sztuczek'),
(14206, 1, 1, 'sztuka'),
(11779, 1, 1, 'szuka'),
(9937, 1, 1, 'szukaja'),
(22974, 1, 1, 'szukaniu'),
(11720, 1, 1, 'szukasz'),
(4871, 1, 1, 'szumow'),
(4662, 1, 1, 'szybka'),
(6019, 1, 1, 'szybki'),
(13872, 1, 1, 'szybkie'),
(13908, 1, 1, 'szybko'),
(29644, 1, 1, 'tablet'),
(7372, 1, 1, 'tabletempanel'),
(8614, 1, 1, 'tajemnic'),
(17400, 1, 1, 'tajnikami'),
(7321, 1, 1, 'tajniki'),
(6064, 1, 1, 'takich'),
(4636, 1, 1, 'takie'),
(13745, 1, 1, 'takiego'),
(13962, 1, 1, 'takim'),
(33477, 1, 1, 'taksonomie'),
(4560, 1, 1, 'takze'),
(33508, 1, 1, 'takzejak'),
(13976, 1, 1, 'targowego'),
(14046, 1, 1, 'targowych'),
(7330, 1, 1, 'techniczne'),
(13869, 1, 1, 'technicznego'),
(20191, 1, 1, 'technicznych'),
(4719, 1, 1, 'technik'),
(4127, 1, 1, 'techniki'),
(6049, 1, 1, 'technologie'),
(6035, 1, 1, 'technologii'),
(4104, 1, 1, 'tego'),
(23000, 1, 1, 'tehnik'),
(6045, 1, 1, 'tej'),
(4832, 1, 1, 'tekst'),
(4812, 1, 1, 'tekstu'),
(14059, 1, 1, 'tekstur'),
(14021, 1, 1, 'teksturami'),
(14146, 1, 1, 'teksturowania'),
(13857, 1, 1, 'telefon'),
(20250, 1, 1, 'telewizor'),
(4738, 1, 1, 'temat'),
(9966, 1, 1, 'tematow'),
(7352, 1, 1, 'tematy'),
(20199, 1, 1, 'tematyka'),
(13777, 1, 1, 'tematyki'),
(9977, 1, 1, 'teoretycznej'),
(4637, 1, 1, 'teoria'),
(26422, 1, 1, 'teorii'),
(22970, 1, 1, 'teraz'),
(11750, 1, 1, 'terminow'),
(33111, 1, 1, 'testowanie'),
(29511, 1, 1, 'testowanieprzep'),
(11825, 1, 1, 'testy'),
(33484, 1, 1, 'tez'),
(13772, 1, 1, 'time'),
(33507, 1, 1, 'tla'),
(23058, 1, 1, 'toczy'),
(4754, 1, 1, 'tok'),
(14078, 1, 1, 'tool'),
(7365, 1, 1, 'tooltransformac'),
(14052, 1, 1, 'topologii'),
(29487, 1, 1, 'trafic'),
(17399, 1, 1, 'trakcie'),
(9965, 1, 1, 'transformacje'),
(4585, 1, 1, 'trenera'),
(11771, 1, 1, 'tresci'),
(33476, 1, 1, 'tresciczym'),
(4861, 1, 1, 'trickow'),
(13704, 1, 1, 'trojwymiarowej'),
(14131, 1, 1, 'trojwymiarowymi'),
(13961, 1, 1, 'trudniejsze'),
(4189, 1, 1, 'trudnosci'),
(11787, 1, 1, 'trwajace'),
(11748, 1, 1, 'trybie'),
(4844, 1, 1, 'tryby'),
(7283, 1, 1, 'trzeba'),
(25848, 1, 1, 'tuminski'),
(4620, 1, 1, 'tutoriali'),
(15977, 1, 1, 'tutorials'),
(6095, 1, 1, 'twoich'),
(6109, 1, 1, 'twoja'),
(13885, 1, 1, 'twojej'),
(13988, 1, 1, 'tworca'),
(14228, 1, 1, 'tworcy'),
(4887, 1, 1, 'tworczym'),
(4137, 1, 1, 'tworzac'),
(8720, 1, 1, 'tworzace'),
(4128, 1, 1, 'tworzenia'),
(33108, 1, 1, 'tworzeniadzieki'),
(13788, 1, 1, 'tworzenie'),
(29622, 1, 1, 'tworzeniem'),
(4076, 1, 1, 'tworzyc'),
(4107, 1, 1, 'tych'),
(33427, 1, 1, 'tyle'),
(4625, 1, 1, 'tylko'),
(4381, 1, 1, 'tym'),
(4821, 1, 1, 'typekit'),
(7383, 1, 1, 'typekitzamiana'),
(4809, 1, 1, 'typografia'),
(4813, 1, 1, 'typografii');
INSERT INTO `ps_search_word` (`id_word`, `id_shop`, `id_lang`, `word`) VALUES
(9961, 1, 1, 'typu'),
(33475, 1, 1, 'typy'),
(4591, 1, 1, 'tysiace'),
(13856, 1, 1, 'uchwyt'),
(23070, 1, 1, 'ucieszony'),
(26133, 1, 1, 'uczac'),
(14203, 1, 1, 'uczelni'),
(20206, 1, 1, 'uczyc'),
(4926, 1, 1, 'udemy'),
(8644, 1, 1, 'udostepniac'),
(8653, 1, 1, 'udostepnic'),
(8711, 1, 1, 'udostepnienie'),
(4923, 1, 1, 'udzielamy'),
(13691, 1, 1, 'ue4'),
(11815, 1, 1, 'ui3'),
(11816, 1, 1, 'uiaccessibility'),
(13907, 1, 1, 'uklad'),
(4156, 1, 1, 'ukonczenia'),
(11833, 1, 1, 'ukonczeniu'),
(14192, 1, 1, 'ukonczyla'),
(7346, 1, 1, 'ulatwi'),
(4787, 1, 1, 'ulatwia'),
(13737, 1, 1, 'umiejetnosc'),
(4761, 1, 1, 'umiejetnosci'),
(23092, 1, 1, 'umiejetosci'),
(16710, 1, 1, 'uniejewski'),
(13728, 1, 1, 'unikalne'),
(14216, 1, 1, 'unikalny'),
(10002, 1, 1, 'uniknac'),
(14060, 1, 1, 'unikniesz'),
(9929, 1, 1, 'uniwersalnym'),
(14105, 1, 1, 'uniwersytecie'),
(13754, 1, 1, 'unreal'),
(13715, 1, 1, 'update'),
(20197, 1, 1, 'upodobania'),
(33566, 1, 1, 'uporzadkowac'),
(6041, 1, 1, 'uporzadkowane'),
(33490, 1, 1, 'uprawnieniami'),
(13982, 1, 1, 'uprzedniej'),
(17437, 1, 1, 'uprzednio'),
(22962, 1, 1, 'uruchamia'),
(33524, 1, 1, 'uruchomic'),
(23048, 1, 1, 'uruchomiles'),
(29510, 1, 1, 'urzadzenia'),
(29583, 1, 1, 'urzadzeniu'),
(11708, 1, 1, 'user'),
(6108, 1, 1, 'usprawnia'),
(4877, 1, 1, 'usprawnienie'),
(14024, 1, 1, 'ustawiac'),
(29592, 1, 1, 'ustawic'),
(4792, 1, 1, 'ustawien'),
(4167, 1, 1, 'ustawienia'),
(13787, 1, 1, 'ustawienie'),
(20237, 1, 1, 'ustawimy'),
(4724, 1, 1, 'usuniemy'),
(4870, 1, 1, 'usuwanie'),
(4213, 1, 1, 'usystematyzowac'),
(14054, 1, 1, 'uszczerbku'),
(7301, 1, 1, 'utrwalic'),
(13714, 1, 1, 'uwaga'),
(14086, 1, 1, 'uwage'),
(29556, 1, 1, 'uwolnic'),
(11801, 1, 1, 'ux4'),
(11802, 1, 1, 'uxbadania'),
(26415, 1, 1, 'uxowiec'),
(11814, 1, 1, 'uxpinprototypow'),
(4902, 1, 1, 'uzupelnic'),
(29488, 1, 1, 'uzupelnieniem'),
(8633, 1, 1, 'uzyskac'),
(29639, 1, 1, 'uzyskamy'),
(13480, 1, 1, 'uzyteczne'),
(29632, 1, 1, 'uzytecznosc'),
(29477, 1, 1, 'uzytecznoscia'),
(11855, 1, 1, 'uzytkownika'),
(33489, 1, 1, 'uzytkownikami'),
(6083, 1, 1, 'uzytkownikow'),
(22998, 1, 1, 'uzywac'),
(23112, 1, 1, 'uzywales'),
(20192, 1, 1, 'uzywamy'),
(20217, 1, 1, 'uzywane'),
(13758, 1, 1, 'uzywany'),
(23002, 1, 1, 'uzywanych'),
(14081, 1, 1, 'vertexow'),
(13795, 1, 1, 'video'),
(7368, 1, 1, 'viewlinie'),
(13779, 1, 1, 'virtual'),
(29474, 1, 1, 'wachlarza'),
(17425, 1, 1, 'wachlarzem'),
(4619, 1, 1, 'wada'),
(33537, 1, 1, 'wadliwej'),
(4611, 1, 1, 'wahaj'),
(8692, 1, 1, 'wakeleta'),
(4801, 1, 1, 'warstw'),
(4694, 1, 1, 'warstwy'),
(11743, 1, 1, 'warsztatow'),
(20209, 1, 1, 'warto'),
(6127, 1, 1, 'wazne'),
(7339, 1, 1, 'wczesniej'),
(4161, 1, 1, 'wczesniejszego'),
(29372, 1, 1, 'wdowczyk'),
(33561, 1, 1, 'wdrozymy'),
(8708, 1, 1, 'wdzieczni'),
(6017, 1, 1, 'web'),
(29491, 1, 1, 'webdesign'),
(29476, 1, 1, 'webdesignera'),
(26414, 1, 1, 'webowa'),
(6050, 1, 1, 'webowe'),
(11749, 1, 1, 'weekendowym'),
(17430, 1, 1, 'wektorow'),
(9943, 1, 1, 'wektorowa'),
(4781, 1, 1, 'wektorowe'),
(7338, 1, 1, 'wektorowej'),
(7354, 1, 1, 'wektorowejrozni'),
(17452, 1, 1, 'wektoroweosoby'),
(4797, 1, 1, 'wektorowych'),
(13902, 1, 1, 'wersja'),
(13918, 1, 1, 'wersje'),
(4601, 1, 1, 'wersji'),
(4175, 1, 1, 'wewnatrz'),
(20196, 1, 1, 'wiadomo'),
(7302, 1, 1, 'wiadomosci'),
(23053, 1, 1, 'wiare'),
(4571, 1, 1, 'wideo'),
(29598, 1, 1, 'widoczne'),
(14002, 1, 1, 'widokaminauczys'),
(14029, 1, 1, 'widoki'),
(13917, 1, 1, 'widoku'),
(4729, 1, 1, 'wiecej'),
(7324, 1, 1, 'wiedza'),
(4215, 1, 1, 'wiedze'),
(4909, 1, 1, 'wiedzial'),
(6077, 1, 1, 'wiedziec'),
(4905, 1, 1, 'wiedzy'),
(11764, 1, 1, 'wiek'),
(29472, 1, 1, 'wieksza'),
(29643, 1, 1, 'wieksze'),
(29590, 1, 1, 'wiekszosc'),
(11827, 1, 1, 'wiekszosci'),
(4091, 1, 1, 'wieku'),
(4728, 1, 1, 'wiele'),
(14179, 1, 1, 'wielkim'),
(14039, 1, 1, 'wieloletni'),
(4584, 1, 1, 'wieloletniego'),
(10000, 1, 1, 'wieloletnim'),
(4113, 1, 1, 'wielu'),
(23106, 1, 1, 'wierze'),
(4818, 1, 1, 'windows'),
(11813, 1, 1, 'wireframe'),
(13721, 1, 1, 'wirtualna'),
(13752, 1, 1, 'wirtualnej'),
(29625, 1, 1, 'witryny'),
(13987, 1, 1, 'wizualizacjami'),
(13708, 1, 1, 'wizualizacje'),
(14044, 1, 1, 'wizualizacji'),
(4851, 1, 1, 'wkrotce'),
(17433, 1, 1, 'wlasciwosciach'),
(14005, 1, 1, 'wlasciwoscinauc'),
(4650, 1, 1, 'wlasciwy'),
(4138, 1, 1, 'wlasne'),
(11723, 1, 1, 'wlasnie'),
(4798, 1, 1, 'wlasnych'),
(13986, 1, 1, 'wnetrz'),
(33422, 1, 1, 'wordpress'),
(33451, 1, 1, 'wordpressinstal'),
(37309, 1, 1, 'wordpressna'),
(33436, 1, 1, 'wordpressprzejd'),
(37311, 1, 1, 'wordpressw'),
(8691, 1, 1, 'wordwalla'),
(33488, 1, 1, 'wpisowzajmiemy'),
(7318, 1, 1, 'wprowadzania'),
(6093, 1, 1, 'wprowadzenia'),
(13751, 1, 1, 'wprowadzenie'),
(6048, 1, 1, 'wprowadzeniem'),
(13702, 1, 1, 'wprowadzi'),
(17413, 1, 1, 'wprowadzimy'),
(9948, 1, 1, 'wraz'),
(23086, 1, 1, 'wroca'),
(13781, 1, 1, 'wskakuj'),
(4136, 1, 1, 'wskazowkami'),
(4165, 1, 1, 'wskazowkom'),
(4924, 1, 1, 'wsparcia'),
(4118, 1, 1, 'wsparcie'),
(6073, 1, 1, 'wspolczesnymi'),
(6096, 1, 1, 'wspolnie'),
(13879, 1, 1, 'wspomagac'),
(14175, 1, 1, 'wspomaganiu'),
(26416, 1, 1, 'wstep'),
(4553, 1, 1, 'wszechstronny'),
(9934, 1, 1, 'wszystkich'),
(11817, 1, 1, 'wszystkichdesig'),
(4124, 1, 1, 'wszystkie'),
(4633, 1, 1, 'wszystkim'),
(13950, 1, 1, 'wtajemniczonych'),
(14182, 1, 1, 'wtyczek'),
(33516, 1, 1, 'wtyczki'),
(4563, 1, 1, 'www'),
(33428, 1, 1, 'wybiera'),
(9933, 1, 1, 'wybor'),
(4911, 1, 1, 'wybrac'),
(20214, 1, 1, 'wybranej'),
(23023, 1, 1, 'wychodzi'),
(4732, 1, 1, 'wyciagnac'),
(4734, 1, 1, 'wyciagniecie'),
(4866, 1, 1, 'wycinanie'),
(29615, 1, 1, 'wycinaniu'),
(9972, 1, 1, 'wydajnosci'),
(13858, 1, 1, 'wydrukowac'),
(33486, 1, 1, 'wygenerujemy'),
(4816, 1, 1, 'wyglad'),
(26412, 1, 1, 'wyglada'),
(13951, 1, 1, 'wygladac'),
(4704, 1, 1, 'wygladala'),
(33446, 1, 1, 'wygladu'),
(14091, 1, 1, 'wygladzic'),
(14055, 1, 1, 'wygladzie'),
(17435, 1, 1, 'wygodna'),
(29540, 1, 1, 'wyjadacza'),
(26425, 1, 1, 'wyjasniane'),
(11714, 1, 1, 'wyjasnic'),
(4668, 1, 1, 'wyjasnimy'),
(7279, 1, 1, 'wyjasnione'),
(20203, 1, 1, 'wykonac'),
(4689, 1, 1, 'wykonamy'),
(7332, 1, 1, 'wykonanie'),
(14035, 1, 1, 'wykonczyc'),
(23012, 1, 1, 'wykonywac'),
(4649, 1, 1, 'wykorzystac'),
(13797, 1, 1, 'wykorzystamy'),
(4122, 1, 1, 'wykorzystania'),
(4822, 1, 1, 'wykorzystanie'),
(29551, 1, 1, 'wykorzystaniem'),
(29577, 1, 1, 'wykorzystaniu'),
(29555, 1, 1, 'wykorzystuja'),
(13720, 1, 1, 'wykorzystujac'),
(13842, 1, 1, 'wykorzystujacyc'),
(16714, 1, 1, 'wykorzystujaych'),
(13942, 1, 1, 'wykorzystuje'),
(9946, 1, 1, 'wykorzystywac'),
(29496, 1, 1, 'wykorzystywane'),
(13875, 1, 1, 'wykorzystywany'),
(9930, 1, 1, 'wykorzystywanym'),
(13980, 1, 1, 'wymaga'),
(13900, 1, 1, 'wymagana'),
(13733, 1, 1, 'wymarzony'),
(13848, 1, 1, 'wymiarco'),
(13823, 1, 1, 'wymiarowania'),
(20245, 1, 1, 'wymodelujemy'),
(7325, 1, 1, 'wyniesiona'),
(33535, 1, 1, 'wynikajacej'),
(11807, 1, 1, 'wynikowpersonym'),
(4854, 1, 1, 'wyobraznia'),
(13929, 1, 1, 'wyposazenie'),
(10005, 1, 1, 'wypracuje'),
(6129, 1, 1, 'wyrobic'),
(14193, 1, 1, 'wyroznieniem'),
(4825, 1, 1, 'wysokiej'),
(29532, 1, 1, 'wyswietlaczami'),
(29608, 1, 1, 'wyswietlaczy'),
(33468, 1, 1, 'wyszukiwarek'),
(14013, 1, 1, 'wytlaczac'),
(29466, 1, 1, 'wytyczne'),
(8620, 1, 1, 'wyzszy'),
(6070, 1, 1, 'wyzwan'),
(4174, 1, 1, 'wyzwaniom'),
(14184, 1, 1, 'wzbogacic'),
(6037, 1, 1, 'wzgledem'),
(11763, 1, 1, 'wzgledu'),
(22783, 1, 1, 'xxiw'),
(14226, 1, 1, 'youtuberzy'),
(4773, 1, 1, 'zaawansowane'),
(17440, 1, 1, 'zaawansowanych'),
(4810, 1, 1, 'zaawansowanym'),
(6137, 1, 1, 'zablokowac'),
(11782, 1, 1, 'zachecam'),
(22997, 1, 1, 'zaczac'),
(17418, 1, 1, 'zaczniemy'),
(9923, 1, 1, 'zacznij'),
(4917, 1, 1, 'zaczyna'),
(9935, 1, 1, 'zaczynaja'),
(13925, 1, 1, 'zaczynajac'),
(4092, 1, 1, 'zaczynalem'),
(4603, 1, 1, 'zaczynasz'),
(11753, 1, 1, 'zadan'),
(9969, 1, 1, 'zadania'),
(4882, 1, 1, 'zadaniem'),
(4160, 1, 1, 'zadnego'),
(13981, 1, 1, 'zadnej'),
(6134, 1, 1, 'zadnych'),
(11719, 1, 1, 'zadowala'),
(23069, 1, 1, 'zadziwiony'),
(7293, 1, 1, 'zagadnien'),
(4635, 1, 1, 'zagadnienia'),
(6063, 1, 1, 'zagadnieniach'),
(29470, 1, 1, 'zagadnienie'),
(6125, 1, 1, 'zagadnieniem'),
(9997, 1, 1, 'zaglebienia'),
(29626, 1, 1, 'zaimportowac'),
(4933, 1, 1, 'zainteresowane'),
(11845, 1, 1, 'zainteresowani'),
(6031, 1, 1, 'zainteresowanie'),
(13985, 1, 1, 'zainteresowanyc'),
(6047, 1, 1, 'zajmiemy'),
(13839, 1, 1, 'zajmujac'),
(16711, 1, 1, 'zajmujacy'),
(13832, 1, 1, 'zajmuje'),
(29484, 1, 1, 'zajmujesz'),
(33559, 1, 1, 'zakodujemy'),
(6101, 1, 1, 'zakonczenie'),
(7337, 1, 1, 'zakresu'),
(11829, 1, 1, 'zalaczane'),
(29492, 1, 1, 'zalecamy'),
(4739, 1, 1, 'zaleta'),
(4669, 1, 1, 'zalety'),
(13817, 1, 1, 'zaleznosci'),
(11746, 1, 1, 'zamiast'),
(29560, 1, 1, 'zaoszczedzic'),
(23036, 1, 1, 'zapamietania'),
(13954, 1, 1, 'zapewniam'),
(4674, 1, 1, 'zapisywanie'),
(14215, 1, 1, 'zapisz'),
(29614, 1, 1, 'zapomnisz'),
(17404, 1, 1, 'zapotrzebowanie'),
(6123, 1, 1, 'zapoznac'),
(11783, 1, 1, 'zapoznania'),
(4785, 1, 1, 'zapoznasz'),
(4680, 1, 1, 'zaprezentujemy'),
(4763, 1, 1, 'zaprocentuja'),
(4883, 1, 1, 'zaprzyjaznil'),
(4198, 1, 1, 'zapytac'),
(29517, 1, 1, 'zarazem'),
(6080, 1, 1, 'zarowno'),
(9952, 1, 1, 'zarzadzania'),
(33491, 1, 1, 'zarzadzanie'),
(6026, 1, 1, 'zasady'),
(4853, 1, 1, 'zasadzie'),
(4576, 1, 1, 'zasobow'),
(29595, 1, 1, 'zasoby'),
(4889, 1, 1, 'zastanawiac'),
(23028, 1, 1, 'zastanawiania'),
(20210, 1, 1, 'zastanowic'),
(4684, 1, 1, 'zastosowan'),
(29558, 1, 1, 'zastosowane'),
(4842, 1, 1, 'zastosowania'),
(23007, 1, 1, 'zastosowanie'),
(13920, 1, 1, 'zastosowaniem'),
(8637, 1, 1, 'zatem'),
(11776, 1, 1, 'zatrudnienie'),
(17428, 1, 1, 'zawarte'),
(13913, 1, 1, 'zawiera'),
(11718, 1, 1, 'zawodowa'),
(4070, 1, 1, 'zawodowca'),
(11766, 1, 1, 'zawodowe'),
(11836, 1, 1, 'zawodzie'),
(23088, 1, 1, 'zbednej'),
(23040, 1, 1, 'zbednych'),
(14111, 1, 1, 'zbrush'),
(14094, 1, 1, 'zbudowac'),
(6054, 1, 1, 'zbudowane'),
(17422, 1, 1, 'zbudujesz'),
(23097, 1, 1, 'zbyt'),
(14053, 1, 1, 'zbytniego'),
(29564, 1, 1, 'zcreative'),
(13948, 1, 1, 'zdaje'),
(8619, 1, 1, 'zdalne'),
(8696, 1, 1, 'zdalnemu'),
(7345, 1, 1, 'zdecydowanie'),
(4133, 1, 1, 'zdjec'),
(4074, 1, 1, 'zdjecia'),
(9956, 1, 1, 'zdjeciami'),
(4722, 1, 1, 'zdjecie'),
(14056, 1, 1, 'zdobedziesz'),
(26132, 1, 1, 'zdobyc'),
(13972, 1, 1, 'zdobytej'),
(29471, 1, 1, 'zdobywa'),
(23008, 1, 1, 'zdobywanej'),
(13775, 1, 1, 'zebranej'),
(29580, 1, 1, 'zebrania'),
(4168, 1, 1, 'zeby'),
(8630, 1, 1, 'zera'),
(14048, 1, 1, 'zeramaya'),
(29642, 1, 1, 'zeskalowac'),
(8651, 1, 1, 'zespolach'),
(29569, 1, 1, 'zestawami'),
(14211, 1, 1, 'zglebiac'),
(8723, 1, 1, 'zglebic'),
(6079, 1, 1, 'zgodne'),
(23103, 1, 1, 'zielony'),
(20242, 1, 1, 'ziemi'),
(9761, 1, 1, 'zienowicz'),
(13272, 1, 1, 'ziobrowski'),
(4778, 1, 1, 'zlozone'),
(33445, 1, 1, 'zmiane'),
(11721, 1, 1, 'zmiany'),
(13783, 1, 1, 'zmienia'),
(14004, 1, 1, 'zmieniac'),
(11775, 1, 1, 'zmienic'),
(13911, 1, 1, 'zmienil'),
(33432, 1, 1, 'zmodyfikujesz'),
(8700, 1, 1, 'znac'),
(6107, 1, 1, 'znacznie'),
(4210, 1, 1, 'znaja'),
(8683, 1, 1, 'znajdz'),
(20194, 1, 1, 'znajdzie'),
(4176, 1, 1, 'znajdziesz'),
(14223, 1, 1, 'znajomosc'),
(4112, 1, 1, 'znajomosci'),
(8710, 1, 1, 'znajomym'),
(4713, 1, 1, 'znal'),
(22980, 1, 1, 'znalazlem'),
(9993, 1, 1, 'znalezc'),
(4084, 1, 1, 'znam'),
(13836, 1, 1, 'znanych'),
(22964, 1, 1, 'zniecheceniem'),
(23051, 1, 1, 'zniecheciles'),
(14138, 1, 1, 'zobacz'),
(26429, 1, 1, 'zobaczenia'),
(20229, 1, 1, 'zobaczyc'),
(20255, 1, 1, 'zobaczymy'),
(13712, 1, 1, 'zobaczysz'),
(11747, 1, 1, 'zobligowanym'),
(9967, 1, 1, 'zoptymalizowac'),
(29648, 1, 1, 'zoptymalizowane'),
(29606, 1, 1, 'zorientowane'),
(29637, 1, 1, 'zorientujemy'),
(20215, 1, 1, 'zostac'),
(4742, 1, 1, 'zostal'),
(7350, 1, 1, 'zostaly'),
(7280, 1, 1, 'zostana'),
(8702, 1, 1, 'zostaw'),
(14119, 1, 1, 'zrealizowal'),
(14204, 1, 1, 'zrealizowala'),
(23050, 1, 1, 'zrobic'),
(4631, 1, 1, 'zrobione'),
(23011, 1, 1, 'zrodlowe'),
(11716, 1, 1, 'zrozumiale'),
(4849, 1, 1, 'zrozumiec'),
(13960, 1, 1, 'zrozumieniu'),
(4643, 1, 1, 'zrozumiesz'),
(33519, 1, 1, 'zwane'),
(4874, 1, 1, 'zwiazane'),
(4685, 1, 1, 'zwiazanych'),
(9971, 1, 1, 'zwiekszenia'),
(4146, 1, 1, 'zwiekszyc'),
(26130, 1, 1, 'zwiezle'),
(4163, 1, 1, 'zwiezlym'),
(26442, 1, 1, 'zwizualizowac'),
(23089, 1, 1, 'zwloki'),
(14084, 1, 1, 'zwracac'),
(23081, 1, 1, 'zwrot'),
(14113, 1, 1, 'zwyciezyl'),
(13794, 1, 1, 'zwyklego'),
(8648, 1, 1, 'zywo');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_shop`
--

CREATE TABLE `ps_shop` (
  `id_shop` int(11) NOT NULL,
  `id_shop_group` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `color` varchar(50) NOT NULL,
  `id_category` int(11) NOT NULL,
  `theme_name` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_shop`
--

INSERT INTO `ps_shop` (`id_shop`, `id_shop_group`, `name`, `color`, `id_category`, `theme_name`, `active`, `deleted`) VALUES
(1, 1, 'be', '', 2, 'classic', 1, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_shop_group`
--

CREATE TABLE `ps_shop_group` (
  `id_shop_group` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `color` varchar(50) NOT NULL,
  `share_customer` tinyint(1) NOT NULL,
  `share_order` tinyint(1) NOT NULL,
  `share_stock` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_shop_group`
--

INSERT INTO `ps_shop_group` (`id_shop_group`, `name`, `color`, `share_customer`, `share_order`, `share_stock`, `active`, `deleted`) VALUES
(1, 'Default', '', 0, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_shop_url`
--

CREATE TABLE `ps_shop_url` (
  `id_shop_url` int(11) NOT NULL,
  `id_shop` int(11) NOT NULL,
  `domain` varchar(150) NOT NULL,
  `domain_ssl` varchar(150) NOT NULL,
  `physical_uri` varchar(64) NOT NULL,
  `virtual_uri` varchar(64) NOT NULL,
  `main` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_shop_url`
--

INSERT INTO `ps_shop_url` (`id_shop_url`, `id_shop`, `domain`, `domain_ssl`, `physical_uri`, `virtual_uri`, `main`, `active`) VALUES
(1, 1, 'localhost', 'localhost', '/', '', 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_smarty_cache`
--

CREATE TABLE `ps_smarty_cache` (
  `id_smarty_cache` char(40) NOT NULL,
  `name` char(40) NOT NULL,
  `cache_id` varchar(254) DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT current_timestamp(),
  `content` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_smarty_last_flush`
--

CREATE TABLE `ps_smarty_last_flush` (
  `type` enum('compile','template') NOT NULL,
  `last_flush` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_smarty_lazy_cache`
--

CREATE TABLE `ps_smarty_lazy_cache` (
  `template_hash` varchar(32) NOT NULL DEFAULT '',
  `cache_id` varchar(191) NOT NULL DEFAULT '',
  `compile_id` varchar(32) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `last_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_specific_price`
--

CREATE TABLE `ps_specific_price` (
  `id_specific_price` int(10) UNSIGNED NOT NULL,
  `id_specific_price_rule` int(11) UNSIGNED NOT NULL,
  `id_cart` int(11) UNSIGNED NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_shop_group` int(11) UNSIGNED NOT NULL,
  `id_currency` int(10) UNSIGNED NOT NULL,
  `id_country` int(10) UNSIGNED NOT NULL,
  `id_group` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED NOT NULL,
  `id_product_attribute` int(10) UNSIGNED NOT NULL,
  `price` decimal(20,6) NOT NULL,
  `from_quantity` mediumint(8) UNSIGNED NOT NULL,
  `reduction` decimal(20,6) NOT NULL,
  `reduction_tax` tinyint(1) NOT NULL DEFAULT 1,
  `reduction_type` enum('amount','percentage') NOT NULL,
  `from` datetime NOT NULL,
  `to` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_specific_price_priority`
--

CREATE TABLE `ps_specific_price_priority` (
  `id_specific_price_priority` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `priority` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_specific_price_rule`
--

CREATE TABLE `ps_specific_price_rule` (
  `id_specific_price_rule` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `id_currency` int(10) UNSIGNED NOT NULL,
  `id_country` int(10) UNSIGNED NOT NULL,
  `id_group` int(10) UNSIGNED NOT NULL,
  `from_quantity` mediumint(8) UNSIGNED NOT NULL,
  `price` decimal(20,6) DEFAULT NULL,
  `reduction` decimal(20,6) NOT NULL,
  `reduction_tax` tinyint(1) NOT NULL DEFAULT 1,
  `reduction_type` enum('amount','percentage') NOT NULL,
  `from` datetime NOT NULL,
  `to` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_specific_price_rule_condition`
--

CREATE TABLE `ps_specific_price_rule_condition` (
  `id_specific_price_rule_condition` int(11) UNSIGNED NOT NULL,
  `id_specific_price_rule_condition_group` int(11) UNSIGNED NOT NULL,
  `type` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_specific_price_rule_condition_group`
--

CREATE TABLE `ps_specific_price_rule_condition_group` (
  `id_specific_price_rule_condition_group` int(11) UNSIGNED NOT NULL,
  `id_specific_price_rule` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_state`
--

CREATE TABLE `ps_state` (
  `id_state` int(10) UNSIGNED NOT NULL,
  `id_country` int(11) UNSIGNED NOT NULL,
  `id_zone` int(11) UNSIGNED NOT NULL,
  `name` varchar(80) NOT NULL,
  `iso_code` varchar(7) NOT NULL,
  `tax_behavior` smallint(1) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_state`
--

INSERT INTO `ps_state` (`id_state`, `id_country`, `id_zone`, `name`, `iso_code`, `tax_behavior`, `active`) VALUES
(1, 21, 2, 'AA', 'AA', 0, 1),
(2, 21, 2, 'AE', 'AE', 0, 1),
(3, 21, 2, 'AP', 'AP', 0, 1),
(4, 21, 2, 'Alabama', 'AL', 0, 1),
(5, 21, 2, 'Alaska', 'AK', 0, 1),
(6, 21, 2, 'Arizona', 'AZ', 0, 1),
(7, 21, 2, 'Arkansas', 'AR', 0, 1),
(8, 21, 2, 'California', 'CA', 0, 1),
(9, 21, 2, 'Colorado', 'CO', 0, 1),
(10, 21, 2, 'Connecticut', 'CT', 0, 1),
(11, 21, 2, 'Delaware', 'DE', 0, 1),
(12, 21, 2, 'Florida', 'FL', 0, 1),
(13, 21, 2, 'Georgia', 'GA', 0, 1),
(14, 21, 2, 'Hawaii', 'HI', 0, 1),
(15, 21, 2, 'Idaho', 'ID', 0, 1),
(16, 21, 2, 'Illinois', 'IL', 0, 1),
(17, 21, 2, 'Indiana', 'IN', 0, 1),
(18, 21, 2, 'Iowa', 'IA', 0, 1),
(19, 21, 2, 'Kansas', 'KS', 0, 1),
(20, 21, 2, 'Kentucky', 'KY', 0, 1),
(21, 21, 2, 'Louisiana', 'LA', 0, 1),
(22, 21, 2, 'Maine', 'ME', 0, 1),
(23, 21, 2, 'Maryland', 'MD', 0, 1),
(24, 21, 2, 'Massachusetts', 'MA', 0, 1),
(25, 21, 2, 'Michigan', 'MI', 0, 1),
(26, 21, 2, 'Minnesota', 'MN', 0, 1),
(27, 21, 2, 'Mississippi', 'MS', 0, 1),
(28, 21, 2, 'Missouri', 'MO', 0, 1),
(29, 21, 2, 'Montana', 'MT', 0, 1),
(30, 21, 2, 'Nebraska', 'NE', 0, 1),
(31, 21, 2, 'Nevada', 'NV', 0, 1),
(32, 21, 2, 'New Hampshire', 'NH', 0, 1),
(33, 21, 2, 'New Jersey', 'NJ', 0, 1),
(34, 21, 2, 'New Mexico', 'NM', 0, 1),
(35, 21, 2, 'New York', 'NY', 0, 1),
(36, 21, 2, 'North Carolina', 'NC', 0, 1),
(37, 21, 2, 'North Dakota', 'ND', 0, 1),
(38, 21, 2, 'Ohio', 'OH', 0, 1),
(39, 21, 2, 'Oklahoma', 'OK', 0, 1),
(40, 21, 2, 'Oregon', 'OR', 0, 1),
(41, 21, 2, 'Pennsylvania', 'PA', 0, 1),
(42, 21, 2, 'Rhode Island', 'RI', 0, 1),
(43, 21, 2, 'South Carolina', 'SC', 0, 1),
(44, 21, 2, 'South Dakota', 'SD', 0, 1),
(45, 21, 2, 'Tennessee', 'TN', 0, 1),
(46, 21, 2, 'Texas', 'TX', 0, 1),
(47, 21, 2, 'Utah', 'UT', 0, 1),
(48, 21, 2, 'Vermont', 'VT', 0, 1),
(49, 21, 2, 'Virginia', 'VA', 0, 1),
(50, 21, 2, 'Washington', 'WA', 0, 1),
(51, 21, 2, 'West Virginia', 'WV', 0, 1),
(52, 21, 2, 'Wisconsin', 'WI', 0, 1),
(53, 21, 2, 'Wyoming', 'WY', 0, 1),
(54, 21, 2, 'Puerto Rico', 'PR', 0, 1),
(55, 21, 2, 'US Virgin Islands', 'VI', 0, 1),
(56, 21, 2, 'District of Columbia', 'DC', 0, 1),
(57, 144, 2, 'Aguascalientes', 'AGS', 0, 1),
(58, 144, 2, 'Baja California', 'BCN', 0, 1),
(59, 144, 2, 'Baja California Sur', 'BCS', 0, 1),
(60, 144, 2, 'Campeche', 'CAM', 0, 1),
(61, 144, 2, 'Chiapas', 'CHP', 0, 1),
(62, 144, 2, 'Chihuahua', 'CHH', 0, 1),
(63, 144, 2, 'Coahuila', 'COA', 0, 1),
(64, 144, 2, 'Colima', 'COL', 0, 1),
(65, 144, 2, 'Ciudad de México', 'CMX', 0, 1),
(66, 144, 2, 'Durango', 'DUR', 0, 1),
(67, 144, 2, 'Guanajuato', 'GUA', 0, 1),
(68, 144, 2, 'Guerrero', 'GRO', 0, 1),
(69, 144, 2, 'Hidalgo', 'HID', 0, 1),
(70, 144, 2, 'Jalisco', 'JAL', 0, 1),
(71, 144, 2, 'Estado de México', 'MEX', 0, 1),
(72, 144, 2, 'Michoacán', 'MIC', 0, 1),
(73, 144, 2, 'Morelos', 'MOR', 0, 1),
(74, 144, 2, 'Nayarit', 'NAY', 0, 1),
(75, 144, 2, 'Nuevo León', 'NLE', 0, 1),
(76, 144, 2, 'Oaxaca', 'OAX', 0, 1),
(77, 144, 2, 'Puebla', 'PUE', 0, 1),
(78, 144, 2, 'Querétaro', 'QUE', 0, 1),
(79, 144, 2, 'Quintana Roo', 'ROO', 0, 1),
(80, 144, 2, 'San Luis Potosí', 'SLP', 0, 1),
(81, 144, 2, 'Sinaloa', 'SIN', 0, 1),
(82, 144, 2, 'Sonora', 'SON', 0, 1),
(83, 144, 2, 'Tabasco', 'TAB', 0, 1),
(84, 144, 2, 'Tamaulipas', 'TAM', 0, 1),
(85, 144, 2, 'Tlaxcala', 'TLA', 0, 1),
(86, 144, 2, 'Veracruz', 'VER', 0, 1),
(87, 144, 2, 'Yucatán', 'YUC', 0, 1),
(88, 144, 2, 'Zacatecas', 'ZAC', 0, 1),
(89, 4, 2, 'Ontario', 'ON', 0, 1),
(90, 4, 2, 'Quebec', 'QC', 0, 1),
(91, 4, 2, 'British Columbia', 'BC', 0, 1),
(92, 4, 2, 'Alberta', 'AB', 0, 1),
(93, 4, 2, 'Manitoba', 'MB', 0, 1),
(94, 4, 2, 'Saskatchewan', 'SK', 0, 1),
(95, 4, 2, 'Nova Scotia', 'NS', 0, 1),
(96, 4, 2, 'New Brunswick', 'NB', 0, 1),
(97, 4, 2, 'Newfoundland and Labrador', 'NL', 0, 1),
(98, 4, 2, 'Prince Edward Island', 'PE', 0, 1),
(99, 4, 2, 'Northwest Territories', 'NT', 0, 1),
(100, 4, 2, 'Yukon', 'YT', 0, 1),
(101, 4, 2, 'Nunavut', 'NU', 0, 1),
(102, 44, 6, 'Buenos Aires', 'B', 0, 1),
(103, 44, 6, 'Catamarca', 'K', 0, 1),
(104, 44, 6, 'Chaco', 'H', 0, 1),
(105, 44, 6, 'Chubut', 'U', 0, 1),
(106, 44, 6, 'Ciudad de Buenos Aires', 'C', 0, 1),
(107, 44, 6, 'Córdoba', 'X', 0, 1),
(108, 44, 6, 'Corrientes', 'W', 0, 1),
(109, 44, 6, 'Entre Ríos', 'E', 0, 1),
(110, 44, 6, 'Formosa', 'P', 0, 1),
(111, 44, 6, 'Jujuy', 'Y', 0, 1),
(112, 44, 6, 'La Pampa', 'L', 0, 1),
(113, 44, 6, 'La Rioja', 'F', 0, 1),
(114, 44, 6, 'Mendoza', 'M', 0, 1),
(115, 44, 6, 'Misiones', 'N', 0, 1),
(116, 44, 6, 'Neuquén', 'Q', 0, 1),
(117, 44, 6, 'Río Negro', 'R', 0, 1),
(118, 44, 6, 'Salta', 'A', 0, 1),
(119, 44, 6, 'San Juan', 'J', 0, 1),
(120, 44, 6, 'San Luis', 'D', 0, 1),
(121, 44, 6, 'Santa Cruz', 'Z', 0, 1),
(122, 44, 6, 'Santa Fe', 'S', 0, 1),
(123, 44, 6, 'Santiago del Estero', 'G', 0, 1),
(124, 44, 6, 'Tierra del Fuego', 'V', 0, 1),
(125, 44, 6, 'Tucumán', 'T', 0, 1),
(126, 10, 1, 'Agrigento', 'AG', 0, 1),
(127, 10, 1, 'Alessandria', 'AL', 0, 1),
(128, 10, 1, 'Ancona', 'AN', 0, 1),
(129, 10, 1, 'Aosta', 'AO', 0, 1),
(130, 10, 1, 'Arezzo', 'AR', 0, 1),
(131, 10, 1, 'Ascoli Piceno', 'AP', 0, 1),
(132, 10, 1, 'Asti', 'AT', 0, 1),
(133, 10, 1, 'Avellino', 'AV', 0, 1),
(134, 10, 1, 'Bari', 'BA', 0, 1),
(135, 10, 1, 'Barletta-Andria-Trani', 'BT', 0, 1),
(136, 10, 1, 'Belluno', 'BL', 0, 1),
(137, 10, 1, 'Benevento', 'BN', 0, 1),
(138, 10, 1, 'Bergamo', 'BG', 0, 1),
(139, 10, 1, 'Biella', 'BI', 0, 1),
(140, 10, 1, 'Bologna', 'BO', 0, 1),
(141, 10, 1, 'Bolzano', 'BZ', 0, 1),
(142, 10, 1, 'Brescia', 'BS', 0, 1),
(143, 10, 1, 'Brindisi', 'BR', 0, 1),
(144, 10, 1, 'Cagliari', 'CA', 0, 1),
(145, 10, 1, 'Caltanissetta', 'CL', 0, 1),
(146, 10, 1, 'Campobasso', 'CB', 0, 1),
(147, 10, 1, 'Carbonia-Iglesias', 'CI', 0, 1),
(148, 10, 1, 'Caserta', 'CE', 0, 1),
(149, 10, 1, 'Catania', 'CT', 0, 1),
(150, 10, 1, 'Catanzaro', 'CZ', 0, 1),
(151, 10, 1, 'Chieti', 'CH', 0, 1),
(152, 10, 1, 'Como', 'CO', 0, 1),
(153, 10, 1, 'Cosenza', 'CS', 0, 1),
(154, 10, 1, 'Cremona', 'CR', 0, 1),
(155, 10, 1, 'Crotone', 'KR', 0, 1),
(156, 10, 1, 'Cuneo', 'CN', 0, 1),
(157, 10, 1, 'Enna', 'EN', 0, 1),
(158, 10, 1, 'Fermo', 'FM', 0, 1),
(159, 10, 1, 'Ferrara', 'FE', 0, 1),
(160, 10, 1, 'Firenze', 'FI', 0, 1),
(161, 10, 1, 'Foggia', 'FG', 0, 1),
(162, 10, 1, 'Forlì-Cesena', 'FC', 0, 1),
(163, 10, 1, 'Frosinone', 'FR', 0, 1),
(164, 10, 1, 'Genova', 'GE', 0, 1),
(165, 10, 1, 'Gorizia', 'GO', 0, 1),
(166, 10, 1, 'Grosseto', 'GR', 0, 1),
(167, 10, 1, 'Imperia', 'IM', 0, 1),
(168, 10, 1, 'Isernia', 'IS', 0, 1),
(169, 10, 1, 'L\'Aquila', 'AQ', 0, 1),
(170, 10, 1, 'La Spezia', 'SP', 0, 1),
(171, 10, 1, 'Latina', 'LT', 0, 1),
(172, 10, 1, 'Lecce', 'LE', 0, 1),
(173, 10, 1, 'Lecco', 'LC', 0, 1),
(174, 10, 1, 'Livorno', 'LI', 0, 1),
(175, 10, 1, 'Lodi', 'LO', 0, 1),
(176, 10, 1, 'Lucca', 'LU', 0, 1),
(177, 10, 1, 'Macerata', 'MC', 0, 1),
(178, 10, 1, 'Mantova', 'MN', 0, 1),
(179, 10, 1, 'Massa', 'MS', 0, 1),
(180, 10, 1, 'Matera', 'MT', 0, 1),
(181, 10, 1, 'Medio Campidano', 'VS', 0, 1),
(182, 10, 1, 'Messina', 'ME', 0, 1),
(183, 10, 1, 'Milano', 'MI', 0, 1),
(184, 10, 1, 'Modena', 'MO', 0, 1),
(185, 10, 1, 'Monza e della Brianza', 'MB', 0, 1),
(186, 10, 1, 'Napoli', 'NA', 0, 1),
(187, 10, 1, 'Novara', 'NO', 0, 1),
(188, 10, 1, 'Nuoro', 'NU', 0, 1),
(189, 10, 1, 'Ogliastra', 'OG', 0, 1),
(190, 10, 1, 'Olbia-Tempio', 'OT', 0, 1),
(191, 10, 1, 'Oristano', 'OR', 0, 1),
(192, 10, 1, 'Padova', 'PD', 0, 1),
(193, 10, 1, 'Palermo', 'PA', 0, 1),
(194, 10, 1, 'Parma', 'PR', 0, 1),
(195, 10, 1, 'Pavia', 'PV', 0, 1),
(196, 10, 1, 'Perugia', 'PG', 0, 1),
(197, 10, 1, 'Pesaro-Urbino', 'PU', 0, 1),
(198, 10, 1, 'Pescara', 'PE', 0, 1),
(199, 10, 1, 'Piacenza', 'PC', 0, 1),
(200, 10, 1, 'Pisa', 'PI', 0, 1),
(201, 10, 1, 'Pistoia', 'PT', 0, 1),
(202, 10, 1, 'Pordenone', 'PN', 0, 1),
(203, 10, 1, 'Potenza', 'PZ', 0, 1),
(204, 10, 1, 'Prato', 'PO', 0, 1),
(205, 10, 1, 'Ragusa', 'RG', 0, 1),
(206, 10, 1, 'Ravenna', 'RA', 0, 1),
(207, 10, 1, 'Reggio Calabria', 'RC', 0, 1),
(208, 10, 1, 'Reggio Emilia', 'RE', 0, 1),
(209, 10, 1, 'Rieti', 'RI', 0, 1),
(210, 10, 1, 'Rimini', 'RN', 0, 1),
(211, 10, 1, 'Roma', 'RM', 0, 1),
(212, 10, 1, 'Rovigo', 'RO', 0, 1),
(213, 10, 1, 'Salerno', 'SA', 0, 1),
(214, 10, 1, 'Sassari', 'SS', 0, 1),
(215, 10, 1, 'Savona', 'SV', 0, 1),
(216, 10, 1, 'Siena', 'SI', 0, 1),
(217, 10, 1, 'Siracusa', 'SR', 0, 1),
(218, 10, 1, 'Sondrio', 'SO', 0, 1),
(219, 10, 1, 'Taranto', 'TA', 0, 1),
(220, 10, 1, 'Teramo', 'TE', 0, 1),
(221, 10, 1, 'Terni', 'TR', 0, 1),
(222, 10, 1, 'Torino', 'TO', 0, 1),
(223, 10, 1, 'Trapani', 'TP', 0, 1),
(224, 10, 1, 'Trento', 'TN', 0, 1),
(225, 10, 1, 'Treviso', 'TV', 0, 1),
(226, 10, 1, 'Trieste', 'TS', 0, 1),
(227, 10, 1, 'Udine', 'UD', 0, 1),
(228, 10, 1, 'Varese', 'VA', 0, 1),
(229, 10, 1, 'Venezia', 'VE', 0, 1),
(230, 10, 1, 'Verbano-Cusio-Ossola', 'VB', 0, 1),
(231, 10, 1, 'Vercelli', 'VC', 0, 1),
(232, 10, 1, 'Verona', 'VR', 0, 1),
(233, 10, 1, 'Vibo Valentia', 'VV', 0, 1),
(234, 10, 1, 'Vicenza', 'VI', 0, 1),
(235, 10, 1, 'Viterbo', 'VT', 0, 1),
(236, 110, 3, 'Aceh', 'ID-AC', 0, 1),
(237, 110, 3, 'Bali', 'ID-BA', 0, 1),
(238, 110, 3, 'Banten', 'ID-BT', 0, 1),
(239, 110, 3, 'Bengkulu', 'ID-BE', 0, 1),
(240, 110, 3, 'Gorontalo', 'ID-GO', 0, 1),
(241, 110, 3, 'Jakarta', 'ID-JK', 0, 1),
(242, 110, 3, 'Jambi', 'ID-JA', 0, 1),
(243, 110, 3, 'Jawa Barat', 'ID-JB', 0, 1),
(244, 110, 3, 'Jawa Tengah', 'ID-JT', 0, 1),
(245, 110, 3, 'Jawa Timur', 'ID-JI', 0, 1),
(246, 110, 3, 'Kalimantan Barat', 'ID-KB', 0, 1),
(247, 110, 3, 'Kalimantan Selatan', 'ID-KS', 0, 1),
(248, 110, 3, 'Kalimantan Tengah', 'ID-KT', 0, 1),
(249, 110, 3, 'Kalimantan Timur', 'ID-KI', 0, 1),
(250, 110, 3, 'Kalimantan Utara', 'ID-KU', 0, 1),
(251, 110, 3, 'Kepulauan Bangka Belitug', 'ID-BB', 0, 1),
(252, 110, 3, 'Kepulauan Riau', 'ID-KR', 0, 1),
(253, 110, 3, 'Lampung', 'ID-LA', 0, 1),
(254, 110, 3, 'Maluku', 'ID-MA', 0, 1),
(255, 110, 3, 'Maluku Utara', 'ID-MU', 0, 1),
(256, 110, 3, 'Nusa Tengara Barat', 'ID-NB', 0, 1),
(257, 110, 3, 'Nusa Tenggara Timur', 'ID-NT', 0, 1),
(258, 110, 3, 'Papua', 'ID-PA', 0, 1),
(259, 110, 3, 'Papua Barat', 'ID-PB', 0, 1),
(260, 110, 3, 'Riau', 'ID-RI', 0, 1),
(261, 110, 3, 'Sulawesi Barat', 'ID-SR', 0, 1),
(262, 110, 3, 'Sulawesi Selatan', 'ID-SN', 0, 1),
(263, 110, 3, 'Sulawesi Tengah', 'ID-ST', 0, 1),
(264, 110, 3, 'Sulawesi Tenggara', 'ID-SG', 0, 1),
(265, 110, 3, 'Sulawesi Utara', 'ID-SA', 0, 1),
(266, 110, 3, 'Sumatera Barat', 'ID-SB', 0, 1),
(267, 110, 3, 'Sumatera Selatan', 'ID-SS', 0, 1),
(268, 110, 3, 'Sumatera Utara', 'ID-SU', 0, 1),
(269, 110, 3, 'Yogyakarta', 'ID-YO', 0, 1),
(270, 11, 3, 'Aichi', '23', 0, 1),
(271, 11, 3, 'Akita', '05', 0, 1),
(272, 11, 3, 'Aomori', '02', 0, 1),
(273, 11, 3, 'Chiba', '12', 0, 1),
(274, 11, 3, 'Ehime', '38', 0, 1),
(275, 11, 3, 'Fukui', '18', 0, 1),
(276, 11, 3, 'Fukuoka', '40', 0, 1),
(277, 11, 3, 'Fukushima', '07', 0, 1),
(278, 11, 3, 'Gifu', '21', 0, 1),
(279, 11, 3, 'Gunma', '10', 0, 1),
(280, 11, 3, 'Hiroshima', '34', 0, 1),
(281, 11, 3, 'Hokkaido', '01', 0, 1),
(282, 11, 3, 'Hyogo', '28', 0, 1),
(283, 11, 3, 'Ibaraki', '08', 0, 1),
(284, 11, 3, 'Ishikawa', '17', 0, 1),
(285, 11, 3, 'Iwate', '03', 0, 1),
(286, 11, 3, 'Kagawa', '37', 0, 1),
(287, 11, 3, 'Kagoshima', '46', 0, 1),
(288, 11, 3, 'Kanagawa', '14', 0, 1),
(289, 11, 3, 'Kochi', '39', 0, 1),
(290, 11, 3, 'Kumamoto', '43', 0, 1),
(291, 11, 3, 'Kyoto', '26', 0, 1),
(292, 11, 3, 'Mie', '24', 0, 1),
(293, 11, 3, 'Miyagi', '04', 0, 1),
(294, 11, 3, 'Miyazaki', '45', 0, 1),
(295, 11, 3, 'Nagano', '20', 0, 1),
(296, 11, 3, 'Nagasaki', '42', 0, 1),
(297, 11, 3, 'Nara', '29', 0, 1),
(298, 11, 3, 'Niigata', '15', 0, 1),
(299, 11, 3, 'Oita', '44', 0, 1),
(300, 11, 3, 'Okayama', '33', 0, 1),
(301, 11, 3, 'Okinawa', '47', 0, 1),
(302, 11, 3, 'Osaka', '27', 0, 1),
(303, 11, 3, 'Saga', '41', 0, 1),
(304, 11, 3, 'Saitama', '11', 0, 1),
(305, 11, 3, 'Shiga', '25', 0, 1),
(306, 11, 3, 'Shimane', '32', 0, 1),
(307, 11, 3, 'Shizuoka', '22', 0, 1),
(308, 11, 3, 'Tochigi', '09', 0, 1),
(309, 11, 3, 'Tokushima', '36', 0, 1),
(310, 11, 3, 'Tokyo', '13', 0, 1),
(311, 11, 3, 'Tottori', '31', 0, 1),
(312, 11, 3, 'Toyama', '16', 0, 1),
(313, 11, 3, 'Wakayama', '30', 0, 1),
(314, 11, 3, 'Yamagata', '06', 0, 1),
(315, 11, 3, 'Yamaguchi', '35', 0, 1),
(316, 11, 3, 'Yamanashi', '19', 0, 1),
(317, 24, 5, 'Australian Capital Territory', 'ACT', 0, 1),
(318, 24, 5, 'New South Wales', 'NSW', 0, 1),
(319, 24, 5, 'Northern Territory', 'NT', 0, 1),
(320, 24, 5, 'Queensland', 'QLD', 0, 1),
(321, 24, 5, 'South Australia', 'SA', 0, 1),
(322, 24, 5, 'Tasmania', 'TAS', 0, 1),
(323, 24, 5, 'Victoria', 'VIC', 0, 1),
(324, 24, 5, 'Western Australia', 'WA', 0, 1),
(325, 109, 3, 'Andhra Pradesh', 'AP', 0, 1),
(326, 109, 3, 'Arunachal Pradesh', 'AR', 0, 1),
(327, 109, 3, 'Assam', 'AS', 0, 1),
(328, 109, 3, 'Bihar', 'BR', 0, 1),
(329, 109, 3, 'Chhattisgarh', 'CT', 0, 1),
(330, 109, 3, 'Goa', 'GA', 0, 1),
(331, 109, 3, 'Gujarat', 'GJ', 0, 1),
(332, 109, 3, 'Haryana', 'HR', 0, 1),
(333, 109, 3, 'Himachal Pradesh', 'HP', 0, 1),
(334, 109, 3, 'Jharkhand', 'JH', 0, 1),
(335, 109, 3, 'Karnataka', 'KA', 0, 1),
(336, 109, 3, 'Kerala', 'KL', 0, 1),
(337, 109, 3, 'Madhya Pradesh', 'MP', 0, 1),
(338, 109, 3, 'Maharashtra', 'MH', 0, 1),
(339, 109, 3, 'Manipur', 'MN', 0, 1),
(340, 109, 3, 'Meghalaya', 'ML', 0, 1),
(341, 109, 3, 'Mizoram', 'MZ', 0, 1),
(342, 109, 3, 'Nagaland', 'NL', 0, 1),
(343, 109, 3, 'Odisha', 'OR', 0, 1),
(344, 109, 3, 'Punjab', 'PB', 0, 1),
(345, 109, 3, 'Rajasthan', 'RJ', 0, 1),
(346, 109, 3, 'Sikkim', 'SK', 0, 1),
(347, 109, 3, 'Tamil Nadu', 'TN', 0, 1),
(348, 109, 3, 'Telangana', 'TG', 0, 1),
(349, 109, 3, 'Tripura', 'TR', 0, 1),
(350, 109, 3, 'Uttar Pradesh', 'UP', 0, 1),
(351, 109, 3, 'Uttarakhand', 'UT', 0, 1),
(352, 109, 3, 'West Bengal', 'WB', 0, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_statssearch`
--

CREATE TABLE `ps_statssearch` (
  `id_statssearch` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `id_shop_group` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `keywords` varchar(255) NOT NULL,
  `results` int(6) NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_stock`
--

CREATE TABLE `ps_stock` (
  `id_stock` int(11) UNSIGNED NOT NULL,
  `id_warehouse` int(11) UNSIGNED NOT NULL,
  `id_product` int(11) UNSIGNED NOT NULL,
  `id_product_attribute` int(11) UNSIGNED NOT NULL,
  `reference` varchar(64) NOT NULL,
  `ean13` varchar(13) DEFAULT NULL,
  `isbn` varchar(32) DEFAULT NULL,
  `upc` varchar(12) DEFAULT NULL,
  `mpn` varchar(40) DEFAULT NULL,
  `physical_quantity` int(11) UNSIGNED NOT NULL,
  `usable_quantity` int(11) UNSIGNED NOT NULL,
  `price_te` decimal(20,6) DEFAULT 0.000000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_stock_available`
--

CREATE TABLE `ps_stock_available` (
  `id_stock_available` int(11) UNSIGNED NOT NULL,
  `id_product` int(11) UNSIGNED NOT NULL,
  `id_product_attribute` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL,
  `id_shop_group` int(11) UNSIGNED NOT NULL,
  `quantity` int(10) NOT NULL DEFAULT 0,
  `physical_quantity` int(11) NOT NULL DEFAULT 0,
  `reserved_quantity` int(11) NOT NULL DEFAULT 0,
  `depends_on_stock` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `out_of_stock` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `location` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_stock_available`
--

INSERT INTO `ps_stock_available` (`id_stock_available`, `id_product`, `id_product_attribute`, `id_shop`, `id_shop_group`, `quantity`, `physical_quantity`, `reserved_quantity`, `depends_on_stock`, `out_of_stock`, `location`) VALUES
(84, 24, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(85, 23, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(86, 22, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(87, 21, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(88, 20, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(89, 18, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(90, 17, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(91, 16, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(92, 11, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(93, 10, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(94, 9, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(95, 5, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(96, 4, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(97, 3, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(98, 2, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(99, 1, 0, 1, 0, 0, 0, 0, 0, 0, ''),
(100, 25, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(101, 25, 60, 1, 0, 999, 0, 0, 0, 1, ''),
(102, 25, 61, 1, 0, 999, 0, 0, 0, 1, ''),
(103, 25, 62, 1, 0, 999, 0, 0, 0, 1, ''),
(104, 25, 63, 1, 0, 999, 0, 0, 0, 1, ''),
(105, 26, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(106, 26, 64, 1, 0, 999, 0, 0, 0, 1, ''),
(107, 26, 65, 1, 0, 999, 0, 0, 0, 1, ''),
(108, 26, 66, 1, 0, 999, 0, 0, 0, 1, ''),
(109, 26, 67, 1, 0, 999, 0, 0, 0, 1, ''),
(110, 27, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(111, 27, 68, 1, 0, 999, 0, 0, 0, 1, ''),
(112, 27, 69, 1, 0, 999, 0, 0, 0, 1, ''),
(113, 27, 70, 1, 0, 999, 0, 0, 0, 1, ''),
(114, 27, 71, 1, 0, 999, 0, 0, 0, 1, ''),
(115, 28, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(116, 28, 72, 1, 0, 999, 0, 0, 0, 1, ''),
(117, 28, 73, 1, 0, 999, 0, 0, 0, 1, ''),
(118, 28, 74, 1, 0, 999, 0, 0, 0, 1, ''),
(119, 28, 75, 1, 0, 999, 0, 0, 0, 1, ''),
(120, 29, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(121, 29, 76, 1, 0, 999, 0, 0, 0, 1, ''),
(122, 29, 77, 1, 0, 999, 0, 0, 0, 1, ''),
(123, 29, 78, 1, 0, 999, 0, 0, 0, 1, ''),
(124, 29, 79, 1, 0, 999, 0, 0, 0, 1, ''),
(125, 30, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(126, 30, 80, 1, 0, 999, 0, 0, 0, 1, ''),
(127, 30, 81, 1, 0, 999, 0, 0, 0, 1, ''),
(128, 30, 82, 1, 0, 999, 0, 0, 0, 1, ''),
(129, 30, 83, 1, 0, 999, 0, 0, 0, 1, ''),
(130, 31, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(131, 31, 84, 1, 0, 999, 0, 0, 0, 1, ''),
(132, 31, 85, 1, 0, 999, 0, 0, 0, 1, ''),
(133, 31, 86, 1, 0, 999, 0, 0, 0, 1, ''),
(134, 31, 87, 1, 0, 999, 0, 0, 0, 1, ''),
(135, 32, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(136, 32, 88, 1, 0, 999, 0, 0, 0, 1, ''),
(137, 32, 89, 1, 0, 999, 0, 0, 0, 1, ''),
(138, 32, 90, 1, 0, 999, 0, 0, 0, 1, ''),
(139, 32, 91, 1, 0, 999, 0, 0, 0, 1, ''),
(140, 33, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(141, 33, 92, 1, 0, 999, 0, 0, 0, 1, ''),
(142, 33, 93, 1, 0, 999, 0, 0, 0, 1, ''),
(143, 33, 94, 1, 0, 999, 0, 0, 0, 1, ''),
(144, 33, 95, 1, 0, 999, 0, 0, 0, 1, ''),
(145, 34, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(146, 34, 96, 1, 0, 999, 0, 0, 0, 1, ''),
(147, 34, 97, 1, 0, 999, 0, 0, 0, 1, ''),
(148, 34, 98, 1, 0, 999, 0, 0, 0, 1, ''),
(149, 34, 99, 1, 0, 999, 0, 0, 0, 1, ''),
(150, 35, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(151, 35, 100, 1, 0, 999, 0, 0, 0, 1, ''),
(152, 35, 101, 1, 0, 999, 0, 0, 0, 1, ''),
(153, 35, 102, 1, 0, 999, 0, 0, 0, 1, ''),
(154, 35, 103, 1, 0, 999, 0, 0, 0, 1, ''),
(155, 36, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(156, 36, 104, 1, 0, 999, 0, 0, 0, 1, ''),
(157, 36, 105, 1, 0, 999, 0, 0, 0, 1, ''),
(158, 36, 106, 1, 0, 999, 0, 0, 0, 1, ''),
(159, 36, 107, 1, 0, 999, 0, 0, 0, 1, ''),
(160, 37, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(161, 37, 108, 1, 0, 999, 0, 0, 0, 1, ''),
(162, 37, 109, 1, 0, 999, 0, 0, 0, 1, ''),
(163, 37, 110, 1, 0, 999, 0, 0, 0, 1, ''),
(164, 37, 111, 1, 0, 999, 0, 0, 0, 1, ''),
(165, 38, 0, 1, 0, 3996, 0, 0, 0, 1, ''),
(166, 38, 112, 1, 0, 999, 0, 0, 0, 1, ''),
(167, 38, 113, 1, 0, 999, 0, 0, 0, 1, ''),
(168, 38, 114, 1, 0, 999, 0, 0, 0, 1, ''),
(169, 38, 115, 1, 0, 999, 0, 0, 0, 1, '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_stock_mvt`
--

CREATE TABLE `ps_stock_mvt` (
  `id_stock_mvt` bigint(20) NOT NULL,
  `id_stock` int(11) NOT NULL,
  `id_order` int(11) DEFAULT NULL,
  `id_supply_order` int(11) DEFAULT NULL,
  `id_stock_mvt_reason` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `employee_lastname` varchar(32) DEFAULT NULL,
  `employee_firstname` varchar(32) DEFAULT NULL,
  `physical_quantity` int(11) NOT NULL,
  `date_add` datetime NOT NULL,
  `sign` smallint(6) NOT NULL DEFAULT 1,
  `price_te` decimal(20,6) DEFAULT 0.000000,
  `last_wa` decimal(20,6) DEFAULT 0.000000,
  `current_wa` decimal(20,6) DEFAULT 0.000000,
  `referer` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_stock_mvt_reason`
--

CREATE TABLE `ps_stock_mvt_reason` (
  `id_stock_mvt_reason` int(11) UNSIGNED NOT NULL,
  `sign` tinyint(1) NOT NULL DEFAULT 1,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_stock_mvt_reason`
--

INSERT INTO `ps_stock_mvt_reason` (`id_stock_mvt_reason`, `sign`, `date_add`, `date_upd`, `deleted`) VALUES
(1, 1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0),
(2, -1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0),
(3, -1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0),
(4, -1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0),
(5, 1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0),
(6, -1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0),
(7, 1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0),
(8, 1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0),
(9, 1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0),
(10, 1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0),
(11, 1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0),
(12, -1, '2022-12-08 17:56:30', '2022-12-08 17:56:30', 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_stock_mvt_reason_lang`
--

CREATE TABLE `ps_stock_mvt_reason_lang` (
  `id_stock_mvt_reason` int(11) UNSIGNED NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_stock_mvt_reason_lang`
--

INSERT INTO `ps_stock_mvt_reason_lang` (`id_stock_mvt_reason`, `id_lang`, `name`) VALUES
(1, 1, 'Wzrost'),
(2, 1, 'Zmniejsz'),
(3, 1, 'Zamówienie klienta'),
(4, 1, 'Regulation following an inventory of stock'),
(5, 1, 'Regulation following an inventory of stock'),
(6, 1, 'Przeniesienie do innego magazynu'),
(7, 1, 'Przeniesienie z innego magazynu'),
(8, 1, 'Zamówienie dostawcy'),
(9, 1, 'Zamówienie klienta'),
(10, 1, 'Zwrot produktu'),
(11, 1, 'Employee Edition'),
(12, 1, 'Employee Edition');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_store`
--

CREATE TABLE `ps_store` (
  `id_store` int(10) UNSIGNED NOT NULL,
  `id_country` int(10) UNSIGNED NOT NULL,
  `id_state` int(10) UNSIGNED DEFAULT NULL,
  `city` varchar(64) NOT NULL,
  `postcode` varchar(12) NOT NULL,
  `latitude` decimal(13,8) DEFAULT NULL,
  `longitude` decimal(13,8) DEFAULT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `fax` varchar(16) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_store`
--

INSERT INTO `ps_store` (`id_store`, `id_country`, `id_state`, `city`, `postcode`, `latitude`, `longitude`, `phone`, `fax`, `email`, `active`, `date_add`, `date_upd`) VALUES
(1, 21, 12, 'Miami', '33135', '25.76500500', '-80.24379700', '', '', '', 1, '2022-12-08 17:57:56', '2022-12-08 17:57:56'),
(2, 21, 12, 'Miami', '33304', '26.13793600', '-80.13943500', '', '', '', 1, '2022-12-08 17:57:56', '2022-12-08 17:57:56'),
(3, 21, 12, 'Miami', '33026', '26.00998700', '-80.29447200', '', '', '', 1, '2022-12-08 17:57:56', '2022-12-08 17:57:56'),
(4, 21, 12, 'Miami', '33133', '25.73629600', '-80.24479700', '', '', '', 1, '2022-12-08 17:57:56', '2022-12-08 17:57:56'),
(5, 21, 12, 'Miami', '33181', '25.88674000', '-80.16329200', '', '', '', 1, '2022-12-08 17:57:56', '2022-12-08 17:57:56');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_store_lang`
--

CREATE TABLE `ps_store_lang` (
  `id_store` int(11) UNSIGNED NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `hours` text DEFAULT NULL,
  `note` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_store_lang`
--

INSERT INTO `ps_store_lang` (`id_store`, `id_lang`, `name`, `address1`, `address2`, `hours`, `note`) VALUES
(1, 1, 'Dade County', '3030 SW 8th St Miami', '', ' [[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"10:00AM - 04:00PM\"],[\"10:00AM - 04:00PM\"]]', ''),
(2, 1, 'E Fort Lauderdale', '1000 Northeast 4th Ave Fort Lauderdale', '', ' [[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"10:00AM - 04:00PM\"],[\"10:00AM - 04:00PM\"]]', ''),
(3, 1, 'Pembroke Pines', '11001 Pines Blvd Pembroke Pines', '', ' [[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"10:00AM - 04:00PM\"],[\"10:00AM - 04:00PM\"]]', ''),
(4, 1, 'Coconut Grove', '2999 SW 32nd Avenue', '', ' [[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"10:00AM - 04:00PM\"],[\"10:00AM - 04:00PM\"]]', ''),
(5, 1, 'N Miami/Biscayne', '12055 Biscayne Blvd', '', ' [[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"09:00AM - 07:00PM\"],[\"10:00AM - 04:00PM\"],[\"10:00AM - 04:00PM\"]]', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_store_shop`
--

CREATE TABLE `ps_store_shop` (
  `id_store` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_store_shop`
--

INSERT INTO `ps_store_shop` (`id_store`, `id_shop`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_supplier`
--

CREATE TABLE `ps_supplier` (
  `id_supplier` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_supplier`
--

INSERT INTO `ps_supplier` (`id_supplier`, `name`, `date_add`, `date_upd`, `active`) VALUES
(1, 'Fashion supplier', '2022-12-08 17:57:52', '2022-12-08 17:57:52', 1),
(2, 'Accessories supplier', '2022-12-08 17:57:52', '2022-12-08 17:57:52', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_supplier_lang`
--

CREATE TABLE `ps_supplier_lang` (
  `id_supplier` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `description` text DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_supplier_lang`
--

INSERT INTO `ps_supplier_lang` (`id_supplier`, `id_lang`, `description`, `meta_title`, `meta_keywords`, `meta_description`) VALUES
(1, 1, '', '', '', ''),
(2, 1, '', '', '', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_supplier_shop`
--

CREATE TABLE `ps_supplier_shop` (
  `id_supplier` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_supplier_shop`
--

INSERT INTO `ps_supplier_shop` (`id_supplier`, `id_shop`) VALUES
(1, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_supply_order`
--

CREATE TABLE `ps_supply_order` (
  `id_supply_order` int(11) UNSIGNED NOT NULL,
  `id_supplier` int(11) UNSIGNED NOT NULL,
  `supplier_name` varchar(64) NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `id_warehouse` int(11) UNSIGNED NOT NULL,
  `id_supply_order_state` int(11) UNSIGNED NOT NULL,
  `id_currency` int(11) UNSIGNED NOT NULL,
  `id_ref_currency` int(11) UNSIGNED NOT NULL,
  `reference` varchar(64) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `date_delivery_expected` datetime DEFAULT NULL,
  `total_te` decimal(20,6) DEFAULT 0.000000,
  `total_with_discount_te` decimal(20,6) DEFAULT 0.000000,
  `total_tax` decimal(20,6) DEFAULT 0.000000,
  `total_ti` decimal(20,6) DEFAULT 0.000000,
  `discount_rate` decimal(20,6) DEFAULT 0.000000,
  `discount_value_te` decimal(20,6) DEFAULT 0.000000,
  `is_template` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_supply_order_detail`
--

CREATE TABLE `ps_supply_order_detail` (
  `id_supply_order_detail` int(11) UNSIGNED NOT NULL,
  `id_supply_order` int(11) UNSIGNED NOT NULL,
  `id_currency` int(11) UNSIGNED NOT NULL,
  `id_product` int(11) UNSIGNED NOT NULL,
  `id_product_attribute` int(11) UNSIGNED NOT NULL,
  `reference` varchar(64) NOT NULL,
  `supplier_reference` varchar(64) NOT NULL,
  `name` varchar(128) NOT NULL,
  `ean13` varchar(13) DEFAULT NULL,
  `isbn` varchar(32) DEFAULT NULL,
  `upc` varchar(12) DEFAULT NULL,
  `mpn` varchar(40) DEFAULT NULL,
  `exchange_rate` decimal(20,6) DEFAULT 0.000000,
  `unit_price_te` decimal(20,6) DEFAULT 0.000000,
  `quantity_expected` int(11) UNSIGNED NOT NULL,
  `quantity_received` int(11) UNSIGNED NOT NULL,
  `price_te` decimal(20,6) DEFAULT 0.000000,
  `discount_rate` decimal(20,6) DEFAULT 0.000000,
  `discount_value_te` decimal(20,6) DEFAULT 0.000000,
  `price_with_discount_te` decimal(20,6) DEFAULT 0.000000,
  `tax_rate` decimal(20,6) DEFAULT 0.000000,
  `tax_value` decimal(20,6) DEFAULT 0.000000,
  `price_ti` decimal(20,6) DEFAULT 0.000000,
  `tax_value_with_order_discount` decimal(20,6) DEFAULT 0.000000,
  `price_with_order_discount_te` decimal(20,6) DEFAULT 0.000000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_supply_order_history`
--

CREATE TABLE `ps_supply_order_history` (
  `id_supply_order_history` int(11) UNSIGNED NOT NULL,
  `id_supply_order` int(11) UNSIGNED NOT NULL,
  `id_employee` int(11) UNSIGNED NOT NULL,
  `employee_lastname` varchar(255) DEFAULT '',
  `employee_firstname` varchar(255) DEFAULT '',
  `id_state` int(11) UNSIGNED NOT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_supply_order_receipt_history`
--

CREATE TABLE `ps_supply_order_receipt_history` (
  `id_supply_order_receipt_history` int(11) UNSIGNED NOT NULL,
  `id_supply_order_detail` int(11) UNSIGNED NOT NULL,
  `id_employee` int(11) UNSIGNED NOT NULL,
  `employee_lastname` varchar(255) DEFAULT '',
  `employee_firstname` varchar(255) DEFAULT '',
  `id_supply_order_state` int(11) UNSIGNED NOT NULL,
  `quantity` int(11) UNSIGNED NOT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_supply_order_state`
--

CREATE TABLE `ps_supply_order_state` (
  `id_supply_order_state` int(11) UNSIGNED NOT NULL,
  `delivery_note` tinyint(1) NOT NULL DEFAULT 0,
  `editable` tinyint(1) NOT NULL DEFAULT 0,
  `receipt_state` tinyint(1) NOT NULL DEFAULT 0,
  `pending_receipt` tinyint(1) NOT NULL DEFAULT 0,
  `enclosed` tinyint(1) NOT NULL DEFAULT 0,
  `color` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_supply_order_state`
--

INSERT INTO `ps_supply_order_state` (`id_supply_order_state`, `delivery_note`, `editable`, `receipt_state`, `pending_receipt`, `enclosed`, `color`) VALUES
(1, 0, 1, 0, 0, 0, '#faab00'),
(2, 1, 0, 0, 0, 0, '#273cff'),
(3, 0, 0, 0, 1, 0, '#ff37f5'),
(4, 0, 0, 1, 1, 0, '#ff3e33'),
(5, 0, 0, 1, 0, 1, '#00d60c'),
(6, 0, 0, 0, 0, 1, '#666666');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_supply_order_state_lang`
--

CREATE TABLE `ps_supply_order_state_lang` (
  `id_supply_order_state` int(11) UNSIGNED NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_supply_order_state_lang`
--

INSERT INTO `ps_supply_order_state_lang` (`id_supply_order_state`, `id_lang`, `name`) VALUES
(1, 1, '1 - Tworzenie w toku'),
(2, 1, '2 - Zamówienie zostało zatwierdzone'),
(3, 1, '3 - W oczekiwaniu'),
(4, 1, '4 - Zamówienie zostało otrzymane w częściach'),
(5, 1, '5 - Otrzymano zamówienie'),
(6, 1, '6 - Zamówienie zostało anulowane');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_tab`
--

CREATE TABLE `ps_tab` (
  `id_tab` int(11) NOT NULL,
  `id_parent` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `module` varchar(64) DEFAULT NULL,
  `class_name` varchar(64) NOT NULL,
  `route_name` varchar(256) DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `hide_host_mode` tinyint(1) NOT NULL,
  `icon` varchar(32) DEFAULT NULL,
  `wording` varchar(255) DEFAULT NULL,
  `wording_domain` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_tab`
--

INSERT INTO `ps_tab` (`id_tab`, `id_parent`, `position`, `module`, `class_name`, `route_name`, `active`, `enabled`, `hide_host_mode`, `icon`, `wording`, `wording_domain`) VALUES
(1, 0, 0, NULL, 'AdminDashboard', NULL, 1, 1, 0, 'trending_up', 'Dashboard', 'Admin.Navigation.Menu'),
(2, 0, 1, NULL, 'SELL', NULL, 1, 1, 0, '', 'Sell', 'Admin.Navigation.Menu'),
(3, 2, 0, NULL, 'AdminParentOrders', NULL, 1, 1, 0, 'shopping_basket', 'Orders', 'Admin.Navigation.Menu'),
(4, 3, 0, NULL, 'AdminOrders', NULL, 1, 1, 0, '', 'Orders', 'Admin.Navigation.Menu'),
(5, 3, 1, NULL, 'AdminInvoices', NULL, 1, 1, 0, '', 'Invoices', 'Admin.Navigation.Menu'),
(6, 3, 2, NULL, 'AdminSlip', NULL, 1, 1, 0, '', 'Credit Slips', 'Admin.Navigation.Menu'),
(7, 3, 3, NULL, 'AdminDeliverySlip', NULL, 1, 1, 0, '', 'Delivery Slips', 'Admin.Navigation.Menu'),
(8, 3, 4, NULL, 'AdminCarts', NULL, 1, 1, 0, '', 'Shopping Carts', 'Admin.Navigation.Menu'),
(9, 2, 1, NULL, 'AdminCatalog', NULL, 1, 1, 0, 'store', 'Catalog', 'Admin.Navigation.Menu'),
(10, 9, 0, NULL, 'AdminProducts', NULL, 1, 1, 0, '', 'Products', 'Admin.Navigation.Menu'),
(11, 9, 1, NULL, 'AdminCategories', NULL, 1, 1, 0, '', 'Categories', 'Admin.Navigation.Menu'),
(12, 9, 2, NULL, 'AdminTracking', NULL, 1, 1, 0, '', 'Monitoring', 'Admin.Navigation.Menu'),
(13, 9, 3, NULL, 'AdminParentAttributesGroups', NULL, 1, 1, 0, '', 'Attributes & Features', 'Admin.Navigation.Menu'),
(14, 13, 0, NULL, 'AdminAttributesGroups', NULL, 1, 1, 0, '', 'Attributes', 'Admin.Navigation.Menu'),
(15, 13, 1, NULL, 'AdminFeatures', NULL, 1, 1, 0, '', 'Features', 'Admin.Navigation.Menu'),
(16, 9, 4, NULL, 'AdminParentManufacturers', NULL, 1, 1, 0, '', 'Brands & Suppliers', 'Admin.Navigation.Menu'),
(17, 16, 0, NULL, 'AdminManufacturers', NULL, 1, 1, 0, '', 'Brands', 'Admin.Navigation.Menu'),
(18, 16, 1, NULL, 'AdminSuppliers', NULL, 1, 1, 0, '', 'Suppliers', 'Admin.Navigation.Menu'),
(19, 9, 5, NULL, 'AdminAttachments', NULL, 1, 1, 0, '', 'Files', 'Admin.Navigation.Menu'),
(20, 9, 6, NULL, 'AdminParentCartRules', NULL, 1, 1, 0, '', 'Discounts', 'Admin.Navigation.Menu'),
(21, 20, 0, NULL, 'AdminCartRules', NULL, 1, 1, 0, '', 'Cart Rules', 'Admin.Navigation.Menu'),
(22, 20, 1, NULL, 'AdminSpecificPriceRule', NULL, 1, 1, 0, '', 'Catalog Price Rules', 'Admin.Navigation.Menu'),
(23, 9, 7, NULL, 'AdminStockManagement', NULL, 1, 1, 0, '', 'Stock', 'Admin.Navigation.Menu'),
(24, 2, 2, NULL, 'AdminParentCustomer', NULL, 1, 1, 0, 'account_circle', 'Customers', 'Admin.Navigation.Menu'),
(25, 24, 0, NULL, 'AdminCustomers', NULL, 1, 1, 0, '', 'Customers', 'Admin.Navigation.Menu'),
(26, 24, 1, NULL, 'AdminAddresses', NULL, 1, 1, 0, '', 'Addresses', 'Admin.Navigation.Menu'),
(27, 24, 2, NULL, 'AdminOutstanding', NULL, 0, 1, 0, '', 'Outstanding', 'Admin.Navigation.Menu'),
(28, 2, 3, NULL, 'AdminParentCustomerThreads', NULL, 1, 1, 0, 'chat', 'Customer Service', 'Admin.Navigation.Menu'),
(29, 28, 0, NULL, 'AdminCustomerThreads', NULL, 1, 1, 0, '', 'Customer Service', 'Admin.Navigation.Menu'),
(30, 28, 1, NULL, 'AdminOrderMessage', NULL, 1, 1, 0, '', 'Order Messages', 'Admin.Navigation.Menu'),
(31, 28, 2, NULL, 'AdminReturn', NULL, 1, 1, 0, '', 'Merchandise Returns', 'Admin.Navigation.Menu'),
(32, 2, 4, '', 'AdminStats', '', 1, 1, 0, 'assessment', 'Stats', 'Admin.Navigation.Menu'),
(33, 2, 5, NULL, 'AdminStock', NULL, 1, 1, 0, 'store', '', ''),
(34, 33, 0, NULL, 'AdminWarehouses', NULL, 1, 1, 0, '', 'Warehouses', 'Admin.Navigation.Menu'),
(35, 33, 1, NULL, 'AdminParentStockManagement', NULL, 1, 1, 0, '', 'Stock Management', 'Admin.Navigation.Menu'),
(36, 35, 0, NULL, 'AdminStockManagement', NULL, 1, 1, 0, '', 'Stock Management', 'Admin.Navigation.Menu'),
(37, 36, 0, NULL, 'AdminStockMvt', NULL, 1, 1, 0, '', 'Stock Movement', 'Admin.Navigation.Menu'),
(38, 36, 1, NULL, 'AdminStockInstantState', NULL, 1, 1, 0, '', 'Instant Stock Status', 'Admin.Navigation.Menu'),
(39, 36, 2, NULL, 'AdminStockCover', NULL, 1, 1, 0, '', 'Stock Coverage', 'Admin.Navigation.Menu'),
(40, 33, 2, NULL, 'AdminSupplyOrders', NULL, 1, 1, 0, '', 'Supply orders', 'Admin.Navigation.Menu'),
(41, 33, 3, NULL, 'AdminStockConfiguration', NULL, 1, 1, 0, '', 'Configuration', 'Admin.Navigation.Menu'),
(42, 0, 2, NULL, 'IMPROVE', NULL, 1, 1, 0, '', 'Improve', 'Admin.Navigation.Menu'),
(43, 42, 0, NULL, 'AdminParentModulesSf', NULL, 1, 1, 0, 'extension', 'Modules', 'Admin.Navigation.Menu'),
(44, 43, 0, NULL, 'AdminModulesSf', NULL, 1, 1, 0, '', 'Module Manager', 'Admin.Navigation.Menu'),
(45, 44, 0, NULL, 'AdminModulesManage', NULL, 1, 1, 0, '', 'Modules', 'Admin.Navigation.Menu'),
(46, 44, 1, NULL, 'AdminModulesNotifications', NULL, 1, 1, 0, '', 'Alerts', 'Admin.Navigation.Menu'),
(47, 44, 2, NULL, 'AdminModulesUpdates', NULL, 1, 1, 0, '', 'Updates', 'Admin.Navigation.Menu'),
(48, 43, 1, NULL, 'AdminParentModulesCatalog', NULL, 1, 1, 0, '', 'Module Catalog', 'Admin.Navigation.Menu'),
(49, 48, 0, '', 'AdminModulesCatalog', '', 0, 1, 0, '', 'Module Catalog', 'Admin.Navigation.Menu'),
(50, 48, 1, '', 'AdminAddonsCatalog', '', 0, 1, 0, '', 'Module Selections', 'Admin.Navigation.Menu'),
(51, 43, 2, NULL, 'AdminModules', NULL, 0, 1, 0, '', '', ''),
(52, 42, 1, NULL, 'AdminParentThemes', NULL, 1, 1, 0, 'desktop_mac', 'Design', 'Admin.Navigation.Menu'),
(53, 130, 1, '', 'AdminThemes', '', 1, 1, 0, '', 'Theme & Logo', 'Admin.Navigation.Menu'),
(54, 52, 1, '', 'AdminThemesCatalog', '', 0, 1, 0, '', 'Theme Catalog', 'Admin.Navigation.Menu'),
(55, 52, 2, NULL, 'AdminParentMailTheme', NULL, 1, 1, 0, '', 'Email Theme', 'Admin.Navigation.Menu'),
(56, 55, 0, NULL, 'AdminMailTheme', NULL, 1, 1, 0, '', 'Email Theme', 'Admin.Navigation.Menu'),
(57, 52, 3, NULL, 'AdminCmsContent', NULL, 1, 1, 0, '', 'Pages', 'Admin.Navigation.Menu'),
(58, 52, 4, NULL, 'AdminModulesPositions', NULL, 1, 1, 0, '', 'Positions', 'Admin.Navigation.Menu'),
(59, 52, 5, NULL, 'AdminImages', NULL, 1, 1, 0, '', 'Image Settings', 'Admin.Navigation.Menu'),
(60, 42, 2, NULL, 'AdminParentShipping', NULL, 1, 1, 0, 'local_shipping', 'Shipping', 'Admin.Navigation.Menu'),
(61, 60, 0, NULL, 'AdminCarriers', NULL, 1, 1, 0, '', 'Carriers', 'Admin.Navigation.Menu'),
(62, 60, 1, NULL, 'AdminShipping', NULL, 1, 1, 0, '', 'Preferences', 'Admin.Navigation.Menu'),
(63, 42, 3, NULL, 'AdminParentPayment', NULL, 1, 1, 0, 'payment', 'Payment', 'Admin.Navigation.Menu'),
(64, 63, 0, NULL, 'AdminPayment', NULL, 1, 1, 0, '', 'Payment Methods', 'Admin.Navigation.Menu'),
(65, 63, 1, NULL, 'AdminPaymentPreferences', NULL, 1, 1, 0, '', 'Preferences', 'Admin.Navigation.Menu'),
(66, 42, 4, NULL, 'AdminInternational', NULL, 1, 1, 0, 'language', 'International', 'Admin.Navigation.Menu'),
(67, 66, 0, NULL, 'AdminParentLocalization', NULL, 1, 1, 0, '', 'Localization', 'Admin.Navigation.Menu'),
(68, 67, 0, NULL, 'AdminLocalization', NULL, 1, 1, 0, '', 'Localization', 'Admin.Navigation.Menu'),
(69, 67, 1, NULL, 'AdminLanguages', NULL, 1, 1, 0, '', 'Languages', 'Admin.Navigation.Menu'),
(70, 67, 2, NULL, 'AdminCurrencies', NULL, 1, 1, 0, '', 'Currencies', 'Admin.Navigation.Menu'),
(71, 67, 3, NULL, 'AdminGeolocation', NULL, 1, 1, 0, '', 'Geolocation', 'Admin.Navigation.Menu'),
(72, 66, 1, NULL, 'AdminParentCountries', NULL, 1, 1, 0, '', 'Locations', 'Admin.Navigation.Menu'),
(73, 72, 0, NULL, 'AdminZones', NULL, 1, 1, 0, '', 'Zones', 'Admin.Navigation.Menu'),
(74, 72, 1, NULL, 'AdminCountries', NULL, 1, 1, 0, '', 'Countries', 'Admin.Navigation.Menu'),
(75, 72, 2, NULL, 'AdminStates', NULL, 1, 1, 0, '', 'States', 'Admin.Navigation.Menu'),
(76, 66, 2, NULL, 'AdminParentTaxes', NULL, 1, 1, 0, '', 'Taxes', 'Admin.Navigation.Menu'),
(77, 76, 0, NULL, 'AdminTaxes', NULL, 1, 1, 0, '', 'Taxes', 'Admin.Navigation.Menu'),
(78, 76, 1, NULL, 'AdminTaxRulesGroup', NULL, 1, 1, 0, '', 'Tax Rules', 'Admin.Navigation.Menu'),
(79, 66, 3, NULL, 'AdminTranslations', NULL, 1, 1, 0, '', 'Translations', 'Admin.Navigation.Menu'),
(80, 0, 3, NULL, 'CONFIGURE', NULL, 1, 1, 0, '', 'Configure', 'Admin.Navigation.Menu'),
(81, 80, 0, NULL, 'ShopParameters', NULL, 1, 1, 0, 'settings', 'Shop Parameters', 'Admin.Navigation.Menu'),
(82, 81, 0, NULL, 'AdminParentPreferences', NULL, 1, 1, 0, '', 'General', 'Admin.Navigation.Menu'),
(83, 82, 0, NULL, 'AdminPreferences', NULL, 1, 1, 0, '', 'General', 'Admin.Navigation.Menu'),
(84, 82, 1, NULL, 'AdminMaintenance', NULL, 1, 1, 0, '', 'Maintenance', 'Admin.Navigation.Menu'),
(85, 81, 1, NULL, 'AdminParentOrderPreferences', NULL, 1, 1, 0, '', 'Order Settings', 'Admin.Navigation.Menu'),
(86, 85, 0, NULL, 'AdminOrderPreferences', NULL, 1, 1, 0, '', 'Order Settings', 'Admin.Navigation.Menu'),
(87, 85, 1, NULL, 'AdminStatuses', NULL, 1, 1, 0, '', 'Statuses', 'Admin.Navigation.Menu'),
(88, 81, 2, NULL, 'AdminPPreferences', NULL, 1, 1, 0, '', 'Product Settings', 'Admin.Navigation.Menu'),
(89, 81, 3, NULL, 'AdminParentCustomerPreferences', NULL, 1, 1, 0, '', 'Customer Settings', 'Admin.Navigation.Menu'),
(90, 89, 0, NULL, 'AdminCustomerPreferences', NULL, 1, 1, 0, '', 'Customer Settings', 'Admin.Navigation.Menu'),
(91, 89, 1, NULL, 'AdminGroups', NULL, 1, 1, 0, '', 'Groups', 'Admin.Navigation.Menu'),
(92, 89, 2, NULL, 'AdminGenders', NULL, 1, 1, 0, '', 'Titles', 'Admin.Navigation.Menu'),
(93, 81, 4, NULL, 'AdminParentStores', NULL, 1, 1, 0, '', 'Contact', 'Admin.Navigation.Menu'),
(94, 93, 0, NULL, 'AdminContacts', NULL, 1, 1, 0, '', 'Contacts', 'Admin.Navigation.Menu'),
(95, 93, 1, NULL, 'AdminStores', NULL, 1, 1, 0, '', 'Stores', 'Admin.Navigation.Menu'),
(96, 81, 5, NULL, 'AdminParentMeta', NULL, 1, 1, 0, '', 'Traffic & SEO', 'Admin.Navigation.Menu'),
(97, 96, 0, NULL, 'AdminMeta', NULL, 1, 1, 0, '', 'SEO & URLs', 'Admin.Navigation.Menu'),
(98, 96, 1, NULL, 'AdminSearchEngines', NULL, 1, 1, 0, '', 'Search Engines', 'Admin.Navigation.Menu'),
(99, 96, 2, NULL, 'AdminReferrers', NULL, 1, 1, 0, '', 'Referrers', 'Admin.Navigation.Menu'),
(100, 81, 6, NULL, 'AdminParentSearchConf', NULL, 1, 1, 0, '', 'Search', 'Admin.Navigation.Menu'),
(101, 100, 0, NULL, 'AdminSearchConf', NULL, 1, 1, 0, '', 'Search', 'Admin.Navigation.Menu'),
(102, 100, 1, NULL, 'AdminTags', NULL, 1, 1, 0, '', 'Tags', 'Admin.Navigation.Menu'),
(103, 80, 1, NULL, 'AdminAdvancedParameters', NULL, 1, 1, 0, 'settings_applications', 'Advanced Parameters', 'Admin.Navigation.Menu'),
(104, 103, 0, NULL, 'AdminInformation', NULL, 1, 1, 0, '', 'Information', 'Admin.Navigation.Menu'),
(105, 103, 1, NULL, 'AdminPerformance', NULL, 1, 1, 0, '', 'Performance', 'Admin.Navigation.Menu'),
(106, 103, 2, NULL, 'AdminAdminPreferences', NULL, 1, 1, 0, '', 'Administration', 'Admin.Navigation.Menu'),
(107, 103, 3, NULL, 'AdminEmails', NULL, 1, 1, 0, '', 'E-mail', 'Admin.Navigation.Menu'),
(108, 103, 4, NULL, 'AdminImport', NULL, 1, 1, 0, '', 'Import', 'Admin.Navigation.Menu'),
(109, 103, 5, NULL, 'AdminParentEmployees', NULL, 1, 1, 0, '', 'Team', 'Admin.Navigation.Menu'),
(110, 109, 0, NULL, 'AdminEmployees', NULL, 1, 1, 0, '', 'Employees', 'Admin.Navigation.Menu'),
(111, 109, 1, NULL, 'AdminProfiles', NULL, 1, 1, 0, '', 'Profiles', 'Admin.Navigation.Menu'),
(112, 109, 2, NULL, 'AdminAccess', NULL, 1, 1, 0, '', 'Permissions', 'Admin.Navigation.Menu'),
(113, 103, 6, NULL, 'AdminParentRequestSql', NULL, 1, 1, 0, '', 'Database', 'Admin.Navigation.Menu'),
(114, 113, 0, NULL, 'AdminRequestSql', NULL, 1, 1, 0, '', 'SQL Manager', 'Admin.Navigation.Menu'),
(115, 113, 1, NULL, 'AdminBackup', NULL, 1, 1, 0, '', 'DB Backup', 'Admin.Navigation.Menu'),
(116, 103, 7, NULL, 'AdminLogs', NULL, 1, 1, 0, '', 'Logs', 'Admin.Navigation.Menu'),
(117, 103, 8, NULL, 'AdminWebservice', NULL, 1, 1, 0, '', 'Webservice', 'Admin.Navigation.Menu'),
(118, 103, 9, NULL, 'AdminShopGroup', NULL, 0, 1, 0, '', 'Multistore', 'Admin.Navigation.Menu'),
(119, 103, 10, NULL, 'AdminShopUrl', NULL, 0, 1, 0, '', 'Multistore', 'Admin.Navigation.Menu'),
(120, 103, 11, NULL, 'AdminFeatureFlag', NULL, 1, 1, 0, '', 'Experimental Features', 'Admin.Navigation.Menu'),
(121, -1, 0, NULL, 'AdminQuickAccesses', NULL, 1, 1, 0, '', 'Quick Access', 'Admin.Navigation.Menu'),
(122, 0, 4, NULL, 'DEFAULT', NULL, 1, 1, 0, '', 'More', 'Admin.Navigation.Menu'),
(123, -1, 1, NULL, 'AdminPatterns', NULL, 1, 1, 0, '', '', ''),
(124, 43, 3, 'blockwishlist', 'WishlistConfigurationAdminParentController', '', 0, 1, 0, '', NULL, NULL),
(125, 124, 1, 'blockwishlist', 'WishlistConfigurationAdminController', '', 1, 1, 0, '', NULL, NULL),
(126, 124, 2, 'blockwishlist', 'WishlistStatisticsAdminController', '', 1, 1, 0, '', NULL, NULL),
(127, -1, 2, 'dashgoals', 'AdminDashgoals', '', 1, 1, 0, '', NULL, NULL),
(128, -1, 3, 'ps_faviconnotificationbo', 'AdminConfigureFaviconBo', '', 1, 1, 0, '', NULL, NULL),
(129, 52, 6, 'ps_linklist', 'AdminLinkWidget', 'admin_link_block_list', 1, 1, 0, '', 'Link List', 'Modules.Linklist.Admin'),
(130, 52, 0, '', 'AdminThemesParent', '', 1, 1, 0, '', 'Theme & Logo', 'Admin.Navigation.Menu'),
(131, 130, 2, 'ps_themecusto', 'AdminPsThemeCustoConfiguration', '', 1, 1, 0, '', NULL, NULL),
(132, 130, 3, 'ps_themecusto', 'AdminPsThemeCustoAdvanced', '', 1, 1, 0, '', NULL, NULL),
(133, 0, 5, 'welcome', 'AdminWelcome', '', 1, 1, 0, '', NULL, NULL),
(134, 81, 7, 'gamification', 'AdminGamification', '', 1, 1, 0, '', NULL, NULL),
(135, -1, 4, 'psgdpr', 'AdminAjaxPsgdpr', '', 1, 1, 0, '', NULL, NULL),
(136, -1, 5, 'psgdpr', 'AdminDownloadInvoicesPsgdpr', '', 1, 1, 0, '', NULL, NULL),
(137, 48, 0, 'ps_mbo', 'AdminPsMboModule', '', 1, 1, 0, '', NULL, NULL),
(138, 48, 1, 'ps_mbo', 'AdminPsMboAddons', '', 1, 1, 0, '', NULL, NULL),
(139, -1, 0, 'ps_mbo', 'AdminPsMboRecommended', '', 1, 1, 0, '', NULL, NULL),
(140, 52, 1, 'ps_mbo', 'AdminPsMboTheme', '', 1, 1, 0, '', NULL, NULL),
(141, -1, 6, 'ps_buybuttonlite', 'AdminAjaxPs_buybuttonlite', '', 1, 1, 0, '', NULL, NULL),
(142, -1, 7, 'ps_checkout', 'AdminAjaxPrestashopCheckout', '', 1, 1, 0, '', NULL, NULL),
(143, -1, 8, 'ps_checkout', 'AdminPaypalOnboardingPrestashopCheckout', '', 1, 1, 0, '', NULL, NULL),
(144, 32, 1, 'ps_metrics', 'AdminMetricsLegacyStatsController', '', 1, 1, 0, '', NULL, NULL),
(145, 32, 2, 'ps_metrics', 'AdminMetricsController', '', 1, 1, 0, '', NULL, NULL),
(146, 42, 5, '', 'Marketing', '', 1, 1, 0, 'campaign', NULL, NULL),
(147, 146, 1, 'ps_facebook', 'AdminPsfacebookModule', '', 1, 1, 0, '', NULL, NULL),
(148, -1, 9, 'ps_facebook', 'AdminAjaxPsfacebook', '', 1, 1, 0, '', NULL, NULL),
(149, 146, 2, 'psxmarketingwithgoogle', 'AdminPsxMktgWithGoogleModule', '', 1, 1, 0, '', NULL, NULL),
(150, -1, 10, 'psxmarketingwithgoogle', 'AdminAjaxPsxMktgWithGoogle', '', 1, 1, 0, '', NULL, NULL),
(151, 0, 6, 'blockreassurance', 'AdminBlockListing', '', 0, 1, 0, '', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_tab_advice`
--

CREATE TABLE `ps_tab_advice` (
  `id_tab` int(11) NOT NULL,
  `id_advice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_tab_lang`
--

CREATE TABLE `ps_tab_lang` (
  `id_tab` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `name` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_tab_lang`
--

INSERT INTO `ps_tab_lang` (`id_tab`, `id_lang`, `name`) VALUES
(1, 1, 'Pulpit'),
(2, 1, 'Sprzedaż'),
(3, 1, 'Zamówienia'),
(4, 1, 'Zamówienia'),
(5, 1, 'Faktury'),
(6, 1, 'Druki kredytowe'),
(7, 1, 'Druk wysyłki'),
(8, 1, 'Koszyki zakupowe'),
(9, 1, 'Katalog'),
(10, 1, 'Produkty'),
(11, 1, 'Kategorie'),
(12, 1, 'Monitorowanie'),
(13, 1, 'Atrybuty & Cechy'),
(14, 1, 'Atrybuty'),
(15, 1, 'Funkcje'),
(16, 1, 'Marki & Dostawcy'),
(17, 1, 'Marki'),
(18, 1, 'Dostawcy'),
(19, 1, 'Pliki'),
(20, 1, 'Rabaty'),
(21, 1, 'Kody rabatowe'),
(22, 1, 'Reguły cenowe katalogu'),
(23, 1, 'Magazyn'),
(24, 1, 'Klienci'),
(25, 1, 'Klienci'),
(26, 1, 'Adresy'),
(27, 1, 'Saldo'),
(28, 1, 'Obsługa klienta'),
(29, 1, 'Obsługa klienta'),
(30, 1, 'Wiadomości zamówienia'),
(31, 1, 'Zwroty produktów'),
(32, 1, 'Statystyki'),
(34, 1, 'Magazyny'),
(35, 1, 'Zarządzanie magazynem'),
(37, 1, 'Ruch magazynowy'),
(38, 1, 'Stany magazynowe'),
(39, 1, 'Aktualne pokrycie stanu'),
(40, 1, 'Dostawa zamówień'),
(41, 1, 'Konfiguracja'),
(42, 1, 'Ulepszenia'),
(43, 1, 'Moduły'),
(44, 1, 'Menedżer modułów'),
(45, 1, 'Moduły'),
(46, 1, 'Powiadomienia'),
(47, 1, 'Aktualizacje'),
(48, 1, 'Katalog'),
(49, 1, 'Katalog'),
(50, 1, 'Module Selections'),
(52, 1, 'Wygląd'),
(53, 1, 'Szablony'),
(54, 1, 'Katalog'),
(55, 1, 'Szablon maila'),
(56, 1, 'Szablon maila'),
(57, 1, 'Strony'),
(58, 1, 'Pozycje'),
(59, 1, 'Zdjęcia'),
(60, 1, 'Wysyłka'),
(61, 1, 'Przewoźnicy'),
(62, 1, 'Preferencje'),
(63, 1, 'Płatność'),
(64, 1, 'Płatności'),
(65, 1, 'Preferencje'),
(66, 1, 'Międzynarodowy'),
(67, 1, 'Lokalizacja'),
(68, 1, 'Lokalizacja'),
(69, 1, 'Języki'),
(70, 1, 'Waluty'),
(71, 1, 'Geolokalizacja'),
(72, 1, 'Położenie'),
(73, 1, 'Strefy'),
(74, 1, 'Kraje'),
(75, 1, 'Województwa lub regiony'),
(76, 1, 'Podatki'),
(77, 1, 'Podatki'),
(78, 1, 'Reguły podatków'),
(79, 1, 'Tłumaczenia'),
(80, 1, 'Konfiguruj'),
(81, 1, 'Preferencje'),
(82, 1, 'Ogólny'),
(83, 1, 'Ogólny'),
(84, 1, 'Przerwa techniczna'),
(85, 1, 'Zamówienia'),
(86, 1, 'Zamówienia'),
(87, 1, 'Statusy'),
(88, 1, 'Produkty'),
(89, 1, 'Klienci'),
(90, 1, 'Klienci'),
(91, 1, 'Grupy'),
(92, 1, 'Tytuły'),
(93, 1, 'Kontakt'),
(94, 1, 'Kontakty'),
(95, 1, 'Sklepy'),
(96, 1, 'Ruch'),
(97, 1, 'SEO & URL'),
(98, 1, 'Wyszukiwarki'),
(99, 1, 'Polecający'),
(100, 1, 'Szukaj'),
(101, 1, 'Szukaj'),
(102, 1, 'Tagi'),
(103, 1, 'Zaawansowane'),
(104, 1, 'Informacja'),
(105, 1, 'Wydajność'),
(106, 1, 'Administracja'),
(107, 1, 'Adres e-mail'),
(108, 1, 'Importuj'),
(109, 1, 'Zespół'),
(110, 1, 'Pracownicy'),
(111, 1, 'Profile'),
(112, 1, 'Uprawnienia'),
(113, 1, 'Baza danych'),
(114, 1, 'Menadżer SQL'),
(115, 1, 'Kopia zapasowa DB'),
(116, 1, 'Logi'),
(117, 1, 'API'),
(118, 1, 'Multisklep'),
(119, 1, 'Multisklep'),
(120, 1, 'Funkcje eksperymentalne'),
(121, 1, 'Szybki dostęp'),
(122, 1, 'Więcej'),
(124, 1, 'Wishlist Module'),
(125, 1, 'Konfiguracja'),
(126, 1, 'Statistics'),
(127, 1, 'Dashgoals'),
(128, 1, 'Pokaż powiadomienia o nowych zamówieniach'),
(129, 1, 'Lista linków'),
(130, 1, 'Szablony'),
(131, 1, 'Pages Configuration'),
(132, 1, 'Advanced Customization'),
(133, 1, 'Welcome'),
(134, 1, 'Merchant Expertise'),
(135, 1, 'Oficjalna zgodność z RODO'),
(136, 1, 'Oficjalna zgodność z RODO'),
(137, 1, 'Katalog'),
(138, 1, 'Module Selections'),
(139, 1, 'Module recommended'),
(140, 1, 'Katalog'),
(141, 1, 'ps_buybuttonlite'),
(142, 1, 'PrestaShop Checkout'),
(143, 1, 'PrestaShop Checkout'),
(144, 1, 'Statystyki'),
(145, 1, 'PrestaShop Metrics'),
(146, 1, 'Marketing'),
(147, 1, 'Facebook'),
(148, 1, 'ps_facebook'),
(149, 1, 'Google'),
(150, 1, 'psxmarketingwithgoogle'),
(151, 1, 'AdminBlockListing');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_tab_module_preference`
--

CREATE TABLE `ps_tab_module_preference` (
  `id_tab_module_preference` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `id_tab` int(11) NOT NULL,
  `module` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_tag`
--

CREATE TABLE `ps_tag` (
  `id_tag` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_tag_count`
--

CREATE TABLE `ps_tag_count` (
  `id_group` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_tag` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_lang` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `id_shop` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `counter` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_tax`
--

CREATE TABLE `ps_tax` (
  `id_tax` int(10) UNSIGNED NOT NULL,
  `rate` decimal(10,3) NOT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_tax`
--

INSERT INTO `ps_tax` (`id_tax`, `rate`, `active`, `deleted`) VALUES
(1, '23.000', 1, 0),
(2, '8.000', 1, 0),
(3, '5.000', 1, 0),
(4, '0.000', 1, 0),
(5, '20.000', 1, 0),
(6, '21.000', 1, 0),
(7, '20.000', 1, 0),
(8, '19.000', 1, 0),
(9, '21.000', 1, 0),
(10, '19.000', 1, 0),
(11, '25.000', 1, 0),
(12, '20.000', 1, 0),
(13, '21.000', 1, 0),
(14, '24.000', 1, 0),
(15, '20.000', 1, 0),
(16, '20.000', 1, 0),
(17, '24.000', 1, 0),
(18, '25.000', 1, 0),
(19, '27.000', 1, 0),
(20, '23.000', 1, 0),
(21, '22.000', 1, 0),
(22, '21.000', 1, 0),
(23, '17.000', 1, 0),
(24, '21.000', 1, 0),
(25, '18.000', 1, 0),
(26, '21.000', 1, 0),
(27, '23.000', 1, 0),
(28, '19.000', 1, 0),
(29, '25.000', 1, 0),
(30, '22.000', 1, 0),
(31, '20.000', 1, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_tax_lang`
--

CREATE TABLE `ps_tax_lang` (
  `id_tax` int(10) UNSIGNED NOT NULL,
  `id_lang` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_tax_lang`
--

INSERT INTO `ps_tax_lang` (`id_tax`, `id_lang`, `name`) VALUES
(1, 1, 'PTU PL 23%'),
(2, 1, 'PTU PL 8%'),
(3, 1, 'PTU PL 5%'),
(4, 1, 'PTU PL 0'),
(5, 1, 'USt. AT 20%'),
(6, 1, 'TVA BE 21%'),
(7, 1, 'ДДС BG 20%'),
(8, 1, 'ΦΠΑ CY 19%'),
(9, 1, 'DPH CZ 21%'),
(10, 1, 'MwSt. DE 19%'),
(11, 1, 'moms DK 25%'),
(12, 1, 'km EE 20%'),
(13, 1, 'IVA ES 21%'),
(14, 1, 'ALV FI 24%'),
(15, 1, 'TVA FR 20%'),
(16, 1, 'VAT UK 20%'),
(17, 1, 'ΦΠΑ GR 24%'),
(18, 1, 'Croatia PDV 25%'),
(19, 1, 'ÁFA HU 27%'),
(20, 1, 'VAT IE 23%'),
(21, 1, 'IVA IT 22%'),
(22, 1, 'PVM LT 21%'),
(23, 1, 'TVA LU 17%'),
(24, 1, 'PVN LV 21%'),
(25, 1, 'VAT MT 18%'),
(26, 1, 'BTW NL 21%'),
(27, 1, 'IVA PT 23%'),
(28, 1, 'TVA RO 19%'),
(29, 1, 'Moms SE 25%'),
(30, 1, 'DDV SI 22%'),
(31, 1, 'DPH SK 20%');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_tax_rule`
--

CREATE TABLE `ps_tax_rule` (
  `id_tax_rule` int(11) NOT NULL,
  `id_tax_rules_group` int(11) NOT NULL,
  `id_country` int(11) NOT NULL,
  `id_state` int(11) NOT NULL,
  `zipcode_from` varchar(12) NOT NULL,
  `zipcode_to` varchar(12) NOT NULL,
  `id_tax` int(11) NOT NULL,
  `behavior` int(11) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_tax_rule`
--

INSERT INTO `ps_tax_rule` (`id_tax_rule`, `id_tax_rules_group`, `id_country`, `id_state`, `zipcode_from`, `zipcode_to`, `id_tax`, `behavior`, `description`) VALUES
(1, 1, 3, 0, '0', '0', 1, 0, ''),
(2, 1, 233, 0, '0', '0', 1, 0, ''),
(3, 1, 16, 0, '0', '0', 1, 0, ''),
(4, 1, 20, 0, '0', '0', 1, 0, ''),
(5, 1, 1, 0, '0', '0', 1, 0, ''),
(6, 1, 86, 0, '0', '0', 1, 0, ''),
(7, 1, 9, 0, '0', '0', 1, 0, ''),
(8, 1, 74, 0, '0', '0', 1, 0, ''),
(9, 1, 6, 0, '0', '0', 1, 0, ''),
(10, 1, 8, 0, '0', '0', 1, 0, ''),
(11, 1, 26, 0, '0', '0', 1, 0, ''),
(12, 1, 10, 0, '0', '0', 1, 0, ''),
(13, 1, 76, 0, '0', '0', 1, 0, ''),
(14, 1, 124, 0, '0', '0', 1, 0, ''),
(15, 1, 130, 0, '0', '0', 1, 0, ''),
(16, 1, 12, 0, '0', '0', 1, 0, ''),
(17, 1, 142, 0, '0', '0', 1, 0, ''),
(18, 1, 138, 0, '0', '0', 1, 0, ''),
(19, 1, 13, 0, '0', '0', 1, 0, ''),
(20, 1, 2, 0, '0', '0', 1, 0, ''),
(21, 1, 14, 0, '0', '0', 1, 0, ''),
(22, 1, 15, 0, '0', '0', 1, 0, ''),
(23, 1, 36, 0, '0', '0', 1, 0, ''),
(24, 1, 191, 0, '0', '0', 1, 0, ''),
(25, 1, 37, 0, '0', '0', 1, 0, ''),
(26, 1, 7, 0, '0', '0', 1, 0, ''),
(27, 1, 18, 0, '0', '0', 1, 0, ''),
(28, 1, 17, 0, '0', '0', 1, 0, ''),
(29, 2, 3, 0, '0', '0', 2, 0, ''),
(30, 2, 233, 0, '0', '0', 2, 0, ''),
(31, 2, 16, 0, '0', '0', 2, 0, ''),
(32, 2, 20, 0, '0', '0', 2, 0, ''),
(33, 2, 1, 0, '0', '0', 2, 0, ''),
(34, 2, 86, 0, '0', '0', 2, 0, ''),
(35, 2, 9, 0, '0', '0', 2, 0, ''),
(36, 2, 74, 0, '0', '0', 2, 0, ''),
(37, 2, 6, 0, '0', '0', 2, 0, ''),
(38, 2, 8, 0, '0', '0', 2, 0, ''),
(39, 2, 26, 0, '0', '0', 2, 0, ''),
(40, 2, 10, 0, '0', '0', 2, 0, ''),
(41, 2, 76, 0, '0', '0', 2, 0, ''),
(42, 2, 124, 0, '0', '0', 2, 0, ''),
(43, 2, 130, 0, '0', '0', 2, 0, ''),
(44, 2, 12, 0, '0', '0', 2, 0, ''),
(45, 2, 142, 0, '0', '0', 2, 0, ''),
(46, 2, 138, 0, '0', '0', 2, 0, ''),
(47, 2, 13, 0, '0', '0', 2, 0, ''),
(48, 2, 2, 0, '0', '0', 2, 0, ''),
(49, 2, 14, 0, '0', '0', 2, 0, ''),
(50, 2, 15, 0, '0', '0', 2, 0, ''),
(51, 2, 36, 0, '0', '0', 2, 0, ''),
(52, 2, 191, 0, '0', '0', 2, 0, ''),
(53, 2, 37, 0, '0', '0', 2, 0, ''),
(54, 2, 7, 0, '0', '0', 2, 0, ''),
(55, 2, 18, 0, '0', '0', 2, 0, ''),
(56, 2, 17, 0, '0', '0', 2, 0, ''),
(57, 3, 3, 0, '0', '0', 3, 0, ''),
(58, 3, 233, 0, '0', '0', 3, 0, ''),
(59, 3, 16, 0, '0', '0', 3, 0, ''),
(60, 3, 20, 0, '0', '0', 3, 0, ''),
(61, 3, 1, 0, '0', '0', 3, 0, ''),
(62, 3, 86, 0, '0', '0', 3, 0, ''),
(63, 3, 9, 0, '0', '0', 3, 0, ''),
(64, 3, 74, 0, '0', '0', 3, 0, ''),
(65, 3, 6, 0, '0', '0', 3, 0, ''),
(66, 3, 8, 0, '0', '0', 3, 0, ''),
(67, 3, 10, 0, '0', '0', 3, 0, ''),
(68, 3, 76, 0, '0', '0', 3, 0, ''),
(69, 3, 124, 0, '0', '0', 3, 0, ''),
(70, 3, 130, 0, '0', '0', 3, 0, ''),
(71, 3, 12, 0, '0', '0', 3, 0, ''),
(72, 3, 142, 0, '0', '0', 3, 0, ''),
(73, 3, 138, 0, '0', '0', 3, 0, ''),
(74, 3, 13, 0, '0', '0', 3, 0, ''),
(75, 3, 2, 0, '0', '0', 3, 0, ''),
(76, 3, 14, 0, '0', '0', 3, 0, ''),
(77, 3, 15, 0, '0', '0', 3, 0, ''),
(78, 3, 36, 0, '0', '0', 3, 0, ''),
(79, 3, 191, 0, '0', '0', 3, 0, ''),
(80, 3, 37, 0, '0', '0', 3, 0, ''),
(81, 3, 7, 0, '0', '0', 3, 0, ''),
(82, 3, 18, 0, '0', '0', 3, 0, ''),
(83, 3, 17, 0, '0', '0', 3, 0, ''),
(84, 4, 3, 0, '0', '0', 4, 0, ''),
(85, 4, 233, 0, '0', '0', 4, 0, ''),
(86, 4, 16, 0, '0', '0', 4, 0, ''),
(87, 4, 20, 0, '0', '0', 4, 0, ''),
(88, 4, 1, 0, '0', '0', 4, 0, ''),
(89, 4, 86, 0, '0', '0', 4, 0, ''),
(90, 4, 9, 0, '0', '0', 4, 0, ''),
(91, 4, 74, 0, '0', '0', 4, 0, ''),
(92, 4, 6, 0, '0', '0', 4, 0, ''),
(93, 4, 8, 0, '0', '0', 4, 0, ''),
(94, 4, 10, 0, '0', '0', 4, 0, ''),
(95, 4, 76, 0, '0', '0', 4, 0, ''),
(96, 4, 124, 0, '0', '0', 4, 0, ''),
(97, 4, 130, 0, '0', '0', 4, 0, ''),
(98, 4, 12, 0, '0', '0', 4, 0, ''),
(99, 4, 142, 0, '0', '0', 4, 0, ''),
(100, 4, 138, 0, '0', '0', 4, 0, ''),
(101, 4, 13, 0, '0', '0', 4, 0, ''),
(102, 4, 2, 0, '0', '0', 4, 0, ''),
(103, 4, 14, 0, '0', '0', 4, 0, ''),
(104, 4, 15, 0, '0', '0', 4, 0, ''),
(105, 4, 36, 0, '0', '0', 4, 0, ''),
(106, 4, 191, 0, '0', '0', 4, 0, ''),
(107, 4, 37, 0, '0', '0', 4, 0, ''),
(108, 4, 7, 0, '0', '0', 4, 0, ''),
(109, 4, 18, 0, '0', '0', 4, 0, ''),
(110, 4, 17, 0, '0', '0', 4, 0, ''),
(111, 5, 14, 0, '0', '0', 1, 0, ''),
(112, 5, 2, 0, '0', '0', 5, 0, ''),
(113, 5, 3, 0, '0', '0', 6, 0, ''),
(114, 5, 233, 0, '0', '0', 7, 0, ''),
(115, 5, 76, 0, '0', '0', 8, 0, ''),
(116, 5, 16, 0, '0', '0', 9, 0, ''),
(117, 5, 1, 0, '0', '0', 10, 0, ''),
(118, 5, 20, 0, '0', '0', 11, 0, ''),
(119, 5, 86, 0, '0', '0', 12, 0, ''),
(120, 5, 6, 0, '0', '0', 13, 0, ''),
(121, 5, 7, 0, '0', '0', 14, 0, ''),
(122, 5, 8, 0, '0', '0', 15, 0, ''),
(123, 5, 17, 0, '0', '0', 16, 0, ''),
(124, 5, 9, 0, '0', '0', 17, 0, ''),
(125, 5, 74, 0, '0', '0', 18, 0, ''),
(126, 5, 142, 0, '0', '0', 19, 0, ''),
(127, 5, 26, 0, '0', '0', 20, 0, ''),
(128, 5, 10, 0, '0', '0', 21, 0, ''),
(129, 5, 130, 0, '0', '0', 22, 0, ''),
(130, 5, 12, 0, '0', '0', 23, 0, ''),
(131, 5, 124, 0, '0', '0', 24, 0, ''),
(132, 5, 138, 0, '0', '0', 25, 0, ''),
(133, 5, 13, 0, '0', '0', 26, 0, ''),
(134, 5, 15, 0, '0', '0', 27, 0, ''),
(135, 5, 36, 0, '0', '0', 28, 0, ''),
(136, 5, 18, 0, '0', '0', 29, 0, ''),
(137, 5, 191, 0, '0', '0', 30, 0, ''),
(138, 5, 37, 0, '0', '0', 31, 0, '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_tax_rules_group`
--

CREATE TABLE `ps_tax_rules_group` (
  `id_tax_rules_group` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `active` int(11) NOT NULL,
  `deleted` tinyint(1) UNSIGNED NOT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_tax_rules_group`
--

INSERT INTO `ps_tax_rules_group` (`id_tax_rules_group`, `name`, `active`, `deleted`, `date_add`, `date_upd`) VALUES
(1, 'PL Standard Rate (23%)', 1, 0, '2022-12-08 17:56:31', '2022-12-08 17:56:31'),
(2, 'PL Reduced Rate (8%)', 1, 0, '2022-12-08 17:56:31', '2022-12-08 17:56:31'),
(3, 'PL Reduced Rate (5%)', 1, 0, '2022-12-08 17:56:31', '2022-12-08 17:56:31'),
(4, 'PL Exempted Rate (0%)', 1, 0, '2022-12-08 17:56:31', '2022-12-08 17:56:31'),
(5, 'EU VAT For Virtual Products', 1, 0, '2022-12-08 17:56:31', '2022-12-08 17:56:31');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_tax_rules_group_shop`
--

CREATE TABLE `ps_tax_rules_group_shop` (
  `id_tax_rules_group` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_tax_rules_group_shop`
--

INSERT INTO `ps_tax_rules_group_shop` (`id_tax_rules_group`, `id_shop`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_timezone`
--

CREATE TABLE `ps_timezone` (
  `id_timezone` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_timezone`
--

INSERT INTO `ps_timezone` (`id_timezone`, `name`) VALUES
(1, 'Africa/Abidjan'),
(2, 'Africa/Accra'),
(3, 'Africa/Addis_Ababa'),
(4, 'Africa/Algiers'),
(5, 'Africa/Asmara'),
(6, 'Africa/Asmera'),
(7, 'Africa/Bamako'),
(8, 'Africa/Bangui'),
(9, 'Africa/Banjul'),
(10, 'Africa/Bissau'),
(11, 'Africa/Blantyre'),
(12, 'Africa/Brazzaville'),
(13, 'Africa/Bujumbura'),
(14, 'Africa/Cairo'),
(15, 'Africa/Casablanca'),
(16, 'Africa/Ceuta'),
(17, 'Africa/Conakry'),
(18, 'Africa/Dakar'),
(19, 'Africa/Dar_es_Salaam'),
(20, 'Africa/Djibouti'),
(21, 'Africa/Douala'),
(22, 'Africa/El_Aaiun'),
(23, 'Africa/Freetown'),
(24, 'Africa/Gaborone'),
(25, 'Africa/Harare'),
(26, 'Africa/Johannesburg'),
(27, 'Africa/Kampala'),
(28, 'Africa/Khartoum'),
(29, 'Africa/Kigali'),
(30, 'Africa/Kinshasa'),
(31, 'Africa/Lagos'),
(32, 'Africa/Libreville'),
(33, 'Africa/Lome'),
(34, 'Africa/Luanda'),
(35, 'Africa/Lubumbashi'),
(36, 'Africa/Lusaka'),
(37, 'Africa/Malabo'),
(38, 'Africa/Maputo'),
(39, 'Africa/Maseru'),
(40, 'Africa/Mbabane'),
(41, 'Africa/Mogadishu'),
(42, 'Africa/Monrovia'),
(43, 'Africa/Nairobi'),
(44, 'Africa/Ndjamena'),
(45, 'Africa/Niamey'),
(46, 'Africa/Nouakchott'),
(47, 'Africa/Ouagadougou'),
(48, 'Africa/Porto-Novo'),
(49, 'Africa/Sao_Tome'),
(50, 'Africa/Timbuktu'),
(51, 'Africa/Tripoli'),
(52, 'Africa/Tunis'),
(53, 'Africa/Windhoek'),
(54, 'America/Adak'),
(55, 'America/Anchorage '),
(56, 'America/Anguilla'),
(57, 'America/Antigua'),
(58, 'America/Araguaina'),
(59, 'America/Argentina/Buenos_Aires'),
(60, 'America/Argentina/Catamarca'),
(61, 'America/Argentina/ComodRivadavia'),
(62, 'America/Argentina/Cordoba'),
(63, 'America/Argentina/Jujuy'),
(64, 'America/Argentina/La_Rioja'),
(65, 'America/Argentina/Mendoza'),
(66, 'America/Argentina/Rio_Gallegos'),
(67, 'America/Argentina/Salta'),
(68, 'America/Argentina/San_Juan'),
(69, 'America/Argentina/San_Luis'),
(70, 'America/Argentina/Tucuman'),
(71, 'America/Argentina/Ushuaia'),
(72, 'America/Aruba'),
(73, 'America/Asuncion'),
(74, 'America/Atikokan'),
(75, 'America/Atka'),
(76, 'America/Bahia'),
(77, 'America/Barbados'),
(78, 'America/Belem'),
(79, 'America/Belize'),
(80, 'America/Blanc-Sablon'),
(81, 'America/Boa_Vista'),
(82, 'America/Bogota'),
(83, 'America/Boise'),
(84, 'America/Buenos_Aires'),
(85, 'America/Cambridge_Bay'),
(86, 'America/Campo_Grande'),
(87, 'America/Cancun'),
(88, 'America/Caracas'),
(89, 'America/Catamarca'),
(90, 'America/Cayenne'),
(91, 'America/Cayman'),
(92, 'America/Chicago'),
(93, 'America/Chihuahua'),
(94, 'America/Coral_Harbour'),
(95, 'America/Cordoba'),
(96, 'America/Costa_Rica'),
(97, 'America/Cuiaba'),
(98, 'America/Curacao'),
(99, 'America/Danmarkshavn'),
(100, 'America/Dawson'),
(101, 'America/Dawson_Creek'),
(102, 'America/Denver'),
(103, 'America/Detroit'),
(104, 'America/Dominica'),
(105, 'America/Edmonton'),
(106, 'America/Eirunepe'),
(107, 'America/El_Salvador'),
(108, 'America/Ensenada'),
(109, 'America/Fort_Wayne'),
(110, 'America/Fortaleza'),
(111, 'America/Glace_Bay'),
(112, 'America/Godthab'),
(113, 'America/Goose_Bay'),
(114, 'America/Grand_Turk'),
(115, 'America/Grenada'),
(116, 'America/Guadeloupe'),
(117, 'America/Guatemala'),
(118, 'America/Guayaquil'),
(119, 'America/Guyana'),
(120, 'America/Halifax'),
(121, 'America/Havana'),
(122, 'America/Hermosillo'),
(123, 'America/Indiana/Indianapolis'),
(124, 'America/Indiana/Knox'),
(125, 'America/Indiana/Marengo'),
(126, 'America/Indiana/Petersburg'),
(127, 'America/Indiana/Tell_City'),
(128, 'America/Indiana/Vevay'),
(129, 'America/Indiana/Vincennes'),
(130, 'America/Indiana/Winamac'),
(131, 'America/Indianapolis'),
(132, 'America/Inuvik'),
(133, 'America/Iqaluit'),
(134, 'America/Jamaica'),
(135, 'America/Jujuy'),
(136, 'America/Juneau'),
(137, 'America/Kentucky/Louisville'),
(138, 'America/Kentucky/Monticello'),
(139, 'America/Knox_IN'),
(140, 'America/La_Paz'),
(141, 'America/Lima'),
(142, 'America/Los_Angeles'),
(143, 'America/Louisville'),
(144, 'America/Maceio'),
(145, 'America/Managua'),
(146, 'America/Manaus'),
(147, 'America/Marigot'),
(148, 'America/Martinique'),
(149, 'America/Mazatlan'),
(150, 'America/Mendoza'),
(151, 'America/Menominee'),
(152, 'America/Merida'),
(153, 'America/Mexico_City'),
(154, 'America/Miquelon'),
(155, 'America/Moncton'),
(156, 'America/Monterrey'),
(157, 'America/Montevideo'),
(158, 'America/Montreal'),
(159, 'America/Montserrat'),
(160, 'America/Nassau'),
(161, 'America/New_York'),
(162, 'America/Nipigon'),
(163, 'America/Nome'),
(164, 'America/Noronha'),
(165, 'America/North_Dakota/Center'),
(166, 'America/North_Dakota/New_Salem'),
(167, 'America/Panama'),
(168, 'America/Pangnirtung'),
(169, 'America/Paramaribo'),
(170, 'America/Phoenix'),
(171, 'America/Port-au-Prince'),
(172, 'America/Port_of_Spain'),
(173, 'America/Porto_Acre'),
(174, 'America/Porto_Velho'),
(175, 'America/Puerto_Rico'),
(176, 'America/Rainy_River'),
(177, 'America/Rankin_Inlet'),
(178, 'America/Recife'),
(179, 'America/Regina'),
(180, 'America/Resolute'),
(181, 'America/Rio_Branco'),
(182, 'America/Rosario'),
(183, 'America/Santarem'),
(184, 'America/Santiago'),
(185, 'America/Santo_Domingo'),
(186, 'America/Sao_Paulo'),
(187, 'America/Scoresbysund'),
(188, 'America/Shiprock'),
(189, 'America/St_Barthelemy'),
(190, 'America/St_Johns'),
(191, 'America/St_Kitts'),
(192, 'America/St_Lucia'),
(193, 'America/St_Thomas'),
(194, 'America/St_Vincent'),
(195, 'America/Swift_Current'),
(196, 'America/Tegucigalpa'),
(197, 'America/Thule'),
(198, 'America/Thunder_Bay'),
(199, 'America/Tijuana'),
(200, 'America/Toronto'),
(201, 'America/Tortola'),
(202, 'America/Vancouver'),
(203, 'America/Virgin'),
(204, 'America/Whitehorse'),
(205, 'America/Winnipeg'),
(206, 'America/Yakutat'),
(207, 'America/Yellowknife'),
(208, 'Antarctica/Casey'),
(209, 'Antarctica/Davis'),
(210, 'Antarctica/DumontDUrville'),
(211, 'Antarctica/Mawson'),
(212, 'Antarctica/McMurdo'),
(213, 'Antarctica/Palmer'),
(214, 'Antarctica/Rothera'),
(215, 'Antarctica/South_Pole'),
(216, 'Antarctica/Syowa'),
(217, 'Antarctica/Vostok'),
(218, 'Arctic/Longyearbyen'),
(219, 'Asia/Aden'),
(220, 'Asia/Almaty'),
(221, 'Asia/Amman'),
(222, 'Asia/Anadyr'),
(223, 'Asia/Aqtau'),
(224, 'Asia/Aqtobe'),
(225, 'Asia/Ashgabat'),
(226, 'Asia/Ashkhabad'),
(227, 'Asia/Baghdad'),
(228, 'Asia/Bahrain'),
(229, 'Asia/Baku'),
(230, 'Asia/Bangkok'),
(231, 'Asia/Beirut'),
(232, 'Asia/Bishkek'),
(233, 'Asia/Brunei'),
(234, 'Asia/Calcutta'),
(235, 'Asia/Choibalsan'),
(236, 'Asia/Chongqing'),
(237, 'Asia/Chungking'),
(238, 'Asia/Colombo'),
(239, 'Asia/Dacca'),
(240, 'Asia/Damascus'),
(241, 'Asia/Dhaka'),
(242, 'Asia/Dili'),
(243, 'Asia/Dubai'),
(244, 'Asia/Dushanbe'),
(245, 'Asia/Gaza'),
(246, 'Asia/Harbin'),
(247, 'Asia/Ho_Chi_Minh'),
(248, 'Asia/Hong_Kong'),
(249, 'Asia/Hovd'),
(250, 'Asia/Irkutsk'),
(251, 'Asia/Istanbul'),
(252, 'Asia/Jakarta'),
(253, 'Asia/Jayapura'),
(254, 'Asia/Jerusalem'),
(255, 'Asia/Kabul'),
(256, 'Asia/Kamchatka'),
(257, 'Asia/Karachi'),
(258, 'Asia/Kashgar'),
(259, 'Asia/Kathmandu'),
(260, 'Asia/Katmandu'),
(261, 'Asia/Kolkata'),
(262, 'Asia/Krasnoyarsk'),
(263, 'Asia/Kuala_Lumpur'),
(264, 'Asia/Kuching'),
(265, 'Asia/Kuwait'),
(266, 'Asia/Macao'),
(267, 'Asia/Macau'),
(268, 'Asia/Magadan'),
(269, 'Asia/Makassar'),
(270, 'Asia/Manila'),
(271, 'Asia/Muscat'),
(272, 'Asia/Nicosia'),
(273, 'Asia/Novosibirsk'),
(274, 'Asia/Omsk'),
(275, 'Asia/Oral'),
(276, 'Asia/Phnom_Penh'),
(277, 'Asia/Pontianak'),
(278, 'Asia/Pyongyang'),
(279, 'Asia/Qatar'),
(280, 'Asia/Qyzylorda'),
(281, 'Asia/Rangoon'),
(282, 'Asia/Riyadh'),
(283, 'Asia/Saigon'),
(284, 'Asia/Sakhalin'),
(285, 'Asia/Samarkand'),
(286, 'Asia/Seoul'),
(287, 'Asia/Shanghai'),
(288, 'Asia/Singapore'),
(289, 'Asia/Taipei'),
(290, 'Asia/Tashkent'),
(291, 'Asia/Tbilisi'),
(292, 'Asia/Tehran'),
(293, 'Asia/Tel_Aviv'),
(294, 'Asia/Thimbu'),
(295, 'Asia/Thimphu'),
(296, 'Asia/Tokyo'),
(297, 'Asia/Ujung_Pandang'),
(298, 'Asia/Ulaanbaatar'),
(299, 'Asia/Ulan_Bator'),
(300, 'Asia/Urumqi'),
(301, 'Asia/Vientiane'),
(302, 'Asia/Vladivostok'),
(303, 'Asia/Yakutsk'),
(304, 'Asia/Yekaterinburg'),
(305, 'Asia/Yerevan'),
(306, 'Atlantic/Azores'),
(307, 'Atlantic/Bermuda'),
(308, 'Atlantic/Canary'),
(309, 'Atlantic/Cape_Verde'),
(310, 'Atlantic/Faeroe'),
(311, 'Atlantic/Faroe'),
(312, 'Atlantic/Jan_Mayen'),
(313, 'Atlantic/Madeira'),
(314, 'Atlantic/Reykjavik'),
(315, 'Atlantic/South_Georgia'),
(316, 'Atlantic/St_Helena'),
(317, 'Atlantic/Stanley'),
(318, 'Australia/ACT'),
(319, 'Australia/Adelaide'),
(320, 'Australia/Brisbane'),
(321, 'Australia/Broken_Hill'),
(322, 'Australia/Canberra'),
(323, 'Australia/Currie'),
(324, 'Australia/Darwin'),
(325, 'Australia/Eucla'),
(326, 'Australia/Hobart'),
(327, 'Australia/LHI'),
(328, 'Australia/Lindeman'),
(329, 'Australia/Lord_Howe'),
(330, 'Australia/Melbourne'),
(331, 'Australia/North'),
(332, 'Australia/NSW'),
(333, 'Australia/Perth'),
(334, 'Australia/Queensland'),
(335, 'Australia/South'),
(336, 'Australia/Sydney'),
(337, 'Australia/Tasmania'),
(338, 'Australia/Victoria'),
(339, 'Australia/West'),
(340, 'Australia/Yancowinna'),
(341, 'Europe/Amsterdam'),
(342, 'Europe/Andorra'),
(343, 'Europe/Athens'),
(344, 'Europe/Belfast'),
(345, 'Europe/Belgrade'),
(346, 'Europe/Berlin'),
(347, 'Europe/Bratislava'),
(348, 'Europe/Brussels'),
(349, 'Europe/Bucharest'),
(350, 'Europe/Budapest'),
(351, 'Europe/Chisinau'),
(352, 'Europe/Copenhagen'),
(353, 'Europe/Dublin'),
(354, 'Europe/Gibraltar'),
(355, 'Europe/Guernsey'),
(356, 'Europe/Helsinki'),
(357, 'Europe/Isle_of_Man'),
(358, 'Europe/Istanbul'),
(359, 'Europe/Jersey'),
(360, 'Europe/Kaliningrad'),
(361, 'Europe/Kiev'),
(362, 'Europe/Lisbon'),
(363, 'Europe/Ljubljana'),
(364, 'Europe/London'),
(365, 'Europe/Luxembourg'),
(366, 'Europe/Madrid'),
(367, 'Europe/Malta'),
(368, 'Europe/Mariehamn'),
(369, 'Europe/Minsk'),
(370, 'Europe/Monaco'),
(371, 'Europe/Moscow'),
(372, 'Europe/Nicosia'),
(373, 'Europe/Oslo'),
(374, 'Europe/Paris'),
(375, 'Europe/Podgorica'),
(376, 'Europe/Prague'),
(377, 'Europe/Riga'),
(378, 'Europe/Rome'),
(379, 'Europe/Samara'),
(380, 'Europe/San_Marino'),
(381, 'Europe/Sarajevo'),
(382, 'Europe/Simferopol'),
(383, 'Europe/Skopje'),
(384, 'Europe/Sofia'),
(385, 'Europe/Stockholm'),
(386, 'Europe/Tallinn'),
(387, 'Europe/Tirane'),
(388, 'Europe/Tiraspol'),
(389, 'Europe/Uzhgorod'),
(390, 'Europe/Vaduz'),
(391, 'Europe/Vatican'),
(392, 'Europe/Vienna'),
(393, 'Europe/Vilnius'),
(394, 'Europe/Volgograd'),
(395, 'Europe/Warsaw'),
(396, 'Europe/Zagreb'),
(397, 'Europe/Zaporozhye'),
(398, 'Europe/Zurich'),
(399, 'Indian/Antananarivo'),
(400, 'Indian/Chagos'),
(401, 'Indian/Christmas'),
(402, 'Indian/Cocos'),
(403, 'Indian/Comoro'),
(404, 'Indian/Kerguelen'),
(405, 'Indian/Mahe'),
(406, 'Indian/Maldives'),
(407, 'Indian/Mauritius'),
(408, 'Indian/Mayotte'),
(409, 'Indian/Reunion'),
(410, 'Pacific/Apia'),
(411, 'Pacific/Auckland'),
(412, 'Pacific/Chatham'),
(413, 'Pacific/Easter'),
(414, 'Pacific/Efate'),
(415, 'Pacific/Enderbury'),
(416, 'Pacific/Fakaofo'),
(417, 'Pacific/Fiji'),
(418, 'Pacific/Funafuti'),
(419, 'Pacific/Galapagos'),
(420, 'Pacific/Gambier'),
(421, 'Pacific/Guadalcanal'),
(422, 'Pacific/Guam'),
(423, 'Pacific/Honolulu'),
(424, 'Pacific/Johnston'),
(425, 'Pacific/Kiritimati'),
(426, 'Pacific/Kosrae'),
(427, 'Pacific/Kwajalein'),
(428, 'Pacific/Majuro'),
(429, 'Pacific/Marquesas'),
(430, 'Pacific/Midway'),
(431, 'Pacific/Nauru'),
(432, 'Pacific/Niue'),
(433, 'Pacific/Norfolk'),
(434, 'Pacific/Noumea'),
(435, 'Pacific/Pago_Pago'),
(436, 'Pacific/Palau'),
(437, 'Pacific/Pitcairn'),
(438, 'Pacific/Ponape'),
(439, 'Pacific/Port_Moresby'),
(440, 'Pacific/Rarotonga'),
(441, 'Pacific/Saipan'),
(442, 'Pacific/Samoa'),
(443, 'Pacific/Tahiti'),
(444, 'Pacific/Tarawa'),
(445, 'Pacific/Tongatapu'),
(446, 'Pacific/Truk'),
(447, 'Pacific/Wake'),
(448, 'Pacific/Wallis'),
(449, 'Pacific/Yap'),
(450, 'Brazil/Acre'),
(451, 'Brazil/DeNoronha'),
(452, 'Brazil/East'),
(453, 'Brazil/West'),
(454, 'Canada/Atlantic'),
(455, 'Canada/Central'),
(456, 'Canada/East-Saskatchewan'),
(457, 'Canada/Eastern'),
(458, 'Canada/Mountain'),
(459, 'Canada/Newfoundland'),
(460, 'Canada/Pacific'),
(461, 'Canada/Saskatchewan'),
(462, 'Canada/Yukon'),
(463, 'CET'),
(464, 'Chile/Continental'),
(465, 'Chile/EasterIsland'),
(466, 'CST6CDT'),
(467, 'Cuba'),
(468, 'EET'),
(469, 'Egypt'),
(470, 'Eire'),
(471, 'EST'),
(472, 'EST5EDT'),
(473, 'Etc/GMT'),
(474, 'Etc/GMT+0'),
(475, 'Etc/GMT+1'),
(476, 'Etc/GMT+10'),
(477, 'Etc/GMT+11'),
(478, 'Etc/GMT+12'),
(479, 'Etc/GMT+2'),
(480, 'Etc/GMT+3'),
(481, 'Etc/GMT+4'),
(482, 'Etc/GMT+5'),
(483, 'Etc/GMT+6'),
(484, 'Etc/GMT+7'),
(485, 'Etc/GMT+8'),
(486, 'Etc/GMT+9'),
(487, 'Etc/GMT-0'),
(488, 'Etc/GMT-1'),
(489, 'Etc/GMT-10'),
(490, 'Etc/GMT-11'),
(491, 'Etc/GMT-12'),
(492, 'Etc/GMT-13'),
(493, 'Etc/GMT-14'),
(494, 'Etc/GMT-2'),
(495, 'Etc/GMT-3'),
(496, 'Etc/GMT-4'),
(497, 'Etc/GMT-5'),
(498, 'Etc/GMT-6'),
(499, 'Etc/GMT-7'),
(500, 'Etc/GMT-8'),
(501, 'Etc/GMT-9'),
(502, 'Etc/GMT0'),
(503, 'Etc/Greenwich'),
(504, 'Etc/UCT'),
(505, 'Etc/Universal'),
(506, 'Etc/UTC'),
(507, 'Etc/Zulu'),
(508, 'Factory'),
(509, 'GB'),
(510, 'GB-Eire'),
(511, 'GMT'),
(512, 'GMT+0'),
(513, 'GMT-0'),
(514, 'GMT0'),
(515, 'Greenwich'),
(516, 'Hongkong'),
(517, 'HST'),
(518, 'Iceland'),
(519, 'Iran'),
(520, 'Israel'),
(521, 'Jamaica'),
(522, 'Japan'),
(523, 'Kwajalein'),
(524, 'Libya'),
(525, 'MET'),
(526, 'Mexico/BajaNorte'),
(527, 'Mexico/BajaSur'),
(528, 'Mexico/General'),
(529, 'MST'),
(530, 'MST7MDT'),
(531, 'Navajo'),
(532, 'NZ'),
(533, 'NZ-CHAT'),
(534, 'Poland'),
(535, 'Portugal'),
(536, 'PRC'),
(537, 'PST8PDT'),
(538, 'ROC'),
(539, 'ROK'),
(540, 'Singapore'),
(541, 'Turkey'),
(542, 'UCT'),
(543, 'Universal'),
(544, 'US/Alaska'),
(545, 'US/Aleutian'),
(546, 'US/Arizona'),
(547, 'US/Central'),
(548, 'US/East-Indiana'),
(549, 'US/Eastern'),
(550, 'US/Hawaii'),
(551, 'US/Indiana-Starke'),
(552, 'US/Michigan'),
(553, 'US/Mountain'),
(554, 'US/Pacific'),
(555, 'US/Pacific-New'),
(556, 'US/Samoa'),
(557, 'UTC'),
(558, 'W-SU'),
(559, 'WET'),
(560, 'Zulu');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_translation`
--

CREATE TABLE `ps_translation` (
  `id_translation` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `key` text CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `translation` text NOT NULL,
  `domain` varchar(80) NOT NULL,
  `theme` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `ps_translation`
--

INSERT INTO `ps_translation` (`id_translation`, `id_lang`, `key`, `translation`, `domain`, `theme`) VALUES
(1, 1, 'Your order has been changed', 'Twoje zamówienie zostało zmienione', 'EmailsSubject', NULL),
(2, 1, 'New return from order #%d - %s', 'Nowy zwrot z zamówienia: #%d - %s', 'EmailsSubject', NULL),
(3, 1, 'New order : #%d - %s', 'Nowe zamówienie: #%d - %s', 'EmailsSubject', NULL),
(4, 1, 'Product available', 'Produkt dostępny', 'EmailsSubject', NULL),
(5, 1, ': ', ':', 'ShopPdf', NULL),
(6, 1, 'Filter by:', 'Filtruj', 'AdminActions', NULL),
(7, 1, 'Go to maintenance page', '', 'AdminActions', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_warehouse`
--

CREATE TABLE `ps_warehouse` (
  `id_warehouse` int(11) UNSIGNED NOT NULL,
  `id_currency` int(11) UNSIGNED NOT NULL,
  `id_address` int(11) UNSIGNED NOT NULL,
  `id_employee` int(11) UNSIGNED NOT NULL,
  `reference` varchar(64) DEFAULT NULL,
  `name` varchar(45) NOT NULL,
  `management_type` enum('WA','FIFO','LIFO') NOT NULL DEFAULT 'WA',
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_warehouse_carrier`
--

CREATE TABLE `ps_warehouse_carrier` (
  `id_carrier` int(11) UNSIGNED NOT NULL,
  `id_warehouse` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_warehouse_product_location`
--

CREATE TABLE `ps_warehouse_product_location` (
  `id_warehouse_product_location` int(11) UNSIGNED NOT NULL,
  `id_product` int(11) UNSIGNED NOT NULL,
  `id_product_attribute` int(11) UNSIGNED NOT NULL,
  `id_warehouse` int(11) UNSIGNED NOT NULL,
  `location` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_warehouse_shop`
--

CREATE TABLE `ps_warehouse_shop` (
  `id_shop` int(11) UNSIGNED NOT NULL,
  `id_warehouse` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_webservice_account`
--

CREATE TABLE `ps_webservice_account` (
  `id_webservice_account` int(11) NOT NULL,
  `key` varchar(32) NOT NULL,
  `description` text DEFAULT NULL,
  `class_name` varchar(50) NOT NULL DEFAULT 'WebserviceRequest',
  `is_module` tinyint(2) NOT NULL DEFAULT 0,
  `module_name` varchar(50) DEFAULT NULL,
  `active` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_webservice_account`
--

INSERT INTO `ps_webservice_account` (`id_webservice_account`, `key`, `description`, `class_name`, `is_module`, `module_name`, `active`) VALUES
(1, 'VLNJ6H7Y4LURQUY2CUFH6M1NBFLKIMRH', '', 'WebserviceRequest', 0, NULL, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_webservice_account_shop`
--

CREATE TABLE `ps_webservice_account_shop` (
  `id_webservice_account` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_webservice_account_shop`
--

INSERT INTO `ps_webservice_account_shop` (`id_webservice_account`, `id_shop`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_webservice_permission`
--

CREATE TABLE `ps_webservice_permission` (
  `id_webservice_permission` int(11) NOT NULL,
  `resource` varchar(50) NOT NULL,
  `method` enum('GET','POST','PUT','DELETE','HEAD') NOT NULL,
  `id_webservice_account` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_webservice_permission`
--

INSERT INTO `ps_webservice_permission` (`id_webservice_permission`, `resource`, `method`, `id_webservice_account`) VALUES
(1, 'addresses', 'GET', 1),
(3, 'addresses', 'POST', 1),
(2, 'addresses', 'PUT', 1),
(4, 'addresses', 'DELETE', 1),
(5, 'addresses', 'HEAD', 1),
(6, 'attachments', 'GET', 1),
(8, 'attachments', 'POST', 1),
(7, 'attachments', 'PUT', 1),
(9, 'attachments', 'DELETE', 1),
(10, 'attachments', 'HEAD', 1),
(11, 'carriers', 'GET', 1),
(13, 'carriers', 'POST', 1),
(12, 'carriers', 'PUT', 1),
(14, 'carriers', 'DELETE', 1),
(15, 'carriers', 'HEAD', 1),
(21, 'carts', 'GET', 1),
(23, 'carts', 'POST', 1),
(22, 'carts', 'PUT', 1),
(24, 'carts', 'DELETE', 1),
(25, 'carts', 'HEAD', 1),
(16, 'cart_rules', 'GET', 1),
(18, 'cart_rules', 'POST', 1),
(17, 'cart_rules', 'PUT', 1),
(19, 'cart_rules', 'DELETE', 1),
(20, 'cart_rules', 'HEAD', 1),
(26, 'categories', 'GET', 1),
(28, 'categories', 'POST', 1),
(27, 'categories', 'PUT', 1),
(29, 'categories', 'DELETE', 1),
(30, 'categories', 'HEAD', 1),
(31, 'combinations', 'GET', 1),
(33, 'combinations', 'POST', 1),
(32, 'combinations', 'PUT', 1),
(34, 'combinations', 'DELETE', 1),
(35, 'combinations', 'HEAD', 1),
(36, 'configurations', 'GET', 1),
(38, 'configurations', 'POST', 1),
(37, 'configurations', 'PUT', 1),
(39, 'configurations', 'DELETE', 1),
(40, 'configurations', 'HEAD', 1),
(41, 'contacts', 'GET', 1),
(43, 'contacts', 'POST', 1),
(42, 'contacts', 'PUT', 1),
(44, 'contacts', 'DELETE', 1),
(45, 'contacts', 'HEAD', 1),
(46, 'content_management_system', 'GET', 1),
(48, 'content_management_system', 'POST', 1),
(47, 'content_management_system', 'PUT', 1),
(49, 'content_management_system', 'DELETE', 1),
(50, 'content_management_system', 'HEAD', 1),
(51, 'countries', 'GET', 1),
(53, 'countries', 'POST', 1),
(52, 'countries', 'PUT', 1),
(54, 'countries', 'DELETE', 1),
(55, 'countries', 'HEAD', 1),
(56, 'currencies', 'GET', 1),
(58, 'currencies', 'POST', 1),
(57, 'currencies', 'PUT', 1),
(59, 'currencies', 'DELETE', 1),
(60, 'currencies', 'HEAD', 1),
(71, 'customers', 'GET', 1),
(73, 'customers', 'POST', 1),
(72, 'customers', 'PUT', 1),
(74, 'customers', 'DELETE', 1),
(75, 'customers', 'HEAD', 1),
(61, 'customer_messages', 'GET', 1),
(63, 'customer_messages', 'POST', 1),
(62, 'customer_messages', 'PUT', 1),
(64, 'customer_messages', 'DELETE', 1),
(65, 'customer_messages', 'HEAD', 1),
(66, 'customer_threads', 'GET', 1),
(68, 'customer_threads', 'POST', 1),
(67, 'customer_threads', 'PUT', 1),
(69, 'customer_threads', 'DELETE', 1),
(70, 'customer_threads', 'HEAD', 1),
(76, 'customizations', 'GET', 1),
(78, 'customizations', 'POST', 1),
(77, 'customizations', 'PUT', 1),
(79, 'customizations', 'DELETE', 1),
(80, 'customizations', 'HEAD', 1),
(81, 'deliveries', 'GET', 1),
(83, 'deliveries', 'POST', 1),
(82, 'deliveries', 'PUT', 1),
(84, 'deliveries', 'DELETE', 1),
(85, 'deliveries', 'HEAD', 1),
(86, 'employees', 'GET', 1),
(88, 'employees', 'POST', 1),
(87, 'employees', 'PUT', 1),
(89, 'employees', 'DELETE', 1),
(90, 'employees', 'HEAD', 1),
(91, 'groups', 'GET', 1),
(93, 'groups', 'POST', 1),
(92, 'groups', 'PUT', 1),
(94, 'groups', 'DELETE', 1),
(95, 'groups', 'HEAD', 1),
(96, 'guests', 'GET', 1),
(98, 'guests', 'POST', 1),
(97, 'guests', 'PUT', 1),
(99, 'guests', 'DELETE', 1),
(100, 'guests', 'HEAD', 1),
(106, 'images', 'GET', 1),
(108, 'images', 'POST', 1),
(107, 'images', 'PUT', 1),
(109, 'images', 'DELETE', 1),
(110, 'images', 'HEAD', 1),
(101, 'image_types', 'GET', 1),
(103, 'image_types', 'POST', 1),
(102, 'image_types', 'PUT', 1),
(104, 'image_types', 'DELETE', 1),
(105, 'image_types', 'HEAD', 1),
(111, 'languages', 'GET', 1),
(113, 'languages', 'POST', 1),
(112, 'languages', 'PUT', 1),
(114, 'languages', 'DELETE', 1),
(115, 'languages', 'HEAD', 1),
(116, 'manufacturers', 'GET', 1),
(118, 'manufacturers', 'POST', 1),
(117, 'manufacturers', 'PUT', 1),
(119, 'manufacturers', 'DELETE', 1),
(120, 'manufacturers', 'HEAD', 1),
(121, 'messages', 'GET', 1),
(123, 'messages', 'POST', 1),
(122, 'messages', 'PUT', 1),
(124, 'messages', 'DELETE', 1),
(125, 'messages', 'HEAD', 1),
(166, 'orders', 'GET', 1),
(168, 'orders', 'POST', 1),
(167, 'orders', 'PUT', 1),
(169, 'orders', 'DELETE', 1),
(170, 'orders', 'HEAD', 1),
(126, 'order_carriers', 'GET', 1),
(128, 'order_carriers', 'POST', 1),
(127, 'order_carriers', 'PUT', 1),
(129, 'order_carriers', 'DELETE', 1),
(130, 'order_carriers', 'HEAD', 1),
(131, 'order_cart_rules', 'GET', 1),
(133, 'order_cart_rules', 'POST', 1),
(132, 'order_cart_rules', 'PUT', 1),
(134, 'order_cart_rules', 'DELETE', 1),
(135, 'order_cart_rules', 'HEAD', 1),
(136, 'order_details', 'GET', 1),
(138, 'order_details', 'POST', 1),
(137, 'order_details', 'PUT', 1),
(139, 'order_details', 'DELETE', 1),
(140, 'order_details', 'HEAD', 1),
(141, 'order_histories', 'GET', 1),
(143, 'order_histories', 'POST', 1),
(142, 'order_histories', 'PUT', 1),
(144, 'order_histories', 'DELETE', 1),
(145, 'order_histories', 'HEAD', 1),
(146, 'order_invoices', 'GET', 1),
(148, 'order_invoices', 'POST', 1),
(147, 'order_invoices', 'PUT', 1),
(149, 'order_invoices', 'DELETE', 1),
(150, 'order_invoices', 'HEAD', 1),
(151, 'order_payments', 'GET', 1),
(153, 'order_payments', 'POST', 1),
(152, 'order_payments', 'PUT', 1),
(154, 'order_payments', 'DELETE', 1),
(155, 'order_payments', 'HEAD', 1),
(156, 'order_slip', 'GET', 1),
(158, 'order_slip', 'POST', 1),
(157, 'order_slip', 'PUT', 1),
(159, 'order_slip', 'DELETE', 1),
(160, 'order_slip', 'HEAD', 1),
(161, 'order_states', 'GET', 1),
(163, 'order_states', 'POST', 1),
(162, 'order_states', 'PUT', 1),
(164, 'order_states', 'DELETE', 1),
(165, 'order_states', 'HEAD', 1),
(171, 'price_ranges', 'GET', 1),
(173, 'price_ranges', 'POST', 1),
(172, 'price_ranges', 'PUT', 1),
(174, 'price_ranges', 'DELETE', 1),
(175, 'price_ranges', 'HEAD', 1),
(206, 'products', 'GET', 1),
(208, 'products', 'POST', 1),
(207, 'products', 'PUT', 1),
(209, 'products', 'DELETE', 1),
(210, 'products', 'HEAD', 1),
(176, 'product_customization_fields', 'GET', 1),
(178, 'product_customization_fields', 'POST', 1),
(177, 'product_customization_fields', 'PUT', 1),
(179, 'product_customization_fields', 'DELETE', 1),
(180, 'product_customization_fields', 'HEAD', 1),
(186, 'product_features', 'GET', 1),
(188, 'product_features', 'POST', 1),
(187, 'product_features', 'PUT', 1),
(189, 'product_features', 'DELETE', 1),
(190, 'product_features', 'HEAD', 1),
(181, 'product_feature_values', 'GET', 1),
(183, 'product_feature_values', 'POST', 1),
(182, 'product_feature_values', 'PUT', 1),
(184, 'product_feature_values', 'DELETE', 1),
(185, 'product_feature_values', 'HEAD', 1),
(196, 'product_options', 'GET', 1),
(198, 'product_options', 'POST', 1),
(197, 'product_options', 'PUT', 1),
(199, 'product_options', 'DELETE', 1),
(200, 'product_options', 'HEAD', 1),
(191, 'product_option_values', 'GET', 1),
(193, 'product_option_values', 'POST', 1),
(192, 'product_option_values', 'PUT', 1),
(194, 'product_option_values', 'DELETE', 1),
(195, 'product_option_values', 'HEAD', 1),
(201, 'product_suppliers', 'GET', 1),
(203, 'product_suppliers', 'POST', 1),
(202, 'product_suppliers', 'PUT', 1),
(204, 'product_suppliers', 'DELETE', 1),
(205, 'product_suppliers', 'HEAD', 1),
(211, 'search', 'GET', 1),
(213, 'search', 'POST', 1),
(212, 'search', 'PUT', 1),
(214, 'search', 'DELETE', 1),
(215, 'search', 'HEAD', 1),
(226, 'shops', 'GET', 1),
(228, 'shops', 'POST', 1),
(227, 'shops', 'PUT', 1),
(229, 'shops', 'DELETE', 1),
(230, 'shops', 'HEAD', 1),
(216, 'shop_groups', 'GET', 1),
(218, 'shop_groups', 'POST', 1),
(217, 'shop_groups', 'PUT', 1),
(219, 'shop_groups', 'DELETE', 1),
(220, 'shop_groups', 'HEAD', 1),
(221, 'shop_urls', 'GET', 1),
(223, 'shop_urls', 'POST', 1),
(222, 'shop_urls', 'PUT', 1),
(224, 'shop_urls', 'DELETE', 1),
(225, 'shop_urls', 'HEAD', 1),
(236, 'specific_prices', 'GET', 1),
(238, 'specific_prices', 'POST', 1),
(237, 'specific_prices', 'PUT', 1),
(239, 'specific_prices', 'DELETE', 1),
(240, 'specific_prices', 'HEAD', 1),
(231, 'specific_price_rules', 'GET', 1),
(233, 'specific_price_rules', 'POST', 1),
(232, 'specific_price_rules', 'PUT', 1),
(234, 'specific_price_rules', 'DELETE', 1),
(235, 'specific_price_rules', 'HEAD', 1),
(241, 'states', 'GET', 1),
(243, 'states', 'POST', 1),
(242, 'states', 'PUT', 1),
(244, 'states', 'DELETE', 1),
(245, 'states', 'HEAD', 1),
(261, 'stocks', 'GET', 1),
(263, 'stocks', 'POST', 1),
(262, 'stocks', 'PUT', 1),
(264, 'stocks', 'DELETE', 1),
(265, 'stocks', 'HEAD', 1),
(246, 'stock_availables', 'GET', 1),
(248, 'stock_availables', 'POST', 1),
(247, 'stock_availables', 'PUT', 1),
(249, 'stock_availables', 'DELETE', 1),
(250, 'stock_availables', 'HEAD', 1),
(256, 'stock_movements', 'GET', 1),
(258, 'stock_movements', 'POST', 1),
(257, 'stock_movements', 'PUT', 1),
(259, 'stock_movements', 'DELETE', 1),
(260, 'stock_movements', 'HEAD', 1),
(251, 'stock_movement_reasons', 'GET', 1),
(253, 'stock_movement_reasons', 'POST', 1),
(252, 'stock_movement_reasons', 'PUT', 1),
(254, 'stock_movement_reasons', 'DELETE', 1),
(255, 'stock_movement_reasons', 'HEAD', 1),
(266, 'stores', 'GET', 1),
(268, 'stores', 'POST', 1),
(267, 'stores', 'PUT', 1),
(269, 'stores', 'DELETE', 1),
(270, 'stores', 'HEAD', 1),
(271, 'suppliers', 'GET', 1),
(273, 'suppliers', 'POST', 1),
(272, 'suppliers', 'PUT', 1),
(274, 'suppliers', 'DELETE', 1),
(275, 'suppliers', 'HEAD', 1),
(296, 'supply_orders', 'GET', 1),
(298, 'supply_orders', 'POST', 1),
(297, 'supply_orders', 'PUT', 1),
(299, 'supply_orders', 'DELETE', 1),
(300, 'supply_orders', 'HEAD', 1),
(276, 'supply_order_details', 'GET', 1),
(278, 'supply_order_details', 'POST', 1),
(277, 'supply_order_details', 'PUT', 1),
(279, 'supply_order_details', 'DELETE', 1),
(280, 'supply_order_details', 'HEAD', 1),
(281, 'supply_order_histories', 'GET', 1),
(283, 'supply_order_histories', 'POST', 1),
(282, 'supply_order_histories', 'PUT', 1),
(284, 'supply_order_histories', 'DELETE', 1),
(285, 'supply_order_histories', 'HEAD', 1),
(286, 'supply_order_receipt_histories', 'GET', 1),
(288, 'supply_order_receipt_histories', 'POST', 1),
(287, 'supply_order_receipt_histories', 'PUT', 1),
(289, 'supply_order_receipt_histories', 'DELETE', 1),
(290, 'supply_order_receipt_histories', 'HEAD', 1),
(291, 'supply_order_states', 'GET', 1),
(293, 'supply_order_states', 'POST', 1),
(292, 'supply_order_states', 'PUT', 1),
(294, 'supply_order_states', 'DELETE', 1),
(295, 'supply_order_states', 'HEAD', 1),
(301, 'tags', 'GET', 1),
(303, 'tags', 'POST', 1),
(302, 'tags', 'PUT', 1),
(304, 'tags', 'DELETE', 1),
(305, 'tags', 'HEAD', 1),
(316, 'taxes', 'GET', 1),
(318, 'taxes', 'POST', 1),
(317, 'taxes', 'PUT', 1),
(319, 'taxes', 'DELETE', 1),
(320, 'taxes', 'HEAD', 1),
(311, 'tax_rules', 'GET', 1),
(313, 'tax_rules', 'POST', 1),
(312, 'tax_rules', 'PUT', 1),
(314, 'tax_rules', 'DELETE', 1),
(315, 'tax_rules', 'HEAD', 1),
(306, 'tax_rule_groups', 'GET', 1),
(308, 'tax_rule_groups', 'POST', 1),
(307, 'tax_rule_groups', 'PUT', 1),
(309, 'tax_rule_groups', 'DELETE', 1),
(310, 'tax_rule_groups', 'HEAD', 1),
(321, 'translated_configurations', 'GET', 1),
(323, 'translated_configurations', 'POST', 1),
(322, 'translated_configurations', 'PUT', 1),
(324, 'translated_configurations', 'DELETE', 1),
(325, 'translated_configurations', 'HEAD', 1),
(331, 'warehouses', 'GET', 1),
(333, 'warehouses', 'POST', 1),
(332, 'warehouses', 'PUT', 1),
(334, 'warehouses', 'DELETE', 1),
(335, 'warehouses', 'HEAD', 1),
(326, 'warehouse_product_locations', 'GET', 1),
(328, 'warehouse_product_locations', 'POST', 1),
(327, 'warehouse_product_locations', 'PUT', 1),
(329, 'warehouse_product_locations', 'DELETE', 1),
(330, 'warehouse_product_locations', 'HEAD', 1),
(336, 'weight_ranges', 'GET', 1),
(338, 'weight_ranges', 'POST', 1),
(337, 'weight_ranges', 'PUT', 1),
(339, 'weight_ranges', 'DELETE', 1),
(340, 'weight_ranges', 'HEAD', 1),
(341, 'zones', 'GET', 1),
(343, 'zones', 'POST', 1),
(342, 'zones', 'PUT', 1),
(344, 'zones', 'DELETE', 1),
(345, 'zones', 'HEAD', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_web_browser`
--

CREATE TABLE `ps_web_browser` (
  `id_web_browser` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_web_browser`
--

INSERT INTO `ps_web_browser` (`id_web_browser`, `name`) VALUES
(1, 'Safari'),
(2, 'Safari iPad'),
(3, 'Firefox'),
(4, 'Opera'),
(5, 'IE 6'),
(6, 'IE 7'),
(7, 'IE 8'),
(8, 'IE 9'),
(9, 'IE 10'),
(10, 'IE 11'),
(11, 'Chrome');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_wishlist`
--

CREATE TABLE `ps_wishlist` (
  `id_wishlist` int(10) UNSIGNED NOT NULL,
  `id_customer` int(10) UNSIGNED NOT NULL,
  `id_shop` int(10) UNSIGNED DEFAULT 1,
  `id_shop_group` int(10) UNSIGNED DEFAULT 1,
  `token` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `counter` int(10) UNSIGNED DEFAULT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `default` int(10) UNSIGNED DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Zrzut danych tabeli `ps_wishlist`
--

INSERT INTO `ps_wishlist` (`id_wishlist`, `id_customer`, `id_shop`, `id_shop_group`, `token`, `name`, `counter`, `date_add`, `date_upd`, `default`) VALUES
(1, 4, 1, 1, 'DDD26F95512E573F', 'Moja lista życzeń', NULL, '2022-12-11 22:16:13', '2022-12-11 22:16:13', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_wishlist_product`
--

CREATE TABLE `ps_wishlist_product` (
  `id_wishlist_product` int(10) NOT NULL,
  `id_wishlist` int(10) UNSIGNED NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_product_attribute` int(10) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  `priority` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_wishlist_product_cart`
--

CREATE TABLE `ps_wishlist_product_cart` (
  `id_wishlist_product` int(10) UNSIGNED NOT NULL,
  `id_cart` int(10) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  `date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_zone`
--

CREATE TABLE `ps_zone` (
  `id_zone` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_zone`
--

INSERT INTO `ps_zone` (`id_zone`, `name`, `active`) VALUES
(1, 'Europe', 1),
(2, 'North America', 1),
(3, 'Asia', 1),
(4, 'Africa', 1),
(5, 'Oceania', 1),
(6, 'South America', 1),
(7, 'Europe (non-EU)', 1),
(8, 'Central America/Antilla', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ps_zone_shop`
--

CREATE TABLE `ps_zone_shop` (
  `id_zone` int(11) UNSIGNED NOT NULL,
  `id_shop` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `ps_zone_shop`
--

INSERT INTO `ps_zone_shop` (`id_zone`, `id_shop`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `ps_access`
--
ALTER TABLE `ps_access`
  ADD PRIMARY KEY (`id_profile`,`id_authorization_role`);

--
-- Indeksy dla tabeli `ps_accessory`
--
ALTER TABLE `ps_accessory`
  ADD KEY `accessory_product` (`id_product_1`,`id_product_2`);

--
-- Indeksy dla tabeli `ps_address`
--
ALTER TABLE `ps_address`
  ADD PRIMARY KEY (`id_address`),
  ADD KEY `address_customer` (`id_customer`),
  ADD KEY `id_country` (`id_country`),
  ADD KEY `id_state` (`id_state`),
  ADD KEY `id_manufacturer` (`id_manufacturer`),
  ADD KEY `id_supplier` (`id_supplier`),
  ADD KEY `id_warehouse` (`id_warehouse`);

--
-- Indeksy dla tabeli `ps_address_format`
--
ALTER TABLE `ps_address_format`
  ADD PRIMARY KEY (`id_country`);

--
-- Indeksy dla tabeli `ps_admin_filter`
--
ALTER TABLE `ps_admin_filter`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_filter_search_id_idx` (`employee`,`shop`,`controller`,`action`,`filter_id`);

--
-- Indeksy dla tabeli `ps_advice`
--
ALTER TABLE `ps_advice`
  ADD PRIMARY KEY (`id_advice`);

--
-- Indeksy dla tabeli `ps_advice_lang`
--
ALTER TABLE `ps_advice_lang`
  ADD PRIMARY KEY (`id_advice`,`id_lang`);

--
-- Indeksy dla tabeli `ps_alias`
--
ALTER TABLE `ps_alias`
  ADD PRIMARY KEY (`id_alias`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indeksy dla tabeli `ps_attachment`
--
ALTER TABLE `ps_attachment`
  ADD PRIMARY KEY (`id_attachment`);

--
-- Indeksy dla tabeli `ps_attachment_lang`
--
ALTER TABLE `ps_attachment_lang`
  ADD PRIMARY KEY (`id_attachment`,`id_lang`);

--
-- Indeksy dla tabeli `ps_attribute`
--
ALTER TABLE `ps_attribute`
  ADD PRIMARY KEY (`id_attribute`),
  ADD KEY `attribute_group` (`id_attribute_group`);

--
-- Indeksy dla tabeli `ps_attribute_group`
--
ALTER TABLE `ps_attribute_group`
  ADD PRIMARY KEY (`id_attribute_group`);

--
-- Indeksy dla tabeli `ps_attribute_group_lang`
--
ALTER TABLE `ps_attribute_group_lang`
  ADD PRIMARY KEY (`id_attribute_group`,`id_lang`),
  ADD KEY `IDX_4653726C67A664FB` (`id_attribute_group`),
  ADD KEY `IDX_4653726CBA299860` (`id_lang`);

--
-- Indeksy dla tabeli `ps_attribute_group_shop`
--
ALTER TABLE `ps_attribute_group_shop`
  ADD PRIMARY KEY (`id_attribute_group`,`id_shop`),
  ADD KEY `IDX_DB30BAAC67A664FB` (`id_attribute_group`),
  ADD KEY `IDX_DB30BAAC274A50A0` (`id_shop`);

--
-- Indeksy dla tabeli `ps_attribute_impact`
--
ALTER TABLE `ps_attribute_impact`
  ADD PRIMARY KEY (`id_attribute_impact`),
  ADD UNIQUE KEY `id_product` (`id_product`,`id_attribute`);

--
-- Indeksy dla tabeli `ps_attribute_lang`
--
ALTER TABLE `ps_attribute_lang`
  ADD PRIMARY KEY (`id_attribute`,`id_lang`),
  ADD KEY `IDX_3ABE46A77A4F53DC` (`id_attribute`),
  ADD KEY `IDX_3ABE46A7BA299860` (`id_lang`);

--
-- Indeksy dla tabeli `ps_attribute_shop`
--
ALTER TABLE `ps_attribute_shop`
  ADD PRIMARY KEY (`id_attribute`,`id_shop`),
  ADD KEY `IDX_A7DD8E677A4F53DC` (`id_attribute`),
  ADD KEY `IDX_A7DD8E67274A50A0` (`id_shop`);

--
-- Indeksy dla tabeli `ps_authorization_role`
--
ALTER TABLE `ps_authorization_role`
  ADD PRIMARY KEY (`id_authorization_role`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indeksy dla tabeli `ps_badge`
--
ALTER TABLE `ps_badge`
  ADD PRIMARY KEY (`id_badge`);

--
-- Indeksy dla tabeli `ps_badge_lang`
--
ALTER TABLE `ps_badge_lang`
  ADD PRIMARY KEY (`id_badge`,`id_lang`);

--
-- Indeksy dla tabeli `ps_blockwishlist_statistics`
--
ALTER TABLE `ps_blockwishlist_statistics`
  ADD PRIMARY KEY (`id_statistics`);

--
-- Indeksy dla tabeli `ps_carrier`
--
ALTER TABLE `ps_carrier`
  ADD PRIMARY KEY (`id_carrier`),
  ADD KEY `deleted` (`deleted`,`active`),
  ADD KEY `id_tax_rules_group` (`id_tax_rules_group`),
  ADD KEY `reference` (`id_reference`,`deleted`,`active`);

--
-- Indeksy dla tabeli `ps_carrier_group`
--
ALTER TABLE `ps_carrier_group`
  ADD PRIMARY KEY (`id_carrier`,`id_group`);

--
-- Indeksy dla tabeli `ps_carrier_lang`
--
ALTER TABLE `ps_carrier_lang`
  ADD PRIMARY KEY (`id_lang`,`id_shop`,`id_carrier`);

--
-- Indeksy dla tabeli `ps_carrier_shop`
--
ALTER TABLE `ps_carrier_shop`
  ADD PRIMARY KEY (`id_carrier`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_carrier_tax_rules_group_shop`
--
ALTER TABLE `ps_carrier_tax_rules_group_shop`
  ADD PRIMARY KEY (`id_carrier`,`id_tax_rules_group`,`id_shop`);

--
-- Indeksy dla tabeli `ps_carrier_zone`
--
ALTER TABLE `ps_carrier_zone`
  ADD PRIMARY KEY (`id_carrier`,`id_zone`);

--
-- Indeksy dla tabeli `ps_cart`
--
ALTER TABLE `ps_cart`
  ADD PRIMARY KEY (`id_cart`),
  ADD KEY `cart_customer` (`id_customer`),
  ADD KEY `id_address_delivery` (`id_address_delivery`),
  ADD KEY `id_address_invoice` (`id_address_invoice`),
  ADD KEY `id_carrier` (`id_carrier`),
  ADD KEY `id_lang` (`id_lang`),
  ADD KEY `id_currency` (`id_currency`),
  ADD KEY `id_guest` (`id_guest`),
  ADD KEY `id_shop_group` (`id_shop_group`),
  ADD KEY `id_shop_2` (`id_shop`,`date_upd`),
  ADD KEY `id_shop` (`id_shop`,`date_add`);

--
-- Indeksy dla tabeli `ps_cart_cart_rule`
--
ALTER TABLE `ps_cart_cart_rule`
  ADD PRIMARY KEY (`id_cart`,`id_cart_rule`),
  ADD KEY `id_cart_rule` (`id_cart_rule`);

--
-- Indeksy dla tabeli `ps_cart_product`
--
ALTER TABLE `ps_cart_product`
  ADD PRIMARY KEY (`id_cart`,`id_product`,`id_product_attribute`,`id_customization`,`id_address_delivery`),
  ADD KEY `id_product_attribute` (`id_product_attribute`),
  ADD KEY `id_cart_order` (`id_cart`,`date_add`,`id_product`,`id_product_attribute`);

--
-- Indeksy dla tabeli `ps_cart_rule`
--
ALTER TABLE `ps_cart_rule`
  ADD PRIMARY KEY (`id_cart_rule`),
  ADD KEY `id_customer` (`id_customer`,`active`,`date_to`),
  ADD KEY `group_restriction` (`group_restriction`,`active`,`date_to`),
  ADD KEY `id_customer_2` (`id_customer`,`active`,`highlight`,`date_to`),
  ADD KEY `group_restriction_2` (`group_restriction`,`active`,`highlight`,`date_to`),
  ADD KEY `date_from` (`date_from`),
  ADD KEY `date_to` (`date_to`);

--
-- Indeksy dla tabeli `ps_cart_rule_carrier`
--
ALTER TABLE `ps_cart_rule_carrier`
  ADD PRIMARY KEY (`id_cart_rule`,`id_carrier`);

--
-- Indeksy dla tabeli `ps_cart_rule_combination`
--
ALTER TABLE `ps_cart_rule_combination`
  ADD PRIMARY KEY (`id_cart_rule_1`,`id_cart_rule_2`),
  ADD KEY `id_cart_rule_1` (`id_cart_rule_1`),
  ADD KEY `id_cart_rule_2` (`id_cart_rule_2`);

--
-- Indeksy dla tabeli `ps_cart_rule_country`
--
ALTER TABLE `ps_cart_rule_country`
  ADD PRIMARY KEY (`id_cart_rule`,`id_country`);

--
-- Indeksy dla tabeli `ps_cart_rule_group`
--
ALTER TABLE `ps_cart_rule_group`
  ADD PRIMARY KEY (`id_cart_rule`,`id_group`);

--
-- Indeksy dla tabeli `ps_cart_rule_lang`
--
ALTER TABLE `ps_cart_rule_lang`
  ADD PRIMARY KEY (`id_cart_rule`,`id_lang`);

--
-- Indeksy dla tabeli `ps_cart_rule_product_rule`
--
ALTER TABLE `ps_cart_rule_product_rule`
  ADD PRIMARY KEY (`id_product_rule`);

--
-- Indeksy dla tabeli `ps_cart_rule_product_rule_group`
--
ALTER TABLE `ps_cart_rule_product_rule_group`
  ADD PRIMARY KEY (`id_product_rule_group`);

--
-- Indeksy dla tabeli `ps_cart_rule_product_rule_value`
--
ALTER TABLE `ps_cart_rule_product_rule_value`
  ADD PRIMARY KEY (`id_product_rule`,`id_item`);

--
-- Indeksy dla tabeli `ps_cart_rule_shop`
--
ALTER TABLE `ps_cart_rule_shop`
  ADD PRIMARY KEY (`id_cart_rule`,`id_shop`);

--
-- Indeksy dla tabeli `ps_category`
--
ALTER TABLE `ps_category`
  ADD PRIMARY KEY (`id_category`),
  ADD KEY `category_parent` (`id_parent`),
  ADD KEY `nleftrightactive` (`nleft`,`nright`,`active`),
  ADD KEY `level_depth` (`level_depth`),
  ADD KEY `nright` (`nright`),
  ADD KEY `activenleft` (`active`,`nleft`),
  ADD KEY `activenright` (`active`,`nright`);

--
-- Indeksy dla tabeli `ps_category_group`
--
ALTER TABLE `ps_category_group`
  ADD PRIMARY KEY (`id_category`,`id_group`),
  ADD KEY `id_category` (`id_category`),
  ADD KEY `id_group` (`id_group`);

--
-- Indeksy dla tabeli `ps_category_lang`
--
ALTER TABLE `ps_category_lang`
  ADD PRIMARY KEY (`id_category`,`id_shop`,`id_lang`),
  ADD KEY `category_name` (`name`);

--
-- Indeksy dla tabeli `ps_category_product`
--
ALTER TABLE `ps_category_product`
  ADD PRIMARY KEY (`id_category`,`id_product`),
  ADD KEY `id_product` (`id_product`),
  ADD KEY `id_category` (`id_category`,`position`);

--
-- Indeksy dla tabeli `ps_category_shop`
--
ALTER TABLE `ps_category_shop`
  ADD PRIMARY KEY (`id_category`,`id_shop`);

--
-- Indeksy dla tabeli `ps_cms`
--
ALTER TABLE `ps_cms`
  ADD PRIMARY KEY (`id_cms`);

--
-- Indeksy dla tabeli `ps_cms_category`
--
ALTER TABLE `ps_cms_category`
  ADD PRIMARY KEY (`id_cms_category`),
  ADD KEY `category_parent` (`id_parent`);

--
-- Indeksy dla tabeli `ps_cms_category_lang`
--
ALTER TABLE `ps_cms_category_lang`
  ADD PRIMARY KEY (`id_cms_category`,`id_shop`,`id_lang`),
  ADD KEY `category_name` (`name`);

--
-- Indeksy dla tabeli `ps_cms_category_shop`
--
ALTER TABLE `ps_cms_category_shop`
  ADD PRIMARY KEY (`id_cms_category`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_cms_lang`
--
ALTER TABLE `ps_cms_lang`
  ADD PRIMARY KEY (`id_cms`,`id_shop`,`id_lang`);

--
-- Indeksy dla tabeli `ps_cms_role`
--
ALTER TABLE `ps_cms_role`
  ADD PRIMARY KEY (`id_cms_role`,`id_cms`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indeksy dla tabeli `ps_cms_role_lang`
--
ALTER TABLE `ps_cms_role_lang`
  ADD PRIMARY KEY (`id_cms_role`,`id_lang`,`id_shop`);

--
-- Indeksy dla tabeli `ps_cms_shop`
--
ALTER TABLE `ps_cms_shop`
  ADD PRIMARY KEY (`id_cms`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_condition`
--
ALTER TABLE `ps_condition`
  ADD PRIMARY KEY (`id_condition`,`id_ps_condition`);

--
-- Indeksy dla tabeli `ps_condition_advice`
--
ALTER TABLE `ps_condition_advice`
  ADD PRIMARY KEY (`id_condition`,`id_advice`);

--
-- Indeksy dla tabeli `ps_condition_badge`
--
ALTER TABLE `ps_condition_badge`
  ADD PRIMARY KEY (`id_condition`,`id_badge`);

--
-- Indeksy dla tabeli `ps_configuration`
--
ALTER TABLE `ps_configuration`
  ADD PRIMARY KEY (`id_configuration`),
  ADD KEY `name` (`name`),
  ADD KEY `id_shop` (`id_shop`),
  ADD KEY `id_shop_group` (`id_shop_group`);

--
-- Indeksy dla tabeli `ps_configuration_kpi`
--
ALTER TABLE `ps_configuration_kpi`
  ADD PRIMARY KEY (`id_configuration_kpi`),
  ADD KEY `name` (`name`),
  ADD KEY `id_shop` (`id_shop`),
  ADD KEY `id_shop_group` (`id_shop_group`);

--
-- Indeksy dla tabeli `ps_configuration_kpi_lang`
--
ALTER TABLE `ps_configuration_kpi_lang`
  ADD PRIMARY KEY (`id_configuration_kpi`,`id_lang`);

--
-- Indeksy dla tabeli `ps_configuration_lang`
--
ALTER TABLE `ps_configuration_lang`
  ADD PRIMARY KEY (`id_configuration`,`id_lang`);

--
-- Indeksy dla tabeli `ps_connections`
--
ALTER TABLE `ps_connections`
  ADD PRIMARY KEY (`id_connections`),
  ADD KEY `id_guest` (`id_guest`),
  ADD KEY `date_add` (`date_add`),
  ADD KEY `id_page` (`id_page`);

--
-- Indeksy dla tabeli `ps_connections_page`
--
ALTER TABLE `ps_connections_page`
  ADD PRIMARY KEY (`id_connections`,`id_page`,`time_start`);

--
-- Indeksy dla tabeli `ps_connections_source`
--
ALTER TABLE `ps_connections_source`
  ADD PRIMARY KEY (`id_connections_source`),
  ADD KEY `connections` (`id_connections`),
  ADD KEY `orderby` (`date_add`),
  ADD KEY `http_referer` (`http_referer`),
  ADD KEY `request_uri` (`request_uri`);

--
-- Indeksy dla tabeli `ps_contact`
--
ALTER TABLE `ps_contact`
  ADD PRIMARY KEY (`id_contact`);

--
-- Indeksy dla tabeli `ps_contact_lang`
--
ALTER TABLE `ps_contact_lang`
  ADD PRIMARY KEY (`id_contact`,`id_lang`);

--
-- Indeksy dla tabeli `ps_contact_shop`
--
ALTER TABLE `ps_contact_shop`
  ADD PRIMARY KEY (`id_contact`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_country`
--
ALTER TABLE `ps_country`
  ADD PRIMARY KEY (`id_country`),
  ADD KEY `country_iso_code` (`iso_code`),
  ADD KEY `country_` (`id_zone`);

--
-- Indeksy dla tabeli `ps_country_lang`
--
ALTER TABLE `ps_country_lang`
  ADD PRIMARY KEY (`id_country`,`id_lang`);

--
-- Indeksy dla tabeli `ps_country_shop`
--
ALTER TABLE `ps_country_shop`
  ADD PRIMARY KEY (`id_country`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_currency`
--
ALTER TABLE `ps_currency`
  ADD PRIMARY KEY (`id_currency`),
  ADD KEY `currency_iso_code` (`iso_code`);

--
-- Indeksy dla tabeli `ps_currency_lang`
--
ALTER TABLE `ps_currency_lang`
  ADD PRIMARY KEY (`id_currency`,`id_lang`);

--
-- Indeksy dla tabeli `ps_currency_shop`
--
ALTER TABLE `ps_currency_shop`
  ADD PRIMARY KEY (`id_currency`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_customer`
--
ALTER TABLE `ps_customer`
  ADD PRIMARY KEY (`id_customer`),
  ADD KEY `customer_email` (`email`),
  ADD KEY `customer_login` (`email`,`passwd`),
  ADD KEY `id_customer_passwd` (`id_customer`,`passwd`),
  ADD KEY `id_gender` (`id_gender`),
  ADD KEY `id_shop_group` (`id_shop_group`),
  ADD KEY `id_shop` (`id_shop`,`date_add`);

--
-- Indeksy dla tabeli `ps_customer_group`
--
ALTER TABLE `ps_customer_group`
  ADD PRIMARY KEY (`id_customer`,`id_group`),
  ADD KEY `customer_login` (`id_group`),
  ADD KEY `id_customer` (`id_customer`);

--
-- Indeksy dla tabeli `ps_customer_message`
--
ALTER TABLE `ps_customer_message`
  ADD PRIMARY KEY (`id_customer_message`),
  ADD KEY `id_customer_thread` (`id_customer_thread`),
  ADD KEY `id_employee` (`id_employee`);

--
-- Indeksy dla tabeli `ps_customer_message_sync_imap`
--
ALTER TABLE `ps_customer_message_sync_imap`
  ADD KEY `md5_header_index` (`md5_header`(4));

--
-- Indeksy dla tabeli `ps_customer_session`
--
ALTER TABLE `ps_customer_session`
  ADD PRIMARY KEY (`id_customer_session`);

--
-- Indeksy dla tabeli `ps_customer_thread`
--
ALTER TABLE `ps_customer_thread`
  ADD PRIMARY KEY (`id_customer_thread`),
  ADD KEY `id_shop` (`id_shop`),
  ADD KEY `id_lang` (`id_lang`),
  ADD KEY `id_contact` (`id_contact`),
  ADD KEY `id_customer` (`id_customer`),
  ADD KEY `id_order` (`id_order`),
  ADD KEY `id_product` (`id_product`);

--
-- Indeksy dla tabeli `ps_customization`
--
ALTER TABLE `ps_customization`
  ADD PRIMARY KEY (`id_customization`,`id_cart`,`id_product`,`id_address_delivery`),
  ADD KEY `id_product_attribute` (`id_product_attribute`),
  ADD KEY `id_cart_product` (`id_cart`,`id_product`,`id_product_attribute`);

--
-- Indeksy dla tabeli `ps_customization_field`
--
ALTER TABLE `ps_customization_field`
  ADD PRIMARY KEY (`id_customization_field`),
  ADD KEY `id_product` (`id_product`);

--
-- Indeksy dla tabeli `ps_customization_field_lang`
--
ALTER TABLE `ps_customization_field_lang`
  ADD PRIMARY KEY (`id_customization_field`,`id_lang`,`id_shop`);

--
-- Indeksy dla tabeli `ps_customized_data`
--
ALTER TABLE `ps_customized_data`
  ADD PRIMARY KEY (`id_customization`,`type`,`index`);

--
-- Indeksy dla tabeli `ps_date_range`
--
ALTER TABLE `ps_date_range`
  ADD PRIMARY KEY (`id_date_range`);

--
-- Indeksy dla tabeli `ps_delivery`
--
ALTER TABLE `ps_delivery`
  ADD PRIMARY KEY (`id_delivery`),
  ADD KEY `id_zone` (`id_zone`),
  ADD KEY `id_carrier` (`id_carrier`,`id_zone`),
  ADD KEY `id_range_price` (`id_range_price`),
  ADD KEY `id_range_weight` (`id_range_weight`);

--
-- Indeksy dla tabeli `ps_emailsubscription`
--
ALTER TABLE `ps_emailsubscription`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `ps_employee`
--
ALTER TABLE `ps_employee`
  ADD PRIMARY KEY (`id_employee`),
  ADD KEY `employee_login` (`email`,`passwd`),
  ADD KEY `id_employee_passwd` (`id_employee`,`passwd`),
  ADD KEY `id_profile` (`id_profile`);

--
-- Indeksy dla tabeli `ps_employee_session`
--
ALTER TABLE `ps_employee_session`
  ADD PRIMARY KEY (`id_employee_session`);

--
-- Indeksy dla tabeli `ps_employee_shop`
--
ALTER TABLE `ps_employee_shop`
  ADD PRIMARY KEY (`id_employee`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_fb_category_match`
--
ALTER TABLE `ps_fb_category_match`
  ADD PRIMARY KEY (`id_category`,`id_shop`),
  ADD KEY `id_category` (`id_category`,`google_category_id`);

--
-- Indeksy dla tabeli `ps_feature`
--
ALTER TABLE `ps_feature`
  ADD PRIMARY KEY (`id_feature`);

--
-- Indeksy dla tabeli `ps_feature_flag`
--
ALTER TABLE `ps_feature_flag`
  ADD PRIMARY KEY (`id_feature_flag`),
  ADD UNIQUE KEY `UNIQ_91700F175E237E06` (`name`);

--
-- Indeksy dla tabeli `ps_feature_lang`
--
ALTER TABLE `ps_feature_lang`
  ADD PRIMARY KEY (`id_feature`,`id_lang`),
  ADD KEY `id_lang` (`id_lang`,`name`);

--
-- Indeksy dla tabeli `ps_feature_product`
--
ALTER TABLE `ps_feature_product`
  ADD PRIMARY KEY (`id_feature`,`id_product`,`id_feature_value`),
  ADD KEY `id_feature_value` (`id_feature_value`),
  ADD KEY `id_product` (`id_product`);

--
-- Indeksy dla tabeli `ps_feature_shop`
--
ALTER TABLE `ps_feature_shop`
  ADD PRIMARY KEY (`id_feature`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_feature_value`
--
ALTER TABLE `ps_feature_value`
  ADD PRIMARY KEY (`id_feature_value`),
  ADD KEY `feature` (`id_feature`);

--
-- Indeksy dla tabeli `ps_feature_value_lang`
--
ALTER TABLE `ps_feature_value_lang`
  ADD PRIMARY KEY (`id_feature_value`,`id_lang`);

--
-- Indeksy dla tabeli `ps_ganalytics`
--
ALTER TABLE `ps_ganalytics`
  ADD PRIMARY KEY (`id_google_analytics`),
  ADD KEY `id_order` (`id_order`),
  ADD KEY `sent` (`sent`);

--
-- Indeksy dla tabeli `ps_ganalytics_data`
--
ALTER TABLE `ps_ganalytics_data`
  ADD PRIMARY KEY (`id_cart`);

--
-- Indeksy dla tabeli `ps_gender`
--
ALTER TABLE `ps_gender`
  ADD PRIMARY KEY (`id_gender`);

--
-- Indeksy dla tabeli `ps_gender_lang`
--
ALTER TABLE `ps_gender_lang`
  ADD PRIMARY KEY (`id_gender`,`id_lang`),
  ADD KEY `id_gender` (`id_gender`);

--
-- Indeksy dla tabeli `ps_group`
--
ALTER TABLE `ps_group`
  ADD PRIMARY KEY (`id_group`);

--
-- Indeksy dla tabeli `ps_group_lang`
--
ALTER TABLE `ps_group_lang`
  ADD PRIMARY KEY (`id_group`,`id_lang`);

--
-- Indeksy dla tabeli `ps_group_reduction`
--
ALTER TABLE `ps_group_reduction`
  ADD PRIMARY KEY (`id_group_reduction`),
  ADD UNIQUE KEY `id_group` (`id_group`,`id_category`);

--
-- Indeksy dla tabeli `ps_group_shop`
--
ALTER TABLE `ps_group_shop`
  ADD PRIMARY KEY (`id_group`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_guest`
--
ALTER TABLE `ps_guest`
  ADD PRIMARY KEY (`id_guest`),
  ADD KEY `id_customer` (`id_customer`),
  ADD KEY `id_operating_system` (`id_operating_system`),
  ADD KEY `id_web_browser` (`id_web_browser`);

--
-- Indeksy dla tabeli `ps_homeslider`
--
ALTER TABLE `ps_homeslider`
  ADD PRIMARY KEY (`id_homeslider_slides`,`id_shop`);

--
-- Indeksy dla tabeli `ps_homeslider_slides`
--
ALTER TABLE `ps_homeslider_slides`
  ADD PRIMARY KEY (`id_homeslider_slides`);

--
-- Indeksy dla tabeli `ps_homeslider_slides_lang`
--
ALTER TABLE `ps_homeslider_slides_lang`
  ADD PRIMARY KEY (`id_homeslider_slides`,`id_lang`);

--
-- Indeksy dla tabeli `ps_hook`
--
ALTER TABLE `ps_hook`
  ADD PRIMARY KEY (`id_hook`),
  ADD UNIQUE KEY `hook_name` (`name`);

--
-- Indeksy dla tabeli `ps_hook_alias`
--
ALTER TABLE `ps_hook_alias`
  ADD PRIMARY KEY (`id_hook_alias`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indeksy dla tabeli `ps_hook_module`
--
ALTER TABLE `ps_hook_module`
  ADD PRIMARY KEY (`id_module`,`id_hook`,`id_shop`),
  ADD KEY `id_hook` (`id_hook`),
  ADD KEY `id_module` (`id_module`),
  ADD KEY `position` (`id_shop`,`position`);

--
-- Indeksy dla tabeli `ps_hook_module_exceptions`
--
ALTER TABLE `ps_hook_module_exceptions`
  ADD PRIMARY KEY (`id_hook_module_exceptions`),
  ADD KEY `id_module` (`id_module`),
  ADD KEY `id_hook` (`id_hook`);

--
-- Indeksy dla tabeli `ps_image`
--
ALTER TABLE `ps_image`
  ADD PRIMARY KEY (`id_image`),
  ADD UNIQUE KEY `id_product_cover` (`id_product`,`cover`),
  ADD UNIQUE KEY `idx_product_image` (`id_image`,`id_product`,`cover`),
  ADD KEY `image_product` (`id_product`);

--
-- Indeksy dla tabeli `ps_image_lang`
--
ALTER TABLE `ps_image_lang`
  ADD PRIMARY KEY (`id_image`,`id_lang`),
  ADD KEY `id_image` (`id_image`);

--
-- Indeksy dla tabeli `ps_image_shop`
--
ALTER TABLE `ps_image_shop`
  ADD PRIMARY KEY (`id_image`,`id_shop`),
  ADD UNIQUE KEY `id_product` (`id_product`,`id_shop`,`cover`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_image_type`
--
ALTER TABLE `ps_image_type`
  ADD PRIMARY KEY (`id_image_type`),
  ADD KEY `image_type_name` (`name`);

--
-- Indeksy dla tabeli `ps_import_match`
--
ALTER TABLE `ps_import_match`
  ADD PRIMARY KEY (`id_import_match`);

--
-- Indeksy dla tabeli `ps_info`
--
ALTER TABLE `ps_info`
  ADD PRIMARY KEY (`id_info`);

--
-- Indeksy dla tabeli `ps_info_lang`
--
ALTER TABLE `ps_info_lang`
  ADD PRIMARY KEY (`id_info`,`id_lang`,`id_shop`);

--
-- Indeksy dla tabeli `ps_info_shop`
--
ALTER TABLE `ps_info_shop`
  ADD PRIMARY KEY (`id_info`,`id_shop`);

--
-- Indeksy dla tabeli `ps_lang`
--
ALTER TABLE `ps_lang`
  ADD PRIMARY KEY (`id_lang`);

--
-- Indeksy dla tabeli `ps_lang_shop`
--
ALTER TABLE `ps_lang_shop`
  ADD PRIMARY KEY (`id_lang`,`id_shop`),
  ADD KEY `IDX_2F43BFC7BA299860` (`id_lang`),
  ADD KEY `IDX_2F43BFC7274A50A0` (`id_shop`);

--
-- Indeksy dla tabeli `ps_layered_category`
--
ALTER TABLE `ps_layered_category`
  ADD PRIMARY KEY (`id_layered_category`),
  ADD KEY `id_category_shop` (`id_category`,`id_shop`,`type`,`id_value`,`position`),
  ADD KEY `id_category` (`id_category`,`type`);

--
-- Indeksy dla tabeli `ps_layered_filter`
--
ALTER TABLE `ps_layered_filter`
  ADD PRIMARY KEY (`id_layered_filter`);

--
-- Indeksy dla tabeli `ps_layered_filter_block`
--
ALTER TABLE `ps_layered_filter_block`
  ADD PRIMARY KEY (`hash`);

--
-- Indeksy dla tabeli `ps_layered_filter_shop`
--
ALTER TABLE `ps_layered_filter_shop`
  ADD PRIMARY KEY (`id_layered_filter`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_layered_indexable_attribute_group`
--
ALTER TABLE `ps_layered_indexable_attribute_group`
  ADD PRIMARY KEY (`id_attribute_group`);

--
-- Indeksy dla tabeli `ps_layered_indexable_attribute_group_lang_value`
--
ALTER TABLE `ps_layered_indexable_attribute_group_lang_value`
  ADD PRIMARY KEY (`id_attribute_group`,`id_lang`);

--
-- Indeksy dla tabeli `ps_layered_indexable_attribute_lang_value`
--
ALTER TABLE `ps_layered_indexable_attribute_lang_value`
  ADD PRIMARY KEY (`id_attribute`,`id_lang`);

--
-- Indeksy dla tabeli `ps_layered_indexable_feature`
--
ALTER TABLE `ps_layered_indexable_feature`
  ADD PRIMARY KEY (`id_feature`);

--
-- Indeksy dla tabeli `ps_layered_indexable_feature_lang_value`
--
ALTER TABLE `ps_layered_indexable_feature_lang_value`
  ADD PRIMARY KEY (`id_feature`,`id_lang`);

--
-- Indeksy dla tabeli `ps_layered_indexable_feature_value_lang_value`
--
ALTER TABLE `ps_layered_indexable_feature_value_lang_value`
  ADD PRIMARY KEY (`id_feature_value`,`id_lang`);

--
-- Indeksy dla tabeli `ps_layered_price_index`
--
ALTER TABLE `ps_layered_price_index`
  ADD PRIMARY KEY (`id_product`,`id_currency`,`id_shop`,`id_country`),
  ADD KEY `id_currency` (`id_currency`),
  ADD KEY `price_min` (`price_min`),
  ADD KEY `price_max` (`price_max`);

--
-- Indeksy dla tabeli `ps_layered_product_attribute`
--
ALTER TABLE `ps_layered_product_attribute`
  ADD PRIMARY KEY (`id_attribute`,`id_product`,`id_shop`),
  ADD UNIQUE KEY `id_attribute_group` (`id_attribute_group`,`id_attribute`,`id_product`,`id_shop`);

--
-- Indeksy dla tabeli `ps_linksmenutop`
--
ALTER TABLE `ps_linksmenutop`
  ADD PRIMARY KEY (`id_linksmenutop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_linksmenutop_lang`
--
ALTER TABLE `ps_linksmenutop_lang`
  ADD KEY `id_linksmenutop` (`id_linksmenutop`,`id_lang`,`id_shop`);

--
-- Indeksy dla tabeli `ps_link_block`
--
ALTER TABLE `ps_link_block`
  ADD PRIMARY KEY (`id_link_block`);

--
-- Indeksy dla tabeli `ps_link_block_lang`
--
ALTER TABLE `ps_link_block_lang`
  ADD PRIMARY KEY (`id_link_block`,`id_lang`);

--
-- Indeksy dla tabeli `ps_link_block_shop`
--
ALTER TABLE `ps_link_block_shop`
  ADD PRIMARY KEY (`id_link_block`,`id_shop`);

--
-- Indeksy dla tabeli `ps_log`
--
ALTER TABLE `ps_log`
  ADD PRIMARY KEY (`id_log`);

--
-- Indeksy dla tabeli `ps_mail`
--
ALTER TABLE `ps_mail`
  ADD PRIMARY KEY (`id_mail`),
  ADD KEY `recipient` (`recipient`(10));

--
-- Indeksy dla tabeli `ps_manufacturer`
--
ALTER TABLE `ps_manufacturer`
  ADD PRIMARY KEY (`id_manufacturer`);

--
-- Indeksy dla tabeli `ps_manufacturer_lang`
--
ALTER TABLE `ps_manufacturer_lang`
  ADD PRIMARY KEY (`id_manufacturer`,`id_lang`);

--
-- Indeksy dla tabeli `ps_manufacturer_shop`
--
ALTER TABLE `ps_manufacturer_shop`
  ADD PRIMARY KEY (`id_manufacturer`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_memcached_servers`
--
ALTER TABLE `ps_memcached_servers`
  ADD PRIMARY KEY (`id_memcached_server`);

--
-- Indeksy dla tabeli `ps_message`
--
ALTER TABLE `ps_message`
  ADD PRIMARY KEY (`id_message`),
  ADD KEY `message_order` (`id_order`),
  ADD KEY `id_cart` (`id_cart`),
  ADD KEY `id_customer` (`id_customer`),
  ADD KEY `id_employee` (`id_employee`);

--
-- Indeksy dla tabeli `ps_message_readed`
--
ALTER TABLE `ps_message_readed`
  ADD PRIMARY KEY (`id_message`,`id_employee`);

--
-- Indeksy dla tabeli `ps_meta`
--
ALTER TABLE `ps_meta`
  ADD PRIMARY KEY (`id_meta`),
  ADD UNIQUE KEY `page` (`page`);

--
-- Indeksy dla tabeli `ps_meta_lang`
--
ALTER TABLE `ps_meta_lang`
  ADD PRIMARY KEY (`id_meta`,`id_shop`,`id_lang`),
  ADD KEY `id_shop` (`id_shop`),
  ADD KEY `id_lang` (`id_lang`);

--
-- Indeksy dla tabeli `ps_module`
--
ALTER TABLE `ps_module`
  ADD PRIMARY KEY (`id_module`),
  ADD UNIQUE KEY `name_UNIQUE` (`name`),
  ADD KEY `name` (`name`);

--
-- Indeksy dla tabeli `ps_module_access`
--
ALTER TABLE `ps_module_access`
  ADD PRIMARY KEY (`id_profile`,`id_authorization_role`);

--
-- Indeksy dla tabeli `ps_module_carrier`
--
ALTER TABLE `ps_module_carrier`
  ADD PRIMARY KEY (`id_module`,`id_shop`,`id_reference`);

--
-- Indeksy dla tabeli `ps_module_country`
--
ALTER TABLE `ps_module_country`
  ADD PRIMARY KEY (`id_module`,`id_shop`,`id_country`);

--
-- Indeksy dla tabeli `ps_module_currency`
--
ALTER TABLE `ps_module_currency`
  ADD PRIMARY KEY (`id_module`,`id_shop`,`id_currency`),
  ADD KEY `id_module` (`id_module`);

--
-- Indeksy dla tabeli `ps_module_group`
--
ALTER TABLE `ps_module_group`
  ADD PRIMARY KEY (`id_module`,`id_shop`,`id_group`);

--
-- Indeksy dla tabeli `ps_module_history`
--
ALTER TABLE `ps_module_history`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `ps_module_preference`
--
ALTER TABLE `ps_module_preference`
  ADD PRIMARY KEY (`id_module_preference`),
  ADD UNIQUE KEY `employee_module` (`id_employee`,`module`);

--
-- Indeksy dla tabeli `ps_module_shop`
--
ALTER TABLE `ps_module_shop`
  ADD PRIMARY KEY (`id_module`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_operating_system`
--
ALTER TABLE `ps_operating_system`
  ADD PRIMARY KEY (`id_operating_system`);

--
-- Indeksy dla tabeli `ps_orders`
--
ALTER TABLE `ps_orders`
  ADD PRIMARY KEY (`id_order`),
  ADD KEY `reference` (`reference`),
  ADD KEY `id_customer` (`id_customer`),
  ADD KEY `id_cart` (`id_cart`),
  ADD KEY `invoice_number` (`invoice_number`),
  ADD KEY `id_carrier` (`id_carrier`),
  ADD KEY `id_lang` (`id_lang`),
  ADD KEY `id_currency` (`id_currency`),
  ADD KEY `id_address_delivery` (`id_address_delivery`),
  ADD KEY `id_address_invoice` (`id_address_invoice`),
  ADD KEY `id_shop_group` (`id_shop_group`),
  ADD KEY `current_state` (`current_state`),
  ADD KEY `id_shop` (`id_shop`),
  ADD KEY `date_add` (`date_add`);

--
-- Indeksy dla tabeli `ps_order_carrier`
--
ALTER TABLE `ps_order_carrier`
  ADD PRIMARY KEY (`id_order_carrier`),
  ADD KEY `id_order` (`id_order`),
  ADD KEY `id_carrier` (`id_carrier`),
  ADD KEY `id_order_invoice` (`id_order_invoice`);

--
-- Indeksy dla tabeli `ps_order_cart_rule`
--
ALTER TABLE `ps_order_cart_rule`
  ADD PRIMARY KEY (`id_order_cart_rule`),
  ADD KEY `id_order` (`id_order`),
  ADD KEY `id_cart_rule` (`id_cart_rule`);

--
-- Indeksy dla tabeli `ps_order_detail`
--
ALTER TABLE `ps_order_detail`
  ADD PRIMARY KEY (`id_order_detail`),
  ADD KEY `order_detail_order` (`id_order`),
  ADD KEY `product_id` (`product_id`,`product_attribute_id`),
  ADD KEY `product_attribute_id` (`product_attribute_id`),
  ADD KEY `id_tax_rules_group` (`id_tax_rules_group`),
  ADD KEY `id_order_id_order_detail` (`id_order`,`id_order_detail`);

--
-- Indeksy dla tabeli `ps_order_detail_tax`
--
ALTER TABLE `ps_order_detail_tax`
  ADD KEY `id_order_detail` (`id_order_detail`),
  ADD KEY `id_tax` (`id_tax`);

--
-- Indeksy dla tabeli `ps_order_history`
--
ALTER TABLE `ps_order_history`
  ADD PRIMARY KEY (`id_order_history`),
  ADD KEY `order_history_order` (`id_order`),
  ADD KEY `id_employee` (`id_employee`),
  ADD KEY `id_order_state` (`id_order_state`);

--
-- Indeksy dla tabeli `ps_order_invoice`
--
ALTER TABLE `ps_order_invoice`
  ADD PRIMARY KEY (`id_order_invoice`),
  ADD KEY `id_order` (`id_order`);

--
-- Indeksy dla tabeli `ps_order_invoice_payment`
--
ALTER TABLE `ps_order_invoice_payment`
  ADD PRIMARY KEY (`id_order_invoice`,`id_order_payment`),
  ADD KEY `order_payment` (`id_order_payment`),
  ADD KEY `id_order` (`id_order`);

--
-- Indeksy dla tabeli `ps_order_invoice_tax`
--
ALTER TABLE `ps_order_invoice_tax`
  ADD KEY `id_tax` (`id_tax`);

--
-- Indeksy dla tabeli `ps_order_message`
--
ALTER TABLE `ps_order_message`
  ADD PRIMARY KEY (`id_order_message`);

--
-- Indeksy dla tabeli `ps_order_message_lang`
--
ALTER TABLE `ps_order_message_lang`
  ADD PRIMARY KEY (`id_order_message`,`id_lang`);

--
-- Indeksy dla tabeli `ps_order_payment`
--
ALTER TABLE `ps_order_payment`
  ADD PRIMARY KEY (`id_order_payment`),
  ADD KEY `order_reference` (`order_reference`);

--
-- Indeksy dla tabeli `ps_order_return`
--
ALTER TABLE `ps_order_return`
  ADD PRIMARY KEY (`id_order_return`),
  ADD KEY `order_return_customer` (`id_customer`),
  ADD KEY `id_order` (`id_order`);

--
-- Indeksy dla tabeli `ps_order_return_detail`
--
ALTER TABLE `ps_order_return_detail`
  ADD PRIMARY KEY (`id_order_return`,`id_order_detail`,`id_customization`);

--
-- Indeksy dla tabeli `ps_order_return_state`
--
ALTER TABLE `ps_order_return_state`
  ADD PRIMARY KEY (`id_order_return_state`);

--
-- Indeksy dla tabeli `ps_order_return_state_lang`
--
ALTER TABLE `ps_order_return_state_lang`
  ADD PRIMARY KEY (`id_order_return_state`,`id_lang`);

--
-- Indeksy dla tabeli `ps_order_slip`
--
ALTER TABLE `ps_order_slip`
  ADD PRIMARY KEY (`id_order_slip`),
  ADD KEY `order_slip_customer` (`id_customer`),
  ADD KEY `id_order` (`id_order`);

--
-- Indeksy dla tabeli `ps_order_slip_detail`
--
ALTER TABLE `ps_order_slip_detail`
  ADD PRIMARY KEY (`id_order_slip`,`id_order_detail`);

--
-- Indeksy dla tabeli `ps_order_state`
--
ALTER TABLE `ps_order_state`
  ADD PRIMARY KEY (`id_order_state`),
  ADD KEY `module_name` (`module_name`);

--
-- Indeksy dla tabeli `ps_order_state_lang`
--
ALTER TABLE `ps_order_state_lang`
  ADD PRIMARY KEY (`id_order_state`,`id_lang`);

--
-- Indeksy dla tabeli `ps_pack`
--
ALTER TABLE `ps_pack`
  ADD PRIMARY KEY (`id_product_pack`,`id_product_item`,`id_product_attribute_item`),
  ADD KEY `product_item` (`id_product_item`,`id_product_attribute_item`);

--
-- Indeksy dla tabeli `ps_page`
--
ALTER TABLE `ps_page`
  ADD PRIMARY KEY (`id_page`),
  ADD KEY `id_page_type` (`id_page_type`),
  ADD KEY `id_object` (`id_object`);

--
-- Indeksy dla tabeli `ps_pagenotfound`
--
ALTER TABLE `ps_pagenotfound`
  ADD PRIMARY KEY (`id_pagenotfound`),
  ADD KEY `date_add` (`date_add`);

--
-- Indeksy dla tabeli `ps_page_type`
--
ALTER TABLE `ps_page_type`
  ADD PRIMARY KEY (`id_page_type`),
  ADD KEY `name` (`name`);

--
-- Indeksy dla tabeli `ps_page_viewed`
--
ALTER TABLE `ps_page_viewed`
  ADD PRIMARY KEY (`id_page`,`id_date_range`,`id_shop`);

--
-- Indeksy dla tabeli `ps_product`
--
ALTER TABLE `ps_product`
  ADD PRIMARY KEY (`id_product`),
  ADD KEY `reference_idx` (`reference`),
  ADD KEY `supplier_reference_idx` (`supplier_reference`),
  ADD KEY `product_supplier` (`id_supplier`),
  ADD KEY `product_manufacturer` (`id_manufacturer`,`id_product`),
  ADD KEY `id_category_default` (`id_category_default`),
  ADD KEY `indexed` (`indexed`),
  ADD KEY `date_add` (`date_add`),
  ADD KEY `state` (`state`,`date_upd`);

--
-- Indeksy dla tabeli `ps_product_attachment`
--
ALTER TABLE `ps_product_attachment`
  ADD PRIMARY KEY (`id_product`,`id_attachment`);

--
-- Indeksy dla tabeli `ps_product_attribute`
--
ALTER TABLE `ps_product_attribute`
  ADD PRIMARY KEY (`id_product_attribute`),
  ADD UNIQUE KEY `product_default` (`id_product`,`default_on`),
  ADD KEY `product_attribute_product` (`id_product`),
  ADD KEY `reference` (`reference`),
  ADD KEY `supplier_reference` (`supplier_reference`),
  ADD KEY `id_product_id_product_attribute` (`id_product_attribute`,`id_product`);

--
-- Indeksy dla tabeli `ps_product_attribute_combination`
--
ALTER TABLE `ps_product_attribute_combination`
  ADD PRIMARY KEY (`id_attribute`,`id_product_attribute`),
  ADD KEY `id_product_attribute` (`id_product_attribute`);

--
-- Indeksy dla tabeli `ps_product_attribute_image`
--
ALTER TABLE `ps_product_attribute_image`
  ADD PRIMARY KEY (`id_product_attribute`,`id_image`),
  ADD KEY `id_image` (`id_image`);

--
-- Indeksy dla tabeli `ps_product_attribute_shop`
--
ALTER TABLE `ps_product_attribute_shop`
  ADD PRIMARY KEY (`id_product_attribute`,`id_shop`),
  ADD UNIQUE KEY `id_product` (`id_product`,`id_shop`,`default_on`);

--
-- Indeksy dla tabeli `ps_product_carrier`
--
ALTER TABLE `ps_product_carrier`
  ADD PRIMARY KEY (`id_product`,`id_carrier_reference`,`id_shop`);

--
-- Indeksy dla tabeli `ps_product_comment`
--
ALTER TABLE `ps_product_comment`
  ADD PRIMARY KEY (`id_product_comment`),
  ADD KEY `id_product` (`id_product`),
  ADD KEY `id_customer` (`id_customer`),
  ADD KEY `id_guest` (`id_guest`);

--
-- Indeksy dla tabeli `ps_product_comment_criterion`
--
ALTER TABLE `ps_product_comment_criterion`
  ADD PRIMARY KEY (`id_product_comment_criterion`);

--
-- Indeksy dla tabeli `ps_product_comment_criterion_category`
--
ALTER TABLE `ps_product_comment_criterion_category`
  ADD PRIMARY KEY (`id_product_comment_criterion`,`id_category`),
  ADD KEY `id_category` (`id_category`);

--
-- Indeksy dla tabeli `ps_product_comment_criterion_lang`
--
ALTER TABLE `ps_product_comment_criterion_lang`
  ADD PRIMARY KEY (`id_product_comment_criterion`,`id_lang`);

--
-- Indeksy dla tabeli `ps_product_comment_criterion_product`
--
ALTER TABLE `ps_product_comment_criterion_product`
  ADD PRIMARY KEY (`id_product`,`id_product_comment_criterion`),
  ADD KEY `id_product_comment_criterion` (`id_product_comment_criterion`);

--
-- Indeksy dla tabeli `ps_product_comment_grade`
--
ALTER TABLE `ps_product_comment_grade`
  ADD PRIMARY KEY (`id_product_comment`,`id_product_comment_criterion`),
  ADD KEY `id_product_comment_criterion` (`id_product_comment_criterion`);

--
-- Indeksy dla tabeli `ps_product_comment_report`
--
ALTER TABLE `ps_product_comment_report`
  ADD PRIMARY KEY (`id_product_comment`,`id_customer`);

--
-- Indeksy dla tabeli `ps_product_comment_usefulness`
--
ALTER TABLE `ps_product_comment_usefulness`
  ADD PRIMARY KEY (`id_product_comment`,`id_customer`);

--
-- Indeksy dla tabeli `ps_product_country_tax`
--
ALTER TABLE `ps_product_country_tax`
  ADD PRIMARY KEY (`id_product`,`id_country`);

--
-- Indeksy dla tabeli `ps_product_download`
--
ALTER TABLE `ps_product_download`
  ADD PRIMARY KEY (`id_product_download`);

--
-- Indeksy dla tabeli `ps_product_group_reduction_cache`
--
ALTER TABLE `ps_product_group_reduction_cache`
  ADD PRIMARY KEY (`id_product`,`id_group`);

--
-- Indeksy dla tabeli `ps_product_lang`
--
ALTER TABLE `ps_product_lang`
  ADD PRIMARY KEY (`id_product`,`id_shop`,`id_lang`),
  ADD KEY `id_lang` (`id_lang`),
  ADD KEY `name` (`name`);

--
-- Indeksy dla tabeli `ps_product_sale`
--
ALTER TABLE `ps_product_sale`
  ADD PRIMARY KEY (`id_product`),
  ADD KEY `quantity` (`quantity`);

--
-- Indeksy dla tabeli `ps_product_shop`
--
ALTER TABLE `ps_product_shop`
  ADD PRIMARY KEY (`id_product`,`id_shop`),
  ADD KEY `id_category_default` (`id_category_default`),
  ADD KEY `date_add` (`date_add`,`active`,`visibility`),
  ADD KEY `indexed` (`indexed`,`active`,`id_product`);

--
-- Indeksy dla tabeli `ps_product_supplier`
--
ALTER TABLE `ps_product_supplier`
  ADD PRIMARY KEY (`id_product_supplier`),
  ADD UNIQUE KEY `id_product` (`id_product`,`id_product_attribute`,`id_supplier`),
  ADD KEY `id_supplier` (`id_supplier`,`id_product`);

--
-- Indeksy dla tabeli `ps_product_tag`
--
ALTER TABLE `ps_product_tag`
  ADD PRIMARY KEY (`id_product`,`id_tag`),
  ADD KEY `id_tag` (`id_tag`),
  ADD KEY `id_lang` (`id_lang`,`id_tag`);

--
-- Indeksy dla tabeli `ps_profile`
--
ALTER TABLE `ps_profile`
  ADD PRIMARY KEY (`id_profile`);

--
-- Indeksy dla tabeli `ps_profile_lang`
--
ALTER TABLE `ps_profile_lang`
  ADD PRIMARY KEY (`id_profile`,`id_lang`);

--
-- Indeksy dla tabeli `ps_pscheckout_cart`
--
ALTER TABLE `ps_pscheckout_cart`
  ADD PRIMARY KEY (`id_pscheckout_cart`);

--
-- Indeksy dla tabeli `ps_pscheckout_funding_source`
--
ALTER TABLE `ps_pscheckout_funding_source`
  ADD PRIMARY KEY (`name`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_pscheckout_order_matrice`
--
ALTER TABLE `ps_pscheckout_order_matrice`
  ADD PRIMARY KEY (`id_order_matrice`);

--
-- Indeksy dla tabeli `ps_psgdpr_consent`
--
ALTER TABLE `ps_psgdpr_consent`
  ADD PRIMARY KEY (`id_gdpr_consent`,`id_module`);

--
-- Indeksy dla tabeli `ps_psgdpr_consent_lang`
--
ALTER TABLE `ps_psgdpr_consent_lang`
  ADD PRIMARY KEY (`id_gdpr_consent`,`id_lang`,`id_shop`);

--
-- Indeksy dla tabeli `ps_psgdpr_log`
--
ALTER TABLE `ps_psgdpr_log`
  ADD PRIMARY KEY (`id_gdpr_log`),
  ADD KEY `id_customer` (`id_customer`),
  ADD KEY `idx_id_customer` (`id_customer`,`id_guest`,`client_name`,`id_module`,`date_add`,`date_upd`);

--
-- Indeksy dla tabeli `ps_psreassurance`
--
ALTER TABLE `ps_psreassurance`
  ADD PRIMARY KEY (`id_psreassurance`);

--
-- Indeksy dla tabeli `ps_psreassurance_lang`
--
ALTER TABLE `ps_psreassurance_lang`
  ADD PRIMARY KEY (`id_psreassurance`,`id_shop`,`id_lang`);

--
-- Indeksy dla tabeli `ps_quick_access`
--
ALTER TABLE `ps_quick_access`
  ADD PRIMARY KEY (`id_quick_access`);

--
-- Indeksy dla tabeli `ps_quick_access_lang`
--
ALTER TABLE `ps_quick_access_lang`
  ADD PRIMARY KEY (`id_quick_access`,`id_lang`);

--
-- Indeksy dla tabeli `ps_range_price`
--
ALTER TABLE `ps_range_price`
  ADD PRIMARY KEY (`id_range_price`),
  ADD UNIQUE KEY `id_carrier` (`id_carrier`,`delimiter1`,`delimiter2`);

--
-- Indeksy dla tabeli `ps_range_weight`
--
ALTER TABLE `ps_range_weight`
  ADD PRIMARY KEY (`id_range_weight`),
  ADD UNIQUE KEY `id_carrier` (`id_carrier`,`delimiter1`,`delimiter2`);

--
-- Indeksy dla tabeli `ps_referrer`
--
ALTER TABLE `ps_referrer`
  ADD PRIMARY KEY (`id_referrer`);

--
-- Indeksy dla tabeli `ps_referrer_cache`
--
ALTER TABLE `ps_referrer_cache`
  ADD PRIMARY KEY (`id_connections_source`,`id_referrer`);

--
-- Indeksy dla tabeli `ps_referrer_shop`
--
ALTER TABLE `ps_referrer_shop`
  ADD PRIMARY KEY (`id_referrer`,`id_shop`);

--
-- Indeksy dla tabeli `ps_request_sql`
--
ALTER TABLE `ps_request_sql`
  ADD PRIMARY KEY (`id_request_sql`);

--
-- Indeksy dla tabeli `ps_required_field`
--
ALTER TABLE `ps_required_field`
  ADD PRIMARY KEY (`id_required_field`),
  ADD KEY `object_name` (`object_name`);

--
-- Indeksy dla tabeli `ps_risk`
--
ALTER TABLE `ps_risk`
  ADD PRIMARY KEY (`id_risk`);

--
-- Indeksy dla tabeli `ps_risk_lang`
--
ALTER TABLE `ps_risk_lang`
  ADD PRIMARY KEY (`id_risk`,`id_lang`),
  ADD KEY `id_risk` (`id_risk`);

--
-- Indeksy dla tabeli `ps_search_engine`
--
ALTER TABLE `ps_search_engine`
  ADD PRIMARY KEY (`id_search_engine`);

--
-- Indeksy dla tabeli `ps_search_index`
--
ALTER TABLE `ps_search_index`
  ADD PRIMARY KEY (`id_word`,`id_product`),
  ADD KEY `id_product` (`id_product`,`weight`);

--
-- Indeksy dla tabeli `ps_search_word`
--
ALTER TABLE `ps_search_word`
  ADD PRIMARY KEY (`id_word`),
  ADD UNIQUE KEY `id_lang` (`id_lang`,`id_shop`,`word`);

--
-- Indeksy dla tabeli `ps_shop`
--
ALTER TABLE `ps_shop`
  ADD PRIMARY KEY (`id_shop`),
  ADD KEY `IDX_CBDFBB9EF5C9E40` (`id_shop_group`);

--
-- Indeksy dla tabeli `ps_shop_group`
--
ALTER TABLE `ps_shop_group`
  ADD PRIMARY KEY (`id_shop_group`);

--
-- Indeksy dla tabeli `ps_shop_url`
--
ALTER TABLE `ps_shop_url`
  ADD PRIMARY KEY (`id_shop_url`),
  ADD KEY `IDX_279F19DA274A50A0` (`id_shop`);

--
-- Indeksy dla tabeli `ps_smarty_cache`
--
ALTER TABLE `ps_smarty_cache`
  ADD PRIMARY KEY (`id_smarty_cache`),
  ADD KEY `name` (`name`),
  ADD KEY `cache_id` (`cache_id`),
  ADD KEY `modified` (`modified`);

--
-- Indeksy dla tabeli `ps_smarty_last_flush`
--
ALTER TABLE `ps_smarty_last_flush`
  ADD PRIMARY KEY (`type`);

--
-- Indeksy dla tabeli `ps_smarty_lazy_cache`
--
ALTER TABLE `ps_smarty_lazy_cache`
  ADD PRIMARY KEY (`template_hash`,`cache_id`,`compile_id`);

--
-- Indeksy dla tabeli `ps_specific_price`
--
ALTER TABLE `ps_specific_price`
  ADD PRIMARY KEY (`id_specific_price`),
  ADD UNIQUE KEY `id_product_2` (`id_product`,`id_product_attribute`,`id_customer`,`id_cart`,`from`,`to`,`id_shop`,`id_shop_group`,`id_currency`,`id_country`,`id_group`,`from_quantity`,`id_specific_price_rule`),
  ADD KEY `id_product` (`id_product`,`id_shop`,`id_currency`,`id_country`,`id_group`,`id_customer`,`from_quantity`,`from`,`to`),
  ADD KEY `from_quantity` (`from_quantity`),
  ADD KEY `id_specific_price_rule` (`id_specific_price_rule`),
  ADD KEY `id_cart` (`id_cart`),
  ADD KEY `id_product_attribute` (`id_product_attribute`),
  ADD KEY `id_shop` (`id_shop`),
  ADD KEY `id_customer` (`id_customer`),
  ADD KEY `from` (`from`),
  ADD KEY `to` (`to`);

--
-- Indeksy dla tabeli `ps_specific_price_priority`
--
ALTER TABLE `ps_specific_price_priority`
  ADD PRIMARY KEY (`id_specific_price_priority`,`id_product`),
  ADD UNIQUE KEY `id_product` (`id_product`);

--
-- Indeksy dla tabeli `ps_specific_price_rule`
--
ALTER TABLE `ps_specific_price_rule`
  ADD PRIMARY KEY (`id_specific_price_rule`),
  ADD KEY `id_product` (`id_shop`,`id_currency`,`id_country`,`id_group`,`from_quantity`,`from`,`to`);

--
-- Indeksy dla tabeli `ps_specific_price_rule_condition`
--
ALTER TABLE `ps_specific_price_rule_condition`
  ADD PRIMARY KEY (`id_specific_price_rule_condition`),
  ADD KEY `id_specific_price_rule_condition_group` (`id_specific_price_rule_condition_group`);

--
-- Indeksy dla tabeli `ps_specific_price_rule_condition_group`
--
ALTER TABLE `ps_specific_price_rule_condition_group`
  ADD PRIMARY KEY (`id_specific_price_rule_condition_group`,`id_specific_price_rule`);

--
-- Indeksy dla tabeli `ps_state`
--
ALTER TABLE `ps_state`
  ADD PRIMARY KEY (`id_state`),
  ADD KEY `id_country` (`id_country`),
  ADD KEY `name` (`name`),
  ADD KEY `id_zone` (`id_zone`);

--
-- Indeksy dla tabeli `ps_statssearch`
--
ALTER TABLE `ps_statssearch`
  ADD PRIMARY KEY (`id_statssearch`);

--
-- Indeksy dla tabeli `ps_stock`
--
ALTER TABLE `ps_stock`
  ADD PRIMARY KEY (`id_stock`),
  ADD KEY `id_warehouse` (`id_warehouse`),
  ADD KEY `id_product` (`id_product`),
  ADD KEY `id_product_attribute` (`id_product_attribute`);

--
-- Indeksy dla tabeli `ps_stock_available`
--
ALTER TABLE `ps_stock_available`
  ADD PRIMARY KEY (`id_stock_available`),
  ADD UNIQUE KEY `product_sqlstock` (`id_product`,`id_product_attribute`,`id_shop`,`id_shop_group`),
  ADD KEY `id_shop` (`id_shop`),
  ADD KEY `id_shop_group` (`id_shop_group`),
  ADD KEY `id_product` (`id_product`),
  ADD KEY `id_product_attribute` (`id_product_attribute`);

--
-- Indeksy dla tabeli `ps_stock_mvt`
--
ALTER TABLE `ps_stock_mvt`
  ADD PRIMARY KEY (`id_stock_mvt`),
  ADD KEY `id_stock` (`id_stock`),
  ADD KEY `id_stock_mvt_reason` (`id_stock_mvt_reason`);

--
-- Indeksy dla tabeli `ps_stock_mvt_reason`
--
ALTER TABLE `ps_stock_mvt_reason`
  ADD PRIMARY KEY (`id_stock_mvt_reason`);

--
-- Indeksy dla tabeli `ps_stock_mvt_reason_lang`
--
ALTER TABLE `ps_stock_mvt_reason_lang`
  ADD PRIMARY KEY (`id_stock_mvt_reason`,`id_lang`);

--
-- Indeksy dla tabeli `ps_store`
--
ALTER TABLE `ps_store`
  ADD PRIMARY KEY (`id_store`);

--
-- Indeksy dla tabeli `ps_store_lang`
--
ALTER TABLE `ps_store_lang`
  ADD PRIMARY KEY (`id_store`,`id_lang`);

--
-- Indeksy dla tabeli `ps_store_shop`
--
ALTER TABLE `ps_store_shop`
  ADD PRIMARY KEY (`id_store`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_supplier`
--
ALTER TABLE `ps_supplier`
  ADD PRIMARY KEY (`id_supplier`);

--
-- Indeksy dla tabeli `ps_supplier_lang`
--
ALTER TABLE `ps_supplier_lang`
  ADD PRIMARY KEY (`id_supplier`,`id_lang`);

--
-- Indeksy dla tabeli `ps_supplier_shop`
--
ALTER TABLE `ps_supplier_shop`
  ADD PRIMARY KEY (`id_supplier`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_supply_order`
--
ALTER TABLE `ps_supply_order`
  ADD PRIMARY KEY (`id_supply_order`),
  ADD KEY `id_supplier` (`id_supplier`),
  ADD KEY `id_warehouse` (`id_warehouse`),
  ADD KEY `reference` (`reference`);

--
-- Indeksy dla tabeli `ps_supply_order_detail`
--
ALTER TABLE `ps_supply_order_detail`
  ADD PRIMARY KEY (`id_supply_order_detail`),
  ADD KEY `id_supply_order` (`id_supply_order`,`id_product`),
  ADD KEY `id_product_attribute` (`id_product_attribute`),
  ADD KEY `id_product_product_attribute` (`id_product`,`id_product_attribute`);

--
-- Indeksy dla tabeli `ps_supply_order_history`
--
ALTER TABLE `ps_supply_order_history`
  ADD PRIMARY KEY (`id_supply_order_history`),
  ADD KEY `id_supply_order` (`id_supply_order`),
  ADD KEY `id_employee` (`id_employee`),
  ADD KEY `id_state` (`id_state`);

--
-- Indeksy dla tabeli `ps_supply_order_receipt_history`
--
ALTER TABLE `ps_supply_order_receipt_history`
  ADD PRIMARY KEY (`id_supply_order_receipt_history`),
  ADD KEY `id_supply_order_detail` (`id_supply_order_detail`),
  ADD KEY `id_supply_order_state` (`id_supply_order_state`);

--
-- Indeksy dla tabeli `ps_supply_order_state`
--
ALTER TABLE `ps_supply_order_state`
  ADD PRIMARY KEY (`id_supply_order_state`);

--
-- Indeksy dla tabeli `ps_supply_order_state_lang`
--
ALTER TABLE `ps_supply_order_state_lang`
  ADD PRIMARY KEY (`id_supply_order_state`,`id_lang`);

--
-- Indeksy dla tabeli `ps_tab`
--
ALTER TABLE `ps_tab`
  ADD PRIMARY KEY (`id_tab`);

--
-- Indeksy dla tabeli `ps_tab_advice`
--
ALTER TABLE `ps_tab_advice`
  ADD PRIMARY KEY (`id_tab`,`id_advice`);

--
-- Indeksy dla tabeli `ps_tab_lang`
--
ALTER TABLE `ps_tab_lang`
  ADD PRIMARY KEY (`id_tab`,`id_lang`),
  ADD KEY `IDX_CFD9262DED47AB56` (`id_tab`),
  ADD KEY `IDX_CFD9262DBA299860` (`id_lang`);

--
-- Indeksy dla tabeli `ps_tab_module_preference`
--
ALTER TABLE `ps_tab_module_preference`
  ADD PRIMARY KEY (`id_tab_module_preference`),
  ADD UNIQUE KEY `employee_module` (`id_employee`,`id_tab`,`module`);

--
-- Indeksy dla tabeli `ps_tag`
--
ALTER TABLE `ps_tag`
  ADD PRIMARY KEY (`id_tag`),
  ADD KEY `tag_name` (`name`),
  ADD KEY `id_lang` (`id_lang`);

--
-- Indeksy dla tabeli `ps_tag_count`
--
ALTER TABLE `ps_tag_count`
  ADD PRIMARY KEY (`id_group`,`id_tag`),
  ADD KEY `id_group` (`id_group`,`id_lang`,`id_shop`,`counter`);

--
-- Indeksy dla tabeli `ps_tax`
--
ALTER TABLE `ps_tax`
  ADD PRIMARY KEY (`id_tax`);

--
-- Indeksy dla tabeli `ps_tax_lang`
--
ALTER TABLE `ps_tax_lang`
  ADD PRIMARY KEY (`id_tax`,`id_lang`);

--
-- Indeksy dla tabeli `ps_tax_rule`
--
ALTER TABLE `ps_tax_rule`
  ADD PRIMARY KEY (`id_tax_rule`),
  ADD KEY `id_tax_rules_group` (`id_tax_rules_group`),
  ADD KEY `id_tax` (`id_tax`),
  ADD KEY `category_getproducts` (`id_tax_rules_group`,`id_country`,`id_state`,`zipcode_from`);

--
-- Indeksy dla tabeli `ps_tax_rules_group`
--
ALTER TABLE `ps_tax_rules_group`
  ADD PRIMARY KEY (`id_tax_rules_group`);

--
-- Indeksy dla tabeli `ps_tax_rules_group_shop`
--
ALTER TABLE `ps_tax_rules_group_shop`
  ADD PRIMARY KEY (`id_tax_rules_group`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_timezone`
--
ALTER TABLE `ps_timezone`
  ADD PRIMARY KEY (`id_timezone`);

--
-- Indeksy dla tabeli `ps_translation`
--
ALTER TABLE `ps_translation`
  ADD PRIMARY KEY (`id_translation`),
  ADD KEY `IDX_ADEBEB36BA299860` (`id_lang`),
  ADD KEY `key` (`domain`);

--
-- Indeksy dla tabeli `ps_warehouse`
--
ALTER TABLE `ps_warehouse`
  ADD PRIMARY KEY (`id_warehouse`);

--
-- Indeksy dla tabeli `ps_warehouse_carrier`
--
ALTER TABLE `ps_warehouse_carrier`
  ADD PRIMARY KEY (`id_warehouse`,`id_carrier`),
  ADD KEY `id_warehouse` (`id_warehouse`),
  ADD KEY `id_carrier` (`id_carrier`);

--
-- Indeksy dla tabeli `ps_warehouse_product_location`
--
ALTER TABLE `ps_warehouse_product_location`
  ADD PRIMARY KEY (`id_warehouse_product_location`),
  ADD UNIQUE KEY `id_product` (`id_product`,`id_product_attribute`,`id_warehouse`);

--
-- Indeksy dla tabeli `ps_warehouse_shop`
--
ALTER TABLE `ps_warehouse_shop`
  ADD PRIMARY KEY (`id_warehouse`,`id_shop`),
  ADD KEY `id_warehouse` (`id_warehouse`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_webservice_account`
--
ALTER TABLE `ps_webservice_account`
  ADD PRIMARY KEY (`id_webservice_account`),
  ADD KEY `key` (`key`);

--
-- Indeksy dla tabeli `ps_webservice_account_shop`
--
ALTER TABLE `ps_webservice_account_shop`
  ADD PRIMARY KEY (`id_webservice_account`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- Indeksy dla tabeli `ps_webservice_permission`
--
ALTER TABLE `ps_webservice_permission`
  ADD PRIMARY KEY (`id_webservice_permission`),
  ADD UNIQUE KEY `resource_2` (`resource`,`method`,`id_webservice_account`),
  ADD KEY `resource` (`resource`),
  ADD KEY `method` (`method`),
  ADD KEY `id_webservice_account` (`id_webservice_account`);

--
-- Indeksy dla tabeli `ps_web_browser`
--
ALTER TABLE `ps_web_browser`
  ADD PRIMARY KEY (`id_web_browser`);

--
-- Indeksy dla tabeli `ps_wishlist`
--
ALTER TABLE `ps_wishlist`
  ADD PRIMARY KEY (`id_wishlist`);

--
-- Indeksy dla tabeli `ps_wishlist_product`
--
ALTER TABLE `ps_wishlist_product`
  ADD PRIMARY KEY (`id_wishlist_product`);

--
-- Indeksy dla tabeli `ps_zone`
--
ALTER TABLE `ps_zone`
  ADD PRIMARY KEY (`id_zone`);

--
-- Indeksy dla tabeli `ps_zone_shop`
--
ALTER TABLE `ps_zone_shop`
  ADD PRIMARY KEY (`id_zone`,`id_shop`),
  ADD KEY `id_shop` (`id_shop`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `ps_address`
--
ALTER TABLE `ps_address`
  MODIFY `id_address` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT dla tabeli `ps_admin_filter`
--
ALTER TABLE `ps_admin_filter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `ps_advice`
--
ALTER TABLE `ps_advice`
  MODIFY `id_advice` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_alias`
--
ALTER TABLE `ps_alias`
  MODIFY `id_alias` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `ps_attachment`
--
ALTER TABLE `ps_attachment`
  MODIFY `id_attachment` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_attachment_lang`
--
ALTER TABLE `ps_attachment_lang`
  MODIFY `id_attachment` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_attribute`
--
ALTER TABLE `ps_attribute`
  MODIFY `id_attribute` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT dla tabeli `ps_attribute_group`
--
ALTER TABLE `ps_attribute_group`
  MODIFY `id_attribute_group` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT dla tabeli `ps_attribute_impact`
--
ALTER TABLE `ps_attribute_impact`
  MODIFY `id_attribute_impact` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_authorization_role`
--
ALTER TABLE `ps_authorization_role`
  MODIFY `id_authorization_role` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=857;

--
-- AUTO_INCREMENT dla tabeli `ps_badge`
--
ALTER TABLE `ps_badge`
  MODIFY `id_badge` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;

--
-- AUTO_INCREMENT dla tabeli `ps_blockwishlist_statistics`
--
ALTER TABLE `ps_blockwishlist_statistics`
  MODIFY `id_statistics` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_carrier`
--
ALTER TABLE `ps_carrier`
  MODIFY `id_carrier` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `ps_cart`
--
ALTER TABLE `ps_cart`
  MODIFY `id_cart` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT dla tabeli `ps_cart_rule`
--
ALTER TABLE `ps_cart_rule`
  MODIFY `id_cart_rule` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_cart_rule_product_rule`
--
ALTER TABLE `ps_cart_rule_product_rule`
  MODIFY `id_product_rule` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_cart_rule_product_rule_group`
--
ALTER TABLE `ps_cart_rule_product_rule_group`
  MODIFY `id_product_rule_group` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_category`
--
ALTER TABLE `ps_category`
  MODIFY `id_category` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT dla tabeli `ps_cms`
--
ALTER TABLE `ps_cms`
  MODIFY `id_cms` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT dla tabeli `ps_cms_category`
--
ALTER TABLE `ps_cms_category`
  MODIFY `id_cms_category` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_cms_category_shop`
--
ALTER TABLE `ps_cms_category_shop`
  MODIFY `id_cms_category` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_cms_role`
--
ALTER TABLE `ps_cms_role`
  MODIFY `id_cms_role` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `ps_condition`
--
ALTER TABLE `ps_condition`
  MODIFY `id_condition` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=245;

--
-- AUTO_INCREMENT dla tabeli `ps_configuration`
--
ALTER TABLE `ps_configuration`
  MODIFY `id_configuration` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=449;

--
-- AUTO_INCREMENT dla tabeli `ps_configuration_kpi`
--
ALTER TABLE `ps_configuration_kpi`
  MODIFY `id_configuration_kpi` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT dla tabeli `ps_connections`
--
ALTER TABLE `ps_connections`
  MODIFY `id_connections` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT dla tabeli `ps_connections_source`
--
ALTER TABLE `ps_connections_source`
  MODIFY `id_connections_source` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_contact`
--
ALTER TABLE `ps_contact`
  MODIFY `id_contact` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `ps_country`
--
ALTER TABLE `ps_country`
  MODIFY `id_country` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=242;

--
-- AUTO_INCREMENT dla tabeli `ps_currency`
--
ALTER TABLE `ps_currency`
  MODIFY `id_currency` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_customer`
--
ALTER TABLE `ps_customer`
  MODIFY `id_customer` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `ps_customer_message`
--
ALTER TABLE `ps_customer_message`
  MODIFY `id_customer_message` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_customer_session`
--
ALTER TABLE `ps_customer_session`
  MODIFY `id_customer_session` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `ps_customer_thread`
--
ALTER TABLE `ps_customer_thread`
  MODIFY `id_customer_thread` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_customization`
--
ALTER TABLE `ps_customization`
  MODIFY `id_customization` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_customization_field`
--
ALTER TABLE `ps_customization_field`
  MODIFY `id_customization_field` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_date_range`
--
ALTER TABLE `ps_date_range`
  MODIFY `id_date_range` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_delivery`
--
ALTER TABLE `ps_delivery`
  MODIFY `id_delivery` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT dla tabeli `ps_emailsubscription`
--
ALTER TABLE `ps_emailsubscription`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_employee`
--
ALTER TABLE `ps_employee`
  MODIFY `id_employee` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_employee_session`
--
ALTER TABLE `ps_employee_session`
  MODIFY `id_employee_session` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `ps_feature`
--
ALTER TABLE `ps_feature`
  MODIFY `id_feature` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT dla tabeli `ps_feature_flag`
--
ALTER TABLE `ps_feature_flag`
  MODIFY `id_feature_flag` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_feature_value`
--
ALTER TABLE `ps_feature_value`
  MODIFY `id_feature_value` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT dla tabeli `ps_ganalytics`
--
ALTER TABLE `ps_ganalytics`
  MODIFY `id_google_analytics` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_gender`
--
ALTER TABLE `ps_gender`
  MODIFY `id_gender` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `ps_group`
--
ALTER TABLE `ps_group`
  MODIFY `id_group` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `ps_group_reduction`
--
ALTER TABLE `ps_group_reduction`
  MODIFY `id_group_reduction` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_guest`
--
ALTER TABLE `ps_guest`
  MODIFY `id_guest` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT dla tabeli `ps_homeslider`
--
ALTER TABLE `ps_homeslider`
  MODIFY `id_homeslider_slides` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `ps_homeslider_slides`
--
ALTER TABLE `ps_homeslider_slides`
  MODIFY `id_homeslider_slides` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `ps_hook`
--
ALTER TABLE `ps_hook`
  MODIFY `id_hook` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=771;

--
-- AUTO_INCREMENT dla tabeli `ps_hook_alias`
--
ALTER TABLE `ps_hook_alias`
  MODIFY `id_hook_alias` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT dla tabeli `ps_hook_module_exceptions`
--
ALTER TABLE `ps_hook_module_exceptions`
  MODIFY `id_hook_module_exceptions` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_image`
--
ALTER TABLE `ps_image`
  MODIFY `id_image` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT dla tabeli `ps_image_type`
--
ALTER TABLE `ps_image_type`
  MODIFY `id_image_type` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT dla tabeli `ps_import_match`
--
ALTER TABLE `ps_import_match`
  MODIFY `id_import_match` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_info`
--
ALTER TABLE `ps_info`
  MODIFY `id_info` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_lang`
--
ALTER TABLE `ps_lang`
  MODIFY `id_lang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_layered_category`
--
ALTER TABLE `ps_layered_category`
  MODIFY `id_layered_category` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT dla tabeli `ps_layered_filter`
--
ALTER TABLE `ps_layered_filter`
  MODIFY `id_layered_filter` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_linksmenutop`
--
ALTER TABLE `ps_linksmenutop`
  MODIFY `id_linksmenutop` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_link_block`
--
ALTER TABLE `ps_link_block`
  MODIFY `id_link_block` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `ps_link_block_shop`
--
ALTER TABLE `ps_link_block_shop`
  MODIFY `id_link_block` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `ps_log`
--
ALTER TABLE `ps_log`
  MODIFY `id_log` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=292;

--
-- AUTO_INCREMENT dla tabeli `ps_mail`
--
ALTER TABLE `ps_mail`
  MODIFY `id_mail` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `ps_manufacturer`
--
ALTER TABLE `ps_manufacturer`
  MODIFY `id_manufacturer` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `ps_memcached_servers`
--
ALTER TABLE `ps_memcached_servers`
  MODIFY `id_memcached_server` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_message`
--
ALTER TABLE `ps_message`
  MODIFY `id_message` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_meta`
--
ALTER TABLE `ps_meta`
  MODIFY `id_meta` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT dla tabeli `ps_module`
--
ALTER TABLE `ps_module`
  MODIFY `id_module` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT dla tabeli `ps_module_history`
--
ALTER TABLE `ps_module_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `ps_module_preference`
--
ALTER TABLE `ps_module_preference`
  MODIFY `id_module_preference` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_operating_system`
--
ALTER TABLE `ps_operating_system`
  MODIFY `id_operating_system` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT dla tabeli `ps_orders`
--
ALTER TABLE `ps_orders`
  MODIFY `id_order` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT dla tabeli `ps_order_carrier`
--
ALTER TABLE `ps_order_carrier`
  MODIFY `id_order_carrier` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT dla tabeli `ps_order_cart_rule`
--
ALTER TABLE `ps_order_cart_rule`
  MODIFY `id_order_cart_rule` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_order_detail`
--
ALTER TABLE `ps_order_detail`
  MODIFY `id_order_detail` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT dla tabeli `ps_order_history`
--
ALTER TABLE `ps_order_history`
  MODIFY `id_order_history` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT dla tabeli `ps_order_invoice`
--
ALTER TABLE `ps_order_invoice`
  MODIFY `id_order_invoice` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_order_message`
--
ALTER TABLE `ps_order_message`
  MODIFY `id_order_message` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_order_payment`
--
ALTER TABLE `ps_order_payment`
  MODIFY `id_order_payment` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_order_return`
--
ALTER TABLE `ps_order_return`
  MODIFY `id_order_return` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_order_return_state`
--
ALTER TABLE `ps_order_return_state`
  MODIFY `id_order_return_state` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT dla tabeli `ps_order_slip`
--
ALTER TABLE `ps_order_slip`
  MODIFY `id_order_slip` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_order_state`
--
ALTER TABLE `ps_order_state`
  MODIFY `id_order_state` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT dla tabeli `ps_page`
--
ALTER TABLE `ps_page`
  MODIFY `id_page` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_pagenotfound`
--
ALTER TABLE `ps_pagenotfound`
  MODIFY `id_pagenotfound` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_page_type`
--
ALTER TABLE `ps_page_type`
  MODIFY `id_page_type` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_product`
--
ALTER TABLE `ps_product`
  MODIFY `id_product` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT dla tabeli `ps_product_attribute`
--
ALTER TABLE `ps_product_attribute`
  MODIFY `id_product_attribute` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT dla tabeli `ps_product_comment`
--
ALTER TABLE `ps_product_comment`
  MODIFY `id_product_comment` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_product_comment_criterion`
--
ALTER TABLE `ps_product_comment_criterion`
  MODIFY `id_product_comment_criterion` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_product_download`
--
ALTER TABLE `ps_product_download`
  MODIFY `id_product_download` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_product_supplier`
--
ALTER TABLE `ps_product_supplier`
  MODIFY `id_product_supplier` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT dla tabeli `ps_profile`
--
ALTER TABLE `ps_profile`
  MODIFY `id_profile` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `ps_pscheckout_cart`
--
ALTER TABLE `ps_pscheckout_cart`
  MODIFY `id_pscheckout_cart` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_pscheckout_order_matrice`
--
ALTER TABLE `ps_pscheckout_order_matrice`
  MODIFY `id_order_matrice` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_psgdpr_consent`
--
ALTER TABLE `ps_psgdpr_consent`
  MODIFY `id_gdpr_consent` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_psgdpr_consent_lang`
--
ALTER TABLE `ps_psgdpr_consent_lang`
  MODIFY `id_gdpr_consent` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_psgdpr_log`
--
ALTER TABLE `ps_psgdpr_log`
  MODIFY `id_gdpr_log` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `ps_psreassurance`
--
ALTER TABLE `ps_psreassurance`
  MODIFY `id_psreassurance` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `ps_quick_access`
--
ALTER TABLE `ps_quick_access`
  MODIFY `id_quick_access` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT dla tabeli `ps_range_price`
--
ALTER TABLE `ps_range_price`
  MODIFY `id_range_price` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `ps_range_weight`
--
ALTER TABLE `ps_range_weight`
  MODIFY `id_range_weight` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `ps_referrer`
--
ALTER TABLE `ps_referrer`
  MODIFY `id_referrer` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_referrer_shop`
--
ALTER TABLE `ps_referrer_shop`
  MODIFY `id_referrer` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_request_sql`
--
ALTER TABLE `ps_request_sql`
  MODIFY `id_request_sql` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_required_field`
--
ALTER TABLE `ps_required_field`
  MODIFY `id_required_field` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_risk`
--
ALTER TABLE `ps_risk`
  MODIFY `id_risk` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `ps_search_engine`
--
ALTER TABLE `ps_search_engine`
  MODIFY `id_search_engine` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT dla tabeli `ps_search_word`
--
ALTER TABLE `ps_search_word`
  MODIFY `id_word` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37594;

--
-- AUTO_INCREMENT dla tabeli `ps_shop`
--
ALTER TABLE `ps_shop`
  MODIFY `id_shop` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_shop_group`
--
ALTER TABLE `ps_shop_group`
  MODIFY `id_shop_group` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_shop_url`
--
ALTER TABLE `ps_shop_url`
  MODIFY `id_shop_url` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_specific_price`
--
ALTER TABLE `ps_specific_price`
  MODIFY `id_specific_price` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `ps_specific_price_priority`
--
ALTER TABLE `ps_specific_price_priority`
  MODIFY `id_specific_price_priority` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_specific_price_rule`
--
ALTER TABLE `ps_specific_price_rule`
  MODIFY `id_specific_price_rule` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_specific_price_rule_condition`
--
ALTER TABLE `ps_specific_price_rule_condition`
  MODIFY `id_specific_price_rule_condition` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_specific_price_rule_condition_group`
--
ALTER TABLE `ps_specific_price_rule_condition_group`
  MODIFY `id_specific_price_rule_condition_group` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_state`
--
ALTER TABLE `ps_state`
  MODIFY `id_state` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=353;

--
-- AUTO_INCREMENT dla tabeli `ps_statssearch`
--
ALTER TABLE `ps_statssearch`
  MODIFY `id_statssearch` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_stock`
--
ALTER TABLE `ps_stock`
  MODIFY `id_stock` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_stock_available`
--
ALTER TABLE `ps_stock_available`
  MODIFY `id_stock_available` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=170;

--
-- AUTO_INCREMENT dla tabeli `ps_stock_mvt`
--
ALTER TABLE `ps_stock_mvt`
  MODIFY `id_stock_mvt` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_stock_mvt_reason`
--
ALTER TABLE `ps_stock_mvt_reason`
  MODIFY `id_stock_mvt_reason` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT dla tabeli `ps_store`
--
ALTER TABLE `ps_store`
  MODIFY `id_store` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT dla tabeli `ps_supplier`
--
ALTER TABLE `ps_supplier`
  MODIFY `id_supplier` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `ps_supply_order`
--
ALTER TABLE `ps_supply_order`
  MODIFY `id_supply_order` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_supply_order_detail`
--
ALTER TABLE `ps_supply_order_detail`
  MODIFY `id_supply_order_detail` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_supply_order_history`
--
ALTER TABLE `ps_supply_order_history`
  MODIFY `id_supply_order_history` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_supply_order_receipt_history`
--
ALTER TABLE `ps_supply_order_receipt_history`
  MODIFY `id_supply_order_receipt_history` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_supply_order_state`
--
ALTER TABLE `ps_supply_order_state`
  MODIFY `id_supply_order_state` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT dla tabeli `ps_tab`
--
ALTER TABLE `ps_tab`
  MODIFY `id_tab` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT dla tabeli `ps_tab_module_preference`
--
ALTER TABLE `ps_tab_module_preference`
  MODIFY `id_tab_module_preference` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_tag`
--
ALTER TABLE `ps_tag`
  MODIFY `id_tag` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_tax`
--
ALTER TABLE `ps_tax`
  MODIFY `id_tax` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT dla tabeli `ps_tax_rule`
--
ALTER TABLE `ps_tax_rule`
  MODIFY `id_tax_rule` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT dla tabeli `ps_tax_rules_group`
--
ALTER TABLE `ps_tax_rules_group`
  MODIFY `id_tax_rules_group` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT dla tabeli `ps_timezone`
--
ALTER TABLE `ps_timezone`
  MODIFY `id_timezone` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=561;

--
-- AUTO_INCREMENT dla tabeli `ps_translation`
--
ALTER TABLE `ps_translation`
  MODIFY `id_translation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT dla tabeli `ps_warehouse`
--
ALTER TABLE `ps_warehouse`
  MODIFY `id_warehouse` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_warehouse_product_location`
--
ALTER TABLE `ps_warehouse_product_location`
  MODIFY `id_warehouse_product_location` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_webservice_account`
--
ALTER TABLE `ps_webservice_account`
  MODIFY `id_webservice_account` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_webservice_permission`
--
ALTER TABLE `ps_webservice_permission`
  MODIFY `id_webservice_permission` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=346;

--
-- AUTO_INCREMENT dla tabeli `ps_web_browser`
--
ALTER TABLE `ps_web_browser`
  MODIFY `id_web_browser` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT dla tabeli `ps_wishlist`
--
ALTER TABLE `ps_wishlist`
  MODIFY `id_wishlist` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `ps_wishlist_product`
--
ALTER TABLE `ps_wishlist_product`
  MODIFY `id_wishlist_product` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `ps_zone`
--
ALTER TABLE `ps_zone`
  MODIFY `id_zone` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
